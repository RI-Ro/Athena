#!/usr/bin/env python3
"""Сквозная проверка ИР «Афина» на живом стенде.

Требуется: приложение запущено, в БД загружены backend/sql/900_testdata.sql.
    ATHENA_URL=https://localhost:8443 python3 tests/e2e/run.py
Необязательно: E2E_SMTP_PORT=2525 — поднять тестовый SMTP и проверить письма
(в config.yaml: email.enabled, smtp.host 127.0.0.1, port 2525, security none).

Каждая строка — утверждение «кто, что, на каком этапе → ожидаемый ответ».
Выход с кодом 1, если хотя бы одно не выполнено.
"""
import datetime, os, socket, sys, threading, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from api import *

OK = FAIL = 0
def check(label, cond, got=""):
    global OK, FAIL
    if cond: OK += 1
    else:
        FAIL += 1
        print(f"  НЕ ВЫПОЛНЕНО: {label} — получено {str(got)[:220]}")
def expect(label, res, code):
    codes = code if isinstance(code, (list, tuple)) else [code]
    check(f"{label} → {code}", res[0] in codes, res)
    return res
def section(t): print(f"== {t}")

NAMES = ["author1", "chief1", "exec1", "approver2", "crossdept1", "approver3", "finchief1", "outsider1",
         "signer1", "approver4", "duty1", "clerk1", "auditor1"]
T = {u: login(u) for u in NAMES}
ADMIN_PW = os.environ.get("ATHENA_ADMIN_PASSWORD", "Admin-12345")
T["admin"] = login("admin", ADMIN_PW)
U = {u: call("GET", "/api/me", t)[1]["user_id"] for u, t in T.items()}
DEP = {d["name"]: d["id"] for d in call("GET", "/api/departments", T["author1"])[1]["items"]}
D_DIG, D_FIN = DEP["Департамент цифровизации"], DEP["Департамент финансов"]
RECIPS = [{"user_id": U["duty1"], "department_id": D_DIG}, {"user_id": U["finchief1"], "department_id": D_FIN}]
PW = {}  # подпись подтверждается серверным ключом, пароль подписанта не нужен

def ap(user, step, kind="hierarchy"): return {"stage_type": kind, "approver_id": U[user], "step": step}
def stages(doc, who="author1"): return call("GET", f"/api/documents/{doc}/stages", T[who])[1]["items"]
def stage_of(doc, user): return next(s for s in stages(doc) if s["approver_id"] == U[user] and s["status"] in ("pending", "waiting_deps"))
def decide(doc, user, body, stage=None):
    sid = stage or stage_of(doc, user)["id"]
    return call("POST", f"/api/documents/{doc}/stages/{sid}/decide", T[user], body)
def card(doc, who="author1"): return call("GET", f"/api/documents/{doc}", T[who])
def status(doc): return card(doc)[1]["document"]["status"]
def steps_map(doc): return sorted((s["step_no"], next(n for n, i in U.items() if i == s["approver_id"]), s["status"]) for s in stages(doc))

# ---------------------------------------------------------------------------
section("1. Создание документа и номера шагов согласования")
expect("без роли «Автор»", create_doc(T["exec1"], "x", [], [U["signer1"]]), 403)
expect("администратор не автор", create_doc(T["admin"], "x", [], [U["signer1"]]), 403)
expect("не PDF", create_doc(T["author1"], "x", [], [U["signer1"]], file=b"MZ"), 400)
expect("нет подписанта", create_doc(T["author1"], "x", [], []), 400)
expect("согласующий без роли", create_doc(T["author1"], "x", [ap("outsider1", 1)], [U["signer1"]]), 400)
expect("сам себе согласующий", create_doc(T["author1"], "x", [ap("author1", 1)], [U["signer1"]]), 400)
expect("неверная дата", create_doc(T["author1"], "x", [], [U["signer1"]], extra={"due_date": "31.12.2026"}), 400)
for bad in ([1, 2, 2, 4], [2, 3], [1, 3], [0, 1], [1, 2, 2, 4, 5][:4]):
    users = ["chief1", "approver2", "approver4", "crossdept1"][:len(bad)]
    r = create_doc(T["author1"], "x", [ap(u, s, "cross_dept" if u == "crossdept1" else "hierarchy") for u, s in zip(users, bad)], [U["signer1"]])
    expect(f"номера шагов {bad} отклоняются", r, 400)

# Иванов-1, Петров-2, Сидоров-2, Курочкин-3 → chief1-1, approver2-2, crossdept1-2, approver4-3
c, r = create_doc(T["author1"], "Проверка: шаги 1-2-2-3", [ap("chief1", 1), ap("approver2", 2), ap("crossdept1", 2, "cross_dept"), ap("approver4", 3)],
                  [U["signer1"]], recipients=RECIPS)
check("документ с шагами 1-2-2-3 создан", c == 201, r); A = r["id"]
check("номера шагов 1,2,2,3,4(подпись)", [s[0] for s in steps_map(A)] == [1, 2, 2, 3, 4], steps_map(A))
check("активен только шаг 1", [(s[1], s[2]) for s in steps_map(A) if s[2] == "pending"] == [("chief1", "pending")], steps_map(A))
expect("шаг 2 не может решать раньше шага 1", decide(A, "approver2", {"approve": True}), [404, 409])
expect("шаг 3 не может решать раньше", decide(A, "approver4", {"approve": True}), [404, 409])
expect("подписант не видит документ до своей очереди", decide(A, "signer1", dict(PW, approve=True), stage=0), 404)
expect("посторонний не видит документ", card(A, "outsider1"), 404)
expect("chief1 согласует шаг 1", decide(A, "chief1", {"approve": True, "comment": "ок"}), 200)
check("после шага 1 активны оба этапа шага 2", sorted(s[1] for s in steps_map(A) if s[2] == "pending") == ["approver2", "crossdept1"], steps_map(A))
expect("approver2 согласует", decide(A, "approver2", {"approve": True}), 200)
check("шаг 3 ждёт второго согласующего шага 2", stage_of(A, "approver4")["status"] == "waiting_deps", steps_map(A))
expect("crossdept1 согласует", decide(A, "crossdept1", {"approve": True}), 200)
check("шаг 3 открылся", stage_of(A, "approver4")["status"] == "pending", steps_map(A))
expect("approver4 согласует", decide(A, "approver4", {"approve": True}), 200)
check("документ на подписи", status(A) == "on_signing", status(A))

section("2. Направление «перед собой» и «после себя» — номера остаются подряд")
c, r = create_doc(T["author1"], "Проверка: вставки в маршрут", [ap("chief1", 1), ap("approver2", 2), ap("crossdept1", 2, "cross_dept")], [U["signer1"]])
B = r["id"]
expect("chief1 согласует", decide(B, "chief1", {"approve": True}), 200)
expect("перед собой: автору — нельзя", decide(B, "approver2", {"approve": False, "add_approver_before": True, "add_approver_id": U["author1"]}), 400)
expect("перед собой: без роли — нельзя", decide(B, "approver2", {"approve": False, "add_approver_before": True, "add_approver_id": U["outsider1"]}), 400)
expect("перед собой: уже в маршруте — нельзя", decide(B, "approver2", {"approve": False, "add_approver_before": True, "add_approver_id": U["crossdept1"], "add_approver_stage_type": "cross_dept"}), 409)
expect("approver2 направляет перед собой approver4", decide(B, "approver2", {"approve": False, "add_approver_before": True, "add_approver_id": U["approver4"], "add_approver_stage_type": "hierarchy"}), 200)
m = steps_map(B)
check("после вставки «перед собой»: 1, 2(approver4), 2(crossdept1), 3(approver2), 4(подпись)",
      [(s[0], s[1]) for s in m] == [(1, "chief1"), (2, "approver4"), (2, "crossdept1"), (3, "approver2"), (4, "signer1")], m)
check("approver2 ждёт вставленного", stage_of(B, "approver2")["status"] == "waiting_deps", m)
expect("approver2 не может согласовать, пока не согласовал вставленный", decide(B, "approver2", {"approve": True}), 409)
expect("crossdept1 согласует и направляет «после себя» approver3", decide(B, "crossdept1", {"approve": True, "add_approver_id": U["approver3"], "add_approver_stage_type": "cross_dept"}), 200)
m = steps_map(B)
check("после вставки «после себя» номера подряд", sorted(set(s[0] for s in m)) == list(range(1, max(s[0] for s in m) + 1)), m)
check("approver3 на шаге 3 и активен", (3, "approver3", "pending") in m, m)
expect("approver4 согласует", decide(B, "approver4", {"approve": True}), 200)
expect("approver2 теперь согласует", decide(B, "approver2", {"approve": True}), 200)
check("подпись ждёт approver3", status(B) != "on_signing" or stage_of(B, "signer1")["status"] == "waiting_deps", steps_map(B))
expect("approver3 согласует", decide(B, "approver3", {"approve": True}), 200)
check("все согласовали — документ на подписи", status(B) == "on_signing", (status(B), steps_map(B)))

section("3. Отклонение, правка, новый круг")
c, r = create_doc(T["author1"], "Проверка: отклонение", [ap("chief1", 1), ap("approver2", 2)], [U["signer1"]]); C = r["id"]
expect("отклонение без причины", decide(C, "chief1", {"approve": False}), 400)
expect("отклонение с причиной", decide(C, "chief1", {"approve": False, "comment": "нет сроков"}), 200)
check("статус «отклонён»", status(C) == "rejected")
expect("решение по отклонённому", decide(C, "chief1", {"approve": True}, stage=stages(C)[0]["id"]), 409)
call("POST", "/api/notifications/read-all", T["chief1"])  # старые уведомления прочитаны
expect("автор правит карточку", call("PATCH", f"/api/documents/{C}", T["author1"], {"title": "Проверка: отклонение (исправлено)", "urgency": "normal", "category_id": 1}), 200)
check("согласование началось заново", status(C) == "on_approval_hierarchy" and stage_of(C, "chief1")["status"] == "pending", steps_map(C))
# «Сохранить» в окне правки — несколько запросов (карточка, маршрут, файл), и каждый
# заново запускал маршрут: согласующий получал «требуется ваше решение» по 2–3 раза.
call("PATCH", f"/api/documents/{C}/route", T["author1"], {"approvers": [ap("chief1", 1), ap("approver2", 2)], "signer_ids": [U["signer1"]]})
body, hh = multipart({}, PDF + b"%rev2\n")
call("PATCH", f"/api/documents/{C}/file", T["author1"], body, headers=hh)
UNREAD = lambda who, d: [n["kind"] for n in (call("GET", "/api/notifications?only_unread=true&limit=100", T[who])[1].get("items") or []) if n.get("document_id") == d and not n.get("is_read")]
check("после правки, маршрута и файла — одно уведомление «требуется решение», без дублей",
      UNREAD("chief1", C) == ["stage_pending"], UNREAD("chief1", C))
expect("чужой не может править", call("PATCH", f"/api/documents/{C}", T["chief1"], {"title": "x", "urgency": "normal", "category_id": 1}), [403, 409])
expect("автор удаляет неподписанный", call("DELETE", f"/api/documents/{C}", T["author1"]), 200)

section("4. Подпись серверным ключом, одна подпись из многих, проверка ПЭП")
sid = stage_of(A, "signer1")["id"]
expect("администратор не подписывает", call("POST", f"/api/documents/{A}/stages/{sid}/decide", T["admin"], dict(PW, approve=True)), [403, 404])
res = []
th = [threading.Thread(target=lambda: res.append(decide(A, "signer1", dict(PW, approve=True), stage=sid))) for _ in range(6)]
[t.start() for t in th]; [t.join() for t in th]
check("из 6 одновременных подписей прошла ровно одна", sorted(x[0] for x in res) == [200, 409, 409, 409, 409, 409], sorted(x[0] for x in res))
doc = card(A)[1]["document"]
check("присвоен исходящий номер, документ направлен плановым адресатам", doc["outgoing_number"] and doc["status"] == "sent", doc)
sg = call("GET", f"/api/documents/{A}/signatures", T["author1"])[1]["items"]
check("одна подпись, ПЭП проверена серверным секретом, файл цел", len(sg) == 1 and sg[0]["valid"] and sg[0]["key_match"] and sg[0]["file_intact"], sg)
body, hh = multipart({}, PDF + b"%tamper\n")
expect("замена файла после подписи", call("PATCH", f"/api/documents/{A}/file", T["author1"], body, headers=hh), 409)
expect("правка после подписи", call("PATCH", f"/api/documents/{A}", T["author1"], {"title": "x", "urgency": "normal", "category_id": 1}), 409)
expect("удаление подписанного автором", call("DELETE", f"/api/documents/{A}", T["author1"]), 403)
expect("удаление подписанного администратором", call("DELETE", f"/api/documents/{A}", T["admin"]), [403, 404])

section("5. Кэширование файла документа")
c, b, h = call("GET", f"/api/documents/{A}/file", T["author1"], raw=True)
etag = h.get("ETag")
check("файл отдаётся с ETag и запретом общего кэша", c == 200 and etag and "private" in (h.get("Cache-Control") or ""), (c, dict(h)))
c2, b2, _ = call("GET", f"/api/documents/{A}/file", T["author1"], headers={"If-None-Match": etag or "x"}, raw=True)
check("повторный запрос без изменений → 304 без тела", c2 == 304 and len(b2) == 0, (c2, len(b2)))
expect("посторонний не получает файл даже с ETag", call("GET", f"/api/documents/{A}/file", T["outsider1"], headers={"If-None-Match": etag or "x"}, raw=True)[:2], 404)

section("6. Номера без пропусков")
def out_no(n): return int(n.rsplit("-", 1)[1].split("/")[0])
first = out_no(doc["outgoing_number"])
ids = []
for i in range(6):
    c, r = create_doc(T["author1"], f"Проверка: нумерация {i}", [], [U["signer1"]], recipients=RECIPS); ids.append(r["id"])
# неудачные попытки подписи между удачными не должны «съедать» номера
for d in ids[:3]: decide(d, "exec1", {"approve": True}, stage=stage_of(d, "signer1")["id"])  # отказ: не назначенный подписант
th = [threading.Thread(target=lambda d=d: decide(d, "signer1", dict(PW, approve=True))) for d in ids]
[t.start() for t in th]; [t.join() for t in th]
nums = sorted(out_no(card(d)[1]["document"]["outgoing_number"]) for d in ids)
check("исходящие номера идут подряд, без пропусков и повторов", nums == list(range(first + 1, first + 7)), (first, nums))
def inc_no(who, d): return int(card(d, who)[1]["incoming_marking"]["incoming_number"].rsplit("-", 1)[1].split("/")[0])
th = [threading.Thread(target=lambda d=d: card(d, "duty1")) for d in ids + [A]]
[t.start() for t in th]; [t.join() for t in th]
inc = sorted(inc_no("duty1", d) for d in ids + [A])
check("входящие номера подразделения идут подряд", inc == list(range(inc[0], inc[0] + 7)), inc)
check("повторное открытие не меняет входящий номер", inc_no("duty1", A) == inc_no("duty1", A))

section("7. Доступ посторонних ко всем разделам документа")
subs = ["", "/file", "/marking", "/stages", "/execution", "/recipients", "/history", "/controllers", "/signatures", "/my-roles", "/copies",
        "/counts", "/prints", "/links", "/resolutions", "/versions", "/report", "/acquaintances", "/chat", "/print-diagnostics"]
for who in ("outsider1", "exec1", "auditor1", "admin"):
    bad = [s for s in subs if call("GET", f"/api/documents/{A}{s}", T[who], raw=True)[0] != 404]
    check(f"{who}: все {len(subs)} разделов документа закрыты", not bad, bad)
for path, m, b in [("/api/admin/users", "GET", None), ("/api/admin/users", "POST", {"login": "h", "password": "Qwerty-12345", "full_name": "h"}),
                   (f"/api/admin/users/{U['exec1']}/roles", "PATCH", {"department_id": 0, "roles": ["admin"]}),
                   ("/api/admin/auth-domains", "GET", None), ("/api/admin/settings/marking", "PUT", {"page_mode": "all"}), ("/api/admin/metrics", "GET", None)]:
    expect(f"не администратор: {m} {path}", call(m, path, T["exec1"], b), 403)
expect("аудит не аудитору — пусто", (200, len(call("GET", "/api/audit", T["exec1"])[1].get("items") or [])), 200)
check("аудит не аудитору — нет записей", not (call("GET", "/api/audit", T["exec1"])[1].get("items")))
check("аудитору журнал доступен", len(call("GET", "/api/audit", T["auditor1"])[1].get("items") or []) > 0)
expect("очистка журнала аудитором", call("DELETE", "/api/audit?from=2020-01-01&to=2020-01-02", T["auditor1"]), 403)
expect("без токена", call("GET", "/api/documents"), 401)
expect("поддельный токен", call("GET", "/api/me", "eyJhbGciOiJub25lIn0.eyJ1aWQiOjEsImlzX2FkbWluIjp0cnVlfQ."), 401)

section("8. Резолюции по экземплярам входящего документа")
due = (datetime.date.today() + datetime.timedelta(days=5)).isoformat()
R = lambda who, body, d=A: call("POST", f"/api/documents/{d}/resolutions", T[who], body)
RL = lambda who, d=A: call("GET", f"/api/documents/{d}/resolutions", T[who])[1]
expect("finchief1: документ ещё не зарегистрирован в его подразделении", R("finchief1", {"text": "x", "responsible_id": U["outsider1"]}), 409)
card(A, "finchief1")  # получатель открыл документ — присвоен входящий номер
expect("автор документа не накладывает резолюцию", R("author1", {"text": "x", "responsible_id": U["exec1"]}), 403)
expect("исполнитель чужого подразделения", R("finchief1", {"text": "x", "responsible_id": U["exec1"]}), 403)
expect("срок в прошлом", R("finchief1", {"text": "x", "responsible_id": U["outsider1"], "due_date": "2020-01-01"}), 422)
expect("контролёр без роли", R("finchief1", {"text": "x", "responsible_id": U["outsider1"], "controller_id": U["exec1"]}), 422)
check("кнопка «Наложить резолюцию» есть у документа БЕЗ резолюций (can_issue)", RL("finchief1").get("can_issue") is True, RL("finchief1"))
c, r = expect("finchief1 накладывает резолюцию на экземпляр своего подразделения", R("finchief1", {"text": "Подготовить расчёт", "responsible_id": U["outsider1"], "due_date": due, "controller_id": U["signer1"]}), 201)
RF = r.get("id")
expect("вторая резолюция на тот же экземпляр", R("finchief1", {"text": "y", "responsible_id": U["outsider1"]}), 409)
# Кандидаты в исполнители — ровно подразделения, выбранные в администрировании;
# не выбрано ничего — только своё подразделение (подчинённые сами не входят).
call("PATCH", f"/api/admin/users/{U['duty1']}/departments", T["admin"], {})  # повторный прогон: исходное состояние
CAND = lambda who: sorted(x["id"] for x in call("GET", "/api/users/candidates?group=resolution&q=&limit=100", T[who])[1].get("items", []))
check("duty1 без выбранных подразделений: исполнители только своего подразделения", CAND("duty1") == [U["approver2"]], CAND("duty1"))
expect("исполнитель из подчинённого, но не выбранного подразделения", R("duty1", {"text": "x", "responsible_id": U["exec1"]}), 403)
expect("администратор выбирает duty1 подразделения для резолюций: ДЦ и Отдел разработки",
       call("PATCH", f"/api/admin/users/{U['duty1']}/departments", T["admin"], {"resolution_departments": [2, 4]}), [200, 204])
check("теперь в списке ровно сотрудники выбранных подразделений", CAND("duty1") == sorted([U["approver2"], U["exec1"], U["chief1"], U["author1"]]), CAND("duty1"))
c, r = expect("duty1 накладывает СВОЮ резолюцию на экземпляр своего подразделения", R("duty1", {"text": "Организовать исполнение", "responsible_id": U["exec1"], "due_date": due}), 201)
RD = r.get("id")
vis = {w: sorted(x["id"] for x in RL(w)["items"]) for w in ("author1", "signer1", "finchief1", "outsider1", "duty1", "exec1", "chief1")}
check("автор документа не видит резолюций на входящих экземплярах", vis["author1"] == [], vis)
check("подразделение ФИН видит только свою резолюцию", vis["finchief1"] == [RF] and vis["outsider1"] == [RF], vis)
check("подразделение ДЦ видит только свою резолюцию", vis["duty1"] == [RD] and vis["exec1"] == [RD], vis)
check("контролёр резолюции ФИН видит её (и только её из чужих)", RF in vis["signer1"], vis)
check("исполнитель получил доступ к документу, посторонний — нет", card(A, "exec1")[0] == 200 and card(A, "clerk1")[0] == 404)
ACT = lambda who, rid, act, body=None: call("POST", f"/api/resolutions/{rid}/{act}", T[who], body or {})
expect("исполнитель другого подразделения отчитывается по чужой", ACT("exec1", RF, "report", {"report": "x"}), 404)
expect("чужой руководитель принимает чужую", ACT("duty1", RF, "accept"), 404)
# Изменение резолюции: только автор; текст и срок сохраняются; исполнитель видит её в «Ваших резолюциях».
expect("исполнитель не меняет текст резолюции", call("PUT", f"/api/resolutions/{RF}", T["outsider1"], {"text": "подмена"}), [403, 404])
expect("автор меняет текст и срок", call("PUT", f"/api/resolutions/{RF}", T["finchief1"], {"text": "Подготовить расчёт к пятнице", "due_date": due}), 200)
check("изменённый текст сохранён", any(x["id"] == RF and x["text"] == "Подготовить расчёт к пятнице" for x in RL("finchief1")["items"]), RL("finchief1"))
MY = call("GET", "/api/my/resolutions", T["outsider1"])[1]
check("резолюция в «Ваших резолюциях» исполнителя", RF in [x.get("id") or x.get("resolution_id") for x in (MY.get("items") or [])], str(MY)[:300])
expect("исполнитель берёт в работу", ACT("outsider1", RF, "progress"), 200)
expect("пустой отчёт", ACT("outsider1", RF, "report", {"report": " "}), 400)
expect("принять до отчёта", ACT("finchief1", RF, "accept"), 409)
expect("отчёт", ACT("outsider1", RF, "report", {"report": "Расчёт готов"}), 200)
expect("исполнитель сам принимает свой отчёт", ACT("outsider1", RF, "accept"), 403)
expect("администратор принимает", ACT("admin", RF, "accept"), 404)
expect("вернуть без пояснения", ACT("finchief1", RF, "return"), 400)
expect("вернуть на доработку", ACT("finchief1", RF, "return", {"note": "добавить сравнение"}), 200)
expect("повторный отчёт", ACT("outsider1", RF, "report", {"report": "Добавлено сравнение"}), 200)
expect("контролёр принимает отчёт", ACT("signer1", RF, "accept"), 200)
expect("отчёт после приёмки", ACT("outsider1", RF, "report", {"report": "перепишу"}), 409)
check("резолюция ФИН исполнена", RL("finchief1")["items"][0]["status"] == "done", RL("finchief1"))
# замена исполнителя и отзыв — на резолюции ДЦ
expect("замена исполнителя без причины", ACT("duty1", RD, "reassign", {"from_user_id": U["exec1"], "to_user_id": U["chief1"]}), 400)
expect("замена на сотрудника чужого подразделения", ACT("duty1", RD, "reassign", {"from_user_id": U["exec1"], "to_user_id": U["outsider1"], "reason": "болезнь"}), 403)
expect("замену делает не автор резолюции", ACT("finchief1", RD, "reassign", {"from_user_id": U["exec1"], "to_user_id": U["chief1"], "reason": "x"}), 404)
expect("замена исполнителя", ACT("duty1", RD, "reassign", {"from_user_id": U["exec1"], "to_user_id": U["chief1"], "reason": "болезнь"}), 200)
ex = {e["user_id"]: (e["status"], e["is_responsible"]) for e in RL("duty1")["items"][0]["executors"]}
check("прежний снят, новый — ответственный", ex.get(U["exec1"], ("",))[0] == "cancelled" and ex.get(U["chief1"]) == ("open", True), ex)
expect("снятый исполнитель не отчитывается", ACT("exec1", RD, "report", {"report": "x"}), [403, 404])
expect("отзыв без причины", ACT("duty1", RD, "cancel"), 400)
expect("отзыв чужой резолюции", ACT("finchief1", RD, "cancel", {"reason": "x"}), 404)
expect("отзыв резолюции", ACT("duty1", RD, "cancel", {"reason": "наложена по ошибке"}), 200)
expect("действие по отозванной", ACT("chief1", RD, "report", {"report": "x"}), [403, 404, 409])
c, r = expect("после отзыва можно наложить новую на тот же экземпляр", R("duty1", {"text": "Исполнить в срок", "responsible_id": U["exec1"]}), 201)
c, r2 = create_doc(T["author1"], "Проверка: резолюция до подписи", [ap("chief1", 1)], [U["signer1"]]); N = r2["id"]
expect("резолюция на неподписанный документ", R("chief1", {"text": "x", "responsible_id": U["exec1"]}, N), [403, 409])

section("9. Рассылка, ознакомление, исполнение, архив")
expect("не автор и не подписант рассылает", call("POST", f"/api/documents/{ids[0]}/send", T["chief1"], {"recipients": RECIPS[:1]}), 403)
expect("получатель без роли канцелярии", call("POST", f"/api/documents/{ids[0]}/send", T["author1"], {"recipients": [{"user_id": U["exec1"], "department_id": DEP["Отдел разработки"]}]}), 400)
expect("ознакомление без права", call("POST", f"/api/documents/{A}/acquaint", T["author1"], {"user_ids": [U["exec1"]]}), 403)
# Кандидаты на ознакомление — ровно назначенные подразделения; не назначено — своё.
call("PATCH", f"/api/admin/users/{U['clerk1']}/departments", T["admin"], {})
ACQ = lambda who: sorted(x["id"] for x in (call("GET", "/api/acquaint-candidates?q=", T[who])[1].get("items") or []))
check("clerk1 (Главное управление) без назначений: только своё подразделение, без подчинённых",
      ACQ("clerk1") == sorted([U["auditor1"], U["signer1"], U["approver4"]]), ACQ("clerk1"))
expect("администратор назначает clerk1 для ознакомления Департамент финансов",
       call("PATCH", f"/api/admin/users/{U['clerk1']}/departments", T["admin"], {"acquaint_departments": [DEP["Департамент финансов"]]}), [200, 204])
check("теперь только сотрудники Департамента финансов", ACQ("clerk1") == sorted([U["outsider1"], U["finchief1"], U["crossdept1"], U["approver3"]]), ACQ("clerk1"))
expect("ознакомить сотрудника вне назначенных подразделений нельзя",
       call("POST", f"/api/documents/{ids[0]}/acquaint", T["clerk1"], {"user_ids": [U["exec1"]]}), [403, 404])
expect("чужое сообщение нельзя изменить", (lambda: (
    call("POST", f"/api/documents/{A}/chat", T["exec1"], *[x for x in [multipart({"text": "принято"})[0]]], headers=multipart({})[1]),
    call("PATCH", f"/api/chat/messages/{(call('GET', f'/api/documents/{A}/chat', T['exec1'])[1]['items'] or [{'id': 0}])[-1]['id']}", T["duty1"], {"text": "подмена"}))[1])(), 403)
expect("отметка об исполнении не адресатом", call("POST", f"/api/documents/{ids[0]}/complete", T["author1"], {"note": "готово"}), 403)
expect("отметка без отчёта", call("POST", f"/api/documents/{ids[0]}/complete", T["duty1"], {}), 400)
card(ids[0], "finchief1")
expect("отметка адресата ДЦ", call("POST", f"/api/documents/{ids[0]}/complete", T["duty1"], {"note": "исполнено"}), 200)
expect("отметка адресата ФИН", call("POST", f"/api/documents/{ids[0]}/complete", T["finchief1"], {"note": "исполнено"}), 200)
check("документ исполнен", status(ids[0]) == "executed", status(ids[0]))
expect("архив не автором", call("POST", f"/api/documents/{ids[0]}/archive", T["duty1"]), 403)
expect("архив автором", call("POST", f"/api/documents/{ids[0]}/archive", T["author1"]), 200)
expect("изменения в архивном документе", call("POST", f"/api/documents/{ids[0]}/complete", T["duty1"], {"note": "ещё"}), 409)

section("10. Сессии и вход")
t2 = login("exec1")
check("новый вход вытесняет прежний сеанс", call("GET", "/api/me", T["exec1"])[0] == 401 and call("GET", "/api/me", t2)[0] == 200)
old = t2.copy()
expect("выход без CSRF-заголовка отклонён", call("POST", "/api/auth/logout", t2, csrf=False), 403)
expect("выход", call("POST", "/api/auth/logout", t2), 200)
check("после выхода cookie сеанса удалена из браузера", not t2.session_value)
expect("старая cookie после выхода не действует", call("GET", "/api/me", old), 401)

section("10a. Защищённая cookie сеанса")
s3, body = login("clerk1", raw=True)
sc = next((h for h in s3.set_cookie_headers if "athena_session=" in h), "")
low = sc.lower()
check("токена нет в ответе на вход", "token" not in body, list(body))
check("cookie сеанса HttpOnly", "httponly" in low, sc)
check("cookie сеанса SameSite=Strict", "samesite=strict" in low, sc)
if BASE.startswith("https"):
    check("по HTTPS cookie Secure и с префиксом __Host-", "secure" in low and sc.startswith("__Host-"), sc)
csrf_sc = next((h for h in s3.set_cookie_headers if h.startswith("athena_csrf=")), "")
check("CSRF-cookie доступна интерфейсу (не HttpOnly)", csrf_sc and "httponly" not in csrf_sc.lower(), csrf_sc)
expect("чтение с cookie", call("GET", "/api/me", s3), 200)
expect("изменение без CSRF-заголовка", call("PUT", "/api/preferences/ui.perf", s3, {"mode": "auto"}, csrf=False), 403)
expect("изменение с чужим CSRF-значением", call("PUT", "/api/preferences/ui.perf", s3, {"mode": "auto"}, csrf=False, headers={"X-CSRF-Token": "x" * 43}), 403)
expect("изменение с CSRF-заголовком", call("PUT", "/api/preferences/ui.perf", s3, {"mode": "auto"}), [200, 204])
expect("запрос со страницы чужого сайта", call("PUT", "/api/preferences/ui.perf", s3, {"mode": "lite"}, headers={"Origin": "https://evil.example"}), 403)
expect("токен в заголовке Authorization не принимается",
       call("GET", "/api/me", None, headers={"Authorization": "Bearer " + s3.session_value}), 401)
expect("продление сеанса", call("POST", "/api/auth/refresh", s3), 200)
expect("сеанс после продления", call("GET", "/api/me", s3), 200)
# Логин заведомо несуществующий: блокировка не должна мешать повторному запуску проверок.
ghost = f"ghost-{int(time.time())}"
codes = [call("POST", "/api/auth/login", body={"login": ghost, "password": f"bad{i}"})[0] for i in range(7)]
check("после 5 неверных паролей вход закрывается", codes[:5] == [401] * 5 and codes[5:] == [429, 429], codes)
expect("другой пользователь не затронут", call("POST", "/api/auth/login", body={"login": "clerk1", "password": "password123"}), 200)
expect("метрики без токена извне закрыты либо локальны", (call("GET", "/metrics", raw=True)[0], ""), [200, 401, 403])

section("10b. Сводная панель руководителя")
c, dsh = call("GET", "/api/dashboard?period=90", T["signer1"])
expect("сводка строится", (c, dsh), 200)
need = ["kpi", "timing", "status", "trend", "bottlenecks", "approver_speed", "departments", "resolutions",
        "executors", "categories", "special_marks", "overdue", "upcoming", "stalled"]
check("в сводке все блоки", all(k in dsh for k in need), [k for k in need if k not in dsh])
c, dso = call("GET", "/api/dashboard?period=90", T["outsider1"])
check("постороннему — только его документы (меньше, чем подписанту)", dso["kpi"]["active"] < dsh["kpi"]["active"],
      (dso["kpi"]["active"], dsh["kpi"]["active"]))
ids = {r["document_id"] for k in ("overdue", "upcoming", "stalled") for r in dso[k]}
bad = [i for i in ids if call("GET", f"/api/documents/{i}", T["outsider1"])[0] != 200]
check("каждый документ из сводки открывается этим пользователем", not bad, bad)
ids = {r["document_id"] for k in ("overdue", "upcoming", "stalled") for r in dsh[k]}
bad = [i for i in list(ids)[:25] if call("GET", f"/api/documents/{i}", T["signer1"])[0] != 200]
check("сводка подписанта — тоже только доступные ему", not bad, bad)
for q in ("period=7", "period=30", "period=180", "period=365", "period=ytd", "period=90&mark=1", f"period=90&department={DEP['Департамент финансов']}"):
    expect(f"сводка: {q}", call("GET", "/api/dashboard?" + q, T["signer1"]), 200)
expect("сводка: неизвестный период", call("GET", "/api/dashboard?period=1000", T["signer1"]), 400)
expect("сводка без сеанса", call("GET", "/api/dashboard"), 401)
lay = {"period": "30", "order": ["trend", "kpi"], "hidden": ["urgency"], "wide": {"overdue": True}}
expect("настройка панели сохраняется", call("PUT", "/api/preferences/ui.dashboard", T["signer1"], lay), 200)
check("настройка панели читается обратно", call("GET", "/api/preferences/ui.dashboard", T["signer1"])[1] == lay)
check("у другого пользователя своя настройка", call("GET", "/api/preferences/ui.dashboard", T["chief1"])[1] != lay)

section("12. Видимость документа по этапам (никто не видит раньше своей очереди)")
# Контролёр — сотрудник, которому администратор выдаёт роль «контролёр».
expect("роль контролёра для проверки", call("PATCH", f"/api/admin/users/{U['outsider1']}/roles", T["admin"],
       {"department_id": D_FIN, "roles": ["executor", "controller"]}), [200, 204])
ALL = ["chief1", "approver2", "approver4", "signer1", "outsider1", "duty1", "finchief1", "exec1", "clerk1", "auditor1", "crossdept1"]
def sees(doc): return {u for u in ALL if call("GET", f"/api/documents/{doc}", T[u])[0] == 200}
def in_list(u, cat, doc):
    items = call("GET", f"/api/documents?category={cat}&page_size=100", T[u])[1].get("items") or []
    return any(x["id"] == doc for x in items)
def notified(u, doc, kind=None):
    items = call("GET", "/api/notifications?limit=200", T[u])[1].get("items") or []
    return any(x.get("document_id") == doc and (kind is None or x["kind"] == kind) for x in items)
c, r = create_doc(T["author1"], "Проверка: видимость по этапам", [ap("chief1", 1), ap("approver2", 2), ap("approver4", 3)],
                  [U["signer1"]], recipients=[{"user_id": U["duty1"], "department_id": D_DIG}])
V = r["id"]
expect("на контроль до подписания", call("POST", f"/api/documents/{V}/control", T["author1"],
       {"on_control": True, "controller_ids": [U["outsider1"]]}), 200)
check("шаг 1: видят только автор и согласующий шага 1", sees(V) == {"chief1"}, sees(V))
check("руководитель по области (подписант с ролью руководителя) не видит проект", "signer1" not in sees(V))
check("контролёр не видит и не уведомлён до подписания", "outsider1" not in sees(V) and not notified("outsider1", V))
check("согласующий шага 2 не уведомлён и не видит в «На согласовании»", not notified("approver2", V) and not in_list("approver2", "on_approval", V))
check("автор видит документ в «На согласовании»", in_list("author1", "on_approval", V))
check("согласующий шага 1 видит в «На согласовании»", in_list("chief1", "on_approval", V))
expect("шаг 1 согласован", decide(V, "chief1", {"approve": True}), 200)
check("шаг 2: открылся согласующему шага 2, шаг 3 — нет", sees(V) == {"chief1", "approver2"}, sees(V))
check("у согласовавшего документ ушёл из «На согласовании»", not in_list("chief1", "on_approval", V))
check("согласующий шага 2 уведомлён", notified("approver2", V, "stage_pending"))
expect("шаг 2 согласован", decide(V, "approver2", {"approve": True}), 200)
check("шаг 3: открылся согласующему шага 3, подписанту — нет", sees(V) == {"chief1", "approver2", "approver4"}, sees(V))
expect("шаг 3 отклоняет", decide(V, "approver4", {"approve": False, "comment": "доработать"}), 200)
expect("автор правит и отправляет заново", call("PATCH", f"/api/documents/{V}", T["author1"],
       {"title": "Проверка: видимость по этапам (новый круг)", "urgency": "normal", "category_id": 1}), 200)
check("новый круг: прежние согласующие шагов 2–3 больше не видят промежуточный вариант", sees(V) == {"chief1"}, sees(V))
for u in ("chief1", "approver2", "approver4"):
    expect(f"новый круг: {u} согласует", decide(V, u, {"approve": True}), 200)
check("подпись: подписант видит только после всех согласований", "signer1" in sees(V))
check("подписант видит документ в «На подписи»", in_list("signer1", "on_signing", V))
check("адресат и контролёр до подписания не видят", not ({"duty1", "outsider1"} & sees(V)), sees(V))
expect("подписано", decide(V, "signer1", {"approve": True}), 200)
check("после подписи: контролёр видит и уведомлён", "outsider1" in sees(V) and notified("outsider1", V, "control_assigned"))
check("после подписи: адресат видит", "duty1" in sees(V))
check("посторонние так и не видят", not ({"finchief1", "exec1", "clerk1", "auditor1", "crossdept1"} & sees(V)), sees(V))
c, dsh_o = call("GET", "/api/dashboard?period=7", T["outsider1"])
ids = {x["document_id"] for k in ("overdue", "upcoming", "stalled") for x in dsh_o[k]}
bad = [i for i in ids if call("GET", f"/api/documents/{i}", T["outsider1"])[0] != 200]
check("сводка контролёра — только доступные ему документы", not bad, bad)
# Журналы: руководитель видит журналы подчинённых подразделений, посторонний — нет.
out_s = call("GET", "/api/registry/outgoing", T["signer1"])[1]
check("журнал исходящих руководителя по области не пуст", out_s.get("total_count", 0) > 0, out_s.get("total_count"))
check("в журнале — только доступные ему документы",
      all(call("GET", f"/api/documents/{x['id']}", T["signer1"])[0] == 200 for x in (out_s.get("items") or [])[:20]))
inc_d = call("GET", "/api/registry/incoming", T["duty1"])[1]
check("журнал входящих канцелярии подразделения не пуст", inc_d.get("total_count", 0) > 0)
expect("выгрузка журнала отключена", call("GET", "/api/registry/outgoing/export", T["signer1"], raw=True)[:1] + ("",), 403)

# ---------------------------------------------------------------------------
smtp_port = int(os.environ.get("E2E_SMTP_PORT", "0"))
if smtp_port:
    section("11. Письма адресатам о новом входящем документе")
    got = []
    def smtp_server():
        srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); srv.bind(("127.0.0.1", smtp_port)); srv.listen(5); srv.settimeout(60)
        try:
            while True:
                conn, _ = srv.accept(); f = conn.makefile("rwb"); f.write(b"220 test ESMTP\r\n"); f.flush(); data = False; msg = b""
                while True:
                    line = f.readline()
                    if not line: break
                    if data:
                        if line == b".\r\n": got.append(msg.decode("utf-8", "replace")); data = False; f.write(b"250 ok\r\n"); f.flush(); continue
                        msg += line; continue
                    cmd = line[:4].upper()
                    if cmd == b"EHLO": f.write(b"250 test\r\n")
                    elif cmd == b"DATA": data = True; msg = b""; f.write(b"354 go\r\n")
                    elif cmd == b"QUIT": f.write(b"221 bye\r\n"); f.flush(); break
                    else: f.write(b"250 ok\r\n")
                    f.flush()
                conn.close()
        except Exception: pass
    threading.Thread(target=smtp_server, daemon=True).start()
    c, r = create_doc(T["author1"], "О предоставлении сведений", [], [U["signer1"]], recipients=RECIPS); M = r["id"]
    expect("подпись (рассылка плановым адресатам)", decide(M, "signer1", dict(PW, approve=True)), 200)
    for _ in range(50):
        if len([m for m in got if "О предоставлении сведений" in m or "=?utf-8?" in m]) >= 2: break
        time.sleep(1)
    mine = [m for m in got if f"/document/{M}" in m]
    check("письма ушли обоим адресатам", len(mine) == 2, (len(got), [m[:150] for m in got]))
    if mine:
        check("в письме наименование, ссылка и пометка об автоматической отправке",
              "О предоставлении сведений" in mine[0] and f"/document/{M}" in mine[0] and "автоматически" in mine[0], mine[0][:600])

print(f"\nИтог: выполнено {OK}, не выполнено {FAIL}")
sys.exit(1 if FAIL else 0)
