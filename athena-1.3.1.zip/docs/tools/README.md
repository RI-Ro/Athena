# Сборка инструкции пользователя

* `../user-guide.html` — исходный текст; `../user-guide.pdf` печатается из него Chrome:
  `google-chrome --headless=new --no-pdf-header-footer --print-to-pdf=user-guide.pdf user-guide.html`
* `../user-guide.docx` — та же инструкция в Word для самостоятельной правки. Собирается так:
  `python3 parse.py ../user-guide.html && node gen.js && cp user-guide.docx ..`
  (нужны Python с beautifulsoup4 и Node.js с пакетом `docx`).

Если правите DOCX вручную, имейте в виду: повторная сборка из HTML его перезапишет.
