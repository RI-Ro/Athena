import json,sys
from bs4 import BeautifulSoup, NavigableString
soup=BeautifulSoup(open(sys.argv[1],encoding='utf-8').read(),'html.parser')
def runs(el,bold=False):
    out=[]
    for c in el.children:
        if isinstance(c,NavigableString):
            t=str(c).replace('\n',' ')
            if t: out.append({"t":t,"b":bold})
        elif c.name=='b' or c.name=='strong': out+=runs(c,True)
        elif c.name=='span' and 'btn' in (c.get('class') or []): out.append({"t":c.get_text(),"btn":True})
        elif c.name=='code': out.append({"t":c.get_text(),"code":True})
        elif c.name=='br': out.append({"br":True})
        else: out+=runs(c,bold)
    # normalize spaces
    return out
blocks=[]
for el in soup.body.children:
    if isinstance(el,NavigableString): continue
    cls=el.get('class') or []
    if 'cover' in cls:
        blocks.append({"k":"cover","title":el.h1.get_text(),"sub":[s.strip() for s in el.select_one('.sub').stripped_strings]})
    elif el.name in('h1','h2','h3'): blocks.append({"k":el.name,"r":runs(el)})
    elif el.name=='p': blocks.append({"k":"p","r":runs(el)})
    elif el.name in('ul','ol'): blocks.append({"k":"ol" if el.name=='ol' else "ul","items":[runs(li) for li in el.find_all('li',recursive=False)]})
    elif el.name=='table':
        rows=[]
        for tr in el.find_all('tr'):
            rows.append({"h":tr.find('th') is not None,"c":[runs(td) for td in tr.find_all(['td','th'])]})
        blocks.append({"k":"table","rows":rows})
    elif 'toc' in cls: blocks.append({"k":"toc","items":[d.get_text() for d in el.find_all('div')]})
    elif 'flow' in cls: blocks.append({"k":"flow","items":[[d.b.get_text(), d.get_text()[len(d.b.get_text()):]] for d in el.find_all('div',recursive=False)]})
    elif 'note' in cls or 'tip' in cls or 'warn' in cls: blocks.append({"k":"note" if 'note' in cls else "tip","r":runs(el)})
    else: blocks.append({"k":"p","r":runs(el)})
json.dump(blocks,open('blocks.json','w'),ensure_ascii=False,indent=0)
print(len(blocks), {b['k'] for b in blocks})
