// Package mailer — письма адресатам о новом входящем документе.
//
// Письмо ставится в очередь (таблица email_outbox) в той же транзакции, что
// и рассылка документа, а отправляет его фоновая задача. Поэтому:
//   - недоступный почтовый сервер не задерживает и не ломает рассылку;
//   - письмо не уйдёт по документу, рассылка которого откатилась;
//   - очередь переживает перезапуск и общая для всех рабочих процессов.
//
// Тема и текст задаются шаблонами в конфигурации (email.new_document).
package mailer

import (
	"bytes"
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"log"
	"mime"
	"net"
	"net/mail"
	"net/smtp"
	"strconv"
	"strings"
	"text/template"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/config"
)

// NewDocumentData — параметры, доступные в шаблонах темы и текста письма.
type NewDocumentData struct {
	ID            int64  // идентификатор документа (для своей ссылки)
	Title         string // наименование указания
	Number        string // исходящий номер
	URL           string // ссылка на карточку документа
	RecipientName string // ФИО адресата
	AuthorName    string // ФИО автора
	Department    string // подразделение-получатель
	DueDate       string // срок исполнения (ДД.ММ.ГГГГ) или пусто
	Urgency       string // обычная | срочно | вне очереди
	AppName       string // название системы
}

type settings struct {
	cfg     config.EmailConfig
	appName string
	subject *template.Template
	body    *template.Template
}

var current *settings

// Configure разбирает шаблоны. При ошибке в шаблоне почта выключается с
// записью в журнал — приложение при этом работает.
func Configure(cfg config.EmailConfig, appName string) {
	current = nil
	if !cfg.Enabled {
		return
	}
	subj, err := template.New("subject").Option("missingkey=zero").Parse(cfg.NewDocument.Subject)
	if err != nil {
		log.Printf("почта выключена: ошибка в шаблоне темы (email.new_document.subject): %v", err)
		return
	}
	body, err := template.New("body").Option("missingkey=zero").Parse(cfg.NewDocument.Body)
	if err != nil {
		log.Printf("почта выключена: ошибка в шаблоне текста (email.new_document.body): %v", err)
		return
	}
	current = &settings{cfg: cfg, appName: appName, subject: subj, body: body}
}

// Enabled — включена ли отправка писем.
func Enabled() bool { return current != nil }

// Render формирует тему и текст письма по шаблонам.
func Render(d NewDocumentData) (subject, body string, err error) {
	if current == nil {
		return "", "", errors.New("почта выключена")
	}
	var sb, bb bytes.Buffer
	if err := current.subject.Execute(&sb, d); err != nil {
		return "", "", err
	}
	if err := current.body.Execute(&bb, d); err != nil {
		return "", "", err
	}
	// Тема — одна строка: перевод строки в заголовке письма недопустим.
	subject = strings.Join(strings.Fields(sb.String()), " ")
	return subject, bb.String(), nil
}

var urgencyLabel = map[string]string{"normal": "обычная", "urgent": "срочно", "out_of_turn": "вне очереди"}

// EnqueueNewDocument ставит в очередь письма адресатам о новом входящем
// документе. Вызывается внутри транзакции рассылки.
//
// Никогда не возвращает ошибку и не портит транзакцию: вставка идёт под
// точкой сохранения, при любой неудаче она откатывается, а причина пишется
// в журнал. Адресаты без адреса почты пропускаются.
func EnqueueNewDocument(ctx context.Context, tx pgx.Tx, documentID int64, recipientIDs []int64) {
	if current == nil || len(recipientIDs) == 0 {
		return
	}
	if _, err := tx.Exec(ctx, "SAVEPOINT sp_mail"); err != nil {
		return
	}
	if err := enqueue(ctx, tx, documentID, recipientIDs); err != nil {
		log.Printf("почта: письма по документу %d не поставлены в очередь: %v", documentID, err)
		_, _ = tx.Exec(ctx, "ROLLBACK TO SAVEPOINT sp_mail")
	}
	_, _ = tx.Exec(ctx, "RELEASE SAVEPOINT sp_mail")
}

func enqueue(ctx context.Context, tx pgx.Tx, documentID int64, recipientIDs []int64) error {
	var d NewDocumentData
	var urgency string
	err := tx.QueryRow(ctx, `
		SELECT d.id, d.title, coalesce(d.outgoing_number,''), coalesce(au.full_name,''),
		       coalesce(to_char(coalesce(d.due_datetime::date, d.due_date), 'DD.MM.YYYY'), ''), d.urgency::text
		  FROM documents d LEFT JOIN users au ON au.id = d.author_id
		 WHERE d.id = $1`, documentID).Scan(&d.ID, &d.Title, &d.Number, &d.AuthorName, &d.DueDate, &urgency)
	if err != nil {
		return err
	}
	d.Urgency = urgencyLabel[urgency]
	d.AppName = current.appName
	d.URL = strings.TrimRight(current.cfg.PublicURL, "/") + "/document/" + strconv.FormatInt(d.ID, 10)

	rows, err := tx.Query(ctx, `
		SELECT u.id, coalesce(u.full_name,''), btrim(u.email),
		       coalesce((SELECT dep.name FROM document_recipients dr JOIN departments dep ON dep.id = dr.recipient_department_id
		                  WHERE dr.document_id = $1 AND dr.recipient_user_id = u.id LIMIT 1), '')
		  FROM users u
		 WHERE u.id = ANY($2::bigint[]) AND u.is_active AND coalesce(btrim(u.email),'') <> ''`,
		documentID, recipientIDs)
	if err != nil {
		return err
	}
	type rcpt struct {
		id          int64
		name, email string
		dept        string
	}
	var list []rcpt
	for rows.Next() {
		var r rcpt
		if err := rows.Scan(&r.id, &r.name, &r.email, &r.dept); err != nil {
			rows.Close()
			return err
		}
		list = append(list, r)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return err
	}
	for _, r := range list {
		if _, err := mail.ParseAddress(r.email); err != nil {
			log.Printf("почта: у пользователя %d некорректный адрес %q — письмо пропущено", r.id, r.email)
			continue
		}
		data := d
		data.RecipientName, data.Department = r.name, r.dept
		subject, body, err := Render(data)
		if err != nil {
			return fmt.Errorf("шаблон письма: %w", err)
		}
		if _, err := tx.Exec(ctx, `
			INSERT INTO email_outbox (to_addr, subject, body, kind, document_id, user_id)
			VALUES ($1, $2, $3, 'new_document', $4, $5)`, r.email, subject, body, documentID, r.id); err != nil {
			return err
		}
	}
	return nil
}

// Start запускает фоновую отправку очереди. pool — системное подключение.
func Start(ctx context.Context, pool *pgxpool.Pool) {
	if current == nil {
		return
	}
	log.Printf("почта: отправка писем включена (%s:%d, от %s)", current.cfg.SMTP.Host, smtpPort(), current.cfg.SMTP.From)
	go func() {
		t := time.NewTicker(15 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				for sendBatch(ctx, pool) {
				}
			}
		}
	}()
}

// sendBatch отправляет одно письмо из очереди; true — письмо было, стоит
// сразу проверить следующее.
func sendBatch(ctx context.Context, pool *pgxpool.Pool) bool {
	defer func() {
		if r := recover(); r != nil {
			log.Printf("почта: сбой фоновой отправки: %v", r)
		}
	}()
	tx, err := pool.Begin(ctx)
	if err != nil {
		return false
	}
	defer tx.Rollback(ctx)
	var id int64
	var to, subject, body string
	var attempts int
	// SKIP LOCKED: несколько рабочих процессов не возьмут одно письмо.
	err = tx.QueryRow(ctx, `
		SELECT id, to_addr, subject, body, attempts FROM email_outbox
		 WHERE status = 'pending' AND next_attempt_at <= now()
		 ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED`).Scan(&id, &to, &subject, &body, &attempts)
	if err != nil {
		return false
	}
	sendErr := Send(to, subject, body)
	attempts++
	switch {
	case sendErr == nil:
		_, err = tx.Exec(ctx, `UPDATE email_outbox SET status='sent', attempts=$2, sent_at=now(), last_error=NULL WHERE id=$1`, id, attempts)
	case attempts >= current.cfg.MaxAttempts:
		log.Printf("почта: письмо %d для %s не отправлено после %d попыток: %v", id, to, attempts, sendErr)
		_, err = tx.Exec(ctx, `UPDATE email_outbox SET status='failed', attempts=$2, last_error=$3 WHERE id=$1`, id, attempts, sendErr.Error())
	default:
		// Повтор с нарастающей паузой: 1, 4, 9, 16 … минут.
		_, err = tx.Exec(ctx, `
			UPDATE email_outbox SET attempts=$2::int, last_error=$3,
			       next_attempt_at = now() + make_interval(mins => $2::int * $2::int)
			 WHERE id=$1`, id, attempts, sendErr.Error())
	}
	if err != nil {
		log.Printf("почта: не удалось записать результат отправки письма %d: %v", id, err)
		return false
	}
	return tx.Commit(ctx) == nil && sendErr == nil
}

func smtpPort() int {
	if current.cfg.SMTP.Port > 0 {
		return current.cfg.SMTP.Port
	}
	if strings.EqualFold(current.cfg.SMTP.Security, "tls") {
		return 465
	}
	return 587
}

// Send отправляет одно письмо (text/plain, UTF-8) с тайм-аутом на всё.
func Send(to, subject, body string) error {
	c := current.cfg.SMTP
	timeout := time.Duration(c.TimeoutSeconds) * time.Second
	if timeout <= 0 {
		timeout = 20 * time.Second
	}
	addr := net.JoinHostPort(c.Host, strconv.Itoa(smtpPort()))
	tlsCfg := &tls.Config{ServerName: c.Host, InsecureSkipVerify: c.SkipVerify, MinVersion: tls.VersionTLS12} //nolint:gosec // выключатель — явная настройка
	security := strings.ToLower(c.Security)
	if security == "" {
		security = "starttls"
	}

	conn, err := net.DialTimeout("tcp", addr, timeout)
	if err != nil {
		return err
	}
	_ = conn.SetDeadline(time.Now().Add(timeout))
	if security == "tls" {
		conn = tls.Client(conn, tlsCfg)
	}
	cl, err := smtp.NewClient(conn, c.Host)
	if err != nil {
		conn.Close()
		return err
	}
	defer cl.Close()
	if security == "starttls" {
		if ok, _ := cl.Extension("STARTTLS"); !ok {
			return errors.New("сервер не поддерживает STARTTLS (задайте email.smtp.security: none, если шифрование не требуется)")
		}
		if err := cl.StartTLS(tlsCfg); err != nil {
			return err
		}
	}
	if c.Username != "" {
		if ok, _ := cl.Extension("AUTH"); ok {
			if err := cl.Auth(plainAuth{c.Username, c.Password}); err != nil {
				return err
			}
		}
	}
	from, err := mail.ParseAddress(c.From)
	if err != nil {
		return fmt.Errorf("email.smtp.from: %w", err)
	}
	if err := cl.Mail(from.Address); err != nil {
		return err
	}
	if err := cl.Rcpt(to); err != nil {
		return err
	}
	w, err := cl.Data()
	if err != nil {
		return err
	}
	var msg bytes.Buffer
	fmt.Fprintf(&msg, "From: %s\r\n", from.String())
	fmt.Fprintf(&msg, "To: %s\r\n", to)
	fmt.Fprintf(&msg, "Subject: %s\r\n", mime.QEncoding.Encode("utf-8", subject))
	fmt.Fprintf(&msg, "Date: %s\r\n", time.Now().Format(time.RFC1123Z))
	msg.WriteString("MIME-Version: 1.0\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: 8bit\r\n")
	msg.WriteString("Auto-Submitted: auto-generated\r\n\r\n")
	msg.WriteString(strings.ReplaceAll(strings.ReplaceAll(body, "\r\n", "\n"), "\n", "\r\n"))
	if _, err := w.Write(msg.Bytes()); err != nil {
		return err
	}
	if err := w.Close(); err != nil {
		return err
	}
	return cl.Quit()
}

// plainAuth — AUTH PLAIN. В отличие от smtp.PlainAuth не отказывается
// работать без TLS: шифровать или нет, решает настройка email.smtp.security.
type plainAuth struct{ user, pass string }

func (a plainAuth) Start(*smtp.ServerInfo) (string, []byte, error) {
	return "PLAIN", []byte("\x00" + a.user + "\x00" + a.pass), nil
}
func (a plainAuth) Next([]byte, bool) ([]byte, error) { return nil, nil }
