package domain

import "time"

type Role string

const (
	RoleAuthor            Role = "author"
	RoleApproverHierarchy Role = "approver_hierarchy"
	RoleApproverCrossDept Role = "approver_cross_dept"
	RoleSigner            Role = "signer"
	RoleExecutor          Role = "executor"
	RoleClerk             Role = "clerk"
	RoleChief             Role = "chief"
	RoleController        Role = "controller"
	RoleAdmin             Role = "admin"
)

type Urgency string

const (
	UrgencyNormal    Urgency = "normal"
	UrgencyUrgent    Urgency = "urgent"
	UrgencyOutOfTurn Urgency = "out_of_turn"
)

type Status string

const (
	StatusDraft               Status = "draft"
	StatusOnApprovalHierarchy Status = "on_approval_hierarchy"
	StatusOnApprovalCrossDept Status = "on_approval_cross_dept"
	StatusOnSigning           Status = "on_signing"
	StatusSigned              Status = "signed"
	StatusSent                Status = "sent"
	StatusInProgress          Status = "in_progress"
	StatusExecuted            Status = "executed"
	StatusArchived            Status = "archived"
	StatusRejected            Status = "rejected"
)

type StageStatus string

const (
	StageWaitingDeps StageStatus = "waiting_deps"
	StagePending     StageStatus = "pending"
	StageApproved    StageStatus = "approved"
	StageRejected    StageStatus = "rejected"
)

type User struct {
	ID                    int64      `json:"id"`
	Login                 string     `json:"login"`
	FullName              string     `json:"full_name"`
	PrimaryDepartmentID   int64      `json:"primary_department_id"`
	NumberingDepartmentID int64      `json:"numbering_department_id"`
	Roles                 []UserRole `json:"roles"`
}

type UserRole struct {
	DepartmentID *int64 `json:"department_id,omitempty"`
	Role         Role   `json:"role"`
}

type Document struct {
	ID                 int64      `json:"id"`
	AuthorID           int64      `json:"author_id"`
	AuthorDepartmentID int64      `json:"author_department_id"`
	Title              string     `json:"title"`
	Urgency            Urgency    `json:"urgency"`
	Status             Status     `json:"status"`
	OutgoingNumber     *string    `json:"outgoing_number,omitempty"`
	DueDate            *time.Time `json:"due_date,omitempty"`
	DueDatetime        *time.Time `json:"due_datetime,omitempty"`
	CreatedAt          time.Time  `json:"created_at"`
	UpdatedAt          time.Time  `json:"updated_at"`
	OnControl          bool       `json:"on_control"`
	ControllerID       *int64     `json:"controller_id,omitempty"`
	ControllerName     *string    `json:"controller_name,omitempty"`
	CategoryID         int64      `json:"category_id,omitempty"`
	CategoryName       string     `json:"category_name,omitempty"`
	CategoryColor      string     `json:"category_color,omitempty"`
	// #17 — количество комментариев и вложений: в списках и журнале сразу
	// видно, есть ли по документу переписка и приложенные файлы, без открытия
	// карточки.
	MessageCount int `json:"message_count"`
	FileCount    int `json:"file_count"`
	// Отмечен ли документ звёздочкой ТЕКУЩИМ пользователем. У каждого свой
	// список, поэтому значение зависит от того, кто запрашивает.
	IsFavorite bool `json:"is_favorite"`
	// #26 — особая отметка документа.
	SpecialMarkID    int64      `json:"special_mark_id,omitempty"`
	SpecialMarkName  string     `json:"special_mark_name,omitempty"`
	SpecialMarkColor string     `json:"special_mark_color,omitempty"`
	SignedAt         *time.Time `json:"signed_at,omitempty"`
}

type ApprovalStage struct {
	ID                 int64       `json:"id"`
	DocumentID         int64       `json:"document_id"`
	StageType          string      `json:"stage_type"`
	ApproverID         int64       `json:"approver_id"`
	ApproverName       string      `json:"approver_name,omitempty"`
	ApproverPosition   string      `json:"approver_position,omitempty"`
	ApproverDepartment string      `json:"approver_department,omitempty"`
	ApproverCity       string      `json:"approver_city,omitempty"`
	Status             StageStatus `json:"status"`
	DisplayOrder       int         `json:"display_order"`
	DecidedAt          *time.Time  `json:"decided_at,omitempty"`
	Comment            string      `json:"comment,omitempty"`
	DependsOn          []int64     `json:"depends_on,omitempty"`

	// CanDecide — вправе ли ТЕКУЩИЙ пользователь принять решение по этому
	// этапу прямо сейчас. Считается на сервере.
	//
	// Зачем сервером. Интерфейс определял это сам, сравнивая approver_id с
	// идентификатором пользователя. Такое сравнение не знает о замещении:
	// заместитель видел документ в разделе «на подписи», а кнопки подписи у
	// него не было — ровно та жалоба, которую пункт 19 и описывает. Теперь
	// право считается там же, где оно проверяется при самом действии, поэтому
	// «кнопка есть» и «действие разрешено» не могут разойтись.
	CanDecide bool `json:"can_decide"`

	// StepNo — номер шага согласования (1, 2, 2, 3 …): этапы с одним номером
	// идут параллельно; номера всегда подряд, без пропусков.
	StepNo int `json:"step_no"`

	// Sequential — является ли согласование ПОСЛЕДОВАТЕЛЬНЫМ. Значение
	// одинаково у всех этапов маршрута: это свойство маршрута, а не этапа, но
	// отдельного объекта «маршрут» в API нет, и заводить его ради одного флага
	// незачем.
	//
	//, п. 1: в форме изменения документа галочка
	// «последовательное согласование» всегда показывалась нажатой, потому что
	// её состояние нигде не хранилось и не отдавалось — форма просто ставила
	// true при открытии. Последовательность не хранится отдельным полем, она
	// ВЫРАЖЕНА зависимостями этапов (каждый следующий зависит от предыдущего),
	// поэтому вычисляется из них.
	Sequential bool `json:"sequential"`
}

type ChatMessage struct {
	ID         int64     `json:"id"`
	DocumentID int64     `json:"document_id"`
	AuthorID   int64     `json:"author_id"`
	Text       string    `json:"text"`
	CreatedAt  time.Time `json:"created_at"`
}

type Notification struct {
	ID         int64     `json:"id"`
	UserID     int64     `json:"user_id"`
	DocumentID *int64    `json:"document_id,omitempty"`
	Kind       string    `json:"kind"`
	Payload    []byte    `json:"payload"`
	IsRead     bool      `json:"is_read"`
	CreatedAt  time.Time `json:"created_at"`
}

// PagedResult — унифицированный ответ для всех пагинированных списков.
type PagedResult[T any] struct {
	Items      []T   `json:"items"`
	Page       int   `json:"page"`
	PageSize   int   `json:"page_size"`
	TotalCount int64 `json:"total_count"`
}
