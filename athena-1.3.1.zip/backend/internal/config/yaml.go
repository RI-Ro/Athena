package config

import (
	"log"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

// FileConfig — полная структура config.yaml. Загружается опционально: если
// файла нет, используются значения по умолчанию + переменные окружения
// (env имеет приоритет над файлом, файл — над встроенными дефолтами).
type FileConfig struct {
	HTTP struct {
		// Addr — порт HTTP. Если заданы сертификаты (tls.cert_file/key_file),
		// на нём работает ТОЛЬКО перенаправление на HTTPS (https_addr);
		// если не заданы — само приложение (вход по паролю).
		Addr string `yaml:"addr"`
		// HTTPSAddr — порт HTTPS приложения со входом по паролю (локальные
		// учётные записи и LDAP). Используется только при заданных
		// сертификатах.
		HTTPSAddr string `yaml:"https_addr"`
		// KerberosAddr — ОТДЕЛЬНЫЙ порт со входом по Kerberos (SPNEGO).
		// Пусто — вход по Kerberos выключен. При заданных сертификатах порт
		// работает по HTTPS. Вход по паролю на этом порту отклоняется, а
		// вход по Kerberos отклоняется на порту пароля.
		KerberosAddr string `yaml:"kerberos_addr"`
		TLS          struct {
			CertFile string `yaml:"cert_file"`
			KeyFile  string `yaml:"key_file"`
		} `yaml:"tls"`
		// PublicHost — имя узла для ссылок между портами и для
		// перенаправления на HTTPS. Пусто — берётся из заголовка Host запроса.
		PublicHost     string   `yaml:"public_host"`
		AllowedOrigins []string `yaml:"allowed_origins"`
		// Prefork — запуск нескольких рабочих процессов на одних портах.
		// Требует realtime.redis_addr. PreforkProcesses — их число
		// (0 — по числу ядер процессора).
		Prefork          bool `yaml:"prefork"`
		PreforkProcesses int  `yaml:"prefork_processes"`
		// Определение фактического адреса клиента за NAT/обратным прокси.
		// TrustedProxies — адреса/сети прокси, чьим заголовкам верим (по
		// умолчанию — частные сети и loopback, то есть docker-сети).
		// ClientIPHeader — основной заголовок с адресом клиента
		// (X-Forwarded-For, X-Real-IP, Forwarded или любой другой); пусто —
		// автоопределение по списку заголовков.
		TrustedProxies []string `yaml:"trusted_proxies"`
		ClientIPHeader string   `yaml:"client_ip_header"`
		// Предел частоты обращений. 0 — предела нет (поведение прежних
		// версий). Подробности и то, почему счёт идёт по ПОЛЬЗОВАТЕЛЮ, а не
		// по адресу, — в backend/internal/http/middleware/ratelimit.go.
		RateLimit struct {
			RequestsPerSecond float64 `yaml:"requests_per_second"`
			Burst             int     `yaml:"burst"`
		} `yaml:"rate_limit"`
	} `yaml:"http"`
	Database struct {
		URL      string `yaml:"url"`
		MaxConns int32  `yaml:"max_conns"`
		MinConns int32  `yaml:"min_conns"`
		// Схему создаёт и обновляет администратор БД через psql
		// (backend/sql/*.sql). Приложение подключается ТОЛЬКО обычной ролью
		// (без SUPERUSER/BYPASSRLS), иначе RLS не действует.
	} `yaml:"database"`
	Auth struct {
		JWTSecret string `yaml:"jwt_secret"`
		JWTTTL    string `yaml:"jwt_ttl"`
		// SecretKey — ключ шифрования секретов доменов (пароль учётной записи
		// LDAP, keytab), которые хранятся в БД и задаются через веб. Пусто —
		// используется jwt_secret. Смена ключа делает сохранённые секреты
		// нечитаемыми: их нужно будет ввести заново.
		SecretKey string `yaml:"secret_key"`
		// SingleSession — запрет одновременной работы под одной учётной
		// записью с разных рабочих мест (, п. 8).
		//
		// Выключать его не следует: привязка юридически значимого действия к
		// рабочему месту — часть доказательной базы. Но настройка оставлена,
		// т.к. при внедрении встречаются учётные записи, которыми по
		// регламенту пользуется смена (дежурный пост), и для перехода нужен
		// период, когда запрет ещё не включён.
		SingleSession struct {
			// Enabled — проверять ли единственность сеанса. По умолчанию ДА
			// (пустая структура в yaml означает «включено», см. Normalize).
			Enabled *bool `yaml:"enabled"`
			// OnConflict — что делать, если сеанс уже есть:
			//   displace (по умолчанию) — вытеснить прежний;
			//   deny — отклонить новый вход.
			OnConflict string `yaml:"on_conflict"`
		} `yaml:"single_session"`
	} `yaml:"auth"`
	Pagination struct {
		PageSize    int `yaml:"page_size"`
		PageSizeMax int `yaml:"page_size_max"`
	} `yaml:"pagination"`
	Static struct {
		// Dir — путь к каталогу собранной статики фронтенда (Vite build, папка
		// dist). Если задан, приложение само раздаёт статику и делает SPA-
		// fallback на index.html (nginx не нужен). Пусто — статика не
		// раздаётся (режим «только API», фронт обслуживается отдельно).
		Dir string `yaml:"dir"`
	} `yaml:"static"`
	AccessLog struct {
		// Dir — каталог для access-логов запросов (по аналогии с nginx/apache).
		// Если задан, каждый HTTP-запрос пишется строкой в файл access.log в
		// этом каталоге (время, ip, метод, url, статус, длительность, login).
		// Пусто — access-лог в файл не пишется (остаётся консольный logger).
		Dir string `yaml:"dir"`
	} `yaml:"access_log"`
	Realtime      RealtimeConfig      `yaml:"realtime"`
	Signing       SigningConfig       `yaml:"signing"`
	Email         EmailConfig         `yaml:"email"`
	Metrics       MetricsConfig       `yaml:"metrics"`
	Approval      ApprovalConfig      `yaml:"approval"`
	Registry      RegistryConfig      `yaml:"registry"`
	Print         PrintConfig         `yaml:"print"`
	Marking       MarkingConfig       `yaml:"marking"`
	Lifecycle     LifecycleConfig     `yaml:"lifecycle"`
	Branding      BrandingConfig      `yaml:"branding"`
	SSO           SSOConfig           `yaml:"sso"`
	Numbering     NumberingConfig     `yaml:"numbering"`
	Notifications NotificationsConfig `yaml:"notifications"`
	Search        SearchConfig        `yaml:"search"`
	Uploads       UploadsConfig       `yaml:"uploads"`
}

// SigningConfig — простая электронная подпись (ПЭП).
type SigningConfig struct {
	// Secret — серверный секрет подписи. Подпись документа — это
	// HMAC-SHA256 на этом секрете; без него приложение не запускается.
	// Смена секрета не портит старые подписи, но проверить их новым ключом
	// будет нельзя (в карточке так и будет сказано). env: SIGNING_SECRET
	Secret string `yaml:"secret"`
}

// EmailConfig — письма адресатам о новом входящем документе.
type EmailConfig struct {
	Enabled bool `yaml:"enabled"`
	SMTP    struct {
		Host     string `yaml:"host"`
		Port     int    `yaml:"port"`
		Username string `yaml:"username"`
		Password string `yaml:"password"` // env: SMTP_PASSWORD
		From     string `yaml:"from"`
		// Security: none | starttls | tls. По умолчанию starttls.
		Security       string `yaml:"security"`
		SkipVerify     bool   `yaml:"skip_verify"`
		TimeoutSeconds int    `yaml:"timeout_seconds"`
	} `yaml:"smtp"`
	// PublicURL — адрес системы для ссылок в письмах (https://host:8443).
	PublicURL string `yaml:"public_url"`
	// MaxAttempts — сколько раз пытаться отправить письмо (по умолчанию 5).
	MaxAttempts int `yaml:"max_attempts"`
	// NewDocument — шаблон письма о новом входящем документе. В теме и тексте
	// доступны параметры: {{.ID}}, {{.Title}}, {{.Number}}, {{.URL}},
	// {{.RecipientName}}, {{.AuthorName}}, {{.Department}}, {{.DueDate}},
	// {{.Urgency}}, {{.AppName}}.
	NewDocument struct {
		Subject string `yaml:"subject"`
		Body    string `yaml:"body"`
	} `yaml:"new_document"`
}

// MetricsConfig — доступ к /metrics (Prometheus).
type MetricsConfig struct {
	// Token — если задан, /metrics требует «Authorization: Bearer <token>».
	// Пусто — /metrics доступен только с этого же компьютера (loopback).
	Token string `yaml:"token"`
}

// ApprovalConfig — согласование.
// PrintConfig — выдача документов на печать.
type PrintConfig struct {
	// SpoolDir — папка, через которую отдаётся промаркированный PDF. Файл
	// удаляется сразу после отдачи; остатки убираются фоново и при запуске.
	// Пусто — <временная папка ОС>/athena-print. env: PRINT_SPOOL_DIR
	SpoolDir string `yaml:"spool_dir"`
	// MaxAgeSeconds — сколько файл может пролежать, если отдача оборвалась
	// (фоновая уборка). По умолчанию 300.
	MaxAgeSeconds int `yaml:"max_age_seconds"`
}

// RegistryConfig — журналы регистрации.
type RegistryConfig struct {
	// ExportEnabled — разрешить выгрузку журналов в Excel. По умолчанию
	// выключено: кнопки в интерфейсе нет, адрес выгрузки отвечает 403.
	ExportEnabled bool `yaml:"export_enabled"`
}

type ApprovalConfig struct {
	// StageReminderDays — через сколько дней ожидания напоминать согласующему
	// и автору о зависшем этапе (раз в сутки). 0 — по умолчанию 3; меньше
	// нуля — не напоминать.
	StageReminderDays int `yaml:"stage_reminder_days"`
}

// UploadsConfig — ограничения на загружаемые файлы.
type UploadsConfig struct {
	// MaxPDFMB — максимальный размер файла документа, в мегабайтах.
	// 0 — применяется значение по умолчанию (DefaultMaxPDFMB).
	//
	// Зачем предел вообще: файл документа целиком лежит в БД и целиком
	// читается в память при печати и индексации. Один документ на 300 МБ
	// способен выбить процесс по памяти и забить резервную копию.
	MaxPDFMB int `yaml:"max_pdf_mb"`
}

// DefaultMaxPDFMB — размер по умолчанию. 5 МБ: скан обычного приказа на
// нескольких страницах укладывается, а случайно приложенный архив или
// многотомный скан — нет.
const DefaultMaxPDFMB = 5

// MaxPDFBytes — предел в байтах с учётом значения по умолчанию.
func (u UploadsConfig) MaxPDFBytes() int64 {
	mb := u.MaxPDFMB
	if mb <= 0 {
		mb = DefaultMaxPDFMB
	}
	return int64(mb) << 20
}

// SearchConfig — поиск по содержимому PDF и его фоновая индексация (#4).
type SearchConfig struct {
	// Enabled — запускать ли индексатор в этом процессе. Выключение не ломает
	// поиск по уже проиндексированному, только останавливает наполнение.
	Enabled *bool `yaml:"enabled"`
	// BatchSize — сколько документов берётся за один проход очереди.
	BatchSize int `yaml:"batch_size"`
	// IntervalSeconds — пауза, когда очередь пуста.
	IntervalSeconds int `yaml:"interval_seconds"`
	// MaxAttempts — после скольких неудач документ перестаёт выбираться.
	MaxAttempts int `yaml:"max_attempts"`
	// ExtractCommand — команда извлечения текста: PDF подаётся на stdin,
	// текст ожидается в stdout. По умолчанию pdftotext (poppler-utils).
	ExtractCommand []string `yaml:"extract_command"`
	// ExtractTimeoutSeconds — предел на один файл.
	ExtractTimeoutSeconds int `yaml:"extract_timeout_seconds"`
	// StaleAfterSeconds — через сколько взятое в работу задание считается
	// зависшим (воркер умер) и возвращается в очередь. Обязано быть больше
	// extract_timeout_seconds, иначе задание отберут у работающего воркера.
	StaleAfterSeconds int `yaml:"stale_after_seconds"`
	// MaxTextBytes — сколько текста хранить и индексировать на документ.
	MaxTextBytes int `yaml:"max_text_bytes"`
	// StoreText — хранить ли сам текст (нужен для показа фрагмента).
	StoreText *bool `yaml:"store_text"`
}

// NotificationsConfig — поведение уведомлений (#2).
type NotificationsConfig struct {
	// AlarmKinds — виды событий, которые показываются блокирующей модалкой со
	// звуком, пока пользователь их не прочитает или не отложит. Пусто —
	// применяется список по умолчанию (см. service.DefaultAlarmKinds).
	AlarmKinds []string `yaml:"alarm_kinds"`
	// SnoozeMinutes — допустимые интервалы «отложить», в минутах. По
	// требованию — ровно 5/15/30, другие значения сервер не принимает.
	SnoozeMinutes []int `yaml:"snooze_minutes"`
	// RepeatSeconds — период повторного звукового сигнала, пока модалка
	// открыта. 0 — не повторять.
	RepeatSeconds int `yaml:"repeat_seconds"`
}

// NumberingConfig — параметры формирования регистрационных номеров.
type NumberingConfig struct {
	// NumberPrefixForAll — УСТАРЕЛО и больше не используется. Формат номера
	// теперь: ИСХ-{префикс_подразделения}-{номер}/{год} (напр. ИСХ-9/8/7-231/2026,
	// ИСХ-ГУ-231/2026), без общего хвоста. Поле оставлено для обратной
	// совместимости конфигов и игнорируется.
	NumberPrefixForAll string `yaml:"number_prefix_for_all"`
}

// BrandingConfig — отображаемое название системы и подзаголовок (kicker).
// Отдаётся фронту через GET /api/app-config, чтобы «Афина» и «// доведение
// указаний» не были захардкожены в интерфейсе.
type BrandingConfig struct {
	AppName   string `yaml:"app_name"`
	Tagline   string `yaml:"tagline"`
	Copyright string `yaml:"copyright"` // текст после "©" под кнопкой «Выйти»
	// About — справочная информация, контакты техподдержки, автор проекта и т.д.
	// Показывается в модальном окне при клике на "©". Многострочный текст
	// (переносы сохраняются). Полностью настраивается здесь.
	About string `yaml:"about"`
}

// LoadWithFile читает config.yaml (путь из env CONFIG_FILE или ./config.yaml),
// затем накладывает переменные окружения. Возвращает основной Config (как
// раньше) плюс расширенные секции (Marking, Lifecycle, Realtime), которых в
// плоском env быть не может.
func LoadWithFile() (Config, FileConfig) {
	return LoadWithFilePath("")
}

// LoadWithFilePath — как LoadWithFile, но с явным путём к конфигу (флаг
// --config). Приоритет пути: явный аргумент > env CONFIG_FILE > ./config.yaml.
func LoadWithFilePath(explicitPath string) (Config, FileConfig) {
	var fc FileConfig
	explicit := firstNonEmpty(explicitPath, os.Getenv("CONFIG_FILE"))
	path := firstNonEmpty(explicit, "config.yaml")
	data, readErr := os.ReadFile(path)
	if readErr != nil {
		// Если путь задан ЯВНО (флаг --config или env CONFIG_FILE) и файл не
		// читается — это ошибка конфигурации, а не «нет дефолтного файла».
		// Раньше ошибка молча проглатывалась и применялись дефолты — из-за
		// этого казалось, что --config «не читается».
		if explicit != "" {
			log.Fatalf("не удалось прочитать конфиг %q: %v", path, readErr)
		}
		log.Printf("конфиг %q не найден — используются значения по умолчанию и env", path)
	} else {
		if err := yaml.Unmarshal(data, &fc); err != nil {
			log.Fatalf("ошибка разбора YAML-конфига %q: %v", path, err)
		}
		log.Printf("конфиг загружен: %s", path)
	}

	// Значения по умолчанию для брендинга (если в файле не заданы).
	if fc.Branding.AppName == "" {
		fc.Branding.AppName = "ИР «Афина»"
	}
	if fc.Branding.Tagline == "" {
		fc.Branding.Tagline = "контроль доведения и исполнения указаний"
	}
	if fc.Branding.Copyright == "" {
		fc.Branding.Copyright = "ИР «" + fc.Branding.AppName + "» · контроль доведения и исполнения указаний"
	}
	// Хвост номеров: если не задан явно — берём app_name (обратная совместимость).
	if fc.Numbering.NumberPrefixForAll == "" {
		fc.Numbering.NumberPrefixForAll = fc.Branding.AppName
	}
	if fc.Branding.About == "" {
		fc.Branding.About = "ИР «" + fc.Branding.AppName + "» — контроль доведения и исполнения указаний.\n\n" +
			"Техническая поддержка: support@example.com, тел. +7 (000) 000-00-00.\n" +
			"Режим работы: пн–пт, 9:00–18:00.\n\n" +
			"Настройте этот текст в конфиге: branding.about."
	}

	// Env-override пути шрифта штампов (различается alpine/debian).
	if v := os.Getenv("MARKING_FONT_FILE"); v != "" {
		fc.Marking.FontFile = v
	}
	if v := os.Getenv("MARKING_FONT_NAME"); v != "" {
		fc.Marking.FontName = v
	}
	// Быстрый тумблер вжигания через env (MARKING_BAKE=true|1|on).
	if v := os.Getenv("MARKING_BAKE"); v != "" {
		switch v {
		case "1", "true", "TRUE", "on", "yes":
			fc.Marking.Bake.Enabled = true
		case "0", "false", "FALSE", "off", "no":
			fc.Marking.Bake.Enabled = false
		}
	}
	// Шрифт для вжигания: если в секции bake не задан — берём общий marking.font_*.
	if fc.Marking.Bake.FontFile == "" {
		fc.Marking.Bake.FontFile = fc.Marking.FontFile
	}
	if fc.Marking.Bake.FontName == "" {
		fc.Marking.Bake.FontName = fc.Marking.FontName
	}
	// Env-override каталога статики фронтенда (одно приложение раздаёт и API, и
	// статику; nginx не нужен).
	if v := os.Getenv("PRINT_SPOOL_DIR"); v != "" {
		fc.Print.SpoolDir = v
	}
	if v := os.Getenv("STATIC_DIR"); v != "" {
		fc.Static.Dir = v
	}
	if v := os.Getenv("ACCESS_LOG_DIR"); v != "" {
		fc.AccessLog.Dir = v
	}

	dbURL := firstNonEmpty(os.Getenv("DATABASE_URL"), fc.Database.URL, "postgres://athena_app:CHANGE_ME@localhost:5432/athena?sslmode=disable")
	cfg := Config{
		HTTPAddr:       firstNonEmpty(os.Getenv("HTTP_ADDR"), fc.HTTP.Addr, ":8080"),
		DatabaseURL:    dbURL,
		JWTSecret:      firstNonEmpty(os.Getenv("JWT_SECRET"), fc.Auth.JWTSecret, "CHANGE_ME_IN_PRODUCTION"),
		JWTTTL:         parseDurationOr(firstNonEmpty(os.Getenv("JWT_TTL"), fc.Auth.JWTTTL), 12*time.Hour),
		PageSize:       firstPositive(getEnvInt("PAGE_SIZE", 0), fc.Pagination.PageSize, 20),
		PageSizeMax:    firstPositive(getEnvInt("PAGE_SIZE_MAX", 0), fc.Pagination.PageSizeMax, 100),
		AllowedOrigins: firstNonEmpty(os.Getenv("ALLOWED_ORIGINS"), joinOrigins(fc.HTTP.AllowedOrigins), "http://localhost:5173,http://127.0.0.1:5173"),
	}
	if v := os.Getenv("HTTPS_ADDR"); v != "" {
		fc.HTTP.HTTPSAddr = v
	}
	if v := os.Getenv("KERBEROS_ADDR"); v != "" {
		fc.HTTP.KerberosAddr = v
	}
	if v := os.Getenv("TLS_CERT_FILE"); v != "" {
		fc.HTTP.TLS.CertFile = v
	}
	if v := os.Getenv("TLS_KEY_FILE"); v != "" {
		fc.HTTP.TLS.KeyFile = v
	}
	if fc.HTTP.HTTPSAddr == "" {
		fc.HTTP.HTTPSAddr = ":8443"
	}
	if v := os.Getenv("AUTH_SECRET_KEY"); v != "" {
		fc.Auth.SecretKey = v
	}
	if fc.Auth.SecretKey == "" {
		fc.Auth.SecretKey = cfg.JWTSecret
	}
	if v := os.Getenv("SIGNING_SECRET"); v != "" {
		fc.Signing.Secret = v
	}
	if v := os.Getenv("SMTP_PASSWORD"); v != "" {
		fc.Email.SMTP.Password = v
	}
	if v := os.Getenv("REDIS_ADDR"); v != "" {
		fc.Realtime.RedisAddr = v
	}
	if fc.Email.NewDocument.Subject == "" {
		fc.Email.NewDocument.Subject = `Новое указание: {{.Title}}`
	}
	if fc.Email.NewDocument.Body == "" {
		fc.Email.NewDocument.Body = "Вам направлено новое указание «{{.Title}}».\n\n" +
			"Посмотреть подробную информацию Вы можете по адресу {{.URL}}\n\n" +
			"Информационное письмо сформировано автоматически, отвечать на него не нужно.\n"
	}
	if fc.Email.MaxAttempts <= 0 {
		fc.Email.MaxAttempts = 5
	}
	if fc.Approval.StageReminderDays == 0 {
		fc.Approval.StageReminderDays = 3
	}
	if fc.Database.MaxConns <= 0 {
		fc.Database.MaxConns = 20
	}
	if fc.Database.MinConns <= 0 {
		fc.Database.MinConns = 2
	}
	return cfg, fc
}

// TLSEnabled — заданы ли сертификаты.
func (f FileConfig) TLSEnabled() bool {
	return f.HTTP.TLS.CertFile != "" && f.HTTP.TLS.KeyFile != ""
}

// SingleSessionEnabled — включён ли запрет одновременного входа.
//
// Указатель на bool в структуре нужен именно для того, чтобы отличить
// «не задано» от «задано false». Не задано — значит включено: защитный
// механизм должен работать по умолчанию, иначе он не работает нигде, где
// конфиг не правили.
func (f FileConfig) SingleSessionEnabled() bool {
	if f.Auth.SingleSession.Enabled == nil {
		return true
	}
	return *f.Auth.SingleSession.Enabled
}

// SessionConflictPolicy — «displace» (по умолчанию) или «deny».
//
// По умолчанию вытеснение, а не отказ: при отказе упавший браузер, закрытый
// ноутбук или перезагрузка блокируют человека до истечения срока токена, и
// первым его действием будет звонок администратору. Вытеснение даёт тот же
// запрет на одновременную работу, но без этого.
func (f FileConfig) SessionConflictPolicy() string {
	if f.Auth.SingleSession.OnConflict == "deny" {
		return "deny"
	}
	return "displace"
}

func firstNonEmpty(vals ...string) string {
	for _, v := range vals {
		if v != "" {
			return v
		}
	}
	return ""
}

func firstPositive(vals ...int) int {
	for _, v := range vals {
		if v > 0 {
			return v
		}
	}
	return 0
}

func parseDurationOr(s string, fallback time.Duration) time.Duration {
	if d, err := time.ParseDuration(s); err == nil {
		return d
	}
	return fallback
}

func joinOrigins(origins []string) string {
	out := ""
	for i, o := range origins {
		if i > 0 {
			out += ","
		}
		out += o
	}
	return out
}

// SSOConfig — тексты страницы «вход по Kerberos не выполнен». Сами домены
// (LDAP, Kerberos, keytab) настраиваются через веб: Администрирование →
// Домены. Порт Kerberos задаётся в http.kerberos_addr.
type SSOConfig struct {
	Stub SSOStub `yaml:"stub"`
}

// SSOStub — тексты страницы-заглушки «не авторизован».
type SSOStub struct {
	Title    string     `yaml:"title"`
	Subtitle string     `yaml:"subtitle"`
	Message  string     `yaml:"message"`
	Hint     string     `yaml:"hint"`
	Footer   string     `yaml:"footer"`
	Accent   string     `yaml:"accent"` // цвет акцента, например #4F8CFF
	Admins   []SSOAdmin `yaml:"admins"`
	Support  struct {
		Email string `yaml:"email"`
		Phone string `yaml:"phone"`
		Hours string `yaml:"hours"`
	} `yaml:"support"`
}

// SSOAdmin — контакт администратора на заглушке.
type SSOAdmin struct {
	Name     string `yaml:"name" json:"name"`
	Position string `yaml:"position" json:"position"`
	Phone    string `yaml:"phone" json:"phone"`
	Email    string `yaml:"email" json:"email"`
}
