package repository

import (
	"testing"

	"athena/backend/internal/domain"
)

// Проверка вычисления признака «последовательное согласование» (замечание
// v52, п. 1).
//
// ЗАЧЕМ ЭТОТ ТЕСТ. Жалоба была такой: «при изменении документа галочка
// „последовательное согласование" не сохраняется, всегда показывает нажатой».
// Признак нигде не хранится — он ВЫРАЖЕН зависимостями этапов, и вычисляется
// по ним. Вычисление легко ошибается на краях: маршрут из одного согласующего,
// маршрут без согласующих, смешанный маршрут, этапы подписи (они зависят от
// всех согласующих в ЛЮБОМ режиме и в расчёт входить не должны). Каждый из
// этих случаев здесь разобран отдельно.
func TestStagesSequential(t *testing.T) {
	// hier — этап согласования с перечисленными зависимостями.
	hier := func(deps ...int64) domain.ApprovalStage {
		return domain.ApprovalStage{StageType: "hierarchy", DependsOn: deps}
	}
	// sign — этап подписи. Зависит от всех согласующих в любом режиме, поэтому
	// на ответ влиять не должен.
	sign := func(deps ...int64) domain.ApprovalStage {
		return domain.ApprovalStage{StageType: "signing", DependsOn: deps}
	}

	cases := []struct {
		name   string
		stages []domain.ApprovalStage
		want   bool
	}{
		{
			// Маршрута нет вовсе (согласование пропущено). Отвечаем
			// «последовательное»: это значение по умолчанию в форме, и при
			// сохранении ничего не изменится.
			name:   "согласующих нет",
			stages: []domain.ApprovalStage{sign()},
			want:   true,
		},
		{
			// Один согласующий неотличим: зависимостей нет ни в том, ни в
			// другом режиме.
			name:   "один согласующий",
			stages: []domain.ApprovalStage{hier(), sign(1)},
			want:   true,
		},
		{
			name:   "двое параллельно",
			stages: []domain.ApprovalStage{hier(), hier(), sign(1, 2)},
			want:   false,
		},
		{
			name:   "двое цепочкой",
			stages: []domain.ApprovalStage{hier(), hier(1), sign(1, 2)},
			want:   true,
		},
		{
			name:   "трое цепочкой",
			stages: []domain.ApprovalStage{hier(), hier(1), hier(2), sign(1, 2, 3)},
			want:   true,
		},
		{
			name:   "трое параллельно",
			stages: []domain.ApprovalStage{hier(), hier(), hier(), sign(1, 2, 3)},
			want:   false,
		},
		{
			// Смешанный маршрут: двое цепочкой, третий параллельно им.
			// Последовательным он НЕ является, и показывать галочку нажатой
			// было бы неправдой — сохранение превратило бы маршрут в цепочку.
			name:   "смешанный: часть цепочкой, часть параллельно",
			stages: []domain.ApprovalStage{hier(), hier(1), hier(), sign(1, 2, 3)},
			want:   false,
		},
		{
			// Несколько подписантов: все зависят от всех согласующих. Если бы
			// этапы подписи учитывались, ответ был бы «последовательное» даже
			// для параллельного маршрута.
			name:   "параллельные согласующие и три подписанта",
			stages: []domain.ApprovalStage{hier(), hier(), sign(1, 2), sign(1, 2), sign(1, 2)},
			want:   false,
		},
		{
			// Вырожденный случай: только подписанты, без согласования.
			name:   "только подписанты",
			stages: []domain.ApprovalStage{sign(), sign()},
			want:   true,
		},
	}

	for _, c := range cases {
		if got := stagesSequential(c.stages); got != c.want {
			t.Errorf("%s: получили %v, ожидали %v", c.name, got, c.want)
		}
	}
}
