package authdom

import (
	"testing"
	"time"

	"github.com/jcmturner/gofork/encoding/asn1"
	"github.com/jcmturner/gokrb5/v8/asn1tools"
	"github.com/jcmturner/gokrb5/v8/gssapi"
	"github.com/jcmturner/gokrb5/v8/iana/etypeID"
	"github.com/jcmturner/gokrb5/v8/iana/nametype"
	"github.com/jcmturner/gokrb5/v8/keytab"
	"github.com/jcmturner/gokrb5/v8/messages"
	"github.com/jcmturner/gokrb5/v8/spnego"
	"github.com/jcmturner/gokrb5/v8/types"
)

// forgeToken играет роль KDC: выпускает билет службы для клиента и
// оборачивает KRB_AP_REQ в SPNEGO — ровно то, что браузер кладёт в заголовок
// «Authorization: Negotiate». Возвращает токен и keytab службы.
func forgeToken(t *testing.T, user, crealm, spn, srealm, svcPassword string, authTime time.Time) (token, ktBytes []byte) {
	t.Helper()
	kt := keytab.New()
	if err := kt.AddEntry(spn, srealm, svcPassword, time.Now(), 2, etypeID.AES256_CTS_HMAC_SHA1_96); err != nil {
		t.Fatal(err)
	}
	ktBytes, err := kt.Marshal()
	if err != nil {
		t.Fatal(err)
	}
	cname := types.NewPrincipalName(nametype.KRB_NT_PRINCIPAL, user)
	sname := types.NewPrincipalName(nametype.KRB_NT_SRV_INST, spn)
	tkt, sessionKey, err := messages.NewTicket(cname, crealm, sname, srealm, types.NewKrbFlags(), kt,
		etypeID.AES256_CTS_HMAC_SHA1_96, 2, authTime, authTime, authTime.Add(8*time.Hour), authTime.Add(24*time.Hour))
	if err != nil {
		t.Fatal(err)
	}
	auth, err := types.NewAuthenticator(crealm, cname)
	if err != nil {
		t.Fatal(err)
	}
	auth.CTime = authTime
	apReq, err := messages.NewAPReq(tkt, sessionKey, auth)
	if err != nil {
		t.Fatal(err)
	}
	// Токен механизма KRB5 (RFC 4121): [APPLICATION 0] { OID, 0x0100, AP-REQ }.
	apBytes, err := apReq.Marshal()
	if err != nil {
		t.Fatal(err)
	}
	oidBytes, err := asn1.Marshal(gssapi.OIDKRB5.OID())
	if err != nil {
		t.Fatal(err)
	}
	mech := asn1tools.AddASNAppTag(append(append(oidBytes, 0x01, 0x00), apBytes...), 0)
	st := spnego.SPNEGOToken{Init: true, NegTokenInit: spnego.NegTokenInit{
		MechTypes:      []asn1.ObjectIdentifier{gssapi.OIDKRB5.OID()},
		MechTokenBytes: mech,
	}}
	token, err = st.Marshal()
	if err != nil {
		t.Fatal(err)
	}
	return token, ktBytes
}

func TestKerberosVerify(t *testing.T) {
	token, kt := forgeToken(t, "Ivanov", "DOMAIN2.LOCAL", "HTTP/athena.domain1.local", "DOMAIN1.LOCAL", "svc-secret", time.Now())
	apReq, err := apReqFromToken(token)
	if err != nil {
		t.Fatalf("разбор токена: %v", err)
	}
	// Верный keytab: имя и область КЛИЕНТА (а не службы).
	user, realm, err := verifyAPReq(apReq, kt, "")
	if err != nil || user != "Ivanov" || realm != "DOMAIN2.LOCAL" {
		t.Fatalf("ожидали Ivanov@DOMAIN2.LOCAL, получили %q@%q, err=%v", user, realm, err)
	}
	if got := CanonicalLogin(user, realm); got != "ivanov@DOMAIN2.LOCAL" {
		t.Fatalf("канонический логин: %q", got)
	}
	// Повтор того же билета отклоняется (кэш повторов).
	if _, _, err := verifyAPReq(apReq, kt, ""); err == nil {
		t.Fatal("повторное предъявление билета должно отклоняться")
	}
	// Чужой keytab (другой ключ службы) билет не расшифрует.
	token2, _ := forgeToken(t, "ivanov", "DOMAIN1.LOCAL", "HTTP/athena.domain1.local", "DOMAIN1.LOCAL", "svc-secret", time.Now())
	_, otherKt := forgeToken(t, "x", "DOMAIN1.LOCAL", "HTTP/athena.domain1.local", "DOMAIN1.LOCAL", "another-secret", time.Now())
	ap2, _ := apReqFromToken(token2)
	if _, _, err := verifyAPReq(ap2, otherKt, ""); err == nil {
		t.Fatal("билет не должен подтверждаться чужим keytab")
	}
	// Просроченный аутентификатор (часы разошлись больше допустимого).
	token3, kt3 := forgeToken(t, "ivanov", "DOMAIN1.LOCAL", "HTTP/athena.domain1.local", "DOMAIN1.LOCAL", "svc-secret", time.Now().Add(-30*time.Minute))
	ap3, _ := apReqFromToken(token3)
	if _, _, err := verifyAPReq(ap3, kt3, ""); err == nil {
		t.Fatal("аутентификатор 30-минутной давности должен отклоняться")
	}
	// Мусор вместо токена.
	if _, err := apReqFromToken([]byte("not a token")); err == nil {
		t.Fatal("мусор не должен разбираться как билет")
	}
	if info, err := ParseKeytab(kt); err != nil || info == "" {
		t.Fatalf("описание keytab: %q %v", info, err)
	}
	if _, err := ParseKeytab([]byte{1, 2, 3}); err == nil {
		t.Fatal("мусор не должен разбираться как keytab")
	}
}

func TestSplitLoginAndValidate(t *testing.T) {
	cases := []struct{ in, name, dom string }{
		{"ivanov", "ivanov", ""},
		{"ivanov@DOMAIN1.LOCAL", "ivanov", "DOMAIN1.LOCAL"},
		{`DOMAIN1\ivanov`, "ivanov", "DOMAIN1"},
		{" ivanov@domain2.local ", "ivanov", "domain2.local"},
	}
	for _, c := range cases {
		n, d := SplitLogin(c.in)
		if n != c.name || d != c.dom {
			t.Fatalf("%q: %q %q", c.in, n, d)
		}
	}
	if CanonicalLogin("Ivanov", "domain1.local") == CanonicalLogin("Ivanov", "domain2.local") {
		t.Fatal("одинаковые имена в разных доменах должны давать разные логины")
	}
	d := Domain{Realm: "domain1.local", LDAPEnabled: true, LDAPURLs: []string{"ldaps://dc1"}, LDAPBaseDN: "dc=x"}
	if err := d.Validate(); err != nil || d.Realm != "DOMAIN1.LOCAL" || d.LDAPURLs == nil {
		t.Fatalf("validate: %v %+v", err, d)
	}
	for _, bad := range []Domain{
		{Realm: "bad realm"},
		{Realm: "A.B", LDAPEnabled: true},
		{Realm: "A.B", LDAPURLs: []string{"http://x"}},
		{Realm: "A.B", LDAPUserFilter: "(cn=x)"},
	} {
		b := bad
		if err := b.Validate(); err == nil {
			t.Fatalf("должно отклоняться: %+v", bad)
		}
	}
}

func TestSealer(t *testing.T) {
	s, _ := NewSealer("key-1")
	enc, err := s.Seal([]byte("secret"))
	if err != nil {
		t.Fatal(err)
	}
	if out, err := s.Open(enc); err != nil || string(out) != "secret" {
		t.Fatalf("%q %v", out, err)
	}
	other, _ := NewSealer("key-2")
	if _, err := other.Open(enc); err == nil {
		t.Fatal("чужой ключ не должен расшифровывать")
	}
	enc[len(enc)-1] ^= 1
	if _, err := s.Open(enc); err == nil {
		t.Fatal("изменённый шифртекст должен отклоняться")
	}
}
