// Package authdom — домены аутентификации: несколько LDAP-каталогов и
// Kerberos-областей (realm), управляемые через веб-интерфейс.
//
// Учётная запись доменного пользователя хранится как «логин@REALM»
// (например ivanov@DOMAIN1.LOCAL), поэтому ivanov@DOMAIN1.LOCAL и
// ivanov@DOMAIN2.LOCAL — два разных пользователя. Локальные учётные записи
// (без домена) символа «@» в логине не содержат.
package authdom

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"errors"
)

// Sealer шифрует секреты доменов (пароль служебной учётной записи LDAP,
// keytab) перед записью в БД. AES-256-GCM, ключ — SHA-256 от auth.secret_key.
// Так дамп БД или чтение таблицы не раскрывают секреты без ключа из конфига.
type Sealer struct{ aead cipher.AEAD }

func NewSealer(secret string) (*Sealer, error) {
	if secret == "" {
		return nil, errors.New("authdom: пустой ключ шифрования секретов")
	}
	sum := sha256.Sum256([]byte("athena/authdom/v1:" + secret))
	block, err := aes.NewCipher(sum[:])
	if err != nil {
		return nil, err
	}
	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return &Sealer{aead: aead}, nil
}

func (s *Sealer) Seal(plain []byte) ([]byte, error) {
	nonce := make([]byte, s.aead.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return nil, err
	}
	return s.aead.Seal(nonce, nonce, plain, nil), nil
}

func (s *Sealer) Open(enc []byte) ([]byte, error) {
	n := s.aead.NonceSize()
	if len(enc) < n {
		return nil, errors.New("authdom: повреждённый секрет")
	}
	out, err := s.aead.Open(nil, enc[:n], enc[n:], nil)
	if err != nil {
		return nil, errors.New("authdom: секрет не расшифровывается (сменился auth.secret_key?) — введите его заново")
	}
	return out, nil
}
