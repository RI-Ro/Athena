package authdom

import (
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"net"
	"net/url"
	"strings"
	"time"

	"github.com/go-ldap/ldap/v3"
)

// LDAPUser — то, что каталог сообщил о пользователе.
type LDAPUser struct {
	DN       string
	FullName string
	Position string
	Email    string
}

var (
	// ErrLDAPInvalidCredentials — пользователь не найден или пароль неверен.
	// Причины намеренно не различаются: иначе по ответу можно перебирать
	// существующие логины.
	ErrLDAPInvalidCredentials = errors.New("неверный логин или пароль")
	// ErrLDAPUnavailable — ни один сервер каталога не ответил.
	ErrLDAPUnavailable = errors.New("каталог домена недоступен")
)

func (s *Store) dial(d Domain) (*ldap.Conn, error) {
	timeout := time.Duration(d.LDAPTimeoutSec) * time.Second
	if timeout <= 0 {
		timeout = 5 * time.Second
	}
	var lastErr error
	for _, raw := range d.LDAPURLs {
		u, err := url.Parse(raw)
		if err != nil {
			lastErr = err
			continue
		}
		tlsCfg := &tls.Config{ServerName: u.Hostname(), InsecureSkipVerify: d.LDAPSkipVerify, MinVersion: tls.VersionTLS12} //nolint:gosec // выключатель проверки — явная настройка администратора
		if pem := strings.TrimSpace(d.LDAPCAPEM); pem != "" {
			pool := x509.NewCertPool()
			if !pool.AppendCertsFromPEM([]byte(pem)) {
				return nil, errors.New("сертификат УЦ домена не разбирается (ожидается PEM)")
			}
			tlsCfg.RootCAs = pool
		}
		conn, err := ldap.DialURL(raw,
			ldap.DialWithDialer(&net.Dialer{Timeout: timeout}),
			ldap.DialWithTLSConfig(tlsCfg))
		if err != nil {
			lastErr = err
			continue
		}
		conn.SetTimeout(timeout)
		if d.LDAPStartTLS && strings.EqualFold(u.Scheme, "ldap") {
			if err := conn.StartTLS(tlsCfg); err != nil {
				conn.Close()
				lastErr = fmt.Errorf("StartTLS: %w", err)
				continue
			}
		}
		return conn, nil
	}
	if lastErr == nil {
		lastErr = errors.New("не задан ни один сервер")
	}
	return nil, fmt.Errorf("%w: %v", ErrLDAPUnavailable, lastErr)
}

// search находит ровно одну запись пользователя по логину под служебной
// учётной записью (или анонимно, если она не задана).
func (s *Store) search(conn *ldap.Conn, d Domain, login string) (LDAPUser, error) {
	if d.LDAPBindDN != "" {
		pw, err := s.BindPassword(d)
		if err != nil {
			return LDAPUser{}, err
		}
		if pw == "" {
			return LDAPUser{}, errors.New("не задан пароль служебной учётной записи LDAP")
		}
		if err := conn.Bind(d.LDAPBindDN, pw); err != nil {
			return LDAPUser{}, fmt.Errorf("служебная учётная запись LDAP отклонена: %w", err)
		}
	}
	filter := strings.ReplaceAll(d.LDAPUserFilter, "{login}", ldap.EscapeFilter(login))
	res, err := conn.Search(ldap.NewSearchRequest(
		d.LDAPBaseDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases,
		2, d.LDAPTimeoutSec, false, filter,
		[]string{"dn", d.LDAPAttrFullName, d.LDAPAttrPosition, d.LDAPAttrEmail}, nil))
	if err != nil && !ldap.IsErrorWithCode(err, ldap.LDAPResultSizeLimitExceeded) {
		return LDAPUser{}, fmt.Errorf("поиск в каталоге: %w", err)
	}
	if res == nil || len(res.Entries) == 0 {
		return LDAPUser{}, ErrLDAPInvalidCredentials
	}
	if len(res.Entries) > 1 {
		// Неоднозначность — отказ: входить «под первым попавшимся» нельзя.
		return LDAPUser{}, fmt.Errorf("в каталоге найдено несколько записей для %q — уточните фильтр пользователя", login)
	}
	e := res.Entries[0]
	return LDAPUser{DN: e.DN, FullName: strings.TrimSpace(e.GetAttributeValue(d.LDAPAttrFullName)),
		Position: strings.TrimSpace(e.GetAttributeValue(d.LDAPAttrPosition)),
		Email:    strings.TrimSpace(e.GetAttributeValue(d.LDAPAttrEmail))}, nil
}

// Authenticate проверяет логин и пароль в каталоге домена: находит запись
// пользователя и выполняет bind от его имени.
func (s *Store) Authenticate(d Domain, login, password string) (LDAPUser, error) {
	// Пустой пароль — это «unauthenticated bind», который многие серверы
	// принимают как успех. Ни при каких настройках он не должен пускать.
	if strings.TrimSpace(login) == "" || password == "" {
		return LDAPUser{}, ErrLDAPInvalidCredentials
	}
	conn, err := s.dial(d)
	if err != nil {
		return LDAPUser{}, err
	}
	defer conn.Close()
	u, err := s.search(conn, d, login)
	if err != nil {
		return LDAPUser{}, err
	}
	if err := conn.Bind(u.DN, password); err != nil {
		if ldap.IsErrorWithCode(err, ldap.LDAPResultInvalidCredentials) {
			return LDAPUser{}, ErrLDAPInvalidCredentials
		}
		return LDAPUser{}, fmt.Errorf("проверка пароля в каталоге: %w", err)
	}
	return u, nil
}

// Lookup находит пользователя без проверки пароля (нужно при входе по
// Kerberos, чтобы взять ФИО и должность для автосоздания).
func (s *Store) Lookup(d Domain, login string) (LDAPUser, error) {
	conn, err := s.dial(d)
	if err != nil {
		return LDAPUser{}, err
	}
	defer conn.Close()
	return s.search(conn, d, login)
}

// TestLDAP проверяет соединение и служебную учётную запись; если задан
// login — ещё и поиск этого пользователя. Возвращает описание результата.
func (s *Store) TestLDAP(d Domain, login string) (string, error) {
	conn, err := s.dial(d)
	if err != nil {
		return "", err
	}
	defer conn.Close()
	if strings.TrimSpace(login) == "" {
		if d.LDAPBindDN != "" {
			pw, err := s.BindPassword(d)
			if err != nil {
				return "", err
			}
			if err := conn.Bind(d.LDAPBindDN, pw); err != nil {
				return "", fmt.Errorf("служебная учётная запись отклонена: %w", err)
			}
			return "Соединение установлено, служебная учётная запись принята", nil
		}
		return "Соединение установлено (анонимно)", nil
	}
	u, err := s.search(conn, d, login)
	if err != nil {
		if errors.Is(err, ErrLDAPInvalidCredentials) {
			return "", fmt.Errorf("пользователь %q в каталоге не найден", login)
		}
		return "", err
	}
	return fmt.Sprintf("Найден: %s; ФИО: %q; должность: %q", u.DN, u.FullName, u.Position), nil
}
