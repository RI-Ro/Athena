package handlers

import (
	"context"
	"strings"
	"time"

	"athena/backend/internal/db"
)

// loginLimiter — защита от подбора пароля.
//
// Счёт неудачных попыток ведётся по паре «логин + адрес клиента»: после
// loginMaxFailures неудач за loginWindow вход для этой пары закрывается на
// loginBlock. Отдельно считается сам логин (с любого адреса) с порогом
// повыше — чтобы подбор с множества адресов тоже останавливался, но один
// ошибающийся человек за общим адресом не блокировал коллег.
//
// Счётчики хранятся в БД (auth_login_failures), поэтому едины для всех
// рабочих процессов и переживают перезапуск.
const (
	loginMaxFailures      = 5
	loginMaxFailuresLogin = 30
	loginWindow           = 10 * time.Minute
	loginBlock            = 10 * time.Minute
)

type loginLimiter struct{}

func newLoginLimiter() *loginLimiter { return &loginLimiter{} }

func limiterKeys(login, ip string) (pair, byLogin string) {
	l := strings.ToLower(strings.TrimSpace(login))
	if len(l) > 200 {
		l = l[:200]
	}
	return "p|" + l + "|" + ip, "l|" + l
}

// blocked сообщает, закрыт ли вход, и сколько осталось ждать. При сбое БД
// вход не блокируется: защита от подбора не должна сама становиться отказом.
func (l *loginLimiter) blocked(ctx context.Context, login, ip string) (bool, time.Duration) {
	if db.SystemPool == nil {
		return false, 0
	}
	pair, byLogin := limiterKeys(login, ip)
	var until *time.Time
	err := db.SystemPool.QueryRow(ctx, `
		SELECT max(blocked_until) FROM auth_login_failures
		 WHERE key IN ($1, $2) AND blocked_until > now()`, pair, byLogin).Scan(&until)
	if err != nil || until == nil {
		return false, 0
	}
	return true, time.Until(*until)
}

// fail учитывает неудачную попытку.
func (l *loginLimiter) fail(ctx context.Context, login, ip string) {
	if db.SystemPool == nil {
		return
	}
	pair, byLogin := limiterKeys(login, ip)
	for key, limit := range map[string]int{pair: loginMaxFailures, byLogin: loginMaxFailuresLogin} {
		_, _ = db.SystemPool.Exec(ctx, `
			INSERT INTO auth_login_failures AS f (key, failures, window_start)
			VALUES ($1, 1, now())
			ON CONFLICT (key) DO UPDATE SET
			    failures = CASE WHEN f.window_start < now() - make_interval(secs => $3) THEN 1 ELSE f.failures + 1 END,
			    window_start = CASE WHEN f.window_start < now() - make_interval(secs => $3) THEN now() ELSE f.window_start END,
			    blocked_until = CASE
			        WHEN (CASE WHEN f.window_start < now() - make_interval(secs => $3) THEN 1 ELSE f.failures + 1 END) >= $2
			        THEN now() + make_interval(secs => $4) ELSE f.blocked_until END`,
			key, limit, loginWindow.Seconds(), loginBlock.Seconds())
	}
}

// success сбрасывает счётчик пары после удачного входа.
func (l *loginLimiter) success(ctx context.Context, login, ip string) {
	if db.SystemPool == nil {
		return
	}
	pair, _ := limiterKeys(login, ip)
	_, _ = db.SystemPool.Exec(ctx, `DELETE FROM auth_login_failures WHERE key = $1`, pair)
}
