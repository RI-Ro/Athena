package handlers

import (
	"errors"
	"fmt"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/service"
	"athena/backend/internal/ws"
)

// ResolutionsHandler — резолюции руководителя (, п. 3).
//
// Заменил AssignmentsHandler. Поручение как отдельная сущность удалено
// (миграция 0023 переносит данные и удаляет таблицу assignments): два
// параллельных механизма означали бы вечный вопрос, в каком из них правда.
//
// Жизненный цикл, который поддерживает этот обработчик:
//
//	руководитель НАЛОЖИЛ резолюцию (issued)
//	   -> исполнитель взял в работу (in_progress)
//	   -> исполнитель ОТЧИТАЛСЯ (reported; резолюция -> on_report)
//	   -> автор резолюции ПРИНЯЛ отчёт (accepted) ИЛИ ВЕРНУЛ на доработку
//	   -> когда приняты отчёты всех исполнителей -> резолюция done
//
// Ключевое отличие от прежнего поручения: закрывает резолюцию АВТОР, а не
// исполнитель. Раньше исполнитель сам ставил «выполнено», то есть контроль
// исполнения был формальным.
type ResolutionsHandler struct {
	pool *pgxpool.Pool
	hub  *ws.Hub
}

func NewResolutionsHandler(pool *pgxpool.Pool, hub *ws.Hub) *ResolutionsHandler {
	return &ResolutionsHandler{pool: pool, hub: hub}
}

// scopeText — перечень подразделений для сообщения об отказе.
func scopeText(scope []string) string {
	if len(scope) == 0 {
		return "ни одно подразделение (обратитесь к администратору: " +
			"нужно указать подразделение, которым вы руководите)"
	}
	if len(scope) > 8 {
		return strings.Join(scope[:8], ", ") +
			fmt.Sprintf(" и ещё %d подразделений", len(scope)-8)
	}
	return strings.Join(scope, ", ")
}

var (
	errResForbidden = errors.New("нет права на это действие с резолюцией")
	// резолюцию накладывает только руководитель
	// подразделения; п. 4 — в пределах своей области.
	errResNotChief = errors.New(
		"резолюцию накладывает пользователь с ролью «может ставить резолюции»")
	errResOutOfScope     = errors.New("этот документ вне вашей области полномочий")
	errResExecOutOfScope = errors.New(
		"резолюцию можно давать только сотрудникам подразделений, выбранных вам для резолюций администратором (если не выбраны — своего подразделения); вне вашей области")
	errResClosed = errors.New("резолюция закрыта")
	// Вторая резолюция по документу. Отдельная ошибка, а не общий отказ:
	// человеку важно понять, что дело не в его правах, — резолюция уже есть.
	errResAlreadyIssued = errors.New(
		"по этому документу резолюция уже наложена: резолюция накладывается один раз")
	errResReportEmpty   = errors.New("нужен текст отчёта")
	errResNoExecutors   = errors.New("не указаны исполнители")
	errResDocNotReady   = errors.New("резолюция накладывается на подписанный или направленный документ: пока документ на согласовании, на подписи, отклонён или исполнен, резолюцию наложить нельзя")
	errResBadExecutor   = errors.New("исполнитель не найден или его учётная запись отключена")
	errResBadController = errors.New("контролёром может быть действующий сотрудник с ролью «Контролёр»")
	errResDuePast       = errors.New("срок резолюции не может быть в прошлом")
	errResNotRegistered = errors.New("документ ещё не зарегистрирован в вашем подразделении: резолюция накладывается после того, как адресат открыл документ и ему присвоен входящий номер")
	errResReasonNeeded  = errors.New("укажите причину")
	errResAccepted      = errors.New("ваш отчёт уже принят руководителем — изменить его нельзя")
)

type resolutionExecutor struct {
	ID             int64   `json:"id"`
	UserID         int64   `json:"user_id"`
	FullName       string  `json:"full_name"`
	Position       string  `json:"position,omitempty"`
	IsResponsible  bool    `json:"is_responsible"`
	Status         string  `json:"status"`
	StatusLabel    string  `json:"status_label"`
	Report         *string `json:"report,omitempty"`
	ReportedAt     *string `json:"reported_at,omitempty"`
	AcceptedAt     *string `json:"accepted_at,omitempty"`
	AcceptedByName *string `json:"accepted_by_name,omitempty"`
	ReturnNote     *string `json:"return_note,omitempty"`
	ReassignedFrom *string `json:"reassigned_from_name,omitempty"`
}

type resolutionRow struct {
	ID int64 `json:"id"`
	// Подразделение-получатель, чьему экземпляру документа принадлежит
	// резолюция (у каждого подразделения-получателя — своя).
	DepartmentID   int64                `json:"department_id"`
	DepartmentName string               `json:"department_name"`
	AuthorID       int64                `json:"author_id"`
	AuthorName     string               `json:"author_name"`
	AuthorPosition string               `json:"author_position,omitempty"`
	Text           string               `json:"text"`
	DueDate        *string              `json:"due_date,omitempty"`
	OnControl      bool                 `json:"on_control"`
	ControllerName *string              `json:"controller_name,omitempty"`
	Status         string               `json:"status"`
	StatusLabel    string               `json:"status_label"`
	ClosedAt       *string              `json:"closed_at,omitempty"`
	CloseNote      *string              `json:"close_note,omitempty"`
	CreatedAt      string               `json:"created_at"`
	Overdue        bool                 `json:"overdue"`
	Executors      []resolutionExecutor `json:"executors"`

	// ДОСТУПНЫЕ ДЕЙСТВИЯ для текущего пользователя (, п. 5).
	//
	// ЗАЧЕМ ЭТО ПОЯВИЛОСЬ. Жалоба: «после того как пользователь отметил в
	// резолюции, автор резолюции не может отметить дальше действие». Причина
	// была в том, что интерфейс решал сам, какие кнопки показать, и условия у
	// него были свои: кнопки автора показывались только при наличии
	// исполнителя в состоянии «отчёт представлен». Как только исполнитель
	// отмечал что-то другое (брал в работу), у автора не оставалось ни одной
	// кнопки — хотя закрыть резолюцию, вернуть её или переназначить
	// исполнителя он вправе всегда.
	//
	// Теперь права считает сервер и отдаёт готовыми флагами. Интерфейс их
	// только отображает, поэтому «кнопка есть» и «действие разрешено» не могут
	// разойтись, а новые условия достаточно поправить в одном месте.
	CanProgress bool `json:"can_progress"`
	CanReport   bool `json:"can_report"`
	// CanAccept — принять отчёт исполнителя. CanClose — закрыть резолюцию
	// БЕЗ отчёта: руководитель вправе признать её исполненной, если результат
	// ему известен иначе (доложили лично, исполнитель в отпуске). Это два
	// разных действия с разными формулировками на кнопке, и путать их нельзя.
	CanAccept bool `json:"can_accept"`
	CanClose  bool `json:"can_close"`
	CanReturn bool `json:"can_return"`
	// CanCancel — отозвать резолюцию (ошибочно наложена). CanReassign —
	// заменить исполнителя. Оба действия — с обязательной причиной.
	CanCancel   bool `json:"can_cancel"`
	CanReassign bool `json:"can_reassign"`
	CanEdit     bool `json:"can_edit"`
	// Действий «переназначить», «отменить» и «резолюция во исполнение»
	// больше нет. Резолюция по документу накладывается ОДИН раз, и порядок
	// работы с ней линейный: доложить — принять или вернуть на доработку.
	// Прежние три действия давали ветвление, в котором терялось, кто за что
	// отвечает: переназначенная и отменённая резолюции оставались в карточке
	// наравне с действующей, а дочерние «во исполнение» разводили один
	// документ на дерево поручений с разными сроками.
	// IsAuthor / IsExecutor — чтобы интерфейс мог подписать блок («ваша
	// резолюция», «вам поручено») без повторного сравнения идентификаторов.
	IsAuthor   bool `json:"is_author"`
	IsExecutor bool `json:"is_executor"`
}

// fillResolutionActions проставляет флаги доступных действий (п. 5).
//
// Считается ОДНИМ проходом по уже загруженным строкам, без обращений к базе:
// все нужные сведения (автор, контролёр, состояния исполнителей) уже
// выбраны, и дополнительный запрос на резолюцию дал бы N+1 на вкладке, где
// резолюций бывает десяток.
func fillResolutionActions(items []resolutionRow, userID int64, controllerOf map[int64]bool) {
	for i := range items {
		r := &items[i]
		closed := r.Status == "done" || r.Status == "cancelled"
		r.IsAuthor = r.AuthorID == userID
		// Распоряжаться резолюцией вправе её автор, тот, кто его сейчас
		// замещает, и контролёр (его для этого и назначают). Администратор
		// системы — НЕТ: это техническая роль, прав руководителя она не даёт
		// (иначе администратор мог бы принять отчёт или закрыть резолюцию
		// за руководителя, и по журналу это выглядело бы законным действием).
		master := r.IsAuthor || controllerOf[r.ID]

		var mine *resolutionExecutor
		anyReported := false
		anyOpen := false
		for j := range r.Executors {
			e := &r.Executors[j]
			if e.UserID == userID {
				mine = e
			}
			switch e.Status {
			case "reported":
				anyReported = true
			case "open", "in_progress", "returned":
				anyOpen = true
			}
		}
		r.IsExecutor = mine != nil

		if mine != nil && !closed {
			switch mine.Status {
			case "open", "returned":
				r.CanProgress = true
				r.CanReport = true
			case "in_progress":
				r.CanReport = true
			case "reported":
				// Уточнить отчёт можно, пока руководитель его не принял:
				// исполнитель нередко вспоминает подробность сразу после
				// отправки, и заставлять его ждать возврата на доработку
				// бессмысленно.
				r.CanReport = true
			}
		}

		if master && !closed {
			// Принять отчёт — только когда он есть. Иначе кнопка «Принять
			// отчёт» принимала бы пустоту, и в резолюции оставалось бы
			// «исполнено» без следа того, что сделано.
			r.CanAccept = anyReported
			r.CanReturn = anyReported
			// Закрыть без отчёта — когда есть незакрытые исполнители, но
			// отчёта от них нет. Это и есть то «дальше действие», которого
			// автору не хватало (п. 5).
			r.CanClose = anyOpen && !anyReported
		}
		if r.IsAuthor && !closed {
			r.CanCancel = true
			r.CanReassign = anyOpen || anyReported
			r.CanEdit = true
		}
	}
}

// List GET /api/documents/:id/resolutions
//
// Возвращает плоский список с parent_id — дерево строит интерфейс. Отдавать
// готовое дерево незачем: вложенность редко глубже двух уровней, а плоский
// список проще и дешевле.
func (h *ResolutionsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	items := []resolutionRow{}
	controllerOf := map[int64]bool{}
	canIssue := false
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Доступ к документу проверяет RLS: если документ не виден, выборка
		// пуста, и отдельной проверки прав не нужно.
		var ok bool
		if err := tx.QueryRow(c.Context(),
			`SELECT EXISTS(SELECT 1 FROM documents WHERE id=$1)`, docID).Scan(&ok); err != nil {
			return err
		}
		if !ok {
			return pgx.ErrNoRows
		}

		// Считается ДО выборки резолюций: ниже стоит ранний выход «резолюций
		// нет», и раньше он срабатывал прежде этого расчёта — у документа без
		// резолюций кнопки «Наложить резолюцию» не было ни у кого.
		//
		// Можно ли наложить резолюцию: документ подписан/направлен и есть
		// экземпляр подразделения из области полномочий пользователя, на
		// котором ещё нет действующей резолюции.
		var st string
		if err := tx.QueryRow(c.Context(), `SELECT status::text FROM documents WHERE id = $1`, docID).Scan(&st); err != nil {
			return err
		}
		if resolutionAllowedForStatus(st) {
			if err := tx.QueryRow(c.Context(), `SELECT EXISTS (`+freeInstanceSQL+`)`, docID, userID, 0).Scan(&canIssue); err != nil {
				return err
			}
		}

		rows, err := tx.Query(c.Context(), `
			SELECT r.id, r.department_id, coalesce(dep.name,''), r.author_id, coalesce(au.full_name,''),
			       coalesce(r.author_position,''), r.text,
			       to_char(r.due_date,'YYYY-MM-DD'), r.on_control, ct.full_name,
			       r.status::text,
			       to_char(r.closed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       r.close_note,
			       to_char(r.created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       (r.due_date IS NOT NULL AND r.due_date < current_date
			        AND r.status IN ('issued','in_progress','on_report')) AS overdue
			  FROM resolutions r
			  LEFT JOIN users au ON au.id = r.author_id
			  LEFT JOIN users ct ON ct.id = r.controller_id
			  LEFT JOIN departments dep ON dep.id = r.department_id
			 WHERE r.document_id = $1
			 ORDER BY r.created_at, r.id`, docID)
		if err != nil {
			return err
		}
		defer rows.Close()
		byID := map[int64]int{}
		for rows.Next() {
			var r resolutionRow
			if err := rows.Scan(&r.ID, &r.DepartmentID, &r.DepartmentName, &r.AuthorID, &r.AuthorName, &r.AuthorPosition,
				&r.Text, &r.DueDate, &r.OnControl, &r.ControllerName, &r.Status, &r.ClosedAt,
				&r.CloseNote, &r.CreatedAt, &r.Overdue); err != nil {
				return err
			}
			r.StatusLabel = service.ResolutionLabel(r.Status)
			r.Executors = []resolutionExecutor{}
			byID[r.ID] = len(items)
			items = append(items, r)
		}
		if err := rows.Err(); err != nil {
			return err
		}
		if len(items) == 0 {
			return nil
		}

		// Исполнители — ОДНИМ запросом по всем резолюциям документа, а не
		// запросом на резолюцию: при десятке резолюций это была бы десятка
		// лишних обращений (N+1).
		erows, err := tx.Query(c.Context(), `
			SELECT re.resolution_id, re.id, re.user_id, coalesce(u.full_name,''),
			       coalesce(u.position,''), re.is_responsible, re.status::text,
			       re.report,
			       to_char(re.reported_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       to_char(re.accepted_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       ab.full_name, re.return_note, rf.full_name
			  FROM resolution_executors re
			  JOIN resolutions r ON r.id = re.resolution_id
			  LEFT JOIN users u ON u.id = re.user_id
			  LEFT JOIN users ab ON ab.id = re.accepted_by
			  LEFT JOIN users rf ON rf.id = re.reassigned_from
			 WHERE r.document_id = $1
			 ORDER BY re.is_responsible DESC, u.full_name`, docID)
		if err != nil {
			return err
		}
		defer erows.Close()
		for erows.Next() {
			var resID int64
			var e resolutionExecutor
			if err := erows.Scan(&resID, &e.ID, &e.UserID, &e.FullName, &e.Position,
				&e.IsResponsible, &e.Status, &e.Report, &e.ReportedAt, &e.AcceptedAt,
				&e.AcceptedByName, &e.ReturnNote, &e.ReassignedFrom); err != nil {
				return err
			}
			e.StatusLabel = service.ResolutionExecLabel(e.Status)
			if idx, ok := byID[resID]; ok {
				items[idx].Executors = append(items[idx].Executors, e)
			}
		}
		if err := erows.Err(); err != nil {
			return err
		}

		// Контролёры резолюций — одним запросом по документу: контролёр
		// распоряжается резолюцией так же, как её автор, и без этого набора
		// у него не было бы ни одной кнопки.
		crows, err := tx.Query(c.Context(), `
			SELECT r.id FROM resolutions r
			 WHERE r.document_id = $1 AND r.controller_id = $2`, docID, userID)
		if err != nil {
			return err
		}
		defer crows.Close()
		for crows.Next() {
			var id int64
			if err := crows.Scan(&id); err != nil {
				return err
			}
			controllerOf[id] = true
		}
		if err := crows.Err(); err != nil {
			return err
		}

		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить резолюции")
	}
	fillResolutionActions(items, userID, controllerOf)
	return c.JSON(fiber.Map{
		"items": items,
		// can_issue относится к документу в целом (кнопка «Наложить
		// резолюцию»), флаги внутри items — к каждой резолюции отдельно.
		//
		// Резолюция накладывается ОДИН раз: как только по документу есть
		// хотя бы одна, кнопки больше нет. Проверка здесь — это только
		// интерфейс; настоящий запрет стоит в Create, иначе его можно было
		// бы обойти прямым запросом.
		"can_issue": canIssue,
	})
}

// resolutionAllowedForStatus — на каком этапе жизни документа можно наложить
// резолюцию: документ подписан либо направлен и находится в работе. На
// согласовании и подписи содержание ещё может измениться или быть отклонено;
// по исполненному и архивному поручать уже нечего.
func resolutionAllowedForStatus(st string) bool {
	switch st {
	case "signed", "sent", "in_progress":
		return true
	}
	return false
}

// freeInstanceSQL — экземпляры документа ($1) в подразделениях из области
// полномочий пользователя ($2), на которых нет действующей резолюции.
// $3 — конкретное подразделение (0 — любое из области).
const freeInstanceSQL = `
	SELECT dii.id, dii.receiving_department_id
	  FROM document_incoming_instances dii
	 WHERE dii.document_id = $1
	   AND chief_scope_has($2, dii.receiving_department_id)
	   AND ($3 = 0 OR dii.receiving_department_id = $3)
	   AND NOT EXISTS (SELECT 1 FROM resolutions r
	                    WHERE r.instance_id = dii.id AND r.status <> 'cancelled')
	 ORDER BY dii.id`

type createResolutionReq struct {
	// DepartmentID — подразделение-получатель, на экземпляр которого
	// накладывается резолюция. Нужен, только если в области полномочий
	// руководителя несколько подразделений-получателей этого документа.
	DepartmentID  int64   `json:"department_id"`
	Text          string  `json:"text"`
	DueDate       string  `json:"due_date"`
	OnControl     bool    `json:"on_control"`
	ControllerID  int64   `json:"controller_id"`
	ResponsibleID int64   `json:"responsible_id"`
	CoExecutorIDs []int64 `json:"co_executor_ids"`
}

// Create POST /api/documents/:id/resolutions — наложить резолюцию.
func (h *ResolutionsHandler) Create(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req createResolutionReq
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	req.Text = strings.TrimSpace(req.Text)
	if req.Text == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите текст резолюции")
	}
	if req.ResponsibleID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "укажите ответственного исполнителя")
	}
	if len([]rune(req.Text)) > 4000 {
		return fiber.NewError(fiber.StatusBadRequest, "текст резолюции длиннее 4000 знаков")
	}
	if err := validateDate(req.DueDate, "срок резолюции"); err != nil {
		return err
	}
	if len(req.CoExecutorIDs) > 100 {
		return fiber.NewError(fiber.StatusBadRequest, "слишком много соисполнителей")
	}

	// Соисполнители: убираем дубли и самого ответственного — иначе получилась
	// бы вторая строка того же человека, и уникальность (resolution, user)
	// отвергла бы всю резолюцию.
	coSet := map[int64]bool{}
	for _, id := range req.CoExecutorIDs {
		if id != 0 && id != req.ResponsibleID {
			coSet[id] = true
		}
	}

	var newID int64
	var notify []int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Строка документа блокируется: два руководителя, нажавшие «Наложить
		// резолюцию» одновременно, иначе оба прошли бы проверку «резолюции
		// ещё нет» и создали бы две.
		var docStatus string
		if err := tx.QueryRow(c.Context(),
			`SELECT status::text FROM documents WHERE id = $1 FOR UPDATE`, docID).Scan(&docStatus); err != nil {
			return err
		}
		if !resolutionAllowedForStatus(docStatus) {
			return errResDocNotReady
		}
		// Резолюция накладывается на ЭКЗЕМПЛЯР входящего документа — пару
		// «документ + подразделение-получатель». Ищем экземпляр подразделения
		// из области полномочий руководителя, на котором ещё нет действующей
		// резолюции. Проверка здесь, а не только в интерфейсе.
		var instanceID, departmentID int64
		err := tx.QueryRow(c.Context(), freeInstanceSQL+` LIMIT 1`, docID, userID, req.DepartmentID).
			Scan(&instanceID, &departmentID)
		if errors.Is(err, pgx.ErrNoRows) {
			// Отказ объясняется по причине: человеку нужно понять, что делать.
			chief, cerr := service.IsChief(c.Context(), tx, userID)
			if cerr != nil {
				return cerr
			}
			if !chief {
				return errResNotChief
			}
			var inScope, registered int
			if err := tx.QueryRow(c.Context(), `
				SELECT count(*) FILTER (WHERE chief_scope_has($2, dr.recipient_department_id)),
				       count(*) FILTER (WHERE chief_scope_has($2, dr.recipient_department_id) AND EXISTS (
				           SELECT 1 FROM document_incoming_instances dii
				            WHERE dii.document_id = dr.document_id
				              AND dii.receiving_department_id = dr.recipient_department_id))
				  FROM document_recipients dr WHERE dr.document_id = $1`, docID, userID).Scan(&inScope, &registered); err != nil {
				return err
			}
			switch {
			case inScope == 0:
				scope, serr := service.ResolutionScope(c.Context(), tx, userID)
				if serr != nil {
					return serr
				}
				return fmt.Errorf("%w: документ не направлялся в подразделения вашей области полномочий (%s)",
					errResOutOfScope, scopeText(scope))
			case registered == 0:
				return errResNotRegistered
			default:
				return errResAlreadyIssued
			}
		}
		if err != nil {
			return err
		}
		bad, err := service.ResolutionExecutorsOutOfScope(c.Context(), tx, userID, func() []int64 {
			t := []int64{req.ResponsibleID}
			for id := range coSet {
				t = append(t, id)
			}
			return t
		}())
		if err != nil {
			return err
		}
		if len(bad) > 0 {
			return fmt.Errorf("%w: %s", errResExecOutOfScope, strings.Join(bad, ", "))
		}

		// Исполнители обязаны существовать и быть действующими сотрудниками.
		{
			targets := []int64{req.ResponsibleID}
			for id := range coSet {
				targets = append(targets, id)
			}
			var n int
			if err := tx.QueryRow(c.Context(),
				`SELECT count(*) FROM users WHERE id = ANY($1::bigint[]) AND is_active`, targets).Scan(&n); err != nil {
				return err
			}
			if n != len(targets) {
				return errResBadExecutor
			}
		}
		if req.ControllerID != 0 {
			var ok bool
			if err := tx.QueryRow(c.Context(), `
				SELECT EXISTS (SELECT 1 FROM users u
				                JOIN user_roles ur ON ur.user_id = u.id AND ur.role IN ('controller','default_controller')
				               WHERE u.id = $1 AND u.is_active)`, req.ControllerID).Scan(&ok); err != nil {
				return err
			}
			if !ok {
				return errResBadController
			}
		}
		if strings.TrimSpace(req.DueDate) != "" {
			var past bool
			if err := tx.QueryRow(c.Context(), `SELECT $1::date < current_date`, strings.TrimSpace(req.DueDate)).Scan(&past); err != nil {
				return err
			}
			if past {
				return errResDuePast
			}
		}

		// Снимок должности автора: через год должность изменится, а резолюция
		// обязана остаться читаемой («Начальник управления Иванов»).
		var authorPos string
		_ = tx.QueryRow(c.Context(),
			`SELECT coalesce(position,'') FROM users WHERE id=$1`, userID).Scan(&authorPos)

		var due *string
		if strings.TrimSpace(req.DueDate) != "" {
			d := strings.TrimSpace(req.DueDate)
			due = &d
		}
		var ctrl *int64
		if req.ControllerID != 0 {
			ctrl = &req.ControllerID
		}

		if err := tx.QueryRow(c.Context(), `
			INSERT INTO resolutions (document_id, instance_id, department_id, author_id, author_position, text,
			                         due_date, on_control, controller_id)
			VALUES ($1, $2, $3, $4, NULLIF($5,''), $6, $7::date, $8, $9)
			RETURNING id`,
			docID, instanceID, departmentID, userID, authorPos, req.Text, due,
			req.OnControl || ctrl != nil, ctrl).Scan(&newID); err != nil {
			return err
		}

		// Исполнители: ответственный + соисполнители.
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO resolution_executors (resolution_id, user_id, is_responsible)
			VALUES ($1, $2, TRUE)`, newID, req.ResponsibleID); err != nil {
			return err
		}
		notify = append(notify, req.ResponsibleID)
		for id := range coSet {
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO resolution_executors (resolution_id, user_id, is_responsible)
				VALUES ($1, $2, FALSE)`, newID, id); err != nil {
				return err
			}
			notify = append(notify, id)
		}

		// Доступ и ознакомление для каждого исполнителя: без этого человек не
		// увидит документ, по которому ему дана резолюция, — RLS его отрежет.
		for _, id := range notify {
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO document_access (document_id, user_id, access_reason)
				VALUES ($1, $2, 'executor') ON CONFLICT DO NOTHING`, docID, id); err != nil {
				return err
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO document_acquaintances (document_id, user_id, acquainted_by)
				VALUES ($1, $2, $3) ON CONFLICT (document_id, user_id) DO NOTHING`,
				docID, id, userID); err != nil {
				return err
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, detail, requires_ack)
				VALUES ($1, $2, 'resolution', '{}', $3, NULLIF($4::text,''), $5)`,
				id, docID, userID, req.Text, service.RequiresAck("resolution")); err != nil {
				return err
			}
		}

		// Запись в историю с пометкой о замещении, если резолюцию наложил
		// заместитель руководителя. Пометка о ДЕЛЕГИРОВАНИИ убрана вместе с
		// самим делегированием: остался один механизм —
		// замещение.
		// Контролёр резолюции должен видеть документ и знать о назначении:
		// раньше ему давалось право принимать отчёты, но не доступ к
		// документу, и он не мог открыть то, что контролирует.
		if ctrl != nil && *ctrl != userID {
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO document_access (document_id, user_id, access_reason)
				VALUES ($1, $2, 'controller') ON CONFLICT DO NOTHING`, docID, *ctrl); err != nil {
				return err
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, detail, requires_ack)
				VALUES ($1, $2, 'resolution', '{}', $3, NULLIF($4::text,''), $5)`,
				*ctrl, docID, userID, "Вы назначены контролёром резолюции: "+req.Text, service.RequiresAck("resolution")); err != nil {
				return err
			}
			notify = append(notify, *ctrl)
		}

		comment := "резолюция: " + req.Text
		comment = (comment)
		_, err = tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, 'resolution_issued', $3)`, docID, userID, comment)
		return err
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, errResAlreadyIssued), errors.Is(txErr, errResDocNotReady), errors.Is(txErr, errResNotRegistered):
			return fiber.NewError(fiber.StatusConflict, txErr.Error())
		case errors.Is(txErr, errResBadExecutor), errors.Is(txErr, errResBadController), errors.Is(txErr, errResDuePast):
			return fiber.NewError(fiber.StatusUnprocessableEntity, txErr.Error())
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		case errors.Is(txErr, errResNotChief),
			errors.Is(txErr, errResOutOfScope),
			errors.Is(txErr, errResExecOutOfScope):
			// Текст уже содержит объяснение: роль, перечень подразделений или
			// ФИО тех, кому поручить нельзя. Общее «запрещено» заставляло
			// человека гадать, что именно исправить.
			return fiber.NewError(fiber.StatusForbidden, txErr.Error())
		case errors.Is(txErr, errResForbidden):
			return fiber.NewError(fiber.StatusForbidden,
				"наложить резолюцию может пользователь с ролью «может ставить резолюции» "+
					"по документам своего подразделения и подчинённых ему")
		case strings.Contains(txErr.Error(), "не может быть позже срока вышестоящей"):
			return fiber.NewError(fiber.StatusUnprocessableEntity, txErr.Error())
		case strings.Contains(txErr.Error(), "resolutions_text_check"):
			return fiber.NewError(fiber.StatusUnprocessableEntity, "текст резолюции не может быть пустым")
		}
		if ie := inputError(txErr); ie != nil {
			return ie
		}
		log.Printf("create resolution failed (doc=%d user=%d): %v", docID, userID, txErr)
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось наложить резолюцию")
	}
	if h.hub != nil && len(notify) > 0 {
		h.hub.NotifyUsers(notify, docID, "resolution")
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID})
}

// resolutionContext — сведения, нужные почти каждому действию над резолюцией.
type resolutionContext struct {
	DocumentID int64
	AuthorID   int64
	Status     string
	Text       string
}

func loadResolution(c *fiber.Ctx, tx pgx.Tx, id int64) (resolutionContext, error) {
	var r resolutionContext
	err := tx.QueryRow(c.Context(), `
		SELECT document_id, author_id, status::text, text FROM resolutions WHERE id = $1`, id).
		Scan(&r.DocumentID, &r.AuthorID, &r.Status, &r.Text)
	return r, err
}

// Edit PUT /api/resolutions/:id — изменить текст и срок.
// Право: автор резолюции (или администратор), пока она не закрыта.
func (h *ResolutionsHandler) Edit(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		Text    string `json:"text"`
		DueDate string `json:"due_date"`
	}
	if err := c.BodyParser(&req); err != nil || strings.TrimSpace(req.Text) == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите текст резолюции")
	}
	if len([]rune(req.Text)) > 4000 {
		return fiber.NewError(fiber.StatusBadRequest, "текст резолюции длиннее 4000 знаков")
	}
	if err := validateDate(req.DueDate, "срок резолюции"); err != nil {
		return err
	}
	var editDocID int64
	var editNotify []int64

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		r, err := loadResolution(c, tx, id)
		if err != nil {
			return err
		}
		// Менять резолюцию вправе её автор или тот, кто его сейчас замещает.
		if r.AuthorID != userID {
			return errResForbidden
		}
		if r.Status == "done" || r.Status == "cancelled" {
			return errResClosed
		}
		var due *string
		if strings.TrimSpace(req.DueDate) != "" {
			d := strings.TrimSpace(req.DueDate)
			due = &d
		}
		if due != nil {
			// Срок можно оставить прежним (даже если он уже прошёл), но
			// нельзя переставить на другую дату в прошлом.
			var bad bool
			if err := tx.QueryRow(c.Context(), `
				SELECT $2::date < current_date AND $2::date IS DISTINCT FROM (SELECT due_date FROM resolutions WHERE id = $1)`,
				id, *due).Scan(&bad); err != nil {
				return err
			}
			if bad {
				return errResDuePast
			}
		}
		if _, err := tx.Exec(c.Context(), `
			UPDATE resolutions SET text = $2, due_date = $3::date WHERE id = $1`,
			id, strings.TrimSpace(req.Text), due); err != nil {
			return err
		}
		if _, err = tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, 'resolution_changed', $3)`,
			r.DocumentID, userID, (fmt.Sprintf("резолюция #%d изменена: %s", id, strings.TrimSpace(req.Text)))); err != nil {
			return err
		}
		// Исполнители обязаны узнать, что поручение изменилось: раньше текст
		// и срок менялись молча, и человек продолжал исполнять прежнее.
		editDocID = r.DocumentID
		// Сначала список, потом вставка: RETURNING из notifications под RLS
		// вернул бы только собственные строки (и ошибку для чужих).
		rows, err := tx.Query(c.Context(), `
			SELECT re.user_id FROM resolution_executors re
			 WHERE re.resolution_id = $1 AND re.status NOT IN ('cancelled','accepted') AND re.user_id <> $2`,
			id, userID)
		if err != nil {
			return err
		}
		for rows.Next() {
			var uid int64
			if err := rows.Scan(&uid); err != nil {
				rows.Close()
				return err
			}
			editNotify = append(editNotify, uid)
		}
		rows.Close()
		if err := rows.Err(); err != nil {
			return err
		}
		for _, uid := range editNotify {
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, detail, requires_ack)
				VALUES ($1, $2, 'resolution', '{}', $3, $4, $5)`,
				uid, r.DocumentID, userID, "Резолюция изменена: "+strings.TrimSpace(req.Text),
				service.RequiresAck("resolution")); err != nil {
				return err
			}
		}
		return nil
	})
	if txErr != nil {
		return resolutionActionError(txErr)
	}
	if h.hub != nil && len(editNotify) > 0 {
		h.hub.NotifyUsers(editNotify, editDocID, "resolution")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Progress POST /api/resolutions/:id/progress — исполнитель берёт в работу.
func (h *ResolutionsHandler) Progress(c *fiber.Ctx) error {
	return h.execAction(c, "progress")
}

// Report POST /api/resolutions/:id/report — исполнитель представляет отчёт.
func (h *ResolutionsHandler) Report(c *fiber.Ctx) error {
	return h.execAction(c, "report")
}

// execAction — действия ИСПОЛНИТЕЛЯ над своей строкой резолюции.
//
// Одна функция на два действия: различаются они только целевым статусом и
// требованием текста, а вся обвязка (поиск своей строки, пересчёт статуса
// резолюции, история, уведомление автору) одинакова. Разводить это по двум
// почти одинаковым обработчикам значило бы заводить два места, которые
// разойдутся.
func (h *ResolutionsHandler) execAction(c *fiber.Ctx, action string) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		Report string `json:"report"`
	}
	_ = c.BodyParser(&req)
	req.Report = strings.TrimSpace(req.Report)
	if len([]rune(req.Report)) > 8000 {
		return fiber.NewError(fiber.StatusBadRequest, "отчёт длиннее 8000 знаков")
	}
	if action == "report" && req.Report == "" {
		return fiber.NewError(fiber.StatusBadRequest,
			"укажите, что сделано: отчёт об исполнении обязателен")
	}

	var docID, authorID int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		r, err := loadResolution(c, tx, id)
		if err != nil {
			return err
		}
		docID, authorID = r.DocumentID, r.AuthorID
		if r.Status == "done" || r.Status == "cancelled" {
			return errResClosed
		}

		var execRowID int64
		if err := tx.QueryRow(c.Context(), `
			SELECT id FROM resolution_executors
			 WHERE resolution_id = $1 AND user_id = $2 AND status <> 'cancelled'`,
			id, userID).Scan(&execRowID); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return errResForbidden
			}
			return err
		}

		if action == "progress" {
			if _, err := tx.Exec(c.Context(), `
				UPDATE resolution_executors SET status = 'in_progress', return_note = NULL
				 WHERE id = $1 AND status IN ('open','returned')`, execRowID); err != nil {
				return err
			}
		} else {
			// Только из незакрытых состояний: принятый руководителем отчёт
			// исполнитель переписать не может (раньше мог — и статус
			// «принят» молча откатывался в «отчёт представлен»).
			ct, err := tx.Exec(c.Context(), `
				UPDATE resolution_executors
				   SET status = 'reported', report = $2, reported_at = now(), return_note = NULL
				 WHERE id = $1 AND status IN ('open','in_progress','returned','reported')`, execRowID, req.Report)
			if err != nil {
				return err
			}
			if ct.RowsAffected() == 0 {
				return errResAccepted
			}
		}
		if err := service.RecalcResolutionStatus(c.Context(), tx, id, userID); err != nil {
			return err
		}

		if action == "report" {
			comment := fmt.Sprintf("отчёт по резолюции #%d: %s", id, req.Report)
			comment = (comment)
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO document_history (document_id, actor_id, event_type, comment)
				VALUES ($1, $2, 'resolution_reported', $3)`, docID, userID, comment); err != nil {
				return err
			}
			// Уведомление АВТОРУ резолюции: именно он должен принять отчёт, и
			// без уведомления резолюция зависла бы в состоянии «на отчёте».
			if authorID != 0 && authorID != userID {
				if _, err := tx.Exec(c.Context(), `
					INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, detail, requires_ack)
					VALUES ($1, $2, 'resolution_reported', '{}', $3, NULLIF($4::text,''), $5)`,
					authorID, docID, userID, req.Report,
					service.RequiresAck("resolution_reported")); err != nil {
					return err
				}
			}
		}
		return nil
	})
	if txErr != nil {
		return resolutionActionError(txErr)
	}
	if action == "report" && h.hub != nil && authorID != 0 && authorID != userID {
		h.hub.NotifyUsers([]int64{authorID}, docID, "resolution_reported")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Accept POST /api/resolutions/:id/accept — автор принимает отчёт.
// Body: { "executor_id": 12, "note": "…" }  — executor_id необязателен:
// без него принимаются отчёты ВСЕХ отчитавшихся.
func (h *ResolutionsHandler) Accept(c *fiber.Ctx) error {
	return h.authorDecision(c, true)
}

// Return POST /api/resolutions/:id/return — автор возвращает на доработку.
func (h *ResolutionsHandler) Return(c *fiber.Ctx) error {
	return h.authorDecision(c, false)
}

func (h *ResolutionsHandler) authorDecision(c *fiber.Ctx, accept bool) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		ExecutorUserID int64  `json:"executor_user_id"`
		Note           string `json:"note"`
		// Force — закрыть резолюцию, даже если исполнитель не отчитался
		// (, п. 5). Отдельный признак, а не «принимать всё
		// подряд»: обычное принятие отчёта должно по-прежнему требовать
		// отчёта, иначе руководитель закрывал бы резолюции, не читая их.
		Force bool `json:"force"`
	}
	_ = c.BodyParser(&req)
	req.Note = strings.TrimSpace(req.Note)
	if len([]rune(req.Note)) > 4000 {
		return fiber.NewError(fiber.StatusBadRequest, "текст длиннее 4000 знаков")
	}
	if accept && req.Force && req.Note == "" {
		// Закрытие без отчёта исполнителя обязано быть объяснено: в резолюции
		// не останется ни отчёта, ни причины, и через месяц будет непонятно,
		// на каком основании она исполнена.
		return fiber.NewError(fiber.StatusBadRequest,
			"закрытие резолюции без отчёта исполнителя требует заключения: напишите, на каком основании она считается исполненной")
	}
	if !accept && req.Note == "" {
		// Возврат без объяснения бесполезен: исполнитель не знает, что
		// переделывать, и вернёт то же самое.
		return fiber.NewError(fiber.StatusBadRequest,
			"укажите, что требуется доработать")
	}

	var docID int64
	var notify []int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		r, err := loadResolution(c, tx, id)
		if err != nil {
			return err
		}
		docID = r.DocumentID
		// Принимает отчёт АВТОР резолюции. Контролёр тоже вправе: его для
		// этого и назначают.
		// Принять или вернуть отчёт вправе автор резолюции, его действующий
		// заместитель и контролёр резолюции. Администратор системы — нет.
		if r.AuthorID != userID {
			var isCtl bool
			if err := tx.QueryRow(c.Context(),
				`SELECT EXISTS(SELECT 1 FROM resolutions WHERE id=$1 AND controller_id=$2)`,
				id, userID).Scan(&isCtl); err != nil {
				return err
			}
			if !isCtl {
				return errResForbidden
			}
		}
		if r.Status == "cancelled" {
			return errResClosed
		}

		// Номера параметров одинаковы в обеих ветках, поэтому условие по
		// конкретному исполнителю добавляется как $4 независимо от действия.
		// Подставлять значения в текст запроса нельзя — это прямой путь к
		// SQL-инъекции через текст примечания.
		args := []any{id, userID, req.Note}
		cond := ""
		if req.ExecutorUserID != 0 {
			args = append(args, req.ExecutorUserID)
			cond = " AND user_id = $4"
		}

		// Какие состояния исполнителя можно закрыть.
		//
		// Обычное принятие — только 'reported': принимают ОТЧЁТ, и без отчёта
		// принимать нечего. Закрытие по решению руководителя (Force, п. 5) —
		// любое незакрытое состояние: именно этого действия автору и не
		// хватало, когда исполнитель «отметил» что-то, но не отчитался.
		//
		// Список состояний — константа в тексте запроса, не из тела запроса:
		// подставлять сюда присланное значение означало бы дать клиенту
		// управлять условием UPDATE.
		accepted := "status = 'reported'"
		if accept && req.Force {
			accepted = "status IN ('open','in_progress','reported','returned')"
		}

		var rows pgx.Rows
		if accept {
			rows, err = tx.Query(c.Context(), `
				UPDATE resolution_executors
				   SET status = 'accepted', accepted_at = now(), accepted_by = $2,
				       return_note = NULL,
				       -- Если отчёта не было, в его место пишется заключение
				       -- руководителя: пустой отчёт у исполненной резолюции
				       -- читается как потерянные данные.
				       report = CASE WHEN coalesce(btrim(report),'') = ''
				                     THEN NULLIF($3,'') ELSE report END
				 WHERE resolution_id = $1 AND `+accepted+cond+`
				RETURNING user_id`, args...)
		} else {
			rows, err = tx.Query(c.Context(), `
				UPDATE resolution_executors
				   SET status = 'returned', return_note = NULLIF($3,''),
				       accepted_at = NULL, accepted_by = NULL
				 WHERE resolution_id = $1 AND status = 'reported'
				   -- $2 (кто возвращает) в этом запросе не нужен, но передаётся
				   -- общим списком параметров; без явного типа PostgreSQL
				   -- отклонял запрос, и «вернуть на доработку» не работало.
				   AND $2::bigint IS NOT NULL`+cond+`
				RETURNING user_id`, args...)
		}
		if err != nil {
			return err
		}
		for rows.Next() {
			var uid int64
			if err := rows.Scan(&uid); err != nil {
				rows.Close()
				return err
			}
			notify = append(notify, uid)
		}
		rows.Close()
		if err := rows.Err(); err != nil {
			return err
		}
		if len(notify) == 0 {
			return errResReportEmpty
		}

		if accept && req.Note != "" {
			if _, err := tx.Exec(c.Context(),
				`UPDATE resolutions SET close_note = $2 WHERE id = $1`, id, req.Note); err != nil {
				return err
			}
		}
		if err := service.RecalcResolutionStatus(c.Context(), tx, id, userID); err != nil {
			return err
		}

		event := "resolution_accepted"
		comment := fmt.Sprintf("отчёт по резолюции #%d принят", id)
		if accept && req.Force {
			comment = fmt.Sprintf("резолюция #%d закрыта руководителем без отчёта исполнителя", id)
		}
		if !accept {
			event = "resolution_returned"
			comment = fmt.Sprintf("резолюция #%d возвращена на доработку: %s", id, req.Note)
		} else if req.Note != "" {
			comment += ": " + req.Note
		}
		comment = (comment)
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, $3, $4)`, docID, userID, event, comment); err != nil {
			return err
		}
		for _, uid := range notify {
			if uid == userID {
				continue
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, detail, requires_ack)
				VALUES ($1, $2, $3, '{}', $4, NULLIF($5::text,''), $6)`,
				uid, docID, event, userID, comment, service.RequiresAck(event)); err != nil {
				return err
			}
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, errResReportEmpty) {
			if accept && req.Force {
				return fiber.NewError(fiber.StatusConflict,
					"закрывать нечего: по этой резолюции не осталось незакрытых исполнителей")
			}
			return fiber.NewError(fiber.StatusConflict,
				"нет отчётов, ожидающих решения: исполнитель ещё не отчитался. "+
					"Если результат известен вам иначе, резолюцию можно закрыть с заключением")
		}
		return resolutionActionError(txErr)
	}
	if h.hub != nil && len(notify) > 0 {
		kind := "resolution_accepted"
		if !accept {
			kind = "resolution_returned"
		}
		h.hub.NotifyUsers(notify, docID, kind)
	}
	return c.SendStatus(fiber.StatusOK)
}

// My GET /api/my/resolutions?status=open — резолюции, по которым я исполнитель.
//
// Нужен для раздела «мои поручения» и для счётчика: без него человек узнаёт о
// резолюции только из уведомления, а если оно пропущено — не узнаёт вовсе.
func (h *ResolutionsHandler) My(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	onlyOpen := c.Query("status", "open") == "open"

	cond := ""
	if onlyOpen {
		cond = " AND re.status IN ('open','in_progress','returned')"
	}
	type row struct {
		ResolutionID int64   `json:"resolution_id"`
		DocumentID   int64   `json:"document_id"`
		DocTitle     string  `json:"document_title"`
		OutNumber    *string `json:"outgoing_number,omitempty"`
		AuthorName   string  `json:"author_name"`
		Text         string  `json:"text"`
		DueDate      *string `json:"due_date,omitempty"`
		Status       string  `json:"status"`
		StatusLabel  string  `json:"status_label"`
		Responsible  bool    `json:"is_responsible"`
		Overdue      bool    `json:"overdue"`
		// Executors — исполнители (только для role=author).
		Executors string `json:"executors,omitempty"`
	}
	items := []row{}
	// role=author — резолюции, которые наложил сам пользователь («Ваши
	// резолюции»); по умолчанию — резолюции, где он исполнитель.
	if c.Query("role") == "author" {
		authCond := ""
		if onlyOpen {
			authCond = " AND r.status IN ('issued','in_progress','on_report')"
		}
		txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
			rows, err := tx.Query(c.Context(), `
				SELECT r.id, r.document_id, coalesce(d.title,''), d.outgoing_number,
				       coalesce(au.full_name,''), r.text, to_char(r.due_date,'YYYY-MM-DD'),
				       r.status::text,
				       (r.due_date IS NOT NULL AND r.due_date < current_date AND r.status <> 'done'),
				       coalesce((SELECT string_agg(u.full_name, ', ' ORDER BY u.full_name)
				                   FROM resolution_executors e JOIN users u ON u.id = e.user_id
				                  WHERE e.resolution_id = r.id), '')
				  FROM resolutions r
				  JOIN documents d ON d.id = r.document_id
				  LEFT JOIN users au ON au.id = r.author_id
				 WHERE r.author_id = $1 AND r.status <> 'cancelled'`+authCond+`
				 ORDER BY r.created_at DESC
				 LIMIT 500`, userID)
			if err != nil {
				return err
			}
			defer rows.Close()
			for rows.Next() {
				var x row
				if err := rows.Scan(&x.ResolutionID, &x.DocumentID, &x.DocTitle, &x.OutNumber,
					&x.AuthorName, &x.Text, &x.DueDate, &x.Status, &x.Overdue, &x.Executors); err != nil {
					return err
				}
				x.StatusLabel = authoredStatusLabel(x.Status)
				items = append(items, x)
			}
			return rows.Err()
		})
		if txErr != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить резолюции")
		}
		return c.JSON(fiber.Map{"items": items})
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT r.id, r.document_id, coalesce(d.title,''), d.outgoing_number,
			       coalesce(au.full_name,''), r.text, to_char(r.due_date,'YYYY-MM-DD'),
			       re.status::text, re.is_responsible,
			       (r.due_date IS NOT NULL AND r.due_date < current_date)
			  FROM resolution_executors re
			  JOIN resolutions r ON r.id = re.resolution_id
			  JOIN documents d ON d.id = r.document_id
			  LEFT JOIN users au ON au.id = r.author_id
			 WHERE re.user_id = $1 AND r.status <> 'cancelled'`+cond+`
			 ORDER BY (r.due_date IS NULL), r.due_date, r.created_at
			 LIMIT 500`, userID)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var x row
			if err := rows.Scan(&x.ResolutionID, &x.DocumentID, &x.DocTitle, &x.OutNumber,
				&x.AuthorName, &x.Text, &x.DueDate, &x.Status, &x.Responsible, &x.Overdue); err != nil {
				return err
			}
			x.StatusLabel = service.ResolutionExecLabel(x.Status)
			items = append(items, x)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить резолюции")
	}
	// Флаги доступных действий здесь НЕ проставляются, и это не упущение:
	// этот обработчик отдаёт СПИСОК «моих резолюций» по всем документам, то
	// есть плоские строки другого вида (type row выше), а не карточки
	// резолюций. Действия выполняются в карточке документа, где список
	// приходит из List вместе с флагами.
	return c.JSON(fiber.Map{"items": items})
}

// authoredStatusLabel — подпись общего статуса резолюции (для её автора).
func authoredStatusLabel(s string) string {
	switch s {
	case "issued":
		return "Выдана"
	case "in_progress":
		return "В работе"
	case "on_report":
		return "Есть отчёт"
	case "done":
		return "Исполнена"
	case "cancelled":
		return "Снята"
	}
	return s
}

// resolutionActionError переводит внутренние ошибки в коды и понятные тексты.
// Одно место на все действия: иначе один и тот же случай описывался бы в
// каждом обработчике по-своему.
func resolutionActionError(err error) error {
	switch {
	case errors.Is(err, errResForbidden):
		return fiber.NewError(fiber.StatusForbidden, "нет права на это действие с резолюцией")
	// Три разных отказа вместо одного общего (пп. 4 и 15). Текст ошибки
	// передаётся как есть: в него уже вложено объяснение — роль, перечень
	// подразделений или ФИО тех, кому поручить нельзя. Общее «запрещено»
	// заставляло человека угадывать, что сделать.
	case errors.Is(err, errResNotChief),
		errors.Is(err, errResOutOfScope),
		errors.Is(err, errResExecOutOfScope):
		return fiber.NewError(fiber.StatusForbidden, err.Error())
	case errors.Is(err, errResAlreadyIssued):
		return fiber.NewError(fiber.StatusConflict, err.Error())
	case errors.Is(err, errResClosed):
		return fiber.NewError(fiber.StatusConflict,
			"резолюция уже закрыта: изменять её нельзя")
	case errors.Is(err, errResAccepted):
		return fiber.NewError(fiber.StatusConflict, err.Error())
	case errors.Is(err, errResDuePast), errors.Is(err, errResBadExecutor):
		return fiber.NewError(fiber.StatusUnprocessableEntity, err.Error())
	case errors.Is(err, pgx.ErrNoRows):
		return fiber.NewError(fiber.StatusNotFound, "резолюция не найдена")
	case strings.Contains(err.Error(), "не может быть позже срока вышестоящей"):
		return fiber.NewError(fiber.StatusUnprocessableEntity, err.Error())
	case strings.Contains(err.Error(), "uq_resolution_one_responsible"):
		return fiber.NewError(fiber.StatusConflict,
			"у резолюции может быть только один ответственный исполнитель")
	}
	log.Printf("resolution action failed: %v", err)
	return fiber.NewError(fiber.StatusInternalServerError, "не удалось выполнить действие")
}

// Cancel POST /api/resolutions/:id/cancel — отозвать резолюцию.
//
// Нужна, когда резолюция наложена по ошибке (не тот документ, не то
// поручение). Отозванная остаётся в карточке со статусом «Отменена» и
// причиной; на тот же экземпляр документа после этого можно наложить новую.
// Тело: { "reason": "..." } — причина обязательна.
func (h *ResolutionsHandler) Cancel(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		Reason string `json:"reason"`
	}
	_ = c.BodyParser(&req)
	req.Reason = strings.TrimSpace(req.Reason)
	if req.Reason == "" || len([]rune(req.Reason)) > 2000 {
		return fiber.NewError(fiber.StatusBadRequest, "укажите причину отзыва резолюции (до 2000 знаков)")
	}
	var docID int64
	var notify []int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		r, err := loadResolution(c, tx, id)
		if err != nil {
			return err
		}
		docID = r.DocumentID
		if r.AuthorID != userID {
			return errResForbidden
		}
		if r.Status == "done" || r.Status == "cancelled" {
			return errResClosed
		}
		rows, err := tx.Query(c.Context(), `
			UPDATE resolution_executors SET status = 'cancelled'
			 WHERE resolution_id = $1 AND status <> 'accepted' RETURNING user_id`, id)
		if err != nil {
			return err
		}
		for rows.Next() {
			var uid int64
			if err := rows.Scan(&uid); err != nil {
				rows.Close()
				return err
			}
			notify = append(notify, uid)
		}
		rows.Close()
		if err := rows.Err(); err != nil {
			return err
		}
		if _, err := tx.Exec(c.Context(), `
			UPDATE resolutions SET status = 'cancelled', closed_at = now(), closed_by = $2, close_note = $3
			 WHERE id = $1`, id, userID, req.Reason); err != nil {
			return err
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, 'resolution_cancelled', $3)`, docID, userID,
			fmt.Sprintf("резолюция #%d отозвана: %s", id, req.Reason)); err != nil {
			return err
		}
		for _, uid := range notify {
			if uid == userID {
				continue
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, detail, requires_ack)
				VALUES ($1, $2, 'resolution', '{}', $3, $4, $5)`,
				uid, docID, userID, "Резолюция отозвана: "+req.Reason, service.RequiresAck("resolution")); err != nil {
				return err
			}
		}
		return nil
	})
	if txErr != nil {
		return resolutionActionError(txErr)
	}
	if h.hub != nil && len(notify) > 0 {
		h.hub.NotifyUsers(notify, docID, "resolution")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Reassign POST /api/resolutions/:id/reassign — заменить исполнителя.
//
// Тело: { "from_user_id", "to_user_id", "reason" }. Прежний исполнитель
// снимается (его запись остаётся в карточке как «Снято»), новый получает
// поручение в той же роли (ответственный/соисполнитель), доступ к документу
// и уведомление. Замена записывается в журнал переназначений и в историю.
func (h *ResolutionsHandler) Reassign(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		FromUserID int64  `json:"from_user_id"`
		ToUserID   int64  `json:"to_user_id"`
		Reason     string `json:"reason"`
	}
	if err := c.BodyParser(&req); err != nil || req.FromUserID == 0 || req.ToUserID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "укажите, кого и на кого заменить")
	}
	req.Reason = strings.TrimSpace(req.Reason)
	if req.Reason == "" || len([]rune(req.Reason)) > 2000 {
		return fiber.NewError(fiber.StatusBadRequest, "укажите причину замены исполнителя (до 2000 знаков)")
	}
	if req.FromUserID == req.ToUserID {
		return fiber.NewError(fiber.StatusBadRequest, "новый исполнитель совпадает с прежним")
	}
	var docID int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		r, err := loadResolution(c, tx, id)
		if err != nil {
			return err
		}
		docID = r.DocumentID
		if r.AuthorID != userID {
			return errResForbidden
		}
		if r.Status == "done" || r.Status == "cancelled" {
			return errResClosed
		}
		var responsible bool
		var execStatus string
		if err := tx.QueryRow(c.Context(), `
			SELECT is_responsible, status::text FROM resolution_executors
			 WHERE resolution_id = $1 AND user_id = $2 FOR UPDATE`, id, req.FromUserID).Scan(&responsible, &execStatus); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return errResBadExecutor
			}
			return err
		}
		if execStatus == "accepted" || execStatus == "cancelled" {
			return errResClosed
		}
		var active bool
		if err := tx.QueryRow(c.Context(), `SELECT EXISTS (SELECT 1 FROM users WHERE id = $1 AND is_active)`, req.ToUserID).Scan(&active); err != nil {
			return err
		}
		if !active {
			return errResBadExecutor
		}
		bad, err := service.ResolutionExecutorsOutOfScope(c.Context(), tx, userID, []int64{req.ToUserID})
		if err != nil {
			return err
		}
		if len(bad) > 0 {
			return fmt.Errorf("%w: %s", errResExecOutOfScope, strings.Join(bad, ", "))
		}
		// Прежний снимается и перестаёт быть ответственным (ответственный у
		// резолюции один — это ограничение БД).
		if _, err := tx.Exec(c.Context(), `
			UPDATE resolution_executors SET status = 'cancelled', is_responsible = FALSE
			 WHERE resolution_id = $1 AND user_id = $2`, id, req.FromUserID); err != nil {
			return err
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO resolution_executors (resolution_id, user_id, is_responsible, reassigned_from)
			VALUES ($1, $2, $3, $4)
			ON CONFLICT (resolution_id, user_id) DO UPDATE
			   SET status = 'open', is_responsible = EXCLUDED.is_responsible, reassigned_from = EXCLUDED.reassigned_from,
			       report = NULL, reported_at = NULL, accepted_at = NULL, accepted_by = NULL, return_note = NULL`,
			id, req.ToUserID, responsible, req.FromUserID); err != nil {
			return err
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO reassignments (object_kind, object_id, document_id, from_user_id, to_user_id, actor_id, reason)
			VALUES ('resolution_executor', $1, $2, $3, $4, $5, $6)`, id, docID, req.FromUserID, req.ToUserID, userID, req.Reason); err != nil {
			return err
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_access (document_id, user_id, access_reason)
			VALUES ($1, $2, 'executor') ON CONFLICT DO NOTHING`, docID, req.ToUserID); err != nil {
			return err
		}
		var fromName, toName string
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(full_name,'') FROM users WHERE id=$1`, req.FromUserID).Scan(&fromName)
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(full_name,'') FROM users WHERE id=$1`, req.ToUserID).Scan(&toName)
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, 'resolution_reassigned', $3)`, docID, userID,
			fmt.Sprintf("резолюция #%d: исполнитель %s заменён на %s. Причина: %s", id, fromName, toName, req.Reason)); err != nil {
			return err
		}
		for uid, text := range map[int64]string{
			req.ToUserID:   "Вам поручено исполнение резолюции: " + r.Text,
			req.FromUserID: "Вы сняты с исполнения резолюции: " + req.Reason,
		} {
			if uid == userID {
				continue
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, detail, requires_ack)
				VALUES ($1, $2, 'resolution', '{}', $3, $4, $5)`,
				uid, docID, userID, text, service.RequiresAck("resolution")); err != nil {
				return err
			}
		}
		return service.RecalcResolutionStatus(c.Context(), tx, id, userID)
	})
	if txErr != nil {
		return resolutionActionError(txErr)
	}
	if h.hub != nil {
		h.hub.NotifyUsers([]int64{req.FromUserID, req.ToUserID}, docID, "resolution")
	}
	return c.SendStatus(fiber.StatusOK)
}
