package handlers

import (
	"errors"
	"fmt"
	"log"
	"strconv"
	"strings"

	"athena/backend/internal/authdom"
	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/service"
	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type AuthHandler struct {
	pool     *pgxpool.Pool
	auth     *service.AuthService
	sessions *service.SessionService
	audit    *service.AuditService
	domains  *authdom.Store
	limiter  *loginLimiter
}

func NewAuthHandler(pool *pgxpool.Pool, auth *service.AuthService,
	sessions *service.SessionService, audit *service.AuditService, domains *authdom.Store) *AuthHandler {
	return &AuthHandler{pool: pool, auth: auth, sessions: sessions, audit: audit, domains: domains, limiter: newLoginLimiter()}
}

type loginRequest struct {
	// Login — «ivanov» (локальная учётная запись), «ivanov@DOMAIN1.LOCAL» или
	// «DOMAIN1\ivanov» (учётная запись домена, проверяется в его LDAP).
	Login    string `json:"login"`
	Password string `json:"password"`
	// Domain — необязательно: область, выбранная на странице входа. Имеет
	// смысл только если в самом логине домен не указан.
	Domain string `json:"domain"`
	// Необязательное название рабочего места. Если клиент его передаёт, в
	// журнале и в сообщении о вытеснении будет видно не только IP, но и
	// понятное человеку имя АРМ.
	Workstation string `json:"workstation"`
}

func sessionMeta(c *fiber.Ctx, workstation string) service.SessionMeta {
	return service.SessionMeta{
		IP:          middleware.ClientIP(c),
		IPPeer:      middleware.PeerIP(c),
		IPChain:     middleware.ForwardedChain(c),
		UserAgent:   c.Get("User-Agent"),
		Workstation: strings.TrimSpace(workstation),
	}
}

// loginDenied — отказ во входе с машинно-читаемой причиной (для страницы
// «вход по Kerberos не выполнен») и записью в журнал аудита.
func (h *AuthHandler) loginDenied(c *fiber.Ctx, status int, event, reason, msg, login string, userID int64, meta service.SessionMeta, details map[string]any) error {
	if details == nil {
		details = map[string]any{}
	}
	details["reason"] = reason
	h.audit.Write(service.AuditEvent{
		ActorID: userID, ActorLogin: login, Event: event, Outcome: "denied",
		HTTPMethod: c.Method(), HTTPPath: c.Path(), HTTPStatus: status,
		IP: meta.IP, IPPeer: meta.IPPeer, IPChain: meta.IPChain, UserAgent: meta.UserAgent,
		Details: details,
	})
	return c.Status(status).JSON(fiber.Map{"error": msg, "reason": reason})
}

// Login POST /api/auth/login — вход по паролю: локальная учётная запись
// (bcrypt) либо учётная запись домена (LDAP). Доступен только на порту входа
// по паролю; на порту Kerberos отклоняется.
func (h *AuthHandler) Login(c *fiber.Ctx) error {
	var req loginRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	meta := sessionMeta(c, req.Workstation)
	if middleware.AuthMode(c) == middleware.AuthModeKerberos {
		return h.loginDenied(c, fiber.StatusForbidden, "auth.login_failed", "wrong_port",
			"на этом адресе вход выполняется только по Kerberos; вход по паролю — на другом порту", req.Login, 0, meta, nil)
	}
	if strings.TrimSpace(req.Login) == "" || req.Password == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите логин и пароль")
	}
	ctx := c.Context()

	// Защита от подбора пароля (см. login_limiter.go).
	if blocked, wait := h.limiter.blocked(ctx, req.Login, meta.IP); blocked {
		c.Set(fiber.HeaderRetryAfter, strconv.Itoa(int(wait.Seconds())+1))
		return h.loginDenied(c, fiber.StatusTooManyRequests, "auth.login_failed", "too_many_attempts",
			fmt.Sprintf("слишком много неудачных попыток входа — повторите через %d мин.", int(wait.Minutes())+1),
			req.Login, 0, meta, nil)
	}

	name, domName := authdom.SplitLogin(req.Login)
	if domName == "" {
		domName = strings.TrimSpace(req.Domain)
	}

	var userID int64
	var login string
	var isAdmin bool
	details := map[string]any{"workstation": meta.Workstation}

	invalid := func(shown string, extra map[string]any) error {
		h.limiter.fail(ctx, req.Login, meta.IP)
		// Неудачная попытка входа пишется в журнал аудита ОБЯЗАТЕЛЬНО: серия
		// таких попыток — это подбор пароля. Ответ один и тот же для «нет
		// такого пользователя», «нет такого домена» и «неверный пароль».
		return h.loginDenied(c, fiber.StatusUnauthorized, "auth.login_failed", "invalid_credentials",
			"неверный логин или пароль", shown, 0, meta, extra)
	}

	if domName == "" {
		// --- локальная учётная запись ---
		tx, err := h.pool.Begin(ctx)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "db error")
		}
		defer tx.Rollback(ctx)
		userID, login, isAdmin, err = h.auth.Login(ctx, tx, name, req.Password)
		if err != nil {
			if errors.Is(err, service.ErrInvalidCredentials) {
				return invalid(req.Login, nil)
			}
			// Реальная причина (SQL/схема) уходит в лог сервера, клиенту —
			// общий текст.
			log.Printf("auth login failed for %q: %v", req.Login, err)
			return fiber.NewError(fiber.StatusInternalServerError, "auth error")
		}
		_ = tx.Commit(ctx)
		details["method"] = "password"
	} else {
		// --- учётная запись домена: проверка в LDAP этого домена ---
		d, ok := h.domains.Resolve(ctx, domName)
		if !ok || !d.LDAPEnabled {
			return invalid(req.Login, map[string]any{"domain": domName, "cause": "домен не найден или LDAP выключен"})
		}
		canon := authdom.CanonicalLogin(name, d.Realm)
		lu, err := h.domains.Authenticate(d, strings.TrimSpace(name), req.Password)
		if err != nil {
			if errors.Is(err, authdom.ErrLDAPInvalidCredentials) {
				return invalid(canon, map[string]any{"domain": d.Realm})
			}
			log.Printf("ldap auth %s: %v", canon, err)
			if errors.Is(err, authdom.ErrLDAPUnavailable) {
				return h.loginDenied(c, fiber.StatusServiceUnavailable, "auth.login_failed", "ldap_unavailable",
					"каталог домена "+d.Realm+" недоступен, повторите попытку позже", canon, 0, meta, map[string]any{"domain": d.Realm})
			}
			return h.loginDenied(c, fiber.StatusBadGateway, "auth.login_failed", "ldap_error",
				"ошибка проверки в каталоге домена "+d.Realm+" — обратитесь к администратору", canon, 0, meta,
				map[string]any{"domain": d.Realm, "cause": err.Error()})
		}
		u, derr := h.resolveDomainUser(c, d, canon, &lu)
		if derr != nil {
			return h.loginDenied(c, derr.status, "auth.login_failed", derr.reason, derr.msg, canon, derr.userID, meta, map[string]any{"domain": d.Realm})
		}
		userID, login, isAdmin = u.id, u.login, u.isAdmin
		details["method"] = "ldap"
		details["domain"] = d.Realm
		if u.created {
			details["user_created"] = true
		}
	}
	h.limiter.success(ctx, req.Login, meta.IP)
	return h.openSession(c, userID, login, isAdmin, meta, "auth.login", details)
}

type domainUser struct {
	id      int64
	login   string
	isAdmin bool
	created bool
}

type domainDeny struct {
	status int
	reason string
	msg    string
	userID int64
}

// resolveDomainUser сопоставляет подтверждённую доменную учётную запись
// (логин вида имя@REALM) с пользователем системы; при включённом у домена
// автосоздании заводит его (без ролей, кроме роли «исполнитель», которую
// даёт триггер).
func (h *AuthHandler) resolveDomainUser(c *fiber.Ctx, d authdom.Domain, canon string, lu *authdom.LDAPUser) (domainUser, *domainDeny) {
	ctx := c.Context()
	var u domainUser
	var active bool
	err := h.pool.QueryRow(ctx, `
		SELECT u.id, u.login, u.is_active,
		       EXISTS(SELECT 1 FROM user_roles ur WHERE ur.user_id = u.id AND ur.role = 'admin')
		  FROM users u WHERE u.login = $1 AND u.domain_id = $2`, canon, d.ID).Scan(&u.id, &u.login, &active, &u.isAdmin)
	if err == nil {
		if !active {
			return u, &domainDeny{fiber.StatusForbidden, "inactive", "учётная запись заблокирована", u.id}
		}
		return u, nil
	}
	if !errors.Is(err, pgx.ErrNoRows) {
		log.Printf("domain user lookup %s: %v", canon, err)
		return u, &domainDeny{fiber.StatusInternalServerError, "error", "ошибка входа", 0}
	}
	if !d.AutoCreateUsers {
		return u, &domainDeny{fiber.StatusForbidden, "not_mapped",
			"учётная запись " + canon + " не заведена в системе — обратитесь к администратору", 0}
	}
	// При входе по Kerberos данных каталога ещё нет — берём их из LDAP
	// домена, если он настроен; иначе ФИО = логин (администратор поправит).
	if lu == nil && d.LDAPEnabled {
		name, _ := authdom.SplitLogin(canon)
		if found, e := h.domains.Lookup(d, name); e == nil {
			lu = &found
		} else {
			log.Printf("ldap lookup %s: %v", canon, e)
		}
	}
	fullName, position, email := canon, "", ""
	if lu != nil {
		if lu.FullName != "" {
			fullName = lu.FullName
		}
		position, email = lu.Position, lu.Email
	}
	// password_hash = '!' — заведомо не bcrypt: войти локальным паролем под
	// доменной учётной записью невозможно.
	err = h.pool.QueryRow(ctx, `
		INSERT INTO users (login, password_hash, full_name, position, primary_department_id, numbering_department_id, domain_id, email)
		VALUES ($1, '!', $2, NULLIF($3,''), $4, $4, $5, NULLIF($6,''))
		ON CONFLICT (lower(login)) DO NOTHING
		RETURNING id`, canon, fullName, position, d.DefaultDepartmentID, d.ID, email).Scan(&u.id)
	if err != nil {
		log.Printf("domain user create %s: %v", canon, err)
		return u, &domainDeny{fiber.StatusInternalServerError, "error", "не удалось завести учётную запись", 0}
	}
	u.login, u.created = canon, true
	return u, nil
}

// openSession — общий конец любого входа (пароль, LDAP, Kerberos): сессия,
// токен, запись в журнал.
func (h *AuthHandler) openSession(c *fiber.Ctx, userID int64, login string, isAdmin bool,
	meta service.SessionMeta, event string, details map[string]any) error {
	ctx := c.Context()
	//, п. 8 — одна учётная запись = одно рабочее место.
	//
	// Порядок важен: сначала выпускаем jti, затем открываем сессию, и только
	// потом отдаём токен. Если открыть сессию не удалось (политика deny и уже
	// есть действующий сеанс), токен не выдаётся вовсе.
	jti, err := service.NewJTI()
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось создать сессию")
	}
	token, exp, err := h.auth.IssueToken(userID, login, isAdmin, jti)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "token error")
	}

	sessionID, displaced, err := h.sessions.Open(ctx, userID, jti, exp, meta)
	if err != nil {
		if errors.Is(err, service.ErrSessionConflict) {
			msg := "Вход запрещён: под этой учётной записью уже работают с другого рабочего места"
			if displaced != nil {
				where := displaced.Workstation
				if where == "" {
					where = displaced.IP
				}
				if where != "" {
					msg += " (" + where + ")"
				}
				msg += ", вход выполнен " + displaced.CreatedAt.Local().Format("02.01.2006 15:04")
			}
			msg += ". Завершите тот сеанс или обратитесь к администратору."
			return h.loginDenied(c, fiber.StatusConflict, "auth.login_denied_session", "session_conflict", msg, login, userID, meta, nil)
		}
		log.Printf("session open failed for user %d: %v", userID, err)
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось создать сессию")
	}

	if details == nil {
		details = map[string]any{}
	}
	if displaced != nil {
		details["displaced_session_id"] = displaced.ID
		details["displaced_ip"] = displaced.IP
	}
	h.audit.Write(service.AuditEvent{
		ActorID: userID, ActorLogin: login, SessionID: sessionID,
		Event: event, Outcome: "ok",
		HTTPMethod: c.Method(), HTTPPath: c.Path(), HTTPStatus: fiber.StatusOK,
		IP: meta.IP, IPPeer: meta.IPPeer, IPChain: meta.IPChain, UserAgent: meta.UserAgent, Details: details,
	})

	if err := middleware.SetSessionCookies(c, token, exp, true); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось создать сессию")
	}
	resp := fiber.Map{
		"user_id":    userID,
		"login":      login,
		"expires_at": exp,
	}
	// Человеку важно знать, что его вход кого-то вытеснил: если это был не он,
	// значит учётной записью пользуется кто-то ещё.
	if displaced != nil {
		where := displaced.Workstation
		if where == "" {
			where = displaced.IP
		}
		resp["displaced"] = fiber.Map{
			"where":      where,
			"created_at": displaced.CreatedAt,
		}
	}
	return c.JSON(resp)
}

// Logout POST /api/logout — корректное завершение сеанса.
//
// Нужен именно эндпоинт, а не просто удаление токена на клиенте: при политике
// deny человек иначе не смог бы войти с другого АРМ до истечения срока токена.
func (h *AuthHandler) Logout(c *fiber.Ctx) error {
	jti, _ := c.Locals(middleware.CtxJTI).(string)
	userID, _ := c.Locals(middleware.CtxUserID).(int64)
	login, _ := c.Locals(middleware.CtxLogin).(string)
	sid, _ := c.Locals(middleware.CtxSessionID).(int64)
	if err := h.sessions.Close(c.Context(), jti, "выход пользователя"); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось завершить сеанс")
	}
	middleware.ClearSessionCookies(c)
	h.audit.Write(service.AuditEvent{
		ActorID: userID, ActorLogin: login, SessionID: sid,
		Event: "auth.logout", Outcome: "ok",
		HTTPMethod: c.Method(), HTTPPath: c.Path(), HTTPStatus: fiber.StatusOK,
		IP: middleware.ClientIP(c), IPPeer: middleware.PeerIP(c), IPChain: middleware.ForwardedChain(c), UserAgent: c.Get("User-Agent"),
	})
	return c.SendStatus(fiber.StatusOK)
}

// Me GET /api/me — текущий пользователь и его роли (для гейтинга UI: кнопки
// «Новый документ» и т.п. показываются только при наличии соответствующей роли).
func (h *AuthHandler) Me(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	login, _ := c.Locals(middleware.CtxLogin).(string)

	var roles []string
	var fullName, position string
	// вкладку «Отчётность» не показывать тому, у кого
	// нет роли «формирование отчётности». Признак считается здесь, а не
	// отдельным запросом из интерфейса: профиль запрашивается один раз при
	// входе, и добавить в него поле дешевле, чем ещё один запрос на каждую
	// загрузку страницы.
	//
	// Считается именно ОБЛАСТЬЮ отчётности, а не наличием роли: роль reporter
	// выдаётся В ПОДРАЗДЕЛЕНИИ, и выданная без подразделения она не даёт
	// ничего. Показать вкладку в таком случае значило бы привести человека к
	// пустому экрану.
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `SELECT coalesce(full_name,''), coalesce(position,'') FROM users WHERE id=$1`, userID).Scan(&fullName, &position); e != nil {
			return e
		}
		rows, err := tx.Query(c.Context(), `SELECT DISTINCT role::text FROM user_roles WHERE user_id=$1`, userID)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r string
			if err := rows.Scan(&r); err != nil {
				return err
			}
			roles = append(roles, r)
		}
		if err := rows.Err(); err != nil {
			return err
		}
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить профиль")
	}
	if roles == nil {
		roles = []string{}
	}
	return c.JSON(fiber.Map{
		"user_id": userID, "login": login, "full_name": fullName, "position": position,
		"is_admin": isAdmin, "roles": roles,
		// Производные флаги для удобства фронта.
		"can_create": contains(roles, "author"),
		// Флага can_report в профиле больше нет: сводная отчётность убрана, а
		// право на отчёт по КОНКРЕТНОМУ документу считается по участию в нём
		// и приходит в ответе карточки документа (can_report там же).
		// Роль «может ставить резолюции» (в базе — chief): по этому признаку
		// интерфейс решает, показывать ли средства работы с резолюциями.
		"is_chief": isAdmin || contains(roles, "chief"),
	})
}

func contains(ss []string, v string) bool {
	for _, s := range ss {
		if s == v {
			return true
		}
	}
	return false
}

// ТЕКУЩИЙ токен ещё валиден (эндпоинт под JWTAuth). Фронт вызывает его
// проактивно, поэтому активная сессия не «протухает» на ровном месте, а на
// истёкшем токене клиент уходит на вход (401 обрабатывается на фронте).
func (h *AuthHandler) Refresh(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	login, _ := c.Locals(middleware.CtxLogin).(string)
	// jti СОХРАНЯЕТСЯ: продление токена — это тот же сеанс, а не новый вход.
	// Если выпустить новый jti, продление выглядело бы как вход с другого АРМ
	// и вытесняло бы само себя — пользователя выбрасывало бы каждые 20 минут.
	jti, _ := c.Locals(middleware.CtxJTI).(string)
	token, exp, err := h.auth.IssueToken(userID, login, isAdmin, jti)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "token error")
	}
	// Срок сессии продлевается вместе с токеном, иначе сессия истекла бы
	// раньше токена и человека выбросило бы при живом токене.
	if jti != "" {
		if err := h.sessions.Extend(c.Context(), jti, exp); err != nil {
			log.Printf("не удалось продлить сессию %s: %v", jti, err)
		}
	}
	if err := middleware.SetSessionCookies(c, token, exp, false); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось продлить сеанс")
	}
	return c.JSON(fiber.Map{"user_id": userID, "login": login, "expires_at": exp})
}
