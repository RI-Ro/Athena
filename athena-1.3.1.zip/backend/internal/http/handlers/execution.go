package handlers

import (
	"errors"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/service"
	"athena/backend/internal/ws"
)

type ExecutionHandler struct {
	pool *pgxpool.Pool
	exec *service.ExecutionService
	hub  *ws.Hub
}

func NewExecutionHandler(pool *pgxpool.Pool, exec *service.ExecutionService, hub *ws.Hub) *ExecutionHandler {
	return &ExecutionHandler{pool: pool, exec: exec, hub: hub}
}

type completeRequest struct {
	Note string `json:"note"`
	// Reason — причина отмены (только для Cancel). Отдельное поле, а не
	// переиспользованный Note: отчёт об исполнении и причина его отмены —
	// разные тексты, и складывать их в одно поле значило бы однажды записать
	// причину отмены в отчёт.
	Reason string `json:"reason"`
}

// executionError переводит ошибки службы в коды ответа.
//
// Вынесено в одну функцию, потому что три обработчика (простановка, изменение,
// отмена) отвечают на один и тот же набор причин отказа. Три копии этого
// switch разошлись бы, и человек получал бы на одну и ту же причину разные
// сообщения в зависимости от кнопки.
func executionError(err error) error {
	switch {
	case errors.Is(err, service.ErrExecutionNoteRequired):
		return fiber.NewError(fiber.StatusBadRequest, "укажите отчёт о выполнении (обязательное поле)")
	case errors.Is(err, service.ErrCancelReasonRequired):
		return fiber.NewError(fiber.StatusBadRequest, "укажите причину отмены отметки об исполнении")
	case errors.Is(err, service.ErrNoIncomingInstance):
		return fiber.NewError(fiber.StatusConflict,
			"по вашему подразделению входящий номер ещё не присвоен — отмечать нечего")
	case errors.Is(err, service.ErrNotRecipient):
		// Текст перечисляет основания, потому что иначе человек не понимает,
		// что ему делать: идти к руководителю за резолюцией, к дежурному за
		// ознакомлением или к администратору за ролью.
		return fiber.NewError(fiber.StatusForbidden,
			"отметку об исполнении по этому документу может поставить адресат рассылки, "+
				"сотрудник с ролью «может ставить отметки о выполнении» в этом подразделении, "+
				"ознакомленный с документом или исполнитель резолюции по нему")
	case errors.Is(err, service.ErrAlreadyDone):
		return fiber.NewError(fiber.StatusConflict,
			"отметка об исполнении по вашему входящему номеру уже проставлена — её можно изменить или отменить")
	case errors.Is(err, service.ErrNotExecuted):
		return fiber.NewError(fiber.StatusConflict,
			"отметка об исполнении не проставлена — изменять или отменять нечего")
	case errors.Is(err, service.ErrDocumentArchived):
		return fiber.NewError(fiber.StatusConflict,
			"документ помещён в архив: изменения невозможны")
	case errors.Is(err, pgx.ErrNoRows):
		return fiber.NewError(fiber.StatusNotFound, "документ не найден")
	default:
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось выполнить действие с отметкой об исполнении")
	}
}

func docIDParam(c *fiber.Ctx) (int64, error) {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return 0, fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор документа")
	}
	return id, nil
}

// Complete POST /api/documents/:id/complete — отметка об исполнении по
// входящему номеру подразделения. Когда закрыты все входящие номера, документ
// переходит в 'executed'.
func (h *ExecutionHandler) Complete(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := docIDParam(c)
	if err != nil {
		return err
	}
	var req completeRequest
	_ = c.BodyParser(&req)

	var becameExecuted bool
	var interested []int64
	kind := "execution_done"
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		b, err := h.exec.MarkCompleted(c.Context(), tx, docID, userID, req.Note)
		if err != nil {
			return err
		}
		becameExecuted = b
		if b {
			kind = "document_executed"
		}
		// Уведомление в той же транзакции: тогда оно не может появиться
		// раньше самой отметки (и не потеряется, если отметка откатится).
		ids, err := service.NotifyDocumentEventDetail(c.Context(), tx, docID,
			kind, userID, req.Note, `{}`)
		if err != nil {
			return err
		}
		interested = ids
		return nil
	})
	if txErr != nil {
		return executionError(txErr)
	}
	if h.hub != nil && len(interested) > 0 {
		h.hub.NotifyUsers(interested, docID, kind)
	}
	return c.JSON(fiber.Map{"executed": becameExecuted})
}

// ChangeMark PATCH /api/documents/:id/complete — изменить отчёт в уже
// проставленной отметке.
func (h *ExecutionHandler) ChangeMark(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := docIDParam(c)
	if err != nil {
		return err
	}
	var req completeRequest
	_ = c.BodyParser(&req)

	var interested []int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := h.exec.ChangeMark(c.Context(), tx, docID, userID, req.Note); err != nil {
			return err
		}
		ids, err := service.NotifyDocumentEventDetail(c.Context(), tx, docID,
			"execution_changed", userID, req.Note, `{}`)
		if err != nil {
			return err
		}
		interested = ids
		return nil
	})
	if txErr != nil {
		return executionError(txErr)
	}
	if h.hub != nil && len(interested) > 0 {
		h.hub.NotifyUsers(interested, docID, "execution_changed")
	}
	return c.SendStatus(fiber.StatusOK)
}

// CancelMark DELETE /api/documents/:id/complete — отменить отметку об
// исполнении. Причина обязательна.
//
// Метод DELETE при обязательном теле запроса — намеренно: отменяется именно
// ресурс «отметка об исполнении», и отдельный путь вида
// /complete/cancel создавал бы ощущение, что это ещё одно действие над
// документом, а не снятие уже существующей отметки. Fiber тело у DELETE
// читает без оговорок.
func (h *ExecutionHandler) CancelMark(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := docIDParam(c)
	if err != nil {
		return err
	}
	var req completeRequest
	_ = c.BodyParser(&req)

	var interested []int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := h.exec.CancelMark(c.Context(), tx, docID, userID, req.Reason); err != nil {
			return err
		}
		// Отмена возвращает документ в работу, и это касается всех, кто его
		// видит: иначе у коллеги документ остался бы в «исполненных» до
		// перезагрузки страницы. Уведомление создаётся в ТОЙ ЖЕ транзакции,
		// чтобы оно не могло появиться у человека раньше самого изменения.
		ids, err := service.NotifyDocumentEventDetail(c.Context(), tx, docID,
			"execution_cancelled", userID, req.Reason, `{}`)
		if err != nil {
			return err
		}
		interested = ids
		return nil
	})
	if txErr != nil {
		return executionError(txErr)
	}
	if h.hub != nil && len(interested) > 0 {
		h.hub.NotifyUsers(interested, docID, "execution_cancelled")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Status GET /api/documents/:id/execution — состояние отметки по входящему
// номеру текущего пользователя и то, что он с ней может сделать.
//
// Зачем отдельный запрос. Интерфейс сам решал, показывать ли кнопку «Отметить
// исполненным», и делал это по признаку «я адресат»: отсюда и жалоба п. 21 —
// у исполнителя, не являющегося адресатом, кнопки не было, хотя право у него
// есть. Теперь право считает сервер — тем же условием, которым он его потом и
// проверяет, поэтому «кнопка есть» и «действие разрешено» разойтись не могут.
func (h *ExecutionHandler) Status(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := docIDParam(c)
	if err != nil {
		return err
	}

	var st service.ExecutionStatus
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		s, err := h.exec.Status(c.Context(), tx, docID, userID)
		if err != nil {
			return err
		}
		st = s
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить состояние отметки об исполнении")
	}
	return c.JSON(st)
}
