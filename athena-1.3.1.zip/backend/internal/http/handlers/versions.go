package handlers

import (
	"errors"
	"fmt"
	"strconv"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
)

// VersionsHandler — версионность карточек и вложений.
//
// ГДЕ ИМЕННО СОЗДАЮТСЯ ВЕРСИИ. Не здесь. Версия карточки пишется ТРИГГЕРОМ
// trg_document_version на таблице documents, версия файла — триггером
// trg_archive_document_file на document_files (миграции 0023 и 0024). Это
// сделано сознательно: документ меняют много разных обработчиков
// (редактирование, регистрация входящего, постановка на контроль, смена
// статуса, архивирование), и любой пропущенный вызов «создай версию» означал
// бы дыру в истории изменений — причём незаметную, потому что в интерфейсе всё
// выглядело бы нормально.
//
// ЧТО ИЗМЕНИЛОСЬ В v52.
//
//	п. 6 — версии карточки видит только ИСПОЛНИТЕЛЬ документа (см.
//	       canSeeCardVersions) плюс администратор; все значения отдаются
//	       ЧЕЛОВЕЧЕСКИМИ (ФИО вместо author_id, название подразделения вместо
//	       идентификатора, русские статусы вместо значений перечисления);
//	п. 7 — СКАЧИВАТЬ версии файла нельзя. Обработчик скачивания удалён
//	       целиком, а не спрятан в интерфейсе: спрятанная кнопка оставляет
//	       работающий путь, который открывается прямой ссылкой.
//
// Этот обработчик только ЧИТАЕТ версии и отдаёт разницу между ними.
type VersionsHandler struct {
	pool *pgxpool.Pool
}

func NewVersionsHandler(pool *pgxpool.Pool) *VersionsHandler {
	return &VersionsHandler{pool: pool}
}

// cardFieldLabels — подписи реквизитов карточки для показа разницы.
//
// Держим на бэкенде рядом с составом снимка (функция snapshot_document_version
// в миграции): так состав полей и их названия правятся в двух файлах одной
// задачи, а не в трёх разных местах.
//
// Реквизиты корреспондента из списка убраны вместе с самими реквизитами
// (п. 17).
var cardFieldLabels = map[string]string{
	"title":                "Описание",
	"urgency":              "Срочность",
	"status":               "Статус",
	"outgoing_number":      "Исходящий номер",
	"due_date":             "Срок готовности",
	"due_datetime":         "Срок готовности (с временем)",
	"author_id":            "Автор",
	"author_department_id": "Подразделение автора",
	"category_id":          "Категория",
	"special_mark_id":      "Особая отметка",
	"controller_id":        "Контролёр",
	"on_control":           "На контроле",
}

// cardFieldKind — как показывать значение реквизита (, п. 6:
// «все значения выдавать не как Id, а значения — не id автора, а ФИО»).
//
// Разбор по видам, а не по именам полей в каждом месте кода: иначе при
// добавлении нового реквизита его легко забыть в одном из трёх мест (список
// версий, разница между версиями, отчёт по документу), и там снова появился бы
// числовой идентификатор.
var cardFieldKind = map[string]string{
	"author_id":            "user",
	"controller_id":        "user",
	"author_department_id": "department",
	"category_id":          "category",
	"special_mark_id":      "mark",
	"status":               "status",
	"urgency":              "urgency",
	"on_control":           "bool",
	"due_date":             "date",
	"due_datetime":         "datetime",
}

type cardChange struct {
	Field string `json:"field"`
	Label string `json:"label"`
	// From / To — значения ДЛЯ ЧЕЛОВЕКА (строки). Числовые идентификаторы
	// наружу не отдаются вовсе: отдать их «на случай, если пригодятся» значит
	// однажды увидеть их в интерфейсе.
	From string `json:"from"`
	To   string `json:"to"`
}

// cardFieldValue — одно поле карточки в человеческом виде.
type cardFieldValue struct {
	Field string `json:"field"`
	Label string `json:"label"`
	Value string `json:"value"`
}

type versionRow struct {
	Version     int       `json:"version"`
	ChangedName string    `json:"changed_by_name,omitempty"`
	ChangeNote  string    `json:"change_note,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	// Card — состав карточки в этой версии, уже расшифрованный и в порядке
	// cardFieldOrder.
	Card []cardFieldValue `json:"card"`
	// Changes — чем версия отличается от предыдущей. Считается на сервере, а
	// не на клиенте: сравнение должно быть одинаковым и в интерфейсе, и в
	// отчёте по документу, а два независимых сравнения рано или поздно
	// разойдутся.
	Changes []cardChange `json:"changes"`

	// raw — исходный снимок. Не отдаётся наружу (нет тега json и имя с
	// маленькой буквы): нужен только для расчёта разницы.
	raw map[string]any `json:"-"`
}

// cardFieldOrder — порядок показа реквизитов. Снимок лежит в jsonb, а у jsonb
// порядок ключей не сохраняется (ключи сортируются), поэтому без явного
// порядка карточка в интерфейсе шла бы по алфавиту английских имён полей —
// «author_department_id, author_id, category_id…». Для человека это нечитаемо.
var cardFieldOrder = []string{
	"title", "status", "urgency", "outgoing_number",
	"due_date", "due_datetime",
	"author_id", "author_department_id",
	"category_id", "special_mark_id",
	"on_control", "controller_id",
}

type fileVersionRow struct {
	Version      int       `json:"version"`
	SHA256       string    `json:"sha256"`
	SizeBytes    int64     `json:"size_bytes"`
	UploadedBy   string    `json:"uploaded_by_name,omitempty"`
	UploadedAt   time.Time `json:"uploaded_at"`
	SupersededBy string    `json:"superseded_by_name,omitempty"`
	SupersededAt time.Time `json:"superseded_at"`
	Current      bool      `json:"current"`
}

// canSeeCardVersions — кому показывать версии КАРТОЧКИ (, п. 6:
// «версию карточки показывать только исполнителю»).
//
// О ТОЛКОВАНИИ. В делопроизводстве «исполнитель документа» — это тот, кто
// документ готовил, то есть в нашей модели АВТОР (documents.author_id); именно
// его фамилия стоит в отметке об исполнителе. Не путать с «исполнителем
// резолюции» и с «тем, кто ставит отметку об исполнении» — это другие роли.
// Поэтому право даётся автору документа. Администратор видит всё, как и в
// остальной системе.
//
// Почему не всем, кто видит документ: история правок карточки показывает, что
// именно и когда переделывали в реквизитах, — это рабочая кухня подготовки
// документа, и адресату она не нужна, а вопросы вызывает.
func canSeeCardVersions(ctx *fiber.Ctx, tx pgx.Tx, docID, userID int64, isAdmin bool) (bool, error) {
	if isAdmin {
		return true, nil
	}
	var ok bool
	err := tx.QueryRow(ctx.Context(),
		`SELECT EXISTS (SELECT 1 FROM documents WHERE id = $1 AND author_id = $2)`,
		docID, userID).Scan(&ok)
	return ok, err
}

// List GET /api/documents/:id/versions — версии карточки и файла.
//
// Версии ФАЙЛА отдаются всем, кто видит документ: это перечень «какой файл
// когда действовал» с хэшем, и он нужен при любом разборе. Скачать их
// нельзя (п. 7) — только увидеть, что подменa была и когда.
func (h *VersionsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	cards := []versionRow{}
	files := []fileVersionRow{}
	cardsAllowed := false
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var ok bool
		if err := tx.QueryRow(c.Context(),
			`SELECT EXISTS(SELECT 1 FROM documents WHERE id=$1)`, docID).Scan(&ok); err != nil {
			return err
		}
		if !ok {
			return pgx.ErrNoRows
		}

		allowed, err := canSeeCardVersions(c, tx, docID, userID, isAdmin)
		if err != nil {
			return err
		}
		cardsAllowed = allowed

		if allowed {
			rows, err := tx.Query(c.Context(), `
				SELECT v.version, v.card, coalesce(u.full_name,''),
				       coalesce(v.change_note,''), v.created_at
				  FROM document_versions v
				  LEFT JOIN users u ON u.id = v.changed_by
				 WHERE v.document_id = $1
				 ORDER BY v.version`, docID)
			if err != nil {
				return err
			}
			defer rows.Close()
			for rows.Next() {
				var r versionRow
				if err := rows.Scan(&r.Version, &r.raw, &r.ChangedName,
					&r.ChangeNote, &r.CreatedAt); err != nil {
					return err
				}
				cards = append(cards, r)
			}
			if err := rows.Err(); err != nil {
				return err
			}
			if err := resolveCardValues(c, tx, cards); err != nil {
				return err
			}
		}

		frows, err := tx.Query(c.Context(), `
			SELECT fv.version, fv.sha256, fv.size_bytes, coalesce(u.full_name,''),
			       fv.uploaded_at, coalesce(s.full_name,''), fv.superseded_at
			  FROM document_file_versions fv
			  LEFT JOIN users u ON u.id = fv.uploaded_by
			  LEFT JOIN users s ON s.id = fv.superseded_by
			 WHERE fv.document_id = $1
			 ORDER BY fv.version`, docID)
		if err != nil {
			return err
		}
		defer frows.Close()
		for frows.Next() {
			var r fileVersionRow
			if err := frows.Scan(&r.Version, &r.SHA256, &r.SizeBytes, &r.UploadedBy,
				&r.UploadedAt, &r.SupersededBy, &r.SupersededAt); err != nil {
				return err
			}
			files = append(files, r)
		}
		if err := frows.Err(); err != nil {
			return err
		}

		// Действующий файл лежит не в версиях, а в document_files: версии —
		// это ПРЕЖНИЕ копии. Без этой строки в интерфейсе было бы непонятно,
		// какой файл сейчас настоящий.
		var curSHA string
		var curSize int64
		var curBy string
		var curAt time.Time
		err = tx.QueryRow(c.Context(), `
			SELECT f.sha256, f.size_bytes, coalesce(u.full_name,''), f.uploaded_at
			  FROM document_files f LEFT JOIN users u ON u.id = f.uploaded_by
			 WHERE f.document_id = $1`, docID).Scan(&curSHA, &curSize, &curBy, &curAt)
		if err == nil {
			files = append(files, fileVersionRow{
				Version: len(files) + 1, SHA256: curSHA, SizeBytes: curSize,
				UploadedBy: curBy, UploadedAt: curAt, Current: true,
			})
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return err
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить версии")
	}

	// Разница считается после выборки, по уже упорядоченному списку.
	for i := range cards {
		if i == 0 {
			cards[i].Changes = []cardChange{}
			continue
		}
		cards[i].Changes = diffCards(cards[i-1], cards[i])
	}
	return c.JSON(fiber.Map{
		"card_versions": cards,
		"file_versions": files,
		// card_versions_allowed отдаётся всегда, чтобы интерфейс мог написать
		// «история правок карточки доступна исполнителю документа», а не
		// показывать пустой раздел. Пустой раздел читается как «правок не
		// было» — то есть как неверные сведения.
		"card_versions_allowed": cardsAllowed,
	})
}

// resolveCardValues заменяет идентификаторы в снимках карточек на значения
// (, п. 6).
//
// Справочники читаются ОДНИМ запросом на вид, а не по запросу на значение: у
// документа бывает десяток версий, в каждой по четыре ссылки, и построчное
// разрешение дало бы десятки обращений к базе на одно открытие вкладки.
func resolveCardValues(c *fiber.Ctx, tx pgx.Tx, cards []versionRow) error {
	users := map[int64]string{}
	depts := map[int64]string{}
	cats := map[int64]string{}
	marks := map[int64]string{}

	// Собираем все встречающиеся идентификаторы по видам.
	need := map[string]map[int64]bool{
		"user": {}, "department": {}, "category": {}, "mark": {},
	}
	for _, v := range cards {
		for field, raw := range v.raw {
			kind := cardFieldKind[field]
			set, ok := need[kind]
			if !ok {
				continue
			}
			if id, ok := cardValueInt(raw); ok {
				set[id] = true
			}
		}
	}

	load := func(kind, query string, dst map[int64]string) error {
		ids := make([]int64, 0, len(need[kind]))
		for id := range need[kind] {
			ids = append(ids, id)
		}
		if len(ids) == 0 {
			return nil
		}
		rows, err := tx.Query(c.Context(), query, ids)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var id int64
			var name string
			if err := rows.Scan(&id, &name); err != nil {
				return err
			}
			dst[id] = name
		}
		return rows.Err()
	}

	// ФИО с должностью: в истории правок «Иванов И.И.» без должности нередко
	// неоднозначно, а ровно за этим в историю и смотрят.
	if err := load("user", `
		SELECT id, full_name || CASE WHEN coalesce(position,'') <> ''
		                             THEN ' (' || position || ')' ELSE '' END
		  FROM users WHERE id = ANY($1::bigint[])`, users); err != nil {
		return err
	}
	if err := load("department", `
		SELECT id, name FROM departments WHERE id = ANY($1::bigint[])`, depts); err != nil {
		return err
	}
	if err := load("category", `
		SELECT id, name FROM document_categories WHERE id = ANY($1::bigint[])`, cats); err != nil {
		return err
	}
	if err := load("mark", `
		SELECT id, name FROM special_marks WHERE id = ANY($1::bigint[])`, marks); err != nil {
		return err
	}

	dict := map[string]map[int64]string{
		"user": users, "department": depts, "category": cats, "mark": marks,
	}
	for i := range cards {
		cards[i].Card = buildCardFields(cards[i].raw, dict)
	}
	return nil
}

// buildCardFields приводит снимок к списку «подпись — значение» в читаемом
// порядке. Поля, которых нет в cardFieldOrder (новый реквизит, добавленный в
// снимок позже), идут в конец: молча терять реквизит хуже, чем показать его с
// техническим именем.
func buildCardFields(raw map[string]any, dict map[string]map[int64]string) []cardFieldValue {
	out := make([]cardFieldValue, 0, len(raw))
	seen := map[string]bool{}
	add := func(field string) {
		seen[field] = true
		v, ok := raw[field]
		if !ok {
			return
		}
		out = append(out, cardFieldValue{
			Field: field,
			Label: labelFor(field),
			Value: humanCardValue(field, v, dict),
		})
	}
	for _, f := range cardFieldOrder {
		add(f)
	}
	for f := range raw {
		if !seen[f] {
			add(f)
		}
	}
	return out
}

// diffCards — чем новая версия карточки отличается от прежней.
//
// Сравниваются ЧЕЛОВЕЧЕСКИЕ значения, а не содержимое jsonb. Так в разнице не
// возникает ложных изменений из-за типа (число 5 и строка "5" в jsonb
// различаются, а для человека это одно и то же), и одновременно в разнице
// сразу стоят ФИО и названия, а не идентификаторы (п. 6).
func diffCards(prev, next versionRow) []cardChange {
	out := []cardChange{}
	prevByField := map[string]cardFieldValue{}
	for _, f := range prev.Card {
		prevByField[f.Field] = f
	}
	seen := map[string]bool{}
	for _, nf := range next.Card {
		seen[nf.Field] = true
		pf := prevByField[nf.Field]
		if pf.Value == nf.Value {
			continue
		}
		out = append(out, cardChange{
			Field: nf.Field, Label: nf.Label, From: pf.Value, To: nf.Value,
		})
	}
	// Поле, пропавшее из снимка (удалённый реквизит), — тоже изменение.
	for _, pf := range prev.Card {
		if seen[pf.Field] {
			continue
		}
		out = append(out, cardChange{
			Field: pf.Field, Label: pf.Label, From: pf.Value, To: "—",
		})
	}
	return out
}

func labelFor(field string) string {
	if l, ok := cardFieldLabels[field]; ok {
		return l
	}
	return field
}

// cardValueInt вытаскивает целое из значения jsonb. jsonb отдаёт числа как
// float64, но в снимке могли оказаться и строки (например, после ручной
// правки данных), поэтому разбираются оба случая.
func cardValueInt(v any) (int64, bool) {
	switch x := v.(type) {
	case float64:
		if x == float64(int64(x)) {
			return int64(x), true
		}
	case int64:
		return x, true
	case string:
		if n, err := strconv.ParseInt(x, 10, 64); err == nil {
			return n, true
		}
	}
	return 0, false
}

// humanCardValue — значение реквизита так, как его читает человек.
//
// Пустое значение показывается как «—», а не пустой строкой: пустая ячейка в
// истории изменений неотличима от сбоя отображения.
func humanCardValue(field string, v any, dict map[string]map[int64]string) string {
	if v == nil {
		return "—"
	}
	kind := cardFieldKind[field]
	switch kind {
	case "user", "department", "category", "mark":
		id, ok := cardValueInt(v)
		if !ok || id == 0 {
			return "—"
		}
		if name, ok := dict[kind][id]; ok && name != "" {
			return name
		}
		// Справочная запись удалена — это бывает (категорию убрали из
		// справочника). Честнее сказать прямо, чем показать пустоту: по
		// пустоте нельзя понять, была ли категория вообще.
		return fmt.Sprintf("удалённая запись справочника (№ %d)", id)
	case "status":
		return statusLabelRU(fmt.Sprint(v))
	case "urgency":
		return urgencyLabelRU(fmt.Sprint(v))
	case "bool":
		if b, ok := v.(bool); ok {
			if b {
				return "да"
			}
			return "нет"
		}
	case "date":
		return humanDate(fmt.Sprint(v))
	case "datetime":
		return humanDateTime(fmt.Sprint(v))
	}

	switch x := v.(type) {
	case string:
		if x == "" {
			return "—"
		}
		return x
	case bool:
		if x {
			return "да"
		}
		return "нет"
	case float64:
		if x == float64(int64(x)) {
			return strconv.FormatInt(int64(x), 10)
		}
		return strconv.FormatFloat(x, 'f', -1, 64)
	}
	return fmt.Sprint(v)
}

// humanDate / humanDateTime — даты в привычном виде ДД.ММ.ГГГГ.
//
// В снимке дата лежит так, как её отдал jsonb («2026-10-14» или
// «2026-10-14T09:30:00Z»). Показывать это человеку в истории изменений рядом с
// русскими подписями неправильно, а разбирать на фронте — значит получить два
// разных формата в двух местах.
func humanDate(s string) string {
	if s == "" {
		return "—"
	}
	if len(s) >= 10 {
		if t, err := time.Parse("2006-01-02", s[:10]); err == nil {
			return t.Format("02.01.2006")
		}
	}
	return s
}

func humanDateTime(s string) string {
	if s == "" {
		return "—"
	}
	for _, layout := range []string{time.RFC3339, "2006-01-02T15:04:05", "2006-01-02 15:04:05"} {
		if t, err := time.Parse(layout, s); err == nil {
			return t.Local().Format("02.01.2006 15:04")
		}
	}
	return humanDate(s)
}
