package handlers

import (
	"errors"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgconn"
)

// Проверки пользовательского ввода, общие для нескольких обработчиков.
// Без них неверная дата или несуществующий идентификатор доходили до БД и
// возвращались человеку как «500 внутренняя ошибка».

const maxTitleLen = 500

func validateTitle(title string) error {
	if strings.TrimSpace(title) == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите наименование документа")
	}
	if utf8.RuneCountInString(title) > maxTitleLen {
		return fiber.NewError(fiber.StatusBadRequest, "наименование документа длиннее 500 знаков")
	}
	return nil
}

func validateUrgency(u string) error {
	switch u {
	case "", "normal", "urgent", "out_of_turn":
		return nil
	}
	return fiber.NewError(fiber.StatusBadRequest, "недопустимая срочность")
}

// validateDate проверяет дату вида ГГГГ-ММ-ДД; пустая строка допустима.
func validateDate(s, what string) error {
	if strings.TrimSpace(s) == "" {
		return nil
	}
	if _, err := time.Parse("2006-01-02", strings.TrimSpace(s)); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, what+": дата должна быть в виде ГГГГ-ММ-ДД")
	}
	return nil
}

// validateDateTime проверяет момент времени в RFC 3339 (или дату-время без
// зоны, как отдаёт поле datetime-local); пустая строка допустима.
func validateDateTime(s, what string) error {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil
	}
	for _, layout := range []string{time.RFC3339, "2006-01-02T15:04", "2006-01-02T15:04:05", "2006-01-02 15:04:05", "2006-01-02 15:04"} {
		if _, err := time.Parse(layout, s); err == nil {
			return nil
		}
	}
	return fiber.NewError(fiber.StatusBadRequest, what+": неверный формат даты и времени")
}

// inputError переводит ошибки PostgreSQL, вызванные данными запроса
// (несуществующая ссылка, неверный формат, нарушение ограничения), в ответ
// 4xx. Возвращает nil, если ошибка не про входные данные.
func inputError(err error) error {
	var pg *pgconn.PgError
	if !errors.As(err, &pg) {
		return nil
	}
	switch {
	case pg.Code == "23503":
		return fiber.NewError(fiber.StatusUnprocessableEntity, "указан несуществующий объект (пользователь, подразделение, категория или документ)")
	case pg.Code == "23514", pg.Code == "23502":
		return fiber.NewError(fiber.StatusUnprocessableEntity, "недопустимое значение поля")
	case strings.HasPrefix(pg.Code, "22"):
		return fiber.NewError(fiber.StatusBadRequest, "неверный формат значения (дата, число или идентификатор)")
	}
	return nil
}
