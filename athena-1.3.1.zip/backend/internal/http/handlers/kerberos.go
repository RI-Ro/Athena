package handlers

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"log"
	"net"
	"strings"

	"github.com/gofiber/fiber/v2"

	"athena/backend/internal/authdom"
	"athena/backend/internal/config"
	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
)

// AuthInfo GET /api/auth/info — публичные сведения для страницы входа: в
// каком режиме работает этот порт (пароль или Kerberos), адрес «соседнего»
// порта, список доменов и тексты страницы «вход по Kerberos не выполнен».
func (h *AuthHandler) AuthInfo(fc config.FileConfig) fiber.Handler {
	st := fc.SSO.Stub
	if st.Title == "" {
		st.Title = "Вход по Kerberos недоступен"
	}
	if st.Subtitle == "" {
		st.Subtitle = "Не удалось подтвердить вашу учётную запись в домене"
	}
	if st.Message == "" {
		st.Message = "Ваша доменная учётная запись не заведена в системе или у браузера нет билета Kerberos."
	}
	if st.Hint == "" {
		st.Hint = "Войдите по логину и паролю или обратитесь к администратору."
	}
	scheme := "http"
	passAddr := fc.HTTP.Addr
	if fc.TLSEnabled() {
		scheme, passAddr = "https", fc.HTTP.HTTPSAddr
	}
	portOf := func(addr string) string {
		if _, p, err := net.SplitHostPort(addr); err == nil {
			return p
		}
		return strings.TrimPrefix(addr, ":")
	}
	return func(c *fiber.Ctx) error {
		host := fc.HTTP.PublicHost
		if host == "" {
			host = c.Hostname()
			if hn, _, err := net.SplitHostPort(host); err == nil {
				host = hn
			}
		}
		type dom struct {
			Realm    string `json:"realm"`
			Title    string `json:"title"`
			NetBIOS  string `json:"netbios_name"`
			LDAP     bool   `json:"ldap"`
			Kerberos bool   `json:"kerberos"`
		}
		doms := []dom{}
		kerberosReady := false
		all, _ := h.domains.All(c.Context())
		for _, d := range all {
			if !d.IsActive || (!d.LDAPEnabled && !d.KerberosEnabled) {
				continue
			}
			doms = append(doms, dom{d.Realm, d.Title, d.NetBIOS, d.LDAPEnabled, d.KerberosEnabled && d.HasKeytab})
			if d.KerberosEnabled && d.HasKeytab {
				kerberosReady = true
			}
		}
		kerberosURL := ""
		if fc.HTTP.KerberosAddr != "" {
			kerberosURL = scheme + "://" + net.JoinHostPort(host, portOf(fc.HTTP.KerberosAddr))
		}
		return c.JSON(fiber.Map{
			"mode":             middleware.AuthMode(c),
			"kerberos_enabled": kerberosURL != "" && kerberosReady,
			"kerberos_url":     kerberosURL,
			"password_url":     scheme + "://" + net.JoinHostPort(host, portOf(passAddr)),
			"domains":          doms,
			"stub": fiber.Map{
				"title": st.Title, "subtitle": st.Subtitle, "message": st.Message, "hint": st.Hint,
				"footer": st.Footer, "accent": st.Accent, "admins": st.Admins,
				"support": fiber.Map{"email": st.Support.Email, "phone": st.Support.Phone, "hours": st.Support.Hours},
			},
		})
	}
}

// KerberosLogin GET /api/auth/kerberos — вход по билету Kerberos (SPNEGO).
// Работает только на отдельном порту Kerberos (http.kerberos_addr).
//
// Без заголовка «Authorization: Negotiate …» отвечает 401 с
// «WWW-Authenticate: Negotiate»: браузер из доверенной зоны сам повторит
// запрос с билетом. Билет проверяется по keytab доменов (загружаются через
// веб), пользователь определяется как имя@REALM клиента.
func (h *AuthHandler) KerberosLogin(c *fiber.Ctx) error {
	meta := sessionMeta(c, "")
	if middleware.AuthMode(c) != middleware.AuthModeKerberos {
		return h.loginDenied(c, fiber.StatusForbidden, "auth.sso_denied", "wrong_port",
			"вход по Kerberos выполняется на отдельном порту", "", 0, meta, nil)
	}
	hdr := c.Get(fiber.HeaderAuthorization)
	const prefix = "Negotiate "
	if len(hdr) <= len(prefix) || !strings.EqualFold(hdr[:len(prefix)], prefix) {
		c.Set(fiber.HeaderWWWAuthenticate, "Negotiate")
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
			"error": "требуется билет Kerberos", "reason": "not_authenticated"})
	}
	raw := strings.TrimSpace(hdr[len(prefix):])
	// «TlRMTVNT…» — это NTLM: браузер не получил билет (компьютер не в домене
	// или адрес не в зоне интрасети) и откатился на NTLM, который не принимаем.
	if strings.HasPrefix(raw, "TlRMTVNT") {
		return h.loginDenied(c, fiber.StatusUnauthorized, "auth.sso_denied", "ntlm",
			"браузер прислал NTLM вместо билета Kerberos: компьютер не в домене или адрес системы не входит в зону интрасети", "", 0, meta, nil)
	}
	token, err := base64.StdEncoding.DecodeString(raw)
	if err != nil {
		return h.loginDenied(c, fiber.StatusUnauthorized, "auth.sso_denied", "not_authenticated",
			"билет Kerberos не разбирается", "", 0, meta, nil)
	}
	user, realm, err := h.domains.VerifyKerberos(c.Context(), token)
	if err != nil {
		log.Printf("kerberos: %v", err)
		reason, msg := "not_authenticated", "билет Kerberos не подтверждён"
		if !errors.Is(err, authdom.ErrKerberosRejected) {
			msg = "вход по Kerberos не настроен или билет некорректен"
		}
		return h.loginDenied(c, fiber.StatusUnauthorized, "auth.sso_denied", reason, msg, "", 0, meta,
			map[string]any{"cause": err.Error()})
	}
	// Повторное предъявление того же билета отклоняется. Отметка хранится в
	// БД, поэтому действует для всех рабочих процессов, а не только для
	// того, который видел билет первым.
	sum := sha256.Sum256(token)
	if db.SystemPool != nil {
		tag, err := db.SystemPool.Exec(c.Context(),
			`INSERT INTO kerberos_seen_tokens (token_hash) VALUES ($1) ON CONFLICT DO NOTHING`, hex.EncodeToString(sum[:]))
		if err == nil && tag.RowsAffected() == 0 {
			return h.loginDenied(c, fiber.StatusUnauthorized, "auth.sso_denied", "not_authenticated",
				"билет Kerberos уже был предъявлен", "", 0, meta, map[string]any{"cause": "replay"})
		}
	}
	principal := user + "@" + realm
	d, ok := h.domains.Resolve(c.Context(), realm)
	if !ok || !d.KerberosEnabled {
		return h.loginDenied(c, fiber.StatusForbidden, "auth.sso_denied", "realm_not_allowed",
			"домен "+realm+" не допускается к работе в системе", principal, 0, meta, map[string]any{"principal": principal})
	}
	canon := authdom.CanonicalLogin(user, d.Realm)
	u, derr := h.resolveDomainUser(c, d, canon, nil)
	if derr != nil {
		return h.loginDenied(c, derr.status, "auth.sso_denied", derr.reason, derr.msg, canon, derr.userID, meta,
			map[string]any{"principal": principal})
	}
	// Подтверждение завершения согласования контекста (как у mod_auth_gssapi).
	c.Set(fiber.HeaderWWWAuthenticate, "Negotiate oRQwEqADCgEAoQsGCSqGSIb3EgECAg==")
	details := map[string]any{"method": "kerberos", "principal": principal, "domain": d.Realm}
	if u.created {
		details["user_created"] = true
	}
	return h.openSession(c, u.id, u.login, u.isAdmin, meta, "auth.sso_login", details)
}
