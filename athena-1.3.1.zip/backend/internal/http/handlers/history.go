package handlers

import (
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
)

// HistoryHandler — сквозная история действий по всем документам, доступным
// пользователю. Источники: журнал document_history (регистрация, статусы,
// резолюции, отчёты, отметки об исполнении, ознакомление, печать и т. д.) и
// сообщения обсуждения (с именами вложений). Видимость обеспечивает RLS:
// JOIN с documents отсекает чужие документы, у chat_messages своя политика.
type HistoryHandler struct {
	pool *pgxpool.Pool
}

func NewHistoryHandler(pool *pgxpool.Pool) *HistoryHandler {
	return &HistoryHandler{pool: pool}
}

type historyItem struct {
	DocumentID    int64   `json:"document_id"`
	DocumentTitle string  `json:"document_title"`
	OutNumber     *string `json:"outgoing_number,omitempty"`
	EventType     string  `json:"event_type"`
	ActorName     string  `json:"actor_name"`
	FromStatus    string  `json:"from_status,omitempty"`
	ToStatus      string  `json:"to_status,omitempty"`
	Comment       string  `json:"comment,omitempty"`
	CreatedAt     string  `json:"created_at"`
	// Src/ID — ключ записи (0 — журнал событий, 1 — сообщение): нужен для
	// стабильной постраничной выборки и для устранения дублей на клиенте.
	Src int   `json:"src"`
	ID  int64 `json:"id"`
}

// Global GET /api/history?limit=100&before=<RFC3339>&document_id=<id>
func (h *HistoryHandler) Global(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	limit, _ := strconv.Atoi(c.Query("limit", "100"))
	if limit <= 0 || limit > 300 {
		limit = 100
	}
	// Курсор постраничной выборки: "<время RFC3339Nano>|<src>|<id>". Выборка
	// по тройке (время, src, id), а не по одному времени: у записей, созданных
	// одним действием, время совпадает, и сравнение «меньше времени» теряло бы
	// записи на границе страниц.
	var before *time.Time
	var curSrc int
	var curID int64
	if v := c.Query("cursor"); v != "" {
		parts := strings.Split(v, "|")
		if len(parts) != 3 {
			return fiber.NewError(fiber.StatusBadRequest, "неверный курсор")
		}
		t, err := time.Parse(time.RFC3339Nano, parts[0])
		if err != nil {
			return fiber.NewError(fiber.StatusBadRequest, "неверный курсор")
		}
		src, err1 := strconv.Atoi(parts[1])
		id, err2 := strconv.ParseInt(parts[2], 10, 64)
		if err1 != nil || err2 != nil {
			return fiber.NewError(fiber.StatusBadRequest, "неверный курсор")
		}
		before, curSrc, curID = &t, src, id
	}
	var docID *int64
	if v := c.Query("document_id"); v != "" {
		id, err := strconv.ParseInt(v, 10, 64)
		if err != nil {
			return fiber.NewError(fiber.StatusBadRequest, "неверный document_id")
		}
		docID = &id
	}

	items := []historyItem{}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT t.document_id, t.title, t.outgoing_number, t.event_type, t.actor,
			       t.from_status, t.to_status, t.comment,
			       to_char(t.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
			       t.src, t.id
			  FROM (
			    SELECT h.document_id, coalesce(d.title,'') AS title, d.outgoing_number,
			           h.event_type, coalesce(u.full_name,'') AS actor,
			           coalesce(h.from_status::text,'') AS from_status,
			           coalesce(h.to_status::text,'') AS to_status,
			           coalesce(h.comment,'') AS comment, h.created_at,
			           0 AS src, h.id AS id
			      FROM document_history h
			      JOIN documents d ON d.id = h.document_id
			      LEFT JOIN users u ON u.id = h.actor_id
			    UNION ALL
			    SELECT m.document_id, coalesce(d.title,''), d.outgoing_number,
			           'chat_message'::text, coalesce(u.full_name,''),
			           ''::text, ''::text,
			           trim(coalesce(m.text,'') || coalesce((
			             SELECT ' [файлы: ' || string_agg(a.file_name, ', ') || ']'
			               FROM chat_attachments a WHERE a.message_id = m.id), '')),
			           m.created_at, 1, m.id
			      FROM chat_messages m
			      JOIN documents d ON d.id = m.document_id
			      LEFT JOIN users u ON u.id = m.author_id
			  ) t
			 WHERE ($1::timestamptz IS NULL
			        OR (t.created_at, t.src, t.id) < ($1::timestamptz, $4::int, $5::bigint))
			   AND ($2::bigint IS NULL OR t.document_id = $2::bigint)
			 ORDER BY t.created_at DESC, t.src DESC, t.id DESC
			 LIMIT $3`, before, docID, limit, curSrc, curID)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var x historyItem
			if err := rows.Scan(&x.DocumentID, &x.DocumentTitle, &x.OutNumber, &x.EventType,
				&x.ActorName, &x.FromStatus, &x.ToStatus, &x.Comment, &x.CreatedAt, &x.Src, &x.ID); err != nil {
				return err
			}
			items = append(items, x)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить историю")
	}
	// Курсор следующей страницы — только если страница заполнена целиком.
	nextCursor := ""
	if len(items) == limit {
		last := items[len(items)-1]
		nextCursor = last.CreatedAt + "|" + strconv.Itoa(last.Src) + "|" + strconv.FormatInt(last.ID, 10)
	}
	return c.JSON(fiber.Map{"items": items, "next_cursor": nextCursor})
}
