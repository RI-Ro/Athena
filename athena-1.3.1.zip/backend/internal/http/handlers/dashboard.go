package handlers

import (
	"encoding/json"
	"errors"
	"log"
	"strconv"
	"strings"
	"time"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// DashboardHandler — сводная панель руководителя.
//
// Все цифры считаются по документам, которые пользователь вправе видеть:
// запросы идут в транзакции пользователя (db.WithUserTx), и правила доступа
// (RLS) применяет сама база — к документам, экземплярам, этапам и
// резолюциям. Отдельной логики прав здесь нет и быть не должно: иначе
// панель могла бы показать то, чего человек не видит в списках.
//
// Два вида показателей:
//   - «сейчас» — состояние на текущий момент (в работе, просрочено, ждёт
//     решения), без учёта периода;
//   - «за период» — что произошло за выбранный период, с тем же расчётом за
//     предыдущий период такой же длины для сравнения.
type DashboardHandler struct {
	pool          *pgxpool.Pool
	reminderDays  int
	stalledLimitH float64
}

func NewDashboardHandler(pool *pgxpool.Pool, reminderDays int) *DashboardHandler {
	if reminderDays <= 0 {
		reminderDays = 3
	}
	return &DashboardHandler{pool: pool, reminderDays: reminderDays, stalledLimitH: float64(reminderDays * 24)}
}

// dashboardScope — отборы панели.
type dashboardScope struct {
	CategoryID   int64
	MarkID       int64
	DepartmentID int64
	From, To     time.Time
	PrevFrom     time.Time
	Days         int
	Period       string
	Bucket       string // day | week | month
}

func parseDashboardScope(c *fiber.Ctx) (dashboardScope, error) {
	var s dashboardScope
	now := time.Now()
	s.To = now
	s.Period = c.Query("period", "90")
	switch s.Period {
	case "ytd":
		s.From = time.Date(now.Year(), 1, 1, 0, 0, 0, 0, now.Location())
		s.Days = int(now.Sub(s.From).Hours()/24) + 1
	case "7", "30", "90", "180", "365":
		s.Days, _ = strconv.Atoi(s.Period)
		s.From = now.AddDate(0, 0, -s.Days)
	default:
		return s, errors.New("неизвестный период")
	}
	s.PrevFrom = s.From.Add(-now.Sub(s.From))
	switch {
	case s.Days <= 31:
		s.Bucket = "day"
	case s.Days <= 180:
		s.Bucket = "week"
	default:
		s.Bucket = "month"
	}
	var err error
	if v := c.Query("category"); v != "" {
		if s.CategoryID, err = strconv.ParseInt(v, 10, 64); err != nil || s.CategoryID < 0 {
			return s, errors.New("неверная категория")
		}
	}
	if v := c.Query("department"); v != "" {
		if s.DepartmentID, err = strconv.ParseInt(v, 10, 64); err != nil || s.DepartmentID < 0 {
			return s, errors.New("неверное подразделение")
		}
	}
	if v := c.Query("mark"); v != "" {
		if s.MarkID, err = strconv.ParseInt(v, 10, 64); err != nil || s.MarkID < 0 {
			return s, errors.New("неверная особая отметка")
		}
	}
	return s, nil
}

// Get GET /api/dashboard?period=7|30|90|180|365|ytd&category=&mark=&department=
//
// Вся сводка — ОДИН запрос. Видимые пользователю документы, их экземпляры,
// этапы, подписи и резолюции отбираются по одному разу (MATERIALIZED CTE),
// и правила доступа применяются к каждой строке тоже один раз; дальше
// только агрегаты. Ответ собирает сама база (json), приложение передаёт
// его как есть.
func (h *DashboardHandler) Get(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	sc, err := parseDashboardScope(c)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, err.Error())
	}
	ctx := c.Context()
	query := strings.ReplaceAll(dashboardSQL, "{U}", sc.Bucket)
	var body []byte
	txErr := db.WithUserTx(ctx, h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Панель не должна мешать работе: тяжёлый отбор обрывается.
		if _, err := tx.Exec(ctx, `SET LOCAL statement_timeout = '20s'`); err != nil {
			return err
		}
		return tx.QueryRow(ctx, query, sc.CategoryID, sc.MarkID, sc.DepartmentID,
			sc.From, sc.To, sc.PrevFrom, h.stalledLimitH).Scan(&body)
	})
	if txErr != nil {
		if strings.Contains(txErr.Error(), "statement timeout") {
			return fiber.NewError(fiber.StatusServiceUnavailable, "сводка считается слишком долго — сузьте период или отбор")
		}
		log.Printf("сводка: %v", txErr)
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось построить сводку")
	}
	meta, _ := json.Marshal(fiber.Map{
		"generated_at":  time.Now(),
		"reminder_days": h.reminderDays,
		"period": fiber.Map{
			"code": sc.Period, "from": sc.From, "to": sc.To, "days": sc.Days,
			"prev_from": sc.PrevFrom, "bucket": sc.Bucket,
		},
	})
	// {мета…} + {данные…} → один объект.
	out := make([]byte, 0, len(meta)+len(body)+1)
	out = append(out, meta[:len(meta)-1]...)
	out = append(out, ',')
	out = append(out, body[1:]...)
	c.Set(fiber.HeaderCacheControl, "private, no-store")
	c.Set(fiber.HeaderContentType, fiber.MIMEApplicationJSONCharsetUTF8)
	return c.Send(out)
}

// dashboardSQL — сводка целиком. Параметры: $1 категория, $2 особая отметка,
// $3 подразделение, $4 начало периода, $5 конец, $6 начало предыдущего
// периода такой же длины, $7 порог «зависшего» решения в часах. {U} —
// шаг динамики (day | week | month), подставляется из белого списка.
//
// «Действующий» документ — не исполнен и не в архиве. Черновики в сводку не
// входят: это ещё не документы организации. Отбор по подразделению —
// документ подготовлен им ИЛИ направлен ему (есть его экземпляр).
const dashboardSQL = `
WITH d AS MATERIALIZED (
  SELECT d.id, d.title, d.status::text AS status, d.special_mark_id, d.category_id,
         d.created_at, d.due_date, d.executed_at, d.outgoing_number, d.on_control
    FROM documents d
   WHERE d.status <> 'draft'
     AND ($1::bigint = 0 OR d.category_id = $1)
     AND ($2::bigint = 0 OR d.special_mark_id = $2)
     AND ($3::bigint = 0 OR d.author_department_id = $3
          OR EXISTS (SELECT 1 FROM document_incoming_instances x
                      WHERE x.document_id = d.id AND x.receiving_department_id = $3))
),
inst AS MATERIALIZED (
  SELECT i.id, i.document_id, i.receiving_department_id, i.created_at, i.executed_at, d.due_date, d.status
    FROM document_incoming_instances i JOIN d ON d.id = i.document_id
),
st AS MATERIALIZED (
  SELECT s.document_id, s.approver_id, s.stage_type::text AS stage_type, s.status::text AS status,
         s.step_no, s.created_at, s.activated_at, s.decided_at
    FROM approval_stages s JOIN d ON d.id = s.document_id
),
sig AS MATERIALIZED (
  SELECT s.document_id, min(s.signed_at) AS signed_at
    FROM document_signatures s JOIN d ON d.id = s.document_id GROUP BY s.document_id
),
r AS MATERIALIZED (
  SELECT r.id, r.document_id, r.status::text AS status, r.due_date, r.closed_at, r.created_at
    FROM resolutions r JOIN d ON d.id = r.document_id
),
re AS MATERIALIZED (
  SELECT e.id, e.resolution_id, e.user_id, e.is_responsible, e.status::text AS status
    FROM resolution_executors e JOIN r ON r.id = e.resolution_id
   WHERE r.status IN ('issued','in_progress','on_report')
),
resp AS (
  SELECT DISTINCT ON (re.resolution_id) re.resolution_id, u.full_name
    FROM re JOIN users u ON u.id = re.user_id
   WHERE re.is_responsible AND re.status <> 'cancelled'
   ORDER BY re.resolution_id, re.id
),
started AS (
  SELECT document_id, min(coalesce(activated_at, created_at)) AS started_at FROM st GROUP BY document_id
),
appr AS (
  SELECT sig.signed_at, extract(epoch FROM sig.signed_at - started.started_at) / 3600 AS h
    FROM sig JOIN started USING (document_id)
),
b AS (
  SELECT generate_series(date_trunc('{U}', $4::timestamptz), date_trunc('{U}', $5::timestamptz), interval '1 {U}') AS bucket
)
SELECT json_build_object(
'kpi', (SELECT row_to_json(k) FROM (SELECT
  count(*) FILTER (WHERE status NOT IN ('executed','archived'))                         AS active,
  count(*) FILTER (WHERE status IN ('on_approval_hierarchy','on_approval_cross_dept'))  AS on_approval,
  count(*) FILTER (WHERE status = 'on_signing')                                         AS on_signing,
  count(*) FILTER (WHERE status IN ('signed','sent','in_progress'))                     AS in_execution,
  count(*) FILTER (WHERE status = 'rejected')                                           AS on_revision,
  count(*) FILTER (WHERE on_control AND status NOT IN ('executed','archived','rejected')) AS on_control,
  count(*) FILTER (WHERE status IN ('signed','sent','in_progress') AND due_date < current_date) AS overdue_docs,
  count(*) FILTER (WHERE status IN ('signed','sent','in_progress')
                     AND due_date BETWEEN current_date AND current_date + 7)            AS due_soon_docs,
  -- Просроченные экземпляры — только у документов, которые сейчас на
  -- исполнении (те же документы, что в overdue_docs); у одного документа их
  -- может быть несколько — по числу подразделений-адресатов.
  (SELECT count(*) FROM inst WHERE executed_at IS NULL AND due_date < current_date
       AND status IN ('signed','sent','in_progress'))                                    AS overdue_instances,
  count(*) FILTER (WHERE created_at >= $4 AND created_at < $5)                          AS created_cur,
  count(*) FILTER (WHERE created_at >= $6 AND created_at < $4)                          AS created_prev,
  (SELECT count(*) FROM sig WHERE signed_at >= $4 AND signed_at < $5)                   AS signed_cur,
  (SELECT count(*) FROM sig WHERE signed_at >= $6 AND signed_at < $4)                   AS signed_prev,
  count(*) FILTER (WHERE executed_at >= $4 AND executed_at < $5)                        AS executed_cur,
  count(*) FILTER (WHERE executed_at >= $6 AND executed_at < $4)                        AS executed_prev,
  -- Исполнительская дисциплина по экземплярам (подразделениям): исполнено
  -- в срок / всё, срок чего наступил в периоде (исполненное и просроченное).
  (SELECT count(*) FROM inst WHERE due_date >= $4::date AND due_date < $5::date
       AND executed_at IS NOT NULL AND executed_at::date <= due_date)                   AS ontime_cur,
  (SELECT count(*) FROM inst WHERE due_date >= $4::date AND due_date < least($5::date, current_date + 1)
       AND (executed_at IS NOT NULL OR due_date < current_date))                         AS due_cur,
  (SELECT count(*) FROM inst WHERE due_date >= $6::date AND due_date < $4::date
       AND executed_at IS NOT NULL AND executed_at::date <= due_date)                   AS ontime_prev,
  (SELECT count(*) FROM inst WHERE due_date >= $6::date AND due_date < $4::date
       AND (executed_at IS NOT NULL OR due_date < current_date))                         AS due_prev
  FROM d) k),

-- Средние сроки; медиана рядом со средним: один застрявший документ сильно
-- искажает среднее.
'timing', json_build_object(
  'approval_avg_h_cur',    (SELECT avg(h) FROM appr WHERE signed_at >= $4 AND signed_at < $5),
  'approval_median_h_cur', (SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY h) FROM appr WHERE signed_at >= $4 AND signed_at < $5),
  'approval_avg_h_prev',   (SELECT avg(h) FROM appr WHERE signed_at >= $6 AND signed_at < $4),
  'execution_avg_d_cur',   (SELECT avg(extract(epoch FROM executed_at - created_at)) / 86400 FROM inst WHERE executed_at >= $4 AND executed_at < $5),
  'execution_median_d_cur',(SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY extract(epoch FROM executed_at - created_at)) / 86400
                              FROM inst WHERE executed_at >= $4 AND executed_at < $5),
  'execution_avg_d_prev',  (SELECT avg(extract(epoch FROM executed_at - created_at)) / 86400 FROM inst WHERE executed_at >= $6 AND executed_at < $4)),

'status', (SELECT coalesce(json_agg(x ORDER BY x.n DESC), '[]') FROM (
  SELECT status, count(*) AS n FROM d WHERE status <> 'archived' GROUP BY status) x),

-- Динамика: создано, подписано, исполнено (и сколько экземпляров исполнено
-- с опозданием) по дням/неделям/месяцам периода.
'trend', (SELECT coalesce(json_agg(json_build_object(
      'bucket', b.bucket, 'created', coalesce(tc.n, 0), 'signed', coalesce(ts.n, 0),
      'executed', coalesce(te.n, 0), 'executed_late', coalesce(tl.n, 0)) ORDER BY b.bucket), '[]')
    FROM b
    LEFT JOIN (SELECT date_trunc('{U}', created_at) AS k, count(*) AS n FROM d
                WHERE created_at >= date_trunc('{U}', $4::timestamptz) GROUP BY 1) tc ON tc.k = b.bucket
    LEFT JOIN (SELECT date_trunc('{U}', signed_at) AS k, count(*) AS n FROM sig
                WHERE signed_at >= date_trunc('{U}', $4::timestamptz) GROUP BY 1) ts ON ts.k = b.bucket
    LEFT JOIN (SELECT date_trunc('{U}', executed_at) AS k, count(*) AS n FROM d
                WHERE executed_at >= date_trunc('{U}', $4::timestamptz) GROUP BY 1) te ON te.k = b.bucket
    LEFT JOIN (SELECT date_trunc('{U}', executed_at) AS k, count(*) AS n FROM inst
                WHERE executed_at >= date_trunc('{U}', $4::timestamptz)
                  AND due_date IS NOT NULL AND executed_at::date > due_date GROUP BY 1) tl ON tl.k = b.bucket),

-- У кого сейчас ждут решения: ожидающие этапы по согласующим и подписантам.
'bottlenecks', (SELECT coalesce(json_agg(x), '[]') FROM (
  SELECT st.approver_id AS user_id, u.full_name, coalesce(u.position, '') AS position,
         coalesce(dep.name, '') AS department,
         count(*) AS pending,
         count(*) FILTER (WHERE st.stage_type = 'signing') AS signing,
         max(extract(epoch FROM now() - coalesce(st.activated_at, st.created_at))) / 3600 AS oldest_h,
         avg(extract(epoch FROM now() - coalesce(st.activated_at, st.created_at))) / 3600 AS avg_h
    FROM st JOIN users u ON u.id = st.approver_id
    LEFT JOIN departments dep ON dep.id = u.primary_department_id
   WHERE st.status = 'pending'
   GROUP BY st.approver_id, u.full_name, u.position, dep.name
   ORDER BY pending DESC, oldest_h DESC LIMIT 10) x),

-- Как быстро решают согласующие за период.
'approver_speed', (SELECT coalesce(json_agg(x), '[]') FROM (
  SELECT st.approver_id AS user_id, u.full_name, coalesce(u.position, '') AS position,
         count(*) AS decided,
         count(*) FILTER (WHERE st.status = 'rejected') AS rejected,
         avg(extract(epoch FROM st.decided_at - st.activated_at)) / 3600 AS avg_h,
         percentile_cont(0.5) WITHIN GROUP (ORDER BY extract(epoch FROM st.decided_at - st.activated_at)) / 3600 AS median_h
    FROM st JOIN users u ON u.id = st.approver_id
   WHERE st.decided_at >= $4 AND st.decided_at < $5 AND st.activated_at IS NOT NULL
     AND st.decided_at >= st.activated_at
   GROUP BY st.approver_id, u.full_name, u.position
   ORDER BY avg_h DESC LIMIT 12) x),

-- Исполнительская дисциплина подразделений-получателей.
'departments', (SELECT coalesce(json_agg(x), '[]') FROM (
  SELECT inst.receiving_department_id AS department_id, dep.name,
    count(*) FILTER (WHERE inst.created_at >= $4 AND inst.created_at < $5) AS received,
    count(*) FILTER (WHERE inst.executed_at >= $4 AND inst.executed_at < $5) AS executed,
    count(*) FILTER (WHERE inst.executed_at >= $4 AND inst.executed_at < $5 AND inst.due_date IS NOT NULL
                       AND inst.executed_at::date <= inst.due_date) AS executed_on_time,
    count(*) FILTER (WHERE inst.executed_at >= $4 AND inst.executed_at < $5 AND inst.due_date IS NOT NULL) AS executed_with_due,
    count(*) FILTER (WHERE inst.executed_at IS NULL AND inst.status IN ('signed','sent','in_progress')) AS in_work,
    count(*) FILTER (WHERE inst.executed_at IS NULL AND inst.due_date < current_date
                       AND inst.status IN ('signed','sent','in_progress')) AS overdue,
    avg(extract(epoch FROM inst.executed_at - inst.created_at)) FILTER (WHERE inst.executed_at >= $4 AND inst.executed_at < $5) / 86400 AS avg_days
    FROM inst JOIN departments dep ON dep.id = inst.receiving_department_id
   GROUP BY inst.receiving_department_id, dep.name
   ORDER BY overdue DESC, in_work DESC, dep.name) x),

'resolutions', (SELECT row_to_json(x) FROM (SELECT
  count(*) FILTER (WHERE status IN ('issued','in_progress','on_report')) AS open,
  count(*) FILTER (WHERE status = 'on_report') AS on_report,
  count(*) FILTER (WHERE status IN ('issued','in_progress','on_report') AND due_date < current_date) AS overdue,
  count(*) FILTER (WHERE status IN ('issued','in_progress','on_report')
                     AND due_date BETWEEN current_date AND current_date + 7) AS due_soon,
  count(*) FILTER (WHERE status = 'done' AND closed_at >= $4 AND closed_at < $5) AS done_cur,
  count(*) FILTER (WHERE status = 'done' AND closed_at >= $4 AND closed_at < $5
                     AND due_date IS NOT NULL AND closed_at::date <= due_date) AS done_on_time_cur,
  count(*) FILTER (WHERE status = 'done' AND closed_at >= $4 AND closed_at < $5 AND due_date IS NOT NULL) AS done_with_due_cur,
  count(*) FILTER (WHERE status = 'done' AND closed_at >= $6 AND closed_at < $4) AS done_prev,
  count(*) FILTER (WHERE created_at >= $4 AND created_at < $5) AS issued_cur
  FROM r) x),

-- Нагрузка исполнителей резолюций: открытые поручения и просроченные.
'executors', (SELECT coalesce(json_agg(x), '[]') FROM (
  SELECT re.user_id, u.full_name, coalesce(u.position, '') AS position,
         count(*) AS open,
         count(*) FILTER (WHERE r.due_date < current_date) AS overdue,
         count(*) FILTER (WHERE re.status = 'reported') AS reported,
         count(*) FILTER (WHERE re.is_responsible) AS responsible
    FROM re JOIN r ON r.id = re.resolution_id JOIN users u ON u.id = re.user_id
   WHERE re.status IN ('open','in_progress','returned','reported')
   GROUP BY re.user_id, u.full_name, u.position
   ORDER BY overdue DESC, open DESC LIMIT 10) x),

'categories', (SELECT coalesce(json_agg(x ORDER BY x.created DESC, x.active DESC), '[]') FROM (
  SELECT d.category_id AS id, coalesce(c.name, '—') AS name,
         count(*) FILTER (WHERE d.created_at >= $4 AND d.created_at < $5) AS created,
         count(*) FILTER (WHERE d.status NOT IN ('executed','archived')) AS active
    FROM d LEFT JOIN document_categories c ON c.id = d.category_id
   GROUP BY d.category_id, c.name) x WHERE x.created > 0 OR x.active > 0),

-- Особые отметки: действующие, просроченные и созданные за период.
'special_marks', (SELECT coalesce(json_agg(x ORDER BY x.active DESC, x.created DESC), '[]') FROM (
  SELECT d.special_mark_id AS id, coalesce(sm.name, '—') AS name, coalesce(sm.is_default, false) AS is_default,
         count(*) FILTER (WHERE d.status NOT IN ('executed','archived')) AS active,
         count(*) FILTER (WHERE d.status IN ('signed','sent','in_progress') AND d.due_date < current_date) AS overdue,
         count(*) FILTER (WHERE d.created_at >= $4 AND d.created_at < $5) AS created
    FROM d LEFT JOIN special_marks sm ON sm.id = d.special_mark_id
   GROUP BY d.special_mark_id, sm.name, sm.is_default) x WHERE x.active > 0 OR x.created > 0),

-- Что просрочено сейчас: экземпляры (подразделение не отметило
-- исполнение) и резолюции. Самые давние — первыми.
'overdue', (SELECT coalesce(json_agg(x ORDER BY x.days DESC, x.document_id), '[]') FROM (
  SELECT * FROM (
    SELECT 'instance' AS kind, d.id AS document_id, d.title, coalesce(d.outgoing_number, '') AS number,
           inst.due_date, (current_date - inst.due_date) AS days, dep.name AS who
      FROM inst JOIN d ON d.id = inst.document_id
      JOIN departments dep ON dep.id = inst.receiving_department_id
     WHERE inst.executed_at IS NULL AND inst.due_date < current_date
       AND inst.status IN ('signed','sent','in_progress')
    UNION ALL
    SELECT 'resolution', d.id, d.title, coalesce(d.outgoing_number, ''), r.due_date,
           (current_date - r.due_date), coalesce(resp.full_name, '')
      FROM r JOIN d ON d.id = r.document_id LEFT JOIN resp ON resp.resolution_id = r.id
     WHERE r.status IN ('issued','in_progress','on_report') AND r.due_date < current_date
  ) y ORDER BY days DESC, document_id LIMIT 30) x),

'upcoming', (SELECT coalesce(json_agg(x ORDER BY x.days, x.document_id), '[]') FROM (
  SELECT * FROM (
    SELECT 'instance' AS kind, d.id AS document_id, d.title, coalesce(d.outgoing_number, '') AS number,
           inst.due_date, (inst.due_date - current_date) AS days, dep.name AS who
      FROM inst JOIN d ON d.id = inst.document_id
      JOIN departments dep ON dep.id = inst.receiving_department_id
     WHERE inst.executed_at IS NULL AND inst.due_date BETWEEN current_date AND current_date + 14
       AND inst.status IN ('signed','sent','in_progress')
    UNION ALL
    SELECT 'resolution', d.id, d.title, coalesce(d.outgoing_number, ''), r.due_date,
           (r.due_date - current_date), coalesce(resp.full_name, '')
      FROM r JOIN d ON d.id = r.document_id LEFT JOIN resp ON resp.resolution_id = r.id
     WHERE r.status IN ('issued','in_progress','on_report') AND r.due_date BETWEEN current_date AND current_date + 14
  ) y ORDER BY days, document_id LIMIT 30) x),

-- Документы, которые ждут решения дольше срока напоминания.
'stalled', (SELECT coalesce(json_agg(x ORDER BY x.waiting_h DESC), '[]') FROM (
  SELECT d.id AS document_id, d.title, st.stage_type, st.step_no, u.full_name AS approver,
         extract(epoch FROM now() - coalesce(st.activated_at, st.created_at)) / 3600 AS waiting_h
    FROM st JOIN d ON d.id = st.document_id JOIN users u ON u.id = st.approver_id
   WHERE st.status = 'pending'
     AND extract(epoch FROM now() - coalesce(st.activated_at, st.created_at)) / 3600 >= $7::float8
   ORDER BY waiting_h DESC LIMIT 15) x)
)`
