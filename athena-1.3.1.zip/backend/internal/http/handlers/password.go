package handlers

import (
	"errors"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"golang.org/x/crypto/bcrypt"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/service"
)

// PasswordHandler — самостоятельная смена пароля пользователем.
//
// Раньше пароль мог сменить только администратор, то есть человек, забывший
// или скомпрометировавший пароль, шёл к администратору, а тот знал новый
// пароль — что само по себе плохо.
type PasswordHandler struct {
	pool *pgxpool.Pool
}

func NewPasswordHandler(pool *pgxpool.Pool) *PasswordHandler {
	return &PasswordHandler{pool: pool}
}

// Requirements GET /api/password/requirements — требования к паролю текстом.
//
// Отдаются сервером, а не пишутся в интерфейсе отдельно: иначе подсказка в
// форме и настоящая проверка со временем разойдутся, и человек будет получать
// отказ по правилу, о котором ему не сказали.
func (h *PasswordHandler) Requirements(c *fiber.Ctx) error {
	return c.JSON(fiber.Map{
		"text":       service.PasswordRequirementsText(),
		"min_length": service.PasswordMinLength,
		"min_groups": service.PasswordMinGroups,
		"groups":     []string{"строчные буквы", "заглавные буквы", "цифры", "знаки"},
	})
}

// Change POST /api/password — сменить себе пароль.
// Тело: { "current_password": "...", "new_password": "..." }
func (h *PasswordHandler) Change(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	var req struct {
		CurrentPassword string `json:"current_password"`
		NewPassword     string `json:"new_password"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный запрос")
	}
	if strings.TrimSpace(req.CurrentPassword) == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите текущий пароль")
	}

	// Проверка требований ДО обращения к БД: незачем занимать соединение из-за
	// пароля, который всё равно не подойдёт.
	if err := service.ValidatePassword(req.NewPassword); err != nil {
		// 422, а не 400: запрос корректен, не устраивает именно значение.
		return fiber.NewError(fiber.StatusUnprocessableEntity, err.Error())
	}
	if req.NewPassword == req.CurrentPassword {
		return fiber.NewError(fiber.StatusUnprocessableEntity, "новый пароль совпадает с текущим")
	}

	newHash, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось сохранить пароль")
	}

	var wrongCurrent, domainUser bool
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var curHash string
		if err := tx.QueryRow(c.Context(),
			`SELECT password_hash, domain_id IS NOT NULL FROM users WHERE id = $1 AND is_active = true`, userID).Scan(&curHash, &domainUser); err != nil {
			return err
		}
		// Пароль доменной учётной записи хранится в домене, а не у нас.
		if domainUser {
			return nil
		}
		// Текущий пароль обязателен: иначе чужая открытая сессия позволяла бы
		// сменить пароль и забрать учётную запись.
		if err := bcrypt.CompareHashAndPassword([]byte(curHash), []byte(req.CurrentPassword)); err != nil {
			wrongCurrent = true
			return nil
		}
		if _, err := tx.Exec(c.Context(),
			`UPDATE users SET password_hash = $2 WHERE id = $1`, userID, string(newHash)); err != nil {
			return err
		}
		// Смена пароля — событие безопасности, след о нём обязателен.
		//
		// Ошибка НЕ игнорируется. Первая версия писала в таблицу audit_log,
		// которой в схеме нет, и ошибку глушила присваиванием в `_`. Это
		// работает в Go, но не в PostgreSQL: ошибочный запрос отравляет всю
		// транзакцию, и COMMIT потом падает — пользователь получал бы отказ,
		// а пароль не менялся. Таблица security_events заведена миграцией
		// 0019, и ошибка записи здесь означает настоящую проблему.
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO security_events (user_id, event_type, details)
			VALUES ($1, 'password_changed', 'пароль изменён пользователем')`, userID); err != nil {
			return err
		}
		// Остальные сеансы завершаются: если пароль меняют из-за того, что
		// он стал известен, чужой открытый сеанс должен перестать работать.
		jti, _ := c.Locals(middleware.CtxJTI).(string)
		if _, err := tx.Exec(c.Context(), `
			UPDATE user_sessions SET revoked_at = now(), revoke_reason = 'смена пароля'
			 WHERE user_id = $1 AND revoked_at IS NULL AND jti <> $2`, userID, jti); err != nil {
			return err
		}
		return nil
	})
	if txErr == nil && domainUser {
		return fiber.NewError(fiber.StatusConflict, "пароль доменной учётной записи меняется в домене, а не в системе")
	}
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusUnauthorized, "пользователь не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось сменить пароль")
	}
	if wrongCurrent {
		return fiber.NewError(fiber.StatusForbidden, "текущий пароль указан неверно")
	}
	return c.JSON(fiber.Map{"ok": true})
}
