package handlers

import (
	"crypto/sha256"
	"encoding/hex"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
)

// DuplicatesHandler — предупреждение о повторной регистрации документа.
//
// ЧТО ИЗМЕНИЛОСЬ В v52 И ЧТО ПРИ ЭТОМ ПОТЕРЯНО — СКАЗАНО ПРЯМО.
//
// В версии 51 здесь было ДВА барьера:
//
//	ЖЁСТКИЙ ЗАПРЕТ — уникальный индекс по тройке реквизитов отправителя
//	   («корреспондент + его исходящий номер + дата его документа»). Он
//	   физически не давал зарегистрировать один и тот же входящий документ
//	   дважды;
//	ПРЕДУПРЕЖДЕНИЕ — поиск похожих документов, не запрещающий регистрацию.
//
// Пункт 17 требует убрать корреспондента, его исходящий номер и
// дату его документа. Вместе с реквизитами исчезает и жёсткий запрет по ним:
// сравнивать стало нечего, и никакая замена этого не восполняет — ровно эта
// тройка и была признаком «тот же самый документ».
//
// ЧТО ОСТАЛОСЬ:
//
//	ЖЁСТКИЙ ЗАПРЕТ по входящему номеру внутри подразделения
//	   (uq_incoming_number_per_dept). Он был заведён в v51 именно как ВТОРОЙ,
//	   независимый барьер — на случай, когда реквизиты отправителя не
//	   заполнены, — и работает по-прежнему. Один и тот же входящий номер в
//	   подразделении дважды не выдаётся;
//	ПРЕДУПРЕЖДЕНИЕ по содержимому файла (совпадение sha256) и по заголовку.
//	   Оно не запрещает регистрацию: один и тот же файл законно приходит
//	   повторно (напоминание, рассылка нескольким адресатам), и жёсткий запрет
//	   здесь остановил бы работу.
//
// Практический вывод для организации: защита от повторной регистрации стала
// слабее, и держится она теперь на дисциплине присвоения входящих номеров.
type DuplicatesHandler struct {
	pool *pgxpool.Pool
}

func NewDuplicatesHandler(pool *pgxpool.Pool) *DuplicatesHandler {
	return &DuplicatesHandler{pool: pool}
}

type duplicateCandidate struct {
	DocumentID   int64     `json:"document_id"`
	Title        string    `json:"title"`
	OutNumber    *string   `json:"outgoing_number,omitempty"`
	Status       string    `json:"status"`
	StatusLabel  string    `json:"status_label"`
	CreatedAt    time.Time `json:"created_at"`
	AuthorName   string    `json:"author_name"`
	IncomingNums []string  `json:"incoming_numbers"`
	// Match — чем именно похож: file | title.
	Match      string `json:"match"`
	MatchLabel string `json:"match_label"`
}

var matchLabels = map[string]string{
	"file":  "Тот же файл (совпадает контрольная сумма)",
	"title": "Похожее описание",
}

// Check POST /api/registration/check-duplicate
//
// Вызывается формой регистрации ДО сохранения. Принимает файл (multipart) и/или
// заголовок. Отвечает списком похожих документов — ПРЕДУПРЕЖДЕНИЕМ, без
// запрета: см. пояснение в заголовке файла.
//
// Поле blocking в ответе сохранено и всегда false. Убирать его из ответа
// нельзя: его читает уже работающая у заказчика версия интерфейса, и
// отсутствие поля она истолкует как undefined — то есть как «не блокирует»,
// что верно, но лучше отвечать явно.
func (h *DuplicatesHandler) Check(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	var req struct {
		Title     string `json:"title"`
		ExcludeID int64  `json:"exclude_document_id"`
	}
	// Тело бывает и JSON, и multipart (когда вместе с данными идёт файл).
	if strings.HasPrefix(c.Get("Content-Type"), "multipart/") {
		req.Title = c.FormValue("title")
		req.ExcludeID, _ = strconv.ParseInt(c.FormValue("exclude_document_id"), 10, 64)
	} else {
		_ = c.BodyParser(&req)
	}
	req.Title = strings.TrimSpace(req.Title)

	// Контрольная сумма файла считается здесь же: это самый надёжный признак
	// «тот же документ», не зависящий ни от какого набранного руками текста.
	fileSHA := ""
	if fh, err := c.FormFile("file"); err == nil && fh != nil {
		f, err := fh.Open()
		if err == nil {
			defer f.Close()
			hsh := sha256.New()
			buf := make([]byte, 64*1024)
			for {
				n, rerr := f.Read(buf)
				if n > 0 {
					hsh.Write(buf[:n])
				}
				if rerr != nil {
					break
				}
			}
			fileSHA = hex.EncodeToString(hsh.Sum(nil))
		}
	}

	if req.Title == "" && fileSHA == "" {
		return c.JSON(fiber.Map{"items": []duplicateCandidate{}, "blocking": false})
	}

	items := []duplicateCandidate{}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Свёртка регистра — той же функцией, что и везде в системе: в локали C
		// ILIKE для кириллицы не работает (см. миграцию 0015), и поиск по
		// заголовку без fold_ru находил бы только посимвольные совпадения.
		rows, err := tx.Query(c.Context(), `
			WITH q AS (SELECT NULLIF($1,'') AS sha, NULLIF($2,'') AS ttl)
			SELECT d.id, d.title, d.outgoing_number, d.status::text, d.created_at,
			       coalesce(u.full_name,''),
			       coalesce((SELECT array_agg(i.incoming_number ORDER BY i.incoming_number)
			                   FROM document_incoming_instances i
			                  WHERE i.document_id = d.id), '{}'),
			       CASE
			           WHEN q.sha IS NOT NULL AND EXISTS (
			                SELECT 1 FROM document_files f
			                 WHERE f.document_id = d.id AND f.sha256 = q.sha)
			           THEN 'file'
			           ELSE 'title'
			       END
			  FROM documents d
			  CROSS JOIN q
			  LEFT JOIN users u ON u.id = d.author_id
			 WHERE ($3 = 0 OR d.id <> $3)
			   AND (
			        (q.sha IS NOT NULL AND EXISTS (
			             SELECT 1 FROM document_files f
			              WHERE f.document_id = d.id AND f.sha256 = q.sha))
			     OR (q.ttl IS NOT NULL
			         AND fold_ru(d.title) LIKE '%' || fold_ru(q.ttl) || '%')
			   )
			 ORDER BY d.created_at DESC
			 LIMIT 20`, fileSHA, req.Title, req.ExcludeID)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var x duplicateCandidate
			if err := rows.Scan(&x.DocumentID, &x.Title, &x.OutNumber, &x.Status,
				&x.CreatedAt, &x.AuthorName, &x.IncomingNums, &x.Match); err != nil {
				return err
			}
			x.MatchLabel = matchLabels[x.Match]
			x.StatusLabel = statusLabelRU(x.Status)
			items = append(items, x)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось проверить на повторную регистрацию")
	}

	msg := ""
	if len(items) > 0 {
		msg = "Найдены похожие документы. Проверьте, не регистрируете ли вы его повторно."
	}
	return c.JSON(fiber.Map{
		"items": items, "blocking": false, "message": msg,
		"file_sha256": fileSHA,
	})
}

// CheckIncomingNumber GET /api/registration/check-incoming-number?department_id=4&number=вх-1
//
// Единственный оставшийся ЖЁСТКИЙ барьер повторной регистрации: один и тот же
// входящий номер в подразделении дважды выдан не будет — это держит уникальный
// индекс uq_incoming_number_per_dept. Здесь — предупреждение до попытки,
// чтобы человек узнал о занятом номере до заполнения всей формы, а не из
// отказа при сохранении.
func (h *DuplicatesHandler) CheckIncomingNumber(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	deptID, _ := strconv.ParseInt(c.Query("department_id", "0"), 10, 64)
	number := strings.TrimSpace(c.Query("number"))
	if deptID == 0 || number == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите подразделение и номер")
	}

	var takenBy int64
	var title string
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		err := tx.QueryRow(c.Context(), `
			SELECT i.document_id, coalesce(d.title,'')
			  FROM document_incoming_instances i
			  LEFT JOIN documents d ON d.id = i.document_id
			 WHERE i.receiving_department_id = $1
			   AND normalize_doc_number(i.incoming_number) = normalize_doc_number($2)
			 LIMIT 1`, deptID, number).Scan(&takenBy, &title)
		if err == pgx.ErrNoRows {
			return nil
		}
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось проверить номер")
	}
	if takenBy == 0 {
		return c.JSON(fiber.Map{"taken": false})
	}
	return c.JSON(fiber.Map{
		"taken": true, "document_id": takenBy, "title": title,
		"message": "Этот входящий номер в подразделении уже занят документом «" + title + "»",
	})
}
