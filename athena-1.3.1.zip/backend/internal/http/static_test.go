package http

import (
	"io"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"

	"github.com/gofiber/fiber/v2"
)

func TestSendStatic(t *testing.T) {
	dir := t.TempDir()
	os.MkdirAll(filepath.Join(dir, "assets"), 0o755)
	os.WriteFile(filepath.Join(dir, "assets", "a.js"), []byte("console.log(1)"), 0o644)
	os.WriteFile(filepath.Join(dir, "assets", "a.js.br"), []byte("BR"), 0o644)
	os.WriteFile(filepath.Join(dir, "assets", "a.js.gz"), []byte("GZ"), 0o644)
	os.WriteFile(filepath.Join(dir, "index.html"), []byte("<html>"), 0o644)

	app := fiber.New()
	app.Get("/*", func(c *fiber.Ctx) error {
		rel := c.Path()
		return sendStatic(c, filepath.Join(dir, rel), rel)
	})

	cases := []struct{ path, ae, wantEnc, wantBody, wantCache string }{
		{"/assets/a.js", "gzip, br", "br", "BR", "public, max-age=31536000, immutable"},
		{"/assets/a.js", "gzip", "gzip", "GZ", "public, max-age=31536000, immutable"},
		{"/assets/a.js", "", "", "console.log(1)", "public, max-age=31536000, immutable"},
		{"/assets/a.js", "br;q=0, gzip", "gzip", "GZ", "public, max-age=31536000, immutable"},
		{"/index.html", "br", "", "<html>", "no-cache"},
	}
	for _, tc := range cases {
		req := httptest.NewRequest("GET", tc.path, nil)
		if tc.ae != "" {
			req.Header.Set("Accept-Encoding", tc.ae)
		}
		resp, err := app.Test(req)
		if err != nil {
			t.Fatal(err)
		}
		b, _ := io.ReadAll(resp.Body)
		if resp.Header.Get("Content-Encoding") != tc.wantEnc || string(b) != tc.wantBody || resp.Header.Get("Cache-Control") != tc.wantCache {
			t.Fatalf("%+v: enc=%q body=%q cache=%q", tc, resp.Header.Get("Content-Encoding"), b, resp.Header.Get("Cache-Control"))
		}
		if tc.wantEnc != "" && resp.Header.Get("Content-Type") != "text/javascript; charset=utf-8" {
			t.Fatalf("%+v: тип %q", tc, resp.Header.Get("Content-Type"))
		}
	}
}
