package middleware

import (
	"context"
	"sync"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

// LastSeen отмечает время последней активности пользователя — для раздела
// «кто работает в системе прямо сейчас» в админ-дашборде.
//
// ГЛАВНОЕ: отметка пишется НЕ на каждый запрос.
//
// Открытая страница системы делает запросы постоянно: счётчики категорий раз
// в минуту, колокол по WebSocket, опрос будильников, обновление списка. На
// 1000 пользователей это десятки запросов в секунду, и UPDATE на каждый дал бы
// постоянный поток записи в таблицу users — ровно по той строке, которую
// читает каждая проверка прав. Поэтому в памяти процесса держится время
// последней записи по пользователю, и UPDATE выполняется не чаще, чем раз в
// lastSeenThrottle. Точности «кто активен сейчас» это не вредит: активность
// измеряется минутами, а не секундами.
//
// Запись идёт в отдельной горутине и без RLS-транзакции: это служебное
// действие о самом себе, оно не должно ни задерживать ответ пользователю, ни
// ломать запрос, если БД в этот момент занята.
const lastSeenThrottle = time.Minute

var lastSeen = struct {
	mu sync.Mutex
	at map[int64]time.Time
}{at: make(map[int64]time.Time)}

// lastSeenMaxTracked — предел размера карты. Она не должна расти
// неограниченно: при большом числе пользователей и долгом uptime карта
// занимала бы память впустую. При переполнении карта сбрасывается целиком —
// это приведёт к одному лишнему UPDATE на пользователя, не более.
const lastSeenMaxTracked = 20000

func LastSeen(pool *pgxpool.Pool) fiber.Handler {
	return func(c *fiber.Ctx) error {
		err := c.Next()

		// Только для аутентифицированных запросов: Locals выставляет Auth.
		v := c.Locals(CtxUserID)
		uid, ok := v.(int64)
		if !ok || uid == 0 {
			return err
		}

		now := time.Now()
		lastSeen.mu.Lock()
		prev, seen := lastSeen.at[uid]
		if seen && now.Sub(prev) < lastSeenThrottle {
			lastSeen.mu.Unlock()
			return err
		}
		if len(lastSeen.at) >= lastSeenMaxTracked {
			lastSeen.at = make(map[int64]time.Time, lastSeenMaxTracked/2)
		}
		lastSeen.at[uid] = now
		lastSeen.mu.Unlock()

		// Контекст запроса здесь не годится: он отменяется сразу после
		// отправки ответа, и UPDATE не успел бы выполниться.
		go func(id int64) {
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()
			_, _ = pool.Exec(ctx, `UPDATE users SET last_seen_at = now() WHERE id = $1`, id)
		}(uid)

		return err
	}
}
