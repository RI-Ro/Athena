package middleware

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/base64"
	"net"
	"net/url"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
)

// Сеанс пользователя хранится в cookie, недоступной скриптам страницы.
//
//   - athena_session (по HTTPS — __Host-athena_session) — подписанный токен
//     сеанса: HttpOnly (скрипт страницы его не прочтёт, даже если в неё
//     удалось внедрить чужой код), Secure по HTTPS, SameSite=Strict (браузер
//     не отправит её с запросом, начатого чужим сайтом), Path=/, без Domain
//     (cookie привязана к имени сервера). Префикс __Host- браузер принимает
//     только с Secure, Path=/ и без Domain — это защищает от подмены cookie
//     с соседнего поддомена.
//   - athena_csrf — случайное значение для защиты от подделки запросов
//     (double submit). Скрипту страницы она доступна: интерфейс копирует её в
//     заголовок X-CSRF-Token каждого изменяющего запроса, а сервер сверяет
//     заголовок с cookie. Чужой сайт прочитать её не может, поэтому и
//     заголовок подставить не может.
//
// Порт в «сайт» cookie не входит: cookie, выданная на порту Kerberos,
// действует и на порту входа по паролю того же сервера.
const (
	SessionCookie       = "athena_session"
	SecureSessionCookie = "__Host-athena_session"
	CSRFCookie          = "athena_csrf"
	CSRFHeader          = "X-CSRF-Token"
)

// isHTTPS — пришёл ли запрос по защищённому соединению.
func isHTTPS(c *fiber.Ctx) bool { return c.Protocol() == "https" }

// SessionToken — токен сеанса из cookie запроса ("" — не вошёл).
func SessionToken(c *fiber.Ctx) string {
	if v := c.Cookies(SecureSessionCookie); v != "" {
		return v
	}
	return c.Cookies(SessionCookie)
}

func randomToken() (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}

// SetSessionCookies выдаёт (или продлевает) cookie сеанса до exp. Значение
// CSRF меняется только при входе (rotateCSRF): при продлении сеанса другие
// вкладки продолжают работать с прежним.
func SetSessionCookies(c *fiber.Ctx, token string, exp time.Time, rotateCSRF bool) error {
	secure := isHTTPS(c)
	name := SessionCookie
	if secure {
		name = SecureSessionCookie
	}
	c.Cookie(&fiber.Cookie{
		Name: name, Value: token, Path: "/", Expires: exp,
		HTTPOnly: true, Secure: secure, SameSite: fiber.CookieSameSiteStrictMode,
	})
	csrf := c.Cookies(CSRFCookie)
	if rotateCSRF || len(csrf) < 32 {
		v, err := randomToken()
		if err != nil {
			return err
		}
		csrf = v
	}
	c.Cookie(&fiber.Cookie{
		Name: CSRFCookie, Value: csrf, Path: "/", Expires: exp,
		HTTPOnly: false, Secure: secure, SameSite: fiber.CookieSameSiteStrictMode,
	})
	return nil
}

// ClearSessionCookies удаляет cookie сеанса (выход, отозванный сеанс).
func ClearSessionCookies(c *fiber.Ctx) {
	secure := isHTTPS(c)
	past := time.Unix(0, 0)
	for _, n := range []string{SessionCookie, SecureSessionCookie, CSRFCookie} {
		if n == SecureSessionCookie && !secure {
			continue
		}
		c.Cookie(&fiber.Cookie{
			Name: n, Value: "", Path: "/", Expires: past, MaxAge: -1,
			HTTPOnly: n != CSRFCookie, Secure: secure, SameSite: fiber.CookieSameSiteStrictMode,
		})
	}
}

// requestHost — имя сервера из запроса без порта.
func requestHost(c *fiber.Ctx) string {
	h := string(c.Request().Host())
	if host, _, err := net.SplitHostPort(h); err == nil {
		return strings.Trim(host, "[]")
	}
	return strings.Trim(h, "[]")
}

func unsafeMethod(m string) bool {
	switch m {
	case fiber.MethodGet, fiber.MethodHead, fiber.MethodOptions:
		return false
	}
	return true
}

// CSRF сверяет заголовок X-CSRF-Token с cookie athena_csrf у каждого
// изменяющего запроса. Стоит после проверки сеанса: запросы без сеанса до
// сюда не доходят.
func CSRF() fiber.Handler {
	return func(c *fiber.Ctx) error {
		if !unsafeMethod(c.Method()) {
			return c.Next()
		}
		cookie, header := c.Cookies(CSRFCookie), c.Get(CSRFHeader)
		if cookie == "" || header == "" ||
			subtle.ConstantTimeCompare([]byte(cookie), []byte(header)) != 1 {
			return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
				"error":  "запрос отклонён: не подтверждён источник (обновите страницу)",
				"reason": "csrf",
			})
		}
		return c.Next()
	}
}

// SameOrigin отклоняет изменяющие запросы и открытие WebSocket, начатые
// страницей другого сайта (заголовок Origin с чужим именем сервера).
// Порт не сравнивается: страница порта Kerberos обращается к тому же
// серверу. allowed — дополнительно разрешённые источники
// (http.allowed_origins), например адрес среды разработки.
func SameOrigin(allowed []string) fiber.Handler {
	extra := map[string]bool{}
	for _, a := range allowed {
		extra[strings.TrimRight(strings.ToLower(strings.TrimSpace(a)), "/")] = true
	}
	return func(c *fiber.Ctx) error {
		ws := strings.EqualFold(c.Get(fiber.HeaderUpgrade), "websocket")
		if !unsafeMethod(c.Method()) && !ws {
			return c.Next()
		}
		origin := c.Get(fiber.HeaderOrigin)
		if origin == "" {
			// Не браузер (или браузер, который Origin не прислал на
			// одноимённый запрос). Для запросов с cookie остаётся CSRF и
			// SameSite=Strict.
			return c.Next()
		}
		o := strings.TrimRight(strings.ToLower(origin), "/")
		if extra[o] {
			return c.Next()
		}
		u, err := url.Parse(o)
		if err == nil && u.Hostname() != "" && strings.EqualFold(u.Hostname(), requestHost(c)) {
			return c.Next()
		}
		return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
			"error": "запрос с чужого сайта отклонён", "reason": "origin",
		})
	}
}
