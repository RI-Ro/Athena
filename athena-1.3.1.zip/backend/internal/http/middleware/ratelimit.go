package middleware

import (
	"strconv"
	"sync"
	"time"

	"github.com/gofiber/fiber/v2"
)

// Предел частоты обращений.
//
// ПОЧЕМУ СЧЁТ ИДЁТ ПО ПОЛЬЗОВАТЕЛЮ, А НЕ ПО АДРЕСУ.
//
// Обычный ограничитель считает запросы по IP. В учреждении это не работает:
// целое подразделение выходит в сеть через один NAT, и с точки зрения сервера
// сто человек — это один адрес. Общий предел они выбирают втроём, а остальные
// девяносто семь получают отказ, ничего не сделав. Жалоба «ограничения мешают
// тем, кто за NAT» — ровно про это.
//
// Поэтому ключ здесь — идентификатор пользователя из токена. Предел получается
// персональным: сколько бы людей ни сидело за одним адресом, друг другу они не
// мешают. Для запросов без токена (их немного: вход и общедоступная настройка
// оформления) ключом остаётся адрес — другого признака просто нет.
//
// Алгоритм — «дырявое ведро» (token bucket): rate пополнений в секунду и
// burst как ёмкость. Ровный предел без burst отвергал бы обычную работу
// интерфейса: открытие карточки документа — это сразу десяток запросов
// (вкладки, счётчики, уведомления), и они идут одной пачкой. Поэтому ёмкость
// по умолчанию заметно больше скорости: пачка проходит целиком, а непрерывный
// поток всё равно упирается в rate.
//
// Предел ВЫКЛЮЧЕН по умолчанию (rate = 0): включать ограничение молча, без
// просьбы, значило бы добавить отказы туда, где их не было.

type bucket struct {
	tokens float64
	last   time.Time
}

type rateLimiter struct {
	mu      sync.Mutex
	buckets map[string]*bucket
	rate    float64
	burst   float64
}

// limiterMaxTracked — предел размера карты, чтобы она не росла бесконечно.
// При переполнении карта сбрасывается целиком: это даёт всем по полному
// ведру, то есть в худшем случае один лишний всплеск — и это безопаснее, чем
// занимать память без границы.
const limiterMaxTracked = 50000

func (l *rateLimiter) allow(key string, now time.Time) bool {
	l.mu.Lock()
	defer l.mu.Unlock()

	b, ok := l.buckets[key]
	if !ok {
		if len(l.buckets) >= limiterMaxTracked {
			l.buckets = make(map[string]*bucket, limiterMaxTracked/2)
		}
		b = &bucket{tokens: l.burst, last: now}
		l.buckets[key] = b
	}

	// Пополнение пропорционально прошедшему времени.
	elapsed := now.Sub(b.last).Seconds()
	if elapsed > 0 {
		b.tokens += elapsed * l.rate
		if b.tokens > l.burst {
			b.tokens = l.burst
		}
		b.last = now
	}

	if b.tokens < 1 {
		return false
	}
	b.tokens--
	return true
}

// RateLimit возвращает middleware предела частоты. rate <= 0 — предела нет, и
// тогда возвращается пустой обработчик: ни карты, ни блокировки, ни лишней
// работы на запрос.
func RateLimit(rate float64, burst int) fiber.Handler {
	if rate <= 0 {
		return func(c *fiber.Ctx) error { return c.Next() }
	}
	if burst <= 0 {
		// Разумная ёмкость по умолчанию: пачка запросов при открытии
		// карточки документа должна проходить целиком.
		burst = int(rate * 10)
		if burst < 20 {
			burst = 20
		}
	}
	l := &rateLimiter{
		buckets: make(map[string]*bucket),
		rate:    rate,
		burst:   float64(burst),
	}
	retryAfter := strconv.Itoa(int(1/rate) + 1)

	return func(c *fiber.Ctx) error {
		key := limiterKey(c)
		if l.allow(key, time.Now()) {
			return c.Next()
		}
		// Retry-After говорит клиенту, когда повторить. Без него браузер и
		// любой скрипт повторяют немедленно и только усугубляют затор.
		c.Set("Retry-After", retryAfter)
		return fiber.NewError(fiber.StatusTooManyRequests,
			"слишком много запросов, повторите через несколько секунд")
	}
}

// limiterKey — пользователь, если запрос аутентифицирован, иначе адрес.
// Именно это и делает предел пригодным для работы через NAT.
func limiterKey(c *fiber.Ctx) string {
	if v, ok := c.Locals(CtxUserID).(int64); ok && v != 0 {
		return "u" + strconv.FormatInt(v, 10)
	}
	return "a" + ClientIP(c)
}
