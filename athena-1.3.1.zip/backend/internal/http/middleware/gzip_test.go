package middleware

import (
	"compress/gzip"
	"io"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v2"
)

func newApp() *fiber.App {
	app := fiber.New()
	app.Use(Gzip())
	app.Get("/big", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"v": strings.Repeat("документ ", 500)})
	})
	app.Get("/small", func(c *fiber.Ctx) error { return c.JSON(fiber.Map{"v": 1}) })
	app.Get("/pdf", func(c *fiber.Ctx) error {
		c.Set(fiber.HeaderContentType, "application/pdf")
		return c.SendString(strings.Repeat("x", 5000))
	})
	return app
}

func TestGzipBigJSON(t *testing.T) {
	app := newApp()
	req := httptest.NewRequest("GET", "/big", nil)
	req.Header.Set("Accept-Encoding", "gzip, br")
	resp, err := app.Test(req)
	if err != nil {
		t.Fatal(err)
	}
	if resp.Header.Get("Content-Encoding") != "gzip" {
		t.Fatalf("ожидали gzip, получили %q", resp.Header.Get("Content-Encoding"))
	}
	zr, err := gzip.NewReader(resp.Body)
	if err != nil {
		t.Fatal(err)
	}
	b, _ := io.ReadAll(zr)
	if !strings.Contains(string(b), "документ") {
		t.Fatal("тело после распаковки повреждено")
	}
}

func TestGzipSkips(t *testing.T) {
	app := newApp()
	for _, tc := range []struct{ path, ae, rng string }{
		{"/small", "gzip", ""},
		{"/pdf", "gzip", ""},
		{"/big", "", ""},
		{"/big", "gzip", "bytes=0-10"},
	} {
		req := httptest.NewRequest("GET", tc.path, nil)
		if tc.ae != "" {
			req.Header.Set("Accept-Encoding", tc.ae)
		}
		if tc.rng != "" {
			req.Header.Set("Range", tc.rng)
		}
		resp, err := app.Test(req)
		if err != nil {
			t.Fatal(err)
		}
		if enc := resp.Header.Get("Content-Encoding"); enc != "" {
			t.Fatalf("%+v: не должно сжиматься, получили %q", tc, enc)
		}
	}
}
