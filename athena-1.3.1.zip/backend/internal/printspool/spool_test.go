package printspool

import (
	"io"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"
)

func TestSendRemovesFile(t *testing.T) {
	dir := t.TempDir()
	// остаток прошлого запуска удаляется при старте
	if err := os.WriteFile(dir+"/"+prefix+"old.pdf", []byte("x"), 0o600); err != nil {
		t.Fatal(err)
	}
	past := time.Now().Add(-time.Hour)
	os.Chtimes(dir+"/"+prefix+"old.pdf", past, past)
	s, err := New(dir, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	if n, _ := os.ReadDir(dir); len(n) != 0 {
		t.Fatalf("остатки не удалены при запуске: %d", len(n))
	}
	app := fiber.New()
	app.Get("/p", func(c *fiber.Ctx) error { return s.Send(c, []byte("%PDF-test")) })
	resp, err := app.Test(httptest.NewRequest("GET", "/p", nil))
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(resp.Body)
	if string(body) != "%PDF-test" {
		t.Fatalf("тело ответа: %q", body)
	}
	time.Sleep(50 * time.Millisecond)
	if n, _ := os.ReadDir(dir); len(n) != 0 {
		t.Fatalf("файл выдачи не удалён после отдачи: %d", len(n))
	}
}

func TestSweepOld(t *testing.T) {
	dir := t.TempDir()
	s, _ := New(dir, time.Minute)
	p := dir + "/" + prefix + "stale.pdf"
	os.WriteFile(p, []byte("x"), 0o600)
	old := time.Now().Add(-10 * time.Minute)
	os.Chtimes(p, old, old)
	os.WriteFile(dir+"/"+prefix+"fresh.pdf", []byte("x"), 0o600)
	s.sweep(s.maxAge)
	if _, err := os.Stat(p); !os.IsNotExist(err) {
		t.Fatal("старый файл не удалён")
	}
	if _, err := os.Stat(dir + "/" + prefix + "fresh.pdf"); err != nil {
		t.Fatal("свежий файл удалён раньше времени")
	}
}
