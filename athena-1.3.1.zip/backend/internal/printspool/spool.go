// Package printspool — папка выдачи документов на печать.
//
// Промаркированный PDF перед отдачей пользователю записывается в отдельную
// папку (print.spool_dir), отдаётся из неё потоком и удаляется сразу после
// отдачи. Удаление гарантировано трижды:
//   - поток закрывается сервером после отправки (или обрыва) — файл удаляется;
//   - фоновая уборка раз в минуту удаляет файлы старше max_age (на случай,
//     если процесс был остановлен посреди отдачи);
//   - при запуске приложения удаляются остатки прошлых запусков.
//
// Файлы создаются с правами 0600 в папке 0700: прочитать их может только
// учётная запись службы.
package printspool

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
)

const prefix = "athena-print-"

type Spool struct {
	dir    string
	maxAge time.Duration
}

// New готовит папку: создаёт при необходимости и удаляет остатки прошлых
// запусков.
func New(dir string, maxAge time.Duration) (*Spool, error) {
	if strings.TrimSpace(dir) == "" {
		dir = filepath.Join(os.TempDir(), "athena-print")
	}
	if maxAge <= 0 {
		maxAge = 5 * time.Minute
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, fmt.Errorf("папка печати %s: %w", dir, err)
	}
	_ = os.Chmod(dir, 0o700)
	s := &Spool{dir: dir, maxAge: maxAge}
	// Остатки прошлых запусков. Порог в полминуты, а не ноль: при нескольких
	// рабочих процессах перезапущенный процесс не должен удалить файл,
	// который прямо сейчас отдаёт соседний.
	s.sweep(30 * time.Second)
	return s, nil
}

func (s *Spool) Dir() string { return s.dir }

// Send записывает data во временный файл папки и отдаёт его ответом;
// файл удаляется, как только сервер закроет поток.
func (s *Spool) Send(c *fiber.Ctx, data []byte) error {
	f, err := os.CreateTemp(s.dir, prefix+"*.pdf")
	if err != nil {
		return fmt.Errorf("папка печати: %w", err)
	}
	name := f.Name()
	fail := func(e error) error {
		f.Close()
		os.Remove(name)
		return e
	}
	if err := f.Chmod(0o600); err != nil {
		return fail(err)
	}
	if _, err := f.Write(data); err != nil {
		return fail(err)
	}
	if _, err := f.Seek(0, 0); err != nil {
		return fail(err)
	}
	c.Response().SetBodyStream(&removeOnClose{File: f}, len(data))
	return nil
}

// removeOnClose удаляет файл при закрытии потока.
type removeOnClose struct{ *os.File }

func (r *removeOnClose) Close() error {
	err := r.File.Close()
	if rmErr := os.Remove(r.File.Name()); rmErr != nil && !os.IsNotExist(rmErr) {
		log.Printf("печать: не удалось удалить %s: %v", r.File.Name(), rmErr)
	}
	return err
}

// sweep удаляет файлы выдачи старше olderThan.
func (s *Spool) sweep(olderThan time.Duration) {
	entries, err := os.ReadDir(s.dir)
	if err != nil {
		return
	}
	now := time.Now()
	for _, e := range entries {
		if e.IsDir() || !strings.HasPrefix(e.Name(), prefix) {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		if now.Sub(info.ModTime()) > olderThan {
			p := filepath.Join(s.dir, e.Name())
			if err := os.Remove(p); err == nil {
				log.Printf("печать: удалён оставшийся файл выдачи %s", e.Name())
			}
		}
	}
}

// StartJanitor — фоновая уборка папки раз в минуту.
func (s *Spool) StartJanitor(ctx context.Context) {
	go func() {
		t := time.NewTicker(time.Minute)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				s.sweep(s.maxAge)
			}
		}
	}()
}
