package service

import (
	"context"
	"errors"
	"fmt"
	"net/mail"
	"strings"

	"github.com/jackc/pgx/v5"
	"golang.org/x/crypto/bcrypt"
)

// AdminService — операции администрирования оргструктуры и пользователей.
// Ключевая сложность — корректное сопровождение таблицы транзитивного
// замыкания department_closure при создании и, особенно, при переносе
// (drag-and-drop) подразделений вместе с их поддеревом.
type AdminService struct{}

func NewAdminService() *AdminService { return &AdminService{} }

var (
	ErrDeptHasChildren = errors.New("подразделение содержит вложенные подразделения")
	ErrDeptHasUsers    = errors.New("в подразделении есть пользователи")
	ErrCycle           = errors.New("нельзя переместить подразделение внутрь его же поддерева")
	ErrLoginTaken      = errors.New("логин уже занят")
	ErrPrefixTaken     = errors.New("префикс нумерации уже занят")
	ErrDomainUser      = errors.New("у доменной учётной записи логин и пароль задаются в домене и здесь не меняются")
	ErrBadEmail        = errors.New("адрес электронной почты указан неверно")
	ErrBadLogin        = errors.New("недопустимый логин: для доменной учётной записи укажите имя без домена, для локальной — без символа @")
)

// ---------------------------------------------------------------------------
// Подразделения
// ---------------------------------------------------------------------------

// CreateDepartment создаёт подразделение и добавляет строки замыкания:
// self (depth 0) + связи от всех предков нового родителя. parentID=0 => корень.
func (s *AdminService) CreateDepartment(ctx context.Context, tx pgx.Tx, name, numberingPrefix, city string, parentID int64) (int64, error) {
	var newID int64
	var parent any
	if parentID > 0 {
		parent = parentID
	}
	err := tx.QueryRow(ctx, `
		INSERT INTO departments (parent_id, name, numbering_prefix, city)
		VALUES ($1, $2, NULLIF($3,''), NULLIF($4,''))
		RETURNING id`, parent, name, numberingPrefix, city).Scan(&newID)
	if err != nil {
		if isUniqueViolation(err) {
			return 0, ErrPrefixTaken
		}
		return 0, fmt.Errorf("insert department: %w", err)
	}
	// self-link
	if _, err := tx.Exec(ctx, `INSERT INTO department_closure (ancestor_id, descendant_id, depth) VALUES ($1,$1,0)`, newID); err != nil {
		return 0, fmt.Errorf("closure self: %w", err)
	}
	// связи от всех предков родителя (включая самого родителя)
	if parentID > 0 {
		if _, err := tx.Exec(ctx, `
			INSERT INTO department_closure (ancestor_id, descendant_id, depth)
			SELECT c.ancestor_id, $1, c.depth + 1
			FROM department_closure c
			WHERE c.descendant_id = $2`, newID, parentID); err != nil {
			return 0, fmt.Errorf("closure ancestors: %w", err)
		}
	}
	return newID, nil
}

// UpdateDepartment меняет редактируемые поля (без родителя — для переноса есть
// MoveDepartment). Пустая строка numberingPrefix => NULL.
func (s *AdminService) UpdateDepartment(ctx context.Context, tx pgx.Tx, id int64, name, numberingPrefix, city string, isActive bool) error {
	ct, err := tx.Exec(ctx, `
		UPDATE departments
		SET name=$2, numbering_prefix=NULLIF($3,''), city=NULLIF($4,''), is_active=$5
		WHERE id=$1`, id, name, numberingPrefix, city, isActive)
	if err != nil {
		if isUniqueViolation(err) {
			return ErrPrefixTaken
		}
		return fmt.Errorf("update department: %w", err)
	}
	if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

// MoveDepartment переносит подразделение id (со всем поддеревом) под нового
// родителя newParentID (0 => сделать корневым). Полностью перестраивает
// department_closure для перемещённого поддерева по стандартному алгоритму
// closure-table move. Защита от циклов: newParent не должен быть потомком id.
func (s *AdminService) MoveDepartment(ctx context.Context, tx pgx.Tx, id, newParentID int64) error {
	if id == newParentID {
		return ErrCycle
	}
	if newParentID > 0 {
		var inSubtree bool
		if err := tx.QueryRow(ctx, `
			SELECT EXISTS(SELECT 1 FROM department_closure WHERE ancestor_id=$1 AND descendant_id=$2)`,
			id, newParentID).Scan(&inSubtree); err != nil {
			return err
		}
		if inSubtree {
			return ErrCycle
		}
	}

	// 1) Обновляем parent_id.
	var parent any
	if newParentID > 0 {
		parent = newParentID
	}
	if ct, err := tx.Exec(ctx, `UPDATE departments SET parent_id=$2 WHERE id=$1`, id, parent); err != nil {
		return fmt.Errorf("update parent: %w", err)
	} else if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}

	// 2) Удаляем «внешние» связи: пары (ancestor, descendant), где потомок —
	//    из поддерева id, а предок — НЕ из поддерева id (т.е. старые предки).
	if _, err := tx.Exec(ctx, `
		DELETE FROM department_closure
		WHERE descendant_id IN (SELECT descendant_id FROM department_closure WHERE ancestor_id=$1)
		  AND ancestor_id NOT IN (SELECT descendant_id FROM department_closure WHERE ancestor_id=$1)`,
		id); err != nil {
		return fmt.Errorf("closure detach: %w", err)
	}

	// 3) Добавляем новые связи: каждый предок нового родителя × каждый потомок
	//    перемещаемого узла, с суммой глубин + 1.
	if newParentID > 0 {
		if _, err := tx.Exec(ctx, `
			INSERT INTO department_closure (ancestor_id, descendant_id, depth)
			SELECT super.ancestor_id, sub.descendant_id, super.depth + sub.depth + 1
			FROM department_closure super
			CROSS JOIN department_closure sub
			WHERE super.descendant_id = $2
			  AND sub.ancestor_id = $1`, id, newParentID); err != nil {
			return fmt.Errorf("closure attach: %w", err)
		}
	}
	return nil
}

// DeleteDepartment удаляет подразделение. Нельзя, если есть вложенные
// подразделения или пользователи (parent_id — RESTRICT, users ссылаются).
func (s *AdminService) DeleteDepartment(ctx context.Context, tx pgx.Tx, id int64) error {
	var children, users int
	if err := tx.QueryRow(ctx, `SELECT count(*) FROM departments WHERE parent_id=$1`, id).Scan(&children); err != nil {
		return err
	}
	if children > 0 {
		return ErrDeptHasChildren
	}
	if err := tx.QueryRow(ctx, `SELECT count(*) FROM users WHERE primary_department_id=$1`, id).Scan(&users); err != nil {
		return err
	}
	if users > 0 {
		return ErrDeptHasUsers
	}
	// closure-строки уберутся каскадом (FK ON DELETE CASCADE).
	ct, err := tx.Exec(ctx, `DELETE FROM departments WHERE id=$1`, id)
	if err != nil {
		return fmt.Errorf("delete department: %w", err)
	}
	if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

// ---------------------------------------------------------------------------
// Пользователи
// ---------------------------------------------------------------------------

// CreateUser создаёт пользователя. domainID=0 — локальная учётная запись с
// bcrypt-хэшем пароля; domainID>0 — учётная запись домена: логин сохраняется
// как имя@REALM, локального пароля нет (password_hash = '!').
func (s *AdminService) CreateUser(ctx context.Context, tx pgx.Tx, login, password, fullName, position, basis string, deptID, domainID int64) (int64, error) {
	hash := "!"
	var domain any
	if domainID > 0 {
		var realm string
		if err := tx.QueryRow(ctx, `SELECT realm FROM auth_domains WHERE id=$1`, domainID).Scan(&realm); err != nil {
			return 0, err
		}
		// Допускаем ввод «ivanov» и «ivanov@REALM» — но только своего домена.
		name := login
		if i := strings.LastIndex(login, "@"); i >= 0 {
			if !strings.EqualFold(login[i+1:], realm) {
				return 0, ErrBadLogin
			}
			name = login[:i]
		}
		if name == "" || strings.ContainsAny(name, `@\ `) {
			return 0, ErrBadLogin
		}
		login = strings.ToLower(name) + "@" + realm
		domain = domainID
	} else {
		if strings.Contains(login, "@") {
			return 0, ErrBadLogin
		}
		h, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
		if err != nil {
			return 0, fmt.Errorf("hash password: %w", err)
		}
		hash = string(h)
	}
	var dept any
	if deptID > 0 {
		dept = deptID
	}
	var id int64
	err := tx.QueryRow(ctx, `
		INSERT INTO users (login, password_hash, full_name, position, basis, primary_department_id, numbering_department_id, domain_id)
		VALUES ($1, $2, $3, NULLIF($4,''), NULLIF($5,''), $6, $6, $7)
		RETURNING id`, login, hash, fullName, position, basis, dept, domain).Scan(&id)
	if err != nil {
		if isUniqueViolation(err) {
			return 0, ErrLoginTaken
		}
		return 0, fmt.Errorf("insert user: %w", err)
	}
	return id, nil
}

// UpdateUser меняет ФИО, должность, логин, подразделение и активность.
func (s *AdminService) UpdateUser(ctx context.Context, tx pgx.Tx, id int64, login, fullName, position, basis string, deptID, numberingDeptID int64, isActive bool) error {
	var dept, numDept any
	if deptID > 0 {
		dept = deptID
	}
	// numbering_department_id: если явно не задан — совпадает с основным.
	if numberingDeptID > 0 {
		numDept = numberingDeptID
	} else {
		numDept = dept
	}
	// Логин доменной учётной записи — это имя в домене; менять его здесь
	// нельзя (иначе запись перестанет соответствовать человеку в каталоге).
	// У локальной — нельзя добавить «@».
	var isDomain bool
	var curLogin string
	if err := tx.QueryRow(ctx, `SELECT domain_id IS NOT NULL, login FROM users WHERE id=$1`, id).Scan(&isDomain, &curLogin); err != nil {
		return err
	}
	if isDomain {
		login = curLogin
	} else if strings.Contains(login, "@") || strings.TrimSpace(login) == "" {
		return ErrBadLogin
	}
	ct, err := tx.Exec(ctx, `
		UPDATE users
		SET login=$2, full_name=$3, position=NULLIF($4,''), basis=NULLIF($8,''), primary_department_id=$5,
		    numbering_department_id=$6, is_active=$7
		WHERE id=$1`, id, login, fullName, position, dept, numDept, isActive, basis)
	if err != nil {
		if isUniqueViolation(err) {
			return ErrLoginTaken
		}
		return fmt.Errorf("update user: %w", err)
	}
	if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

// allowedDeptSetTables — таблицы «дополнительных подразделений» пользователя,
// которыми управляет админ. Whitelist защищает от инъекции имени таблицы.
var allowedDeptSetTables = map[string]bool{
	"user_visible_departments":  true,
	"user_acquaint_departments": true,
	"user_incoming_departments": true,
	"user_redirect_departments": true,
	//, п. 4 — дополнительные подразделения, по документам
	// которых пользователь вправе накладывать резолюцию. Своё подразделение и
	// подчинённые ему действуют без записи в этой таблице (они берутся из
	// иерархии), здесь — только подразделения ВНЕ своей ветки.
	"user_resolution_departments": true,
}

// SetUserDepartmentSet заменяет полный набор подразделений в одной из таблиц
// user_visible/acquaint/assign_departments для пользователя.
func (s *AdminService) SetUserDepartmentSet(ctx context.Context, tx pgx.Tx, table string, userID int64, deptIDs []int64) error {
	if !allowedDeptSetTables[table] {
		return fmt.Errorf("недопустимая таблица набора подразделений: %s", table)
	}
	if _, err := tx.Exec(ctx, "DELETE FROM "+table+" WHERE user_id=$1", userID); err != nil {
		return fmt.Errorf("clear %s: %w", table, err)
	}
	if len(deptIDs) == 0 {
		return nil
	}
	if _, err := tx.Exec(ctx,
		"INSERT INTO "+table+" (user_id, department_id) SELECT $1, d FROM unnest($2::bigint[]) AS d ON CONFLICT DO NOTHING",
		userID, deptIDs); err != nil {
		return fmt.Errorf("insert %s: %w", table, err)
	}
	return nil
}

// MoveUser переносит пользователя в другое подразделение (drag-and-drop).
func (s *AdminService) MoveUser(ctx context.Context, tx pgx.Tx, id, deptID int64) error {
	var dept any
	if deptID > 0 {
		dept = deptID
	}
	ct, err := tx.Exec(ctx, `UPDATE users SET primary_department_id=$2, numbering_department_id=$2 WHERE id=$1`, id, dept)
	if err != nil {
		return fmt.Errorf("move user: %w", err)
	}
	if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

// SetPassword задаёт новый пароль пользователю.
func (s *AdminService) SetPassword(ctx context.Context, tx pgx.Tx, id int64, password string) error {
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return fmt.Errorf("hash password: %w", err)
	}
	ct, err := tx.Exec(ctx, `UPDATE users SET password_hash=$2 WHERE id=$1 AND domain_id IS NULL`, id, string(hash))
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		var isDomain bool
		if e := tx.QueryRow(ctx, `SELECT domain_id IS NOT NULL FROM users WHERE id=$1`, id).Scan(&isDomain); e == nil && isDomain {
			return ErrDomainUser
		}
		return pgx.ErrNoRows
	}
	return nil
}

// SetRoles заменяет набор ролей пользователя в указанном подразделении.
// deptID=0 => глобальные роли (department_id IS NULL), напр. admin.
func (s *AdminService) SetRoles(ctx context.Context, tx pgx.Tx, id, deptID int64, roles []string) error {
	if deptID > 0 {
		if _, err := tx.Exec(ctx, `DELETE FROM user_roles WHERE user_id=$1 AND department_id=$2`, id, deptID); err != nil {
			return err
		}
	} else {
		if _, err := tx.Exec(ctx, `DELETE FROM user_roles WHERE user_id=$1 AND department_id IS NULL`, id); err != nil {
			return err
		}
	}
	for _, r := range roles {
		var dept any
		if deptID > 0 {
			dept = deptID
		}
		if _, err := tx.Exec(ctx, `
			INSERT INTO user_roles (user_id, department_id, role)
			VALUES ($1, $2, $3::role_code) ON CONFLICT DO NOTHING`, id, dept, r); err != nil {
			return fmt.Errorf("insert role %s: %w", r, err)
		}
	}
	return nil
}

// isUniqueViolation распознаёт нарушение уникальности Postgres (SQLSTATE 23505).
func isUniqueViolation(err error) bool {
	return err != nil && (containsSQLState(err, "23505"))
}

func containsSQLState(err error, code string) bool {
	type sqlStater interface{ SQLState() string }
	var s sqlStater
	if errors.As(err, &s) {
		return s.SQLState() == code
	}
	return false
}

// SetEmail задаёт адрес электронной почты пользователя (пустая строка —
// убрать). На этот адрес приходят письма о новых входящих документах.
func (s *AdminService) SetEmail(ctx context.Context, tx pgx.Tx, id int64, email string) error {
	email = strings.TrimSpace(email)
	if email != "" {
		if a, err := mail.ParseAddress(email); err != nil || a.Address != email {
			return ErrBadEmail
		}
	}
	_, err := tx.Exec(ctx, `UPDATE users SET email = NULLIF($2,'') WHERE id = $1`, id, email)
	return err
}
