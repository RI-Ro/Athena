package service

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
)

var (
	ErrSelfApproval      = errors.New("нельзя назначить самого себя согласующим")
	ErrDuplicateApprover = errors.New("один и тот же согласующий добавлен несколько раз")
	ErrSignerIsApprover  = errors.New("один и тот же сотрудник указан и согласующим, и подписантом — уберите его из одного из списков")
	ErrApproverWrongRole = errors.New("пользователь не состоит в группе согласования нужного типа")
	ErrSignerWrongRole   = errors.New("подписант не имеет права подписи")
	ErrNoSigner          = errors.New("подписант обязателен")
	ErrBadSteps          = errors.New("номера шагов согласования должны идти подряд, начиная с 1, без пропусков (например 1, 2, 2, 3)")
)

// ApproverInput — один согласующий в маршруте (тип шага + пользователь).
// Порядок между согласующими задаётся Sequential: если true, каждый
// следующий согласующий видит документ только после предыдущего; если
// false — все согласующие параллельны. Подпись сюда НЕ входит — она
// отдельным полем в RouteInput и всегда идёт после всех согласований.
type ApproverInput struct {
	StageType  string // hierarchy | cross_dept
	ApproverID int64
	// Step — номер шага согласования, который задаёт автор: 1, 2, 2, 3 …
	// Согласующие с одинаковым номером работают параллельно; шаг N+1
	// открывается, когда согласовали ВСЕ на шаге N. 0 — «не задан»
	// (см. NormalizeSteps).
	Step int
}

type RouteInput struct {
	Approvers []ApproverInput
	// Sequential используется, только если номера шагов не заданы:
	// true — согласующие по цепочке (1, 2, 3 …), false — все параллельно (1).
	Sequential bool
	// SignerIDs — подписанты (>=1). Подпись всегда последним шагом, после
	// всех согласующих; достаточно подписи одного из указанных.
	SignerIDs []int64
}

// NormalizeSteps заполняет номера шагов, если автор их не задал вовсе
// (все нули): по порядку списка — цепочкой или одним параллельным шагом.
// Частично заданные номера не «чинятся»: это ошибка ввода, её вернёт
// ValidateRoute.
func NormalizeSteps(in RouteInput) RouteInput {
	for _, a := range in.Approvers {
		if a.Step != 0 {
			return in
		}
	}
	out := in
	out.Approvers = make([]ApproverInput, len(in.Approvers))
	for i, a := range in.Approvers {
		a.Step = 1
		if in.Sequential {
			a.Step = i + 1
		}
		out.Approvers[i] = a
	}
	return out
}

// ValidateSteps проверяет главное правило нумерации: использованные номера —
// это ровно 1..K, без пропусков и не с нуля. 1-2-2-3 допустимо;
// 1-2-2-4, 2-3, 0-1 — нет.
func ValidateSteps(steps []int) error {
	if len(steps) == 0 {
		return nil
	}
	seen := make(map[int]bool, len(steps))
	maxStep := 0
	for _, s := range steps {
		if s < 1 {
			return ErrBadSteps
		}
		seen[s] = true
		if s > maxStep {
			maxStep = s
		}
	}
	if len(seen) != maxStep { // есть пропуск между 1 и maxStep
		return ErrBadSteps
	}
	return nil
}

// ValidateRoute проверяет бизнес-правила ДО записи в БД:
//   - есть подписант;
//   - согласующий не автор документа и не указан дважды;
//   - согласующий состоит в группе согласования нужного типа, подписант
//     имеет право подписи;
//   - один человек не может быть и согласующим, и подписантом;
//   - номера шагов идут подряд от 1 без пропусков.
//
// Ожидает маршрут ПОСЛЕ NormalizeSteps.
func ValidateRoute(in RouteInput, authorID int64, roleOK func(userID int64, stageType string) bool, signerOK func(userID int64) bool) error {
	if len(in.SignerIDs) == 0 {
		return ErrNoSigner
	}
	seen := make(map[int64]bool)
	steps := make([]int, 0, len(in.Approvers))
	for _, a := range in.Approvers {
		if a.ApproverID == authorID {
			return ErrSelfApproval
		}
		if seen[a.ApproverID] {
			return ErrDuplicateApprover
		}
		seen[a.ApproverID] = true
		if !roleOK(a.ApproverID, a.StageType) {
			return ErrApproverWrongRole
		}
		steps = append(steps, a.Step)
	}
	if err := ValidateSteps(steps); err != nil {
		return err
	}
	signSeen := make(map[int64]bool)
	for _, sid := range in.SignerIDs {
		if seen[sid] {
			return ErrSignerIsApprover
		}
		if signSeen[sid] {
			return ErrDuplicateApprover
		}
		signSeen[sid] = true
		if !signerOK(sid) {
			return ErrSignerWrongRole
		}
	}
	return nil
}

// BuildStages превращает маршрут в список этапов с зависимостями для
// ApprovalService.CreateRoute.
//
// Этап шага N зависит от ВСЕХ этапов шага N-1 — поэтому он открывается
// только когда предыдущий шаг пройден целиком, а этапы одного шага
// независимы друг от друга (параллельны). Этапы подписи зависят от всех
// этапов последнего шага согласования и получают следующий номер.
func BuildStages(in RouteInput) []StageInput {
	stages := make([]StageInput, 0, len(in.Approvers)+len(in.SignerIDs))
	byStep := make(map[int][]int)
	maxStep := 0
	for i, a := range in.Approvers {
		byStep[a.Step] = append(byStep[a.Step], i)
		if a.Step > maxStep {
			maxStep = a.Step
		}
	}
	for i, a := range in.Approvers {
		stages = append(stages, StageInput{
			StageType:    a.StageType,
			ApproverID:   a.ApproverID,
			DisplayOrder: a.Step*1000 + i,
			StepNo:       a.Step,
			DependsOnIdx: append([]int{}, byStep[a.Step-1]...),
		})
	}
	for j, sid := range in.SignerIDs {
		stages = append(stages, StageInput{
			StageType:    "signing",
			ApproverID:   sid,
			DisplayOrder: (maxStep+1)*1000 + j,
			StepNo:       maxStep + 1,
			DependsOnIdx: append([]int{}, byStep[maxStep]...),
		})
	}
	return stages
}

// ComputeSteps пересчитывает номера шагов по графу зависимостей: номер этапа
// = 1 + наибольший номер среди этапов, от которых он зависит (этап без
// зависимостей — шаг 1).
//
// Так нумерация остаётся верной после того, как согласующий сам направил
// документ кому-то «перед собой» или «после себя»: граф меняется, а номера
// выводятся из него заново. Номера, полученные таким способом, всегда идут
// подряд от 1 без пропусков: у этапа с номером K обязательно есть
// зависимость с номером K-1.
//
// deps: этап -> этапы, от которых он зависит. При цикле (в исправной базе
// невозможен) оставшиеся этапы получают следующий номер, чтобы функция
// завершилась.
func ComputeSteps(ids []int64, deps map[int64][]int64) map[int64]int {
	steps := make(map[int64]int, len(ids))
	known := make(map[int64]bool, len(ids))
	for _, id := range ids {
		known[id] = true
	}
	for len(steps) < len(ids) {
		progressed := false
		for _, id := range ids {
			if _, done := steps[id]; done {
				continue
			}
			level, ready := 1, true
			for _, d := range deps[id] {
				if !known[d] {
					continue // зависимость от удалённого этапа не считается
				}
				ds, ok := steps[d]
				if !ok {
					ready = false
					break
				}
				if ds+1 > level {
					level = ds + 1
				}
			}
			if ready {
				steps[id] = level
				progressed = true
			}
		}
		if !progressed { // цикл
			maxStep := 0
			for _, v := range steps {
				if v > maxStep {
					maxStep = v
				}
			}
			for _, id := range ids {
				if _, done := steps[id]; !done {
					steps[id] = maxStep + 1
				}
			}
		}
	}
	return steps
}

// LoadRoleCheckers одним запросом собирает, кто в какой группе состоит и кто
// имеет право подписи, и возвращает две замыкающие функции для ValidateRoute.
// Так валидация делает ровно один поход в БД, а не по запросу на каждого
// согласующего (важно при 300-500 участниках).
func (s *ApprovalService) LoadRoleCheckers(ctx context.Context, tx pgx.Tx, userIDs []int64) (
	roleOK func(int64, string) bool, signerOK func(int64) bool, err error) {

	// userID -> set of roles
	roles := make(map[int64]map[string]bool)
	rows, err := tx.Query(ctx, `
		SELECT ur.user_id, ur.role::text FROM user_roles ur
		JOIN users u ON u.id = ur.user_id AND u.is_active
		WHERE ur.user_id = ANY($1::bigint[])`, userIDs)
	if err != nil {
		return nil, nil, fmt.Errorf("load roles: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var uid int64
		var role string
		if err := rows.Scan(&uid, &role); err != nil {
			return nil, nil, err
		}
		if roles[uid] == nil {
			roles[uid] = make(map[string]bool)
		}
		roles[uid][role] = true
	}
	if err := rows.Err(); err != nil {
		return nil, nil, err
	}

	stageTypeToRole := map[string]string{
		"hierarchy":  "approver_hierarchy",
		"cross_dept": "approver_cross_dept",
	}
	roleOK = func(userID int64, stageType string) bool {
		need, ok := stageTypeToRole[stageType]
		if !ok {
			return false
		}
		return roles[userID][need]
	}
	signerOK = func(userID int64) bool {
		return roles[userID]["signer"]
	}
	return roleOK, signerOK, nil
}
