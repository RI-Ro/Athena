package service

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
)

// ===========================================================================
// СЕССИИ: ЗАПРЕТ ОДНОВРЕМЕННОГО ВХОДА С РАЗНЫХ АРМ (, п. 8).
//
// Зачем это нужно в система: действия в системе юридически значимы (подпись,
// резолюция, отметка об исполнении), и они должны быть привязаны не только к
// учётной записи, но и к рабочему месту. Если под одной учёткой одновременно
// работают с двух АРМ, по журналу невозможно сказать, кто именно совершил
// действие, — а это главный довод при разборе спорной ситуации. Плюс
// одновременный вход — типичный признак того, что пароль передали коллеге.
//
// КАК ЭТО СДЕЛАНО.
//
// Инвариант «не более одной действующей сессии на учётную запись» держит
// ЧАСТИЧНЫЙ УНИКАЛЬНЫЙ ИНДЕКС в БД (uq_one_active_session, миграция 0023), а
// не проверка в коде. Это принципиально: два одновременных входа — гонка, и
// последовательность «проверить, есть ли сессия» → «вставить» может пройти в
// обоих запросах, создав две сессии. Уникальный индекс не может: второй
// получит ошибку.
//
// В токене появился jti (идентификатор сессии). Middleware на каждом запросе
// убеждается, что сессия с этим jti жива. Поэтому отзыв сессии действует
// СРАЗУ, а не по истечении срока токена: иначе вытесненный АРМ продолжал бы
// работать до конца TTL, и запрет был бы декоративным.
//
// ДВЕ ПОЛИТИКИ КОНФЛИКТА (uploads/auth в конфиге):
//   * displace (по умолчанию) — новый вход вытесняет прежнюю сессию. Выбрано
//     по умолчанию потому, что иначе упавший браузер, закрытый ноутбук или
//     перезагрузка блокируют человека до истечения TTL, и первым, что он
//     сделает, будет звонок администратору;
//   * deny — новый вход отклоняется, пока действует прежняя сессия. Строже и
//     уместно там, где смена АРМ сама по себе событие; человек должен
//     корректно выйти или дождаться истечения.
// ===========================================================================

// ErrSessionConflict — вход отклонён, т.к. уже есть действующая сессия
// (политика deny).
var ErrSessionConflict = errors.New("уже выполнен вход с другого рабочего места")

// ErrSessionRevoked — сессия отозвана (вытеснена или завершена администратором).
// ErrSessionCheckFailed — проверить сессию не удалось (сбой БД).
var ErrSessionCheckFailed = errors.New("не удалось проверить сессию")

var ErrSessionRevoked = errors.New("сессия завершена")

// SessionConflictPolicy — что делать при входе, если сессия уже есть.
type SessionConflictPolicy string

const (
	PolicyDisplace SessionConflictPolicy = "displace"
	PolicyDeny     SessionConflictPolicy = "deny"
)

// SessionService ведёт таблицу user_sessions и кеш проверок.
type SessionService struct {
	pool   *pgxpool.Pool
	policy SessionConflictPolicy
	audit  *AuditService

	// Кеш живых сессий.
	//
	// Зачем: проверка сессии выполняется на КАЖДОМ запросе, а открытая
	// страница делает их десятками в минуту (счётчики, уведомления, список).
	// Обращение к БД на каждый запрос дало бы постоянный поток чтения по
	// одной и той же строке.
	//
	// Почему кеш короткий (sessionCacheTTL): отзыв сессии должен действовать
	// практически сразу — иначе вытесненный АРМ продолжал бы работать. 10
	// секунд — это компромисс: нагрузка падает в десятки раз, а вытеснение
	// человек видит на следующем действии.
	//
	// Кешируются только ПОЛОЖИТЕЛЬНЫЕ результаты. Отрицательный результат не
	// кешируется вовсе: он и так означает отказ, а кешировать «нет» опасно —
	// при ошибке БД отказ залип бы на весь TTL.
	mu    sync.Mutex
	cache map[string]time.Time // jti -> до какого момента считаем живой
}

var sessionCacheTTL = 10 * time.Second

func init() {
	// В режиме prefork выход или вытеснение сеанса происходит в одном рабочем
	// процессе, а кеш остальных об этом не знает. Поэтому там кеш живёт не
	// дольше секунды: отозванный токен перестаёт приниматься всеми
	// процессами практически сразу.
	if os.Getenv("ATHENA_PREFORK_CHILD") != "" {
		sessionCacheTTL = time.Second
	}
}

// sessionCacheMax — предел размера кеша, чтобы он не рос неограниченно при
// большом числе входов и долгом uptime. При переполнении кеш сбрасывается
// целиком: это приведёт лишь к одной лишней проверке в БД на сессию.
const sessionCacheMax = 20000

func NewSessionService(pool *pgxpool.Pool, policy string, audit *AuditService) *SessionService {
	p := PolicyDisplace
	if SessionConflictPolicy(policy) == PolicyDeny {
		p = PolicyDeny
	}
	return &SessionService{pool: pool, policy: p, audit: audit, cache: map[string]time.Time{}}
}

func (s *SessionService) Policy() SessionConflictPolicy { return s.policy }

// NewJTI — идентификатор сессии для токена.
//
// 32 случайных байта: jti попадает в токен и в БД, и угадывание чужого jti не
// должно быть возможным даже теоретически.
func NewJTI() (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", fmt.Errorf("не удалось получить случайные данные: %w", err)
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}

// SessionMeta — сведения о рабочем месте, с которого выполняется вход.
type SessionMeta struct {
	// IP — фактический адрес пользователя (из X-Forwarded-For/X-Real-IP).
	IP string
	// IPPeer — адрес подключения: за NAT это адрес шлюза, общий для всех за
	// ним. Хранится рядом с фактическим, потому что подделать его клиент не
	// может, а фактический берётся из заголовка.
	IPPeer string
	// IPChain — X-Forwarded-For целиком, как пришёл: весь путь запроса,
	// когда прокси несколько.
	IPChain     string
	UserAgent   string
	Workstation string
}

// Open открывает сессию согласно политике.
//
// Возвращает id новой сессии и сведения о вытесненной (если была), чтобы
// обработчик входа мог сообщить человеку, что его прежний сеанс завершён, и
// записать это в аудит.
type DisplacedSession struct {
	ID          int64
	IP          string
	Workstation string
	CreatedAt   time.Time
}

func (s *SessionService) Open(ctx context.Context, userID int64, jti string,
	expiresAt time.Time, meta SessionMeta) (int64, *DisplacedSession, error) {

	// ОДНО соединение на всю операцию: set_config и последующие запросы
	// обязаны идти по одному физическому соединению, иначе переменная
	// app.user_id не видна запросу (та же причина, что и в db.WithUserTx).
	conn, err := s.pool.Acquire(ctx)
	if err != nil {
		return 0, nil, fmt.Errorf("получение соединения: %w", err)
	}
	defer conn.Release()

	tx, err := conn.Begin(ctx)
	if err != nil {
		return 0, nil, fmt.Errorf("начало транзакции: %w", err)
	}
	defer tx.Rollback(ctx)

	// КОНТЕКСТ RLS ОБЯЗАТЕЛЕН, хотя речь о собственной служебной таблице.
	//
	// Причина, из-за которой вход падал с «не удалось создать сессию»:
	// INSERT ... RETURNING применяет к новой строке не только политику
	// WITH CHECK, но и политику SELECT — иначе вернуть строку было бы нельзя.
	// Политика sessions_select разрешает видеть только свои строки
	// (user_id = app.user_id), а при входе app.user_id не был установлен,
	// и PostgreSQL отвечал «new row violates row-level security policy».
	// Проверено на живой базе: тот же INSERT без RETURNING проходит, а с
	// RETURNING и установленным app.user_id — тоже проходит.
	//
	// Вторая, не менее важная причина: без контекста выборка действующей
	// сессии ниже возвращала пусто ВСЕГДА. То есть вытеснение не
	// обнаруживалось, пользователю не сообщалось, с какого АРМ его
	// вытеснили, а политика deny («запрещать вход») не срабатывала вовсе —
	// запрет был бы декоративным.
	//
	// Запрос без параметров — по той же причине, что в db.WithUserTx:
	// у подготовленного запроса LOCAL-эффект set_config ненадёжен. Значение
	// подставляется из int64, инъекция невозможна.
	if _, err := tx.Exec(ctx, fmt.Sprintf(
		"SELECT set_config('app.user_id', '%d', true), set_config('app.is_admin', 'false', true)",
		userID)); err != nil {
		return 0, nil, fmt.Errorf("установка контекста RLS: %w", err)
	}

	// Действующая сессия: не отозванная И не истёкшая. Истёкшую мы не считаем
	// конфликтом — иначе человек, чей токен уже недействителен, не смог бы
	// войти заново до конца TTL.
	var cur DisplacedSession
	var curJTI string
	err = tx.QueryRow(ctx, `
		SELECT id, coalesce(host(ip),''), coalesce(workstation,''), created_at, jti
		  FROM user_sessions
		 WHERE user_id = $1 AND revoked_at IS NULL AND expires_at > now()
		 LIMIT 1`, userID).Scan(&cur.ID, &cur.IP, &cur.Workstation, &cur.CreatedAt, &curJTI)
	hasCurrent := err == nil
	if err != nil && !errors.Is(err, pgx.ErrNoRows) {
		return 0, nil, fmt.Errorf("поиск действующей сессии: %w", err)
	}

	if hasCurrent && s.policy == PolicyDeny {
		return 0, &cur, ErrSessionConflict
	}

	// Отзываем ВСЕ неотозванные сессии пользователя, включая истёкшие: иначе
	// частичный уникальный индекс (один неотозванный сеанс на пользователя) не
	// дал бы вставить новую строку.
	reason := "вход с другого рабочего места"
	if !hasCurrent {
		reason = "завершение истёкшего сеанса"
	}
	if _, err := tx.Exec(ctx, `
		UPDATE user_sessions SET revoked_at = now(), revoke_reason = $2
		 WHERE user_id = $1 AND revoked_at IS NULL`, userID, reason); err != nil {
		return 0, nil, fmt.Errorf("отзыв прежних сессий: %w", err)
	}

	var id int64
	if err := tx.QueryRow(ctx, `
		INSERT INTO user_sessions (user_id, jti, ip, user_agent, workstation, expires_at,
		                           ip_peer, ip_chain)
		VALUES ($1, $2, NULLIF($3,'')::inet, NULLIF($4,''), NULLIF($5,''), $6,
		        NULLIF($7,'')::inet, NULLIF($8,''))
		RETURNING id`,
		userID, jti, meta.IP, meta.UserAgent, meta.Workstation, expiresAt,
		meta.IPPeer, meta.IPChain).Scan(&id); err != nil {
		return 0, nil, fmt.Errorf("создание сессии: %w", err)
	}
	if err := tx.Commit(ctx); err != nil {
		return 0, nil, fmt.Errorf("фиксация транзакции: %w", err)
	}

	// Вытесненный jti убираем из кеша немедленно, иначе прежний АРМ прожил бы
	// на кеше ещё до sessionCacheTTL.
	if hasCurrent {
		s.mu.Lock()
		delete(s.cache, curJTI)
		s.mu.Unlock()
		return id, &cur, nil
	}
	return id, nil, nil
}

// Check проверяет, что сессия жива, и продлевает отметку активности.
//
// Возвращает id сессии: он нужен журналу аудита, чтобы событие было привязано
// не только к человеку, но и к рабочему месту.
//
// userID обязателен и берётся из уже разобранного токена: без него выборка
// по jti не проходит политику sessions_select (видно только свои сессии), и
// функция ВСЕГДА возвращала бы «сессии нет» — то есть пропускала бы любой
// запрос, включая запросы по вытесненной сессии. Проверено на живой базе:
// без app.user_id выборка по jti пуста, с ним — находит строку.
func (s *SessionService) Check(ctx context.Context, userID int64, jti string) (int64, error) {
	if jti == "" {
		// Токен без идентификатора сессии система не выпускает.
		return 0, fmt.Errorf("%w: токен без сессии", ErrSessionRevoked)
	}

	s.mu.Lock()
	if until, ok := s.cache[jti]; ok && time.Now().Before(until) {
		s.mu.Unlock()
		return 0, nil
	}
	s.mu.Unlock()

	var id int64
	var revoked *time.Time
	var reason string
	err := db.WithUserTx(ctx, s.pool, userID, false, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx, `
			SELECT id, revoked_at, coalesce(revoke_reason,'')
			  FROM user_sessions WHERE jti = $1`, jti).Scan(&id, &revoked, &reason)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		// Сессии нет — токен не от действующего входа.
		return 0, fmt.Errorf("%w: сессия не найдена", ErrSessionRevoked)
	}
	if err != nil {
		// Сбой БД: пропускать запрос «на всякий случай» нельзя (отозванная
		// сессия продолжала бы работать), но и разлогинивать человека не за
		// что — отвечаем «временно недоступно».
		return 0, fmt.Errorf("%w: %v", ErrSessionCheckFailed, err)
	}
	if revoked != nil {
		if reason == "" {
			reason = "сессия завершена"
		}
		return id, fmt.Errorf("%w: %s", ErrSessionRevoked, reason)
	}

	s.mu.Lock()
	if len(s.cache) >= sessionCacheMax {
		s.cache = make(map[string]time.Time, sessionCacheMax/2)
	}
	s.cache[jti] = time.Now().Add(sessionCacheTTL)
	s.mu.Unlock()
	return id, nil
}

// Touch обновляет last_seen_at сессии. Вызывается с тем же дросселем, что и
// LastSeen по пользователю, — на каждый запрос это была бы лишняя запись.
// Touch не требует контекста RLS: политика sessions_update разрешает
// обновление без условия (USING true), потому что отметку активности и отзыв
// сессии делает только серверный код. Выборки здесь нет, поэтому ограничение
// видимости из sessions_select не применяется.
func (s *SessionService) Touch(jti string) {
	if jti == "" {
		return
	}
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		_ = s.execSystem(ctx, `UPDATE user_sessions SET last_seen_at = now() WHERE jti = $1`, jti)
	}()
}

// Close закрывает сессию по jti (корректный выход пользователя).
func (s *SessionService) Close(ctx context.Context, jti, reason string) error {
	if jti == "" {
		return nil
	}
	if strings.TrimSpace(reason) == "" {
		reason = "выход пользователя"
	}
	err := s.execSystem(ctx, `
		UPDATE user_sessions SET revoked_at = now(), revoke_reason = $2
		 WHERE jti = $1 AND revoked_at IS NULL`, jti, reason)
	s.mu.Lock()
	delete(s.cache, jti)
	s.mu.Unlock()
	return err
}

// RevokeByUser завершает сессию пользователя принудительно (администратором).
func (s *SessionService) RevokeByUser(ctx context.Context, tx pgx.Tx, userID int64, reason string) error {
	rows, err := tx.Query(ctx, `
		UPDATE user_sessions SET revoked_at = now(), revoke_reason = $2
		 WHERE user_id = $1 AND revoked_at IS NULL
		RETURNING jti`, userID, reason)
	if err != nil {
		return err
	}
	defer rows.Close()
	var jtis []string
	for rows.Next() {
		var j string
		if err := rows.Scan(&j); err != nil {
			return err
		}
		jtis = append(jtis, j)
	}
	if err := rows.Err(); err != nil {
		return err
	}
	s.mu.Lock()
	for _, j := range jtis {
		delete(s.cache, j)
	}
	s.mu.Unlock()
	return nil
}

// execSystem выполняет служебное изменение таблицы сессий (выход, продление,
// время последней активности) через системное подключение: таблица под RLS,
// и без служебного признака UPDATE не находит строку. Право на само
// действие проверено выше по коду — сеанс опознан по jti из подписанного
// токена.
func (s *SessionService) execSystem(ctx context.Context, sql string, args ...any) error {
	pool := db.SystemPool
	if pool == nil {
		return errors.New("системное подключение к БД не открыто")
	}
	_, err := pool.Exec(ctx, sql, args...)
	return err
}

// Extend продлевает сессию вместе с токеном (тот же jti).
func (s *SessionService) Extend(ctx context.Context, jti string, expiresAt time.Time) error {
	if jti == "" {
		return nil
	}
	return s.execSystem(ctx, `
		UPDATE user_sessions SET expires_at = $2, last_seen_at = now()
		 WHERE jti = $1 AND revoked_at IS NULL`, jti, expiresAt)
}
