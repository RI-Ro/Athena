package db

import (
	"context"
	"fmt"
	"log"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Приложение обязано работать от ОБЫЧНОЙ роли PostgreSQL. Для суперпользователя
// и роли с BYPASSRLS сервер отключает Row-Level Security целиком (даже при
// FORCE ROW LEVEL SECURITY), и разграничение доступа к документам исчезает.
// Роль athena_app создаётся скриптом backend/sql/000_init.sql.

// WarnIfRLSBypassed проверяет РАБОЧЕЕ подключение: если приложение ходит в БД
// суперпользователем или ролью с BYPASSRLS, то RLS не действует и разграничение
// доступа к документам фактически отсутствует. Пишем это в лог максимально
// заметно — молчаливый обход RLS и был причиной замечания #5.
//
// Возвращает true, если RLS действует (роль обычная).
func WarnIfRLSBypassed(ctx context.Context, pool *pgxpool.Pool) bool {
	var role string
	var super, bypass bool
	err := pool.QueryRow(ctx,
		`SELECT rolname, rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user`).
		Scan(&role, &super, &bypass)
	if err != nil {
		log.Printf("db: не удалось проверить роль подключения (RLS): %v", err)
		return false
	}
	if super || bypass {
		log.Printf("db: ВНИМАНИЕ! Приложение подключено ролью %q (superuser=%v, bypassrls=%v). "+
			"PostgreSQL ОТКЛЮЧАЕТ Row-Level Security для таких ролей, поэтому разграничение "+
			"доступа к документам НЕ РАБОТАЕТ: администратор и любой пользователь получат "+
			"все документы. Укажите в DATABASE_URL обычную роль (см. APP_DB_ROLE и "+
			"docker-compose.yml).", role, super, bypass)
		return false
	}
	log.Printf("db: роль подключения %q — обычная, RLS действует", role)
	return true
}

// RequiredSchemaVersion — версия схемы БД, с которой работает этот бинарник.
// Схему создаёт и обновляет администратор через psql (backend/sql/*.sql);
// каждый файл записывает свою версию в таблицу schema_version.
const RequiredSchemaVersion = 1

// CheckSchemaVersion сверяет версию схемы с ожидаемой. Приложение само DDL
// не выполняет, поэтому при несовпадении не стартует и объясняет, что делать.
func CheckSchemaVersion(ctx context.Context, pool *pgxpool.Pool) error {
	var v int
	err := pool.QueryRow(ctx, `SELECT coalesce(max(version), 0) FROM schema_version`).Scan(&v)
	if err != nil {
		return fmt.Errorf("схема БД не создана или недоступна (%w).\n"+
			"Разверните её через psql:\n"+
			"  psql -U postgres -d athena -v ON_ERROR_STOP=1 -v app_password='...' -f backend/sql/000_init.sql", err)
	}
	if v < RequiredSchemaVersion {
		return fmt.Errorf("версия схемы БД %d, приложению нужна %d: примените недостающие файлы backend/sql/*.sql через psql",
			v, RequiredSchemaVersion)
	}
	if v > RequiredSchemaVersion {
		log.Printf("db: версия схемы %d новее ожидаемой %d — бинарник устарел относительно БД", v, RequiredSchemaVersion)
	}
	return nil
}
