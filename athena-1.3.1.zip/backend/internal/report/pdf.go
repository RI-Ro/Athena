package report

import (
	"bytes"
	"embed"
	"fmt"
	"sort"
	"strings"
)

// ===========================================================================
// МИНИМАЛЬНЫЙ ГЕНЕРАТОР PDF.
//
// ПОЧЕМУ СВОЙ, А НЕ БИБЛИОТЕКА.
//
// В проекте есть pdfcpu, но он умеет только ПРАВИТЬ готовые PDF (штампы при
// печати), а не создавать их. Отчёты нужно создавать с нуля, с русским текстом
// и графиками. Добавлять ради этого ещё одну внешнюю библиотеку значило бы
// тянуть в поставку несколько мегабайт кода для задачи, которая решается
// примерно шестьюстами строками: PDF — это текстовый формат с нумерованными
// объектами и постфиксными графическими командами.
//
// КИРИЛЛИЦА. Стандартные 14 шрифтов PDF кириллицы не содержат ни в одной
// кодировке, поэтому шрифт встраивается. Используется составной шрифт
// (Type0 / CIDFontType2) с кодировкой Identity-H: текст записывается НОМЕРАМИ
// ГЛИФОВ. Номера и ширины берутся из таблицы glyphs_gen.go, подготовленной
// заранее (scripts/gen_report_font.py) — в рантайме шрифт не парсится.
//
// ЖИРНЫЙ. Второй шрифт не встраивается: жирный рисуется обводкой того же
// контура (режим Tr 2). Это экономит ~65 КБ в каждом отчёте и избавляет от
// второй таблицы глифов. Выглядит как полужирный, чего для заголовков отчёта
// достаточно.
//
// ЧТО НЕ ПОДДЕРЖИВАЕТСЯ СОЗНАТЕЛЬНО: сжатие потоков, прозрачность, растровые
// изображения, переносы по слогам. Отчёт — это текст, линии и прямоугольники;
// всё перечисленное ему не нужно и только увеличило бы код.
// ===========================================================================

//go:embed fonts/report-sans.ttf
var fontFS embed.FS

// Единицы PDF — типографские пункты (1/72 дюйма). A4 — 595×842 pt.
const (
	A4Width  = 595.28
	A4Height = 841.89
	// Поля страницы. 42 pt ≈ 15 мм — обычное поле делового документа.
	marginX = 42.0
	marginY = 48.0
)

// Color — цвет 0..1 по каналам.
type Color struct{ R, G, B float64 }

var (
	ColorText   = Color{0.10, 0.11, 0.13}
	ColorMuted  = Color{0.42, 0.45, 0.50}
	ColorLine   = Color{0.85, 0.87, 0.90}
	ColorAccent = Color{0.16, 0.38, 0.72}
	ColorGood   = Color{0.13, 0.55, 0.33}
	ColorWarn   = Color{0.85, 0.60, 0.13}
	ColorBad    = Color{0.72, 0.21, 0.19}
	ColorFill   = Color{0.96, 0.97, 0.98}
	ColorWhite  = Color{1, 1, 1}
)

// Doc — документ: страницы с содержимым и шрифтом.
type Doc struct {
	pages []*strings.Builder
	cur   *strings.Builder
	y     float64 // текущая вертикальная позиция (сверху вниз)
	// usedGlyphs — какие глифы встретились. По ним строится /W (ширины) и
	// ToUnicode. Включать все 187 символов в каждый документ незачем.
	usedGlyphs map[uint16]rune
	title      string
	footer     string
	pageNo     int
}

func NewDoc(title, footer string) *Doc {
	d := &Doc{usedGlyphs: map[uint16]rune{}, title: title, footer: footer}
	d.AddPage()
	return d
}

// AddPage начинает новую страницу и печатает колонтитулы.
func (d *Doc) AddPage() {
	b := &strings.Builder{}
	d.pages = append(d.pages, b)
	d.cur = b
	d.pageNo++
	d.y = A4Height - marginY

	// Верхний колонтитул: название отчёта и тонкая линия под ним.
	if d.title != "" {
		d.TextAt(marginX, d.y, d.title, 8, ColorMuted, false)
		d.Line(marginX, d.y-4, A4Width-marginX, d.y-4, 0.5, ColorLine)
		d.y -= 20
	}
	// Нижний колонтитул с номером страницы. Печатается сразу: номер известен,
	// а дописывать его потом пришлось бы, перебирая уже готовые потоки.
	foot := fmt.Sprintf("%s — стр. %d", d.footer, d.pageNo)
	d.TextAt(marginX, marginY-18, foot, 7, ColorMuted, false)
}

// Space опускает курсор; при нехватке места начинает новую страницу.
func (d *Doc) Space(h float64) {
	d.y -= h
	if d.y < marginY+10 {
		d.AddPage()
	}
}

// NeedSpace гарантирует, что на странице осталось не меньше h.
// Нужна перед таблицей или графиком: разорванный пополам график читать нельзя.
func (d *Doc) NeedSpace(h float64) {
	if d.y-h < marginY+10 {
		d.AddPage()
	}
}

func (d *Doc) Y() float64 { return d.y }

// --- Текст -----------------------------------------------------------------

// encode переводит строку в последовательность номеров глифов (hex).
// Символы, которых нет в субсете, заменяются вопросительным знаком: пустое
// место в отчёте выглядело бы как потерянные данные.
func (d *Doc) encode(s string) string {
	var sb strings.Builder
	for _, r := range s {
		g, ok := glyphs[r]
		if !ok {
			if r == '\n' || r == '\t' {
				continue
			}
			g = glyphs['?']
			r = '?'
		}
		d.usedGlyphs[g.GID] = r
		fmt.Fprintf(&sb, "%04X", g.GID)
	}
	return sb.String()
}

// Width — ширина строки в пунктах при заданном размере.
func (d *Doc) Width(s string, size float64) float64 {
	total := 0
	for _, r := range s {
		g, ok := glyphs[r]
		if !ok {
			g = glyphs['?']
		}
		total += g.Width
	}
	return float64(total) * size / 1000
}

// TextAt печатает строку с базовой линией в (x, y).
func (d *Doc) TextAt(x, y float64, s string, size float64, c Color, bold bool) {
	if s == "" {
		return
	}
	fmt.Fprintf(d.cur, "q %.3f %.3f %.3f rg\n", c.R, c.G, c.B)
	if bold {
		// Tr 2 = «залить и обвести». Обводка толщиной ~4 % кегля даёт
		// визуальный полужирный без второго шрифта.
		fmt.Fprintf(d.cur, "%.3f %.3f %.3f RG %.3f w 2 Tr\n", c.R, c.G, c.B, size*0.04)
	}
	fmt.Fprintf(d.cur, "BT /F1 %.2f Tf 1 0 0 1 %.2f %.2f Tm <%s> Tj ET\n",
		size, x, y, d.encode(s))
	fmt.Fprint(d.cur, "Q\n")
}

// TextRight печатает строку с выравниванием по правому краю.
func (d *Doc) TextRight(xRight, y float64, s string, size float64, c Color, bold bool) {
	d.TextAt(xRight-d.Width(s, size), y, s, size, c, bold)
}

// TextCenter печатает строку по центру отрезка.
func (d *Doc) TextCenter(xFrom, xTo, y float64, s string, size float64, c Color, bold bool) {
	d.TextAt((xFrom+xTo)/2-d.Width(s, size)/2, y, s, size, c, bold)
}

// Heading — заголовок раздела с отступами.
//
// Отступ СВЕРХУ заметно больше, чем снизу (14 против 8): заголовок должен
// примыкать к своему разделу, а не висеть посередине между двумя. Проверено
// на отрисовке: при симметричных отступах заголовок следующего раздела
// налезал на подписи предыдущего графика.
func (d *Doc) Heading(s string, size float64) {
	d.NeedSpace(size + 30)
	d.y -= size + 14
	d.TextAt(marginX, d.y, s, size, ColorText, true)
	d.y -= 8
}

// Paragraph печатает абзац с переносом по словам в заданной ширине.
//
// Перенос по словам, а не по символам: разорванное посреди слова название
// подразделения в отчёте читается плохо. Слово, которое само длиннее строки,
// всё-таки рвётся — иначе оно вылезло бы за поле.
func (d *Doc) Paragraph(s string, size float64, c Color, width float64) {
	if width <= 0 {
		width = A4Width - 2*marginX
	}
	lineH := size * 1.45
	for _, para := range strings.Split(s, "\n") {
		words := strings.Fields(para)
		if len(words) == 0 {
			d.Space(lineH / 2)
			continue
		}
		line := ""
		flush := func() {
			if line == "" {
				return
			}
			d.NeedSpace(lineH)
			d.y -= lineH
			d.TextAt(marginX, d.y, line, size, c, false)
			line = ""
		}
		for _, w := range words {
			probe := w
			if line != "" {
				probe = line + " " + w
			}
			if d.Width(probe, size) <= width {
				line = probe
				continue
			}
			flush()
			// Слово длиннее строки — рвём по символам.
			for d.Width(w, size) > width {
				cut := len(w)
				for cut > 1 && d.Width(w[:cut], size) > width {
					cut--
				}
				d.NeedSpace(lineH)
				d.y -= lineH
				d.TextAt(marginX, d.y, w[:cut], size, c, false)
				w = w[cut:]
			}
			line = w
		}
		flush()
	}
}

// --- Графика ---------------------------------------------------------------

func (d *Doc) Line(x1, y1, x2, y2, w float64, c Color) {
	fmt.Fprintf(d.cur, "q %.3f %.3f %.3f RG %.2f w %.2f %.2f m %.2f %.2f l S Q\n",
		c.R, c.G, c.B, w, x1, y1, x2, y2)
}

func (d *Doc) Rect(x, y, w, h float64, fill Color) {
	if w <= 0 || h <= 0 {
		return
	}
	fmt.Fprintf(d.cur, "q %.3f %.3f %.3f rg %.2f %.2f %.2f %.2f re f Q\n",
		fill.R, fill.G, fill.B, x, y, w, h)
}

func (d *Doc) RectOutline(x, y, w, h, lw float64, c Color) {
	fmt.Fprintf(d.cur, "q %.3f %.3f %.3f RG %.2f w %.2f %.2f %.2f %.2f re S Q\n",
		c.R, c.G, c.B, lw, x, y, w, h)
}

// --- Сборка файла ----------------------------------------------------------

// Bytes собирает PDF.
//
// Объекты нумеруются подряд, смещения запоминаются для таблицы xref — без
// корректной xref файл не откроется ни одним просмотрщиком.
func (d *Doc) Bytes() ([]byte, error) {
	ttf, err := fontFS.ReadFile("fonts/report-sans.ttf")
	if err != nil {
		return nil, fmt.Errorf("встроенный шрифт отчётов недоступен: %w", err)
	}

	var out bytes.Buffer
	offsets := []int{}
	objNo := 0
	// addObj пишет объект и запоминает смещение.
	addObj := func(body string) int {
		objNo++
		offsets = append(offsets, out.Len())
		fmt.Fprintf(&out, "%d 0 obj\n%s\nendobj\n", objNo, body)
		return objNo
	}
	addStream := func(dict string, data []byte) int {
		objNo++
		offsets = append(offsets, out.Len())
		fmt.Fprintf(&out, "%d 0 obj\n<< %s /Length %d >>\nstream\n", objNo, dict, len(data))
		out.Write(data)
		fmt.Fprint(&out, "\nendstream\nendobj\n")
		return objNo
	}

	out.WriteString("%PDF-1.7\n")
	// Бинарный комментарий после заголовка — признак того, что файл не
	// текстовый. Без него некоторые средства передачи «починят» переводы
	// строк и сломают потоки.
	out.WriteString("%\xE2\xE3\xCF\xD3\n")

	// Шрифт: дескриптор, CID-шрифт, составной шрифт, ToUnicode.
	ttfRef := addStream(fmt.Sprintf("/Length1 %d", len(ttf)), ttf)

	fdRef := addObj(fmt.Sprintf(`<< /Type /FontDescriptor /FontName /ReportSans
/Flags 32 /FontBBox [%d %d %d %d] /ItalicAngle 0
/Ascent %d /Descent %d /CapHeight %d /StemV 80 /FontFile2 %d 0 R >>`,
		fontBBox[0], fontBBox[1], fontBBox[2], fontBBox[3],
		fontAscent, fontDescent, fontCapHeight, ttfRef))

	cidRef := addObj(fmt.Sprintf(`<< /Type /Font /Subtype /CIDFontType2 /BaseFont /ReportSans
/CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >>
/FontDescriptor %d 0 R /DW 600 /W [%s] /CIDToGIDMap /Identity >>`,
		fdRef, d.widthsArray()))

	toUniRef := addStream("", []byte(d.toUnicodeCMap()))

	fontRef := addObj(fmt.Sprintf(`<< /Type /Font /Subtype /Type0 /BaseFont /ReportSans
/Encoding /Identity-H /DescendantFonts [%d 0 R] /ToUnicode %d 0 R >>`,
		cidRef, toUniRef))

	// Содержимое страниц.
	contentRefs := make([]int, 0, len(d.pages))
	for _, p := range d.pages {
		contentRefs = append(contentRefs, addStream("", []byte(p.String())))
	}

	// Страницы ссылаются на объект Pages, который ещё не создан. Поэтому
	// сначала резервируем его номер: в PDF ссылки по номеру, а не по порядку.
	pagesNo := objNo + len(contentRefs) + 1
	pageRefs := make([]int, 0, len(contentRefs))
	for _, cr := range contentRefs {
		pageRefs = append(pageRefs, addObj(fmt.Sprintf(
			`<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2f %.2f]
/Resources << /Font << /F1 %d 0 R >> >> /Contents %d 0 R >>`,
			pagesNo, A4Width, A4Height, fontRef, cr)))
	}

	kids := make([]string, 0, len(pageRefs))
	for _, pr := range pageRefs {
		kids = append(kids, fmt.Sprintf("%d 0 R", pr))
	}
	realPagesNo := addObj(fmt.Sprintf("<< /Type /Pages /Kids [%s] /Count %d >>",
		strings.Join(kids, " "), len(pageRefs)))
	if realPagesNo != pagesNo {
		return nil, fmt.Errorf("внутренняя ошибка: номер объекта Pages %d не совпал с зарезервированным %d",
			realPagesNo, pagesNo)
	}

	catalogRef := addObj(fmt.Sprintf("<< /Type /Catalog /Pages %d 0 R >>", pagesNo))

	xrefPos := out.Len()
	fmt.Fprintf(&out, "xref\n0 %d\n0000000000 65535 f \n", objNo+1)
	for _, off := range offsets {
		fmt.Fprintf(&out, "%010d 00000 n \n", off)
	}
	fmt.Fprintf(&out, "trailer\n<< /Size %d /Root %d 0 R >>\nstartxref\n%d\n%%%%EOF\n",
		objNo+1, catalogRef, xrefPos)
	return out.Bytes(), nil
}

// widthsArray — массив /W: ширины только использованных глифов.
// Формат «cid [w]» по одному глифу: группировать диапазоны незачем, глифов в
// отчёте десятки, а код группировки — лишний источник ошибок.
func (d *Doc) widthsArray() string {
	gids := make([]int, 0, len(d.usedGlyphs))
	for g := range d.usedGlyphs {
		gids = append(gids, int(g))
	}
	sort.Ints(gids)
	var sb strings.Builder
	for _, g := range gids {
		r := d.usedGlyphs[uint16(g)]
		fmt.Fprintf(&sb, "%d [%d] ", g, glyphs[r].Width)
	}
	return strings.TrimSpace(sb.String())
}

// toUnicodeCMap — соответствие «глиф -> символ».
//
// Без него текст в PDF виден, но не копируется и не ищется: просмотрщик знает
// номера глифов, а не буквы. Для отчёта это важно — из него выписывают
// фамилии и номера.
func (d *Doc) toUnicodeCMap() string {
	gids := make([]int, 0, len(d.usedGlyphs))
	for g := range d.usedGlyphs {
		gids = append(gids, int(g))
	}
	sort.Ints(gids)

	var sb strings.Builder
	sb.WriteString(`/CIDInit /ProcSet findresource begin
12 dict begin
begincmap
/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def
/CMapName /Adobe-Identity-UCS def
/CMapType 2 def
1 begincodespacerange
<0000> <FFFF>
endcodespacerange
`)
	// bfchar принимает не больше 100 записей в блоке — ограничение формата.
	for i := 0; i < len(gids); i += 100 {
		end := i + 100
		if end > len(gids) {
			end = len(gids)
		}
		fmt.Fprintf(&sb, "%d beginbfchar\n", end-i)
		for _, g := range gids[i:end] {
			fmt.Fprintf(&sb, "<%04X> <%04X>\n", g, d.usedGlyphs[uint16(g)])
		}
		sb.WriteString("endbfchar\n")
	}
	sb.WriteString("endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n")
	return sb.String()
}
