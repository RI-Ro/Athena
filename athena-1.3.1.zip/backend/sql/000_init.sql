-- ============================================================================
--  ИР «Афина» — РАЗВЁРТЫВАНИЕ БАЗЫ ДАННЫХ С НУЛЯ
-- ============================================================================
--  Единый файл: вся схема, политики RLS, справочные данные, роль приложения
--  и первый администратор. Тестовых данных здесь НЕТ — они в 900_testdata.sql.
--
--  Приложение само схему НЕ создаёт и НЕ меняет: все изменения БД делаются
--  через psql файлами из этого каталога.
--
--  ЗАПУСК (от суперпользователя, в ПУСТОЙ базе):
--
--    createdb -U postgres athena
--    psql -U postgres -d athena -v ON_ERROR_STOP=1 \
--         -v app_password='пароль-роли-приложения' \
--         -v admin_password='пароль-первого-администратора' \
--         -f backend/sql/000_init.sql
--
--  Параметры:
--    app_password   (обязателен) — пароль роли athena_app, под которой работает
--                   приложение (database.url в config.yaml);
--    admin_password (обязателен) — пароль учётной записи admin для первого
--                   входа в веб-интерфейс (не короче 8 символов);
--    app_role       (необязателен, по умолчанию athena_app) — имя роли приложения.
--
--  ПОЧЕМУ ОТДЕЛЬНАЯ РОЛЬ. Разграничение доступа к документам построено на
--  Row-Level Security. Для суперпользователя, владельца БД с BYPASSRLS и т. п.
--  PostgreSQL отключает RLS целиком. Поэтому объекты принадлежат тому, кто
--  запускает этот файл, а приложение ходит ролью athena_app: только DML, без DDL,
--  без SUPERUSER/BYPASSRLS. С привилегированной ролью приложение не стартует.
--
--  Файл выполняется в одной транзакции: либо всё, либо ничего.
-- ============================================================================

\set ON_ERROR_STOP on

\if :{?app_password}
\else
  \echo 'ОШИБКА: не задан пароль роли приложения:  -v app_password=...'
  DO $$ BEGIN RAISE EXCEPTION 'не задан параметр app_password'; END $$;
\endif
\if :{?admin_password}
\else
  \echo 'ОШИБКА: не задан пароль первого администратора:  -v admin_password=...'
  DO $$ BEGIN RAISE EXCEPTION 'не задан параметр admin_password'; END $$;
\endif
\if :{?app_role}
\else
  \set app_role athena_app
\endif

BEGIN;

-- Параметры psql внутри DO-блоков не подставляются — передаём их через GUC
-- (в пределах транзакции).
SELECT set_config('athena.app_role', :'app_role', true) AS app_role \gset init_
SELECT set_config('athena.app_password', :'app_password', true) IS NOT NULL AS ok \gset init_
SELECT set_config('athena.admin_password', :'admin_password', true) IS NOT NULL AS ok \gset init_

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename IN ('users', 'documents')) THEN
        RAISE EXCEPTION 'база не пуста (таблицы системы уже существуют). Этот файл — только для развёртывания с нуля';
    END IF;
    IF current_setting('athena.app_role') !~ '^[a-z_][a-z0-9_]*$' THEN
        RAISE EXCEPTION 'недопустимое имя роли приложения: %', current_setting('athena.app_role');
    END IF;
    IF length(current_setting('athena.admin_password')) < 8 THEN
        RAISE EXCEPTION 'пароль администратора короче 8 символов';
    END IF;
END $$;

SET LOCAL client_min_messages = warning;
SET LOCAL check_function_bodies = false;
SET LOCAL search_path = public;

-- pgcrypto нужен только здесь — для bcrypt-хэша пароля первого администратора.
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;

-- ============================================================================
-- СХЕМА (типы, функции, таблицы, индексы, триггеры, политики RLS)
-- ============================================================================
--
--

--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;

--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;

--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';

--
-- Name: doc_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.doc_status AS ENUM (
    'draft',
    'on_approval_hierarchy',
    'on_approval_cross_dept',
    'on_signing',
    'signed',
    'sent',
    'in_progress',
    'executed',
    'archived',
    'rejected'
);

--
-- Name: doc_urgency; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.doc_urgency AS ENUM (
    'normal',
    'urgent',
    'out_of_turn'
);

--
-- Name: resolution_exec_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.resolution_exec_status AS ENUM (
    'open',
    'in_progress',
    'reported',
    'accepted',
    'returned',
    'cancelled'
);

--
-- Name: resolution_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.resolution_status AS ENUM (
    'issued',
    'in_progress',
    'on_report',
    'done',
    'cancelled'
);

--
-- Name: role_code; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.role_code AS ENUM (
    'author',
    'approver_hierarchy',
    'approver_cross_dept',
    'signer',
    'executor',
    'clerk',
    'chief',
    'controller',
    'printer',
    'admin',
    'default_controller',
    'execution_marker',
    'reporter',
    'auditor',
    'acquainter'
);

--
-- Name: stage_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.stage_status AS ENUM (
    'waiting_deps',
    'pending',
    'approved',
    'rejected'
);

--
-- Name: stage_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.stage_type AS ENUM (
    'hierarchy',
    'cross_dept',
    'signing'
);

--
-- Name: app_can_see_document(bigint, bigint, bigint, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_can_see_document(p_id bigint, p_author bigint, p_author_dept bigint, p_outgoing text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    SELECT p_author = app_user_id()
        OR EXISTS (SELECT 1 FROM document_access da
                    WHERE da.document_id = p_id AND da.user_id = app_user_id())
        OR (p_outgoing IS NOT NULL AND EXISTS (
                SELECT 1 FROM user_roles ur
                  JOIN department_closure dc ON dc.ancestor_id = ur.department_id
                 WHERE ur.user_id = app_user_id() AND ur.role = 'chief'
                   AND dc.descendant_id = p_author_dept))
        OR (p_outgoing IS NOT NULL AND EXISTS (
                SELECT 1 FROM user_visible_departments uvd
                 WHERE uvd.user_id = app_user_id() AND uvd.department_id = p_author_dept))
        OR EXISTS (SELECT 1 FROM document_incoming_instances dii
                     JOIN user_incoming_departments uid ON uid.department_id = dii.receiving_department_id
                    WHERE dii.document_id = p_id AND uid.user_id = app_user_id())
        OR app_is_system()
$$;

--
-- Name: app_is_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_is_admin() RETURNS boolean
    LANGUAGE sql STABLE
    AS $$ SELECT coalesce(NULLIF(current_setting('app.is_admin', true), '')::boolean, false) $$;

--
-- Name: app_is_system(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_is_system() RETURNS boolean
    LANGUAGE sql STABLE
    AS $$ SELECT coalesce(NULLIF(current_setting('app.system', true), ''), '') = 'scheduler' $$;

--
-- Name: app_my_resolution_ids(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_my_resolution_ids() RETURNS SETOF bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
    SELECT re.resolution_id FROM resolution_executors re
     WHERE re.user_id = app_user_id() AND re.status <> 'cancelled'
$$;

--
-- Name: app_resolution_departments(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_resolution_departments() RETURNS SETOF bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
    SELECT uid.department_id FROM user_incoming_departments uid WHERE uid.user_id = app_user_id()
    UNION
    SELECT dc.descendant_id FROM department_closure dc
     WHERE EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = app_user_id() AND ur.role = 'chief')
       AND dc.ancestor_id IN (
            SELECT ur.department_id FROM user_roles ur
             WHERE ur.user_id = app_user_id() AND ur.role = 'chief' AND ur.department_id IS NOT NULL
            UNION
            SELECT u.primary_department_id FROM users u
             WHERE u.id = app_user_id() AND u.primary_department_id IS NOT NULL
               AND EXISTS (SELECT 1 FROM user_roles ur2 WHERE ur2.user_id = app_user_id()
                              AND ur2.role = 'chief' AND ur2.department_id IS NULL)
            UNION
            SELECT urd.department_id FROM user_resolution_departments urd WHERE urd.user_id = app_user_id())
$$;

--
-- Name: app_user_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_user_id() RETURNS bigint
    LANGUAGE sql STABLE
    AS $$ SELECT NULLIF(current_setting('app.user_id', true), '')::bigint $$;

--
-- Name: approval_stage_activated(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.approval_stage_activated() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.status = 'pending' AND (TG_OP = 'INSERT' OR OLD.status IS DISTINCT FROM 'pending') THEN
    NEW.activated_at := now();
  END IF;
  RETURN NEW;
END $$;

--
-- Name: archive_document_file_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.archive_document_file_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_next INT;
BEGIN
    -- Содержимое не изменилось — заменять нечего (повторная загрузка того же
    -- файла не должна плодить версии).
    IF TG_OP = 'UPDATE' AND NEW.sha256 = OLD.sha256 THEN
        RETURN NEW;
    END IF;
    SELECT COALESCE(max(version), 0) + 1 INTO v_next
      FROM document_file_versions WHERE document_id = OLD.document_id;
    INSERT INTO document_file_versions
        (document_id, version, content, sha256, size_bytes, uploaded_by, uploaded_at, superseded_by)
    VALUES (OLD.document_id, v_next, OLD.content, OLD.sha256, OLD.size_bytes,
            OLD.uploaded_by, OLD.uploaded_at,
            NULLIF(current_setting('app.user_id', true), '')::bigint);
    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;
    RETURN NEW;
END;
$$;

--
-- Name: audit_log_bytes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_log_bytes() RETURNS bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
    SELECT pg_total_relation_size('audit_log')::bigint;
$$;

--
-- Name: audit_purge(date, date, bigint, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_purge(p_from date, p_to date, p_actor bigint, p_actor_login text) RETURNS bigint
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_count BIGINT;
BEGIN
    IF p_from IS NULL OR p_to IS NULL THEN
        RAISE EXCEPTION 'нужно указать обе границы периода'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_from > p_to THEN
        RAISE EXCEPTION 'начало периода позже его конца'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    -- Удалять «сегодня» нельзя: в этот же день записывается событие о самом
    -- удалении, и оно исчезло бы вместе с остальным.
    IF p_to >= current_date THEN
        RAISE EXCEPTION 'удалять можно только завершившиеся дни: конец периода должен быть раньше сегодняшнего'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;

    SELECT count(*) INTO v_count
      FROM audit_log
     WHERE occurred_at >= p_from::timestamptz
       AND occurred_at <  (p_to + 1)::timestamptz;

    -- Запись о намерении ставится ДО удаления и в НАСТОЯЩЕЕ время, то есть
    -- заведомо вне удаляемого периода (см. проверку выше). Поэтому
    -- свидетельство об очистке остаётся в журнале после очистки.
    INSERT INTO audit_log (actor_id, actor_login, event, outcome, object_kind, details)
    VALUES (p_actor, p_actor_login, 'audit.purge', 'ok', 'audit_log',
            jsonb_build_object('from', p_from, 'to', p_to, 'rows', v_count));

    DELETE FROM audit_log
     WHERE occurred_at >= p_from::timestamptz
       AND occurred_at <  (p_to + 1)::timestamptz;

    RETURN v_count;
END;
$$;

--
-- Name: check_recipient_role(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_recipient_role() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = NEW.recipient_user_id
      AND department_id = NEW.recipient_department_id
      AND role = 'clerk'
  ) THEN
    RAISE EXCEPTION 'recipient % must have role clerk in department %',
      NEW.recipient_user_id, NEW.recipient_department_id;
  END IF;
  RETURN NEW;
END;
$$;

--
-- Name: check_user_domain_login(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_user_domain_login() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_realm TEXT;
BEGIN
    IF NEW.domain_id IS NULL THEN
        RETURN NEW;
    END IF;
    SELECT realm INTO v_realm FROM auth_domains WHERE id = NEW.domain_id;
    IF v_realm IS NULL OR NEW.login NOT LIKE '%@' || v_realm
       OR NEW.login <> lower(split_part(NEW.login, '@', 1)) || '@' || v_realm THEN
        RAISE EXCEPTION 'логин доменного пользователя должен иметь вид имя@%', coalesce(v_realm, 'REALM')
            USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END;
$$;

--
-- Name: chief_scope_has(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.chief_scope_has(p_user bigint, p_dept bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
    SELECT EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = p_user AND ur.role = 'chief')
       AND EXISTS (
            SELECT 1 FROM department_closure dc
             WHERE dc.descendant_id = p_dept
               AND dc.ancestor_id IN (
                    SELECT ur.department_id FROM user_roles ur
                     WHERE ur.user_id = p_user AND ur.role = 'chief' AND ur.department_id IS NOT NULL
                    UNION
                    SELECT u.primary_department_id FROM users u
                     WHERE u.id = p_user AND u.primary_department_id IS NOT NULL
                       AND EXISTS (SELECT 1 FROM user_roles ur2 WHERE ur2.user_id = p_user
                                      AND ur2.role = 'chief' AND ur2.department_id IS NULL)
                    UNION
                    SELECT urd.department_id FROM user_resolution_departments urd WHERE urd.user_id = p_user))
$$;

--
-- Name: documents_archive_clears_control(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.documents_archive_clears_control() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.status = 'archived' AND OLD.status IS DISTINCT FROM 'archived' THEN
    NEW.on_control := false;
  END IF;
  RETURN NEW;
END $$;

--
-- Name: documents_count_by_status(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.documents_count_by_status() RETURNS TABLE(status text, cnt bigint)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
    SELECT d.status::text, count(*) FROM documents d GROUP BY d.status;
$$;

--
-- Name: enqueue_document_text_index(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enqueue_document_text_index() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO document_file_text (document_id, status, attempts, updated_at)
    VALUES (NEW.document_id, 'pending', 0, now())
    ON CONFLICT (document_id) DO UPDATE
        SET status = 'pending', attempts = 0, error = NULL, updated_at = now();
    RETURN NEW;
END;
$$;

--
-- Name: fold_ru(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fold_ru(s text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
    SELECT translate(
        lower(coalesce(s, '')),                 -- латиница и цифры: lower() достаточно
        'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ',   -- кириллица: таблицей, без локали
        'абвгдеёжзийклмнопрстуфхцчшщъыьэюя');
$$;

--
-- Name: grant_executor_role(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.grant_executor_role() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO user_roles (user_id, department_id, role)
    VALUES (NEW.id, NEW.primary_department_id, 'executor')
    ON CONFLICT DO NOTHING;
    RETURN NEW;
END
$$;

--
-- Name: normalize_doc_number(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.normalize_doc_number(s text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
    -- Сначала свёртка регистра, и только потом выбрасывание разделителей.
    -- Если сделать наоборот через upper(), в локали C строчные кириллические
    -- буквы не поднимутся в верхний регистр, а будут УДАЛЕНЫ вместе с
    -- разделителями: «вх-1/2-231/2026» превратится в «122312026» и начнёт
    -- находить исходящий номер. Проверено — ложное совпадение воспроизводится.
    SELECT regexp_replace(public.fold_ru(s), '[^0-9a-zа-яё]', '', 'g');
$$;

--
-- Name: notifications_dedupe(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notifications_dedupe() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_id bigint;
BEGIN
    IF NEW.document_id IS NULL THEN
        RETURN NEW;
    END IF;
    IF NEW.kind = 'route_restarted' AND EXISTS (
        SELECT 1 FROM notifications n
         WHERE n.user_id = NEW.user_id AND n.document_id = NEW.document_id
           AND n.kind = 'stage_pending' AND NOT n.is_read
           AND n.created_at > now() - interval '1 minute') THEN
        RETURN NULL;
    END IF;
    SELECT n.id INTO v_id FROM notifications n
     WHERE n.user_id = NEW.user_id AND n.document_id = NEW.document_id
       AND n.kind = NEW.kind AND NOT n.is_read
       AND n.actor_id IS NOT DISTINCT FROM NEW.actor_id
       AND n.detail IS NOT DISTINCT FROM NEW.detail
       AND n.created_at > now() - interval '1 hour'
     ORDER BY n.id DESC LIMIT 1;
    IF v_id IS NOT NULL THEN
        UPDATE notifications
           SET created_at = now(), payload = NEW.payload, snoozed_until = NULL,
               requires_ack = requires_ack OR NEW.requires_ack
         WHERE id = v_id;
        RETURN NULL;
    END IF;
    -- «Требуется ваше решение» вытесняет непрочитанное «начато заново» по
    -- этому документу, пришедшее раньше в том же действии.
    IF NEW.kind = 'stage_pending' THEN
        DELETE FROM notifications n
         WHERE n.user_id = NEW.user_id AND n.document_id = NEW.document_id
           AND n.kind = 'route_restarted' AND NOT n.is_read
           AND n.created_at > now() - interval '1 minute';
    END IF;
    RETURN NEW;
END;
$$;

--
-- Name: resolution_visible(bigint, bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.resolution_visible(p_id bigint, p_document bigint, p_department bigint, p_author bigint, p_controller bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
    SELECT p_author = app_user_id()
        OR p_controller = app_user_id()
        OR EXISTS (SELECT 1 FROM resolution_executors re
                    WHERE re.resolution_id = p_id AND re.user_id = app_user_id() AND re.status <> 'cancelled')
        OR EXISTS (SELECT 1 FROM document_recipients dr
                    WHERE dr.document_id = p_document AND dr.recipient_department_id = p_department
                      AND dr.recipient_user_id = app_user_id())
        OR EXISTS (SELECT 1 FROM user_incoming_departments uid
                    WHERE uid.user_id = app_user_id() AND uid.department_id = p_department)
        OR chief_scope_has(app_user_id(), p_department)
        OR app_is_system()
$$;

--
-- Name: set_default_special_mark(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_default_special_mark() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.special_mark_id IS NULL THEN
        SELECT id INTO NEW.special_mark_id FROM special_marks WHERE is_default LIMIT 1;
    END IF;
    RETURN NEW;
END;
$$;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

--
-- Name: snapshot_document_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.snapshot_document_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_next INT;
    v_card JSONB;
    v_prev JSONB;
BEGIN
    v_card := jsonb_build_object(
        'title', NEW.title,
        'urgency', NEW.urgency,
        'status', NEW.status,
        'outgoing_number', NEW.outgoing_number,
        'due_date', NEW.due_date,
        'due_datetime', NEW.due_datetime,
        'author_id', NEW.author_id,
        'author_department_id', NEW.author_department_id,
        'category_id', NEW.category_id,
        'special_mark_id', NEW.special_mark_id,
        'controller_id', NEW.controller_id,
        'on_control', NEW.on_control
    );
    -- Версия создаётся только при РЕАЛЬНОМ изменении реквизитов (пояснение —
    -- в миграции 0023).
    IF TG_OP = 'UPDATE' THEN
        SELECT dv.card INTO v_prev FROM document_versions dv
         WHERE dv.document_id = NEW.id ORDER BY dv.version DESC LIMIT 1;
        IF v_prev IS NOT NULL AND v_prev = v_card THEN
            RETURN NULL;
        END IF;
    END IF;
    SELECT COALESCE(max(version), 0) + 1 INTO v_next
      FROM document_versions WHERE document_id = NEW.id;
    INSERT INTO document_versions (document_id, version, card, changed_by)
    VALUES (NEW.id, v_next, v_card,
            NULLIF(current_setting('app.user_id', true), '')::bigint);
    RETURN NULL;
END;
$$;

--
-- Name: approval_stage_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_stage_dependencies (
    stage_id bigint NOT NULL,
    depends_on_stage_id bigint NOT NULL,
    CONSTRAINT approval_stage_dependencies_check CHECK ((stage_id <> depends_on_stage_id))
);

--
-- Name: approval_stages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_stages (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    stage_type public.stage_type NOT NULL,
    approver_id bigint NOT NULL,
    status public.stage_status DEFAULT 'waiting_deps'::public.stage_status NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    decided_at timestamp with time zone,
    comment text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    step_no integer DEFAULT 1 NOT NULL,
    activated_at timestamp with time zone,
    CONSTRAINT approval_stages_step_no_check CHECK ((step_no >= 1))
);

--
-- Name: approval_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.approval_stages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: approval_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.approval_stages_id_seq OWNED BY public.approval_stages.id;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    actor_id bigint,
    actor_login text,
    session_id bigint,
    event text NOT NULL,
    object_kind text,
    object_id bigint,
    document_id bigint,
    outcome text DEFAULT 'ok'::text NOT NULL,
    http_method text,
    http_path text,
    http_status integer,
    ip inet,
    user_agent text,
    details jsonb,
    ip_peer inet,
    ip_chain text,
    CONSTRAINT audit_log_outcome_check CHECK ((outcome = ANY (ARRAY['ok'::text, 'denied'::text, 'error'::text])))
);

ALTER TABLE ONLY public.audit_log FORCE ROW LEVEL SECURITY;

--
-- Name: COLUMN audit_log.ip_peer; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.ip_peer IS 'адрес подключения (шлюз NAT/прокси), подделать нельзя';

--
-- Name: COLUMN audit_log.ip_chain; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.ip_chain IS 'заголовок X-Forwarded-For целиком, как пришёл';

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;

--
-- Name: auth_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_domains (
    id bigint NOT NULL,
    realm text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    netbios_name text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    ldap_enabled boolean DEFAULT false NOT NULL,
    ldap_urls text[] DEFAULT '{}'::text[] NOT NULL,
    ldap_start_tls boolean DEFAULT false NOT NULL,
    ldap_skip_verify boolean DEFAULT false NOT NULL,
    ldap_ca_pem text,
    ldap_bind_dn text,
    ldap_bind_password_enc bytea,
    ldap_base_dn text,
    ldap_user_filter text DEFAULT '(&(objectClass=user)(sAMAccountName={login}))'::text NOT NULL,
    ldap_attr_full_name text DEFAULT 'displayName'::text NOT NULL,
    ldap_attr_position text DEFAULT 'title'::text NOT NULL,
    ldap_timeout_sec integer DEFAULT 5 NOT NULL,
    kerberos_enabled boolean DEFAULT false NOT NULL,
    kerberos_spn text,
    kerberos_keytab_enc bytea,
    kerberos_keytab_uploaded_at timestamp with time zone,
    auto_create_users boolean DEFAULT false NOT NULL,
    default_department_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    ldap_attr_email text DEFAULT 'mail'::text NOT NULL,
    CONSTRAINT auth_domains_realm_chk CHECK (((realm = upper(realm)) AND (realm ~ '^[A-Z0-9][A-Z0-9.-]*$'::text)))
);

ALTER TABLE ONLY public.auth_domains FORCE ROW LEVEL SECURITY;

--
-- Name: TABLE auth_domains; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.auth_domains IS 'Домены аутентификации (LDAP/Kerberos). Управляются через веб: Администрирование → Домены. Секреты (пароль LDAP, keytab) хранятся зашифрованными ключом auth.secret_key.';

--
-- Name: auth_domains_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_domains_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: auth_domains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_domains_id_seq OWNED BY public.auth_domains.id;

--
-- Name: auth_login_failures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_login_failures (
    key text NOT NULL,
    failures integer DEFAULT 0 NOT NULL,
    window_start timestamp with time zone DEFAULT now() NOT NULL,
    blocked_until timestamp with time zone
);

--
-- Name: chat_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_attachments (
    id bigint NOT NULL,
    message_id bigint NOT NULL,
    file_name text NOT NULL,
    content bytea NOT NULL,
    mime_type text NOT NULL,
    size_bytes integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);
ALTER TABLE ONLY public.chat_attachments ALTER COLUMN content SET STORAGE EXTERNAL;

ALTER TABLE ONLY public.chat_attachments FORCE ROW LEVEL SECURITY;

--
-- Name: chat_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: chat_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_attachments_id_seq OWNED BY public.chat_attachments.id;

--
-- Name: chat_message_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message_reads (
    message_id bigint NOT NULL,
    user_id bigint NOT NULL,
    read_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.chat_message_reads FORCE ROW LEVEL SECURITY;

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    author_id bigint NOT NULL,
    text text,
    edited_at timestamp with time zone,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.chat_messages FORCE ROW LEVEL SECURITY;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;

--
-- Name: department_closure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.department_closure (
    ancestor_id bigint NOT NULL,
    descendant_id bigint NOT NULL,
    depth integer NOT NULL
);

--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id bigint NOT NULL,
    parent_id bigint,
    name text NOT NULL,
    numbering_prefix text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    city text
);

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;

--
-- Name: document_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_access (
    document_id bigint NOT NULL,
    user_id bigint NOT NULL,
    access_reason text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: document_acquaintances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_acquaintances (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    user_id bigint NOT NULL,
    acquainted_by bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: document_acquaintances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_acquaintances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_acquaintances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_acquaintances_id_seq OWNED BY public.document_acquaintances.id;

--
-- Name: document_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_categories (
    id bigint NOT NULL,
    name text NOT NULL,
    code text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    color text
);

--
-- Name: document_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_categories_id_seq OWNED BY public.document_categories.id;

--
-- Name: document_controllers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_controllers (
    document_id bigint NOT NULL,
    user_id bigint NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: document_copies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_copies (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    user_id bigint NOT NULL,
    copy_number integer NOT NULL,
    reason text NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: document_copies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_copies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_copies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_copies_id_seq OWNED BY public.document_copies.id;

--
-- Name: document_favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_favorites (
    user_id bigint NOT NULL,
    document_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.document_favorites FORCE ROW LEVEL SECURITY;

--
-- Name: document_file_text; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_file_text (
    document_id bigint NOT NULL,
    content_text text,
    tsv tsvector,
    pages integer,
    chars integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    error text,
    attempts integer DEFAULT 0 NOT NULL,
    indexed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    CONSTRAINT document_file_text_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'indexed'::text, 'empty'::text, 'failed'::text])))
);

ALTER TABLE ONLY public.document_file_text FORCE ROW LEVEL SECURITY;

--
-- Name: document_file_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_file_versions (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    version integer NOT NULL,
    content bytea NOT NULL,
    sha256 text NOT NULL,
    size_bytes integer NOT NULL,
    uploaded_by bigint,
    uploaded_at timestamp with time zone NOT NULL,
    superseded_at timestamp with time zone DEFAULT now() NOT NULL,
    superseded_by bigint
);
ALTER TABLE ONLY public.document_file_versions ALTER COLUMN content SET STORAGE EXTERNAL;

ALTER TABLE ONLY public.document_file_versions FORCE ROW LEVEL SECURITY;

--
-- Name: document_file_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_file_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_file_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_file_versions_id_seq OWNED BY public.document_file_versions.id;

--
-- Name: document_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_files (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    content bytea NOT NULL,
    sha256 text NOT NULL,
    size_bytes integer NOT NULL,
    mime_type text DEFAULT 'application/pdf'::text NOT NULL,
    uploaded_by bigint,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT document_files_mime_type_check CHECK ((mime_type = 'application/pdf'::text))
);
ALTER TABLE ONLY public.document_files ALTER COLUMN content SET STORAGE EXTERNAL;

ALTER TABLE ONLY public.document_files FORCE ROW LEVEL SECURITY;

--
-- Name: document_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_files_id_seq OWNED BY public.document_files.id;

--
-- Name: document_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_history (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    actor_id bigint,
    event_type text NOT NULL,
    from_status public.doc_status,
    to_status public.doc_status,
    comment text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: document_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_history_id_seq OWNED BY public.document_history.id;

--
-- Name: document_incoming_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_incoming_instances (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    receiving_department_id bigint NOT NULL,
    received_by bigint,
    incoming_number text NOT NULL,
    instance_label text,
    first_viewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    executed_at timestamp with time zone,
    executed_by bigint,
    execution_note text,
    execution_actor_note text
);

--
-- Name: document_incoming_instances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_incoming_instances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_incoming_instances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_incoming_instances_id_seq OWNED BY public.document_incoming_instances.id;

--
-- Name: document_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_links (
    id bigint NOT NULL,
    source_document_id bigint NOT NULL,
    target_document_id bigint,
    text_note text,
    link_type text DEFAULT 'related'::text NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_link_target CHECK (((target_document_id IS NOT NULL) <> (text_note IS NOT NULL))),
    CONSTRAINT document_links_check CHECK ((source_document_id <> target_document_id)),
    CONSTRAINT document_links_link_type_check CHECK ((link_type = ANY (ARRAY['related'::text, 'reply_to'::text, 'in_pursuance_of'::text, 'annuls'::text, 'appendix'::text])))
);

--
-- Name: document_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_links_id_seq OWNED BY public.document_links.id;

--
-- Name: document_prints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_prints (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    instance_number integer DEFAULT 0 NOT NULL,
    user_id bigint NOT NULL,
    copy_number integer NOT NULL,
    printed_at timestamp with time zone DEFAULT now() NOT NULL,
    reg_journal text,
    reg_number text,
    reg_at timestamp with time zone,
    registered_by bigint,
    registrant_fio text
);

--
-- Name: document_prints_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_prints_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_prints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_prints_id_seq OWNED BY public.document_prints.id;

--
-- Name: document_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_recipients (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    recipient_user_id bigint NOT NULL,
    recipient_department_id bigint NOT NULL,
    is_planned boolean DEFAULT false NOT NULL,
    completed_at timestamp with time zone,
    completion_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    added_by bigint
);

--
-- Name: document_recipients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_recipients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_recipients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_recipients_id_seq OWNED BY public.document_recipients.id;

--
-- Name: document_signatures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_signatures (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    signer_id bigint NOT NULL,
    signed_at timestamp with time zone DEFAULT now() NOT NULL,
    signature_type text NOT NULL,
    signature_hash text NOT NULL,
    storage_resource text NOT NULL,
    signer_fio text,
    signer_position text,
    signer_login text,
    signed_ip text,
    user_agent text,
    document_hash text,
    actor_note text,
    signed_payload text,
    key_id text,
    CONSTRAINT document_signatures_signature_type_check CHECK ((signature_type = ANY (ARRAY['ПЭП'::text, 'НЭП'::text, 'УНЭП'::text, 'УКЭП'::text])))
);

--
-- Name: COLUMN document_signatures.signature_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.document_signatures.signature_hash IS 'HMAC-SHA256(серверный секрет signing.secret, signed_payload), hex.';

--
-- Name: COLUMN document_signatures.signed_payload; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.document_signatures.signed_payload IS 'Подписанная строка: хэш файла, документ, подписант, номер, время.';

--
-- Name: COLUMN document_signatures.key_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.document_signatures.key_id IS 'Отпечаток секрета, которым выполнена подпись (для смены ключа).';

--
-- Name: document_signatures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_signatures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_signatures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_signatures_id_seq OWNED BY public.document_signatures.id;

--
-- Name: document_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_versions (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    version integer NOT NULL,
    card jsonb NOT NULL,
    changed_by bigint,
    change_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: document_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_versions_id_seq OWNED BY public.document_versions.id;

--
-- Name: document_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_views (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    viewer_id bigint NOT NULL,
    viewed_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: document_views_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: document_views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_views_id_seq OWNED BY public.document_views.id;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id bigint NOT NULL,
    author_id bigint NOT NULL,
    author_department_id bigint NOT NULL,
    title text NOT NULL,
    urgency public.doc_urgency DEFAULT 'normal'::public.doc_urgency NOT NULL,
    status public.doc_status DEFAULT 'draft'::public.doc_status NOT NULL,
    outgoing_number text,
    due_date date,
    due_datetime timestamp with time zone,
    executed_at timestamp with time zone,
    archived_at timestamp with time zone,
    controller_id bigint,
    on_control boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    category_id bigint NOT NULL,
    special_mark_id bigint NOT NULL,
    approval_round integer DEFAULT 1 NOT NULL
);

ALTER TABLE ONLY public.documents FORCE ROW LEVEL SECURITY;

--
-- Name: COLUMN documents.approval_round; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.documents.approval_round IS 'Круг согласования: увеличивается, когда автор правит документ и согласование начинается заново.';

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;

--
-- Name: email_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_outbox (
    id bigint NOT NULL,
    to_addr text NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    kind text DEFAULT 'new_document'::text NOT NULL,
    document_id bigint,
    user_id bigint,
    status text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    CONSTRAINT email_outbox_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'failed'::text])))
);

--
-- Name: TABLE email_outbox; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.email_outbox IS 'Очередь писем. Письмо ставится в очередь в той же транзакции, что и действие; отправляет фоновая задача.';

--
-- Name: email_outbox_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_outbox_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: email_outbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_outbox_id_seq OWNED BY public.email_outbox.id;

--
-- Name: executors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.executors (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    executor_id bigint NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    report text
);

--
-- Name: executors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.executors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: executors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.executors_id_seq OWNED BY public.executors.id;

--
-- Name: kerberos_seen_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kerberos_seen_tokens (
    token_hash text NOT NULL,
    seen_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    document_id bigint,
    kind text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    actor_id bigint,
    detail text,
    requires_ack boolean DEFAULT false NOT NULL,
    snoozed_until timestamp with time zone
);

ALTER TABLE ONLY public.notifications FORCE ROW LEVEL SECURITY;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;

--
-- Name: numbering_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.numbering_sequences (
    department_id bigint NOT NULL,
    year integer NOT NULL,
    seq_type text NOT NULL,
    last_value integer DEFAULT 0 NOT NULL,
    CONSTRAINT numbering_sequences_seq_type_check CHECK ((seq_type = ANY (ARRAY['outgoing'::text, 'incoming'::text])))
);

--
-- Name: reassignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reassignments (
    id bigint NOT NULL,
    object_kind text NOT NULL,
    object_id bigint NOT NULL,
    document_id bigint NOT NULL,
    from_user_id bigint NOT NULL,
    to_user_id bigint NOT NULL,
    actor_id bigint NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_reassign_diff CHECK ((from_user_id <> to_user_id)),
    CONSTRAINT reassignments_object_kind_check CHECK ((object_kind = ANY (ARRAY['approval_stage'::text, 'resolution_executor'::text]))),
    CONSTRAINT reassignments_reason_check CHECK ((btrim(reason) <> ''::text))
);

--
-- Name: reassignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reassignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: reassignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reassignments_id_seq OWNED BY public.reassignments.id;

--
-- Name: recipient_group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipient_group_members (
    group_id bigint NOT NULL,
    user_id bigint NOT NULL,
    department_id bigint NOT NULL
);

--
-- Name: recipient_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipient_groups (
    id bigint NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: recipient_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recipient_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: recipient_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recipient_groups_id_seq OWNED BY public.recipient_groups.id;

--
-- Name: resolution_executors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resolution_executors (
    id bigint NOT NULL,
    resolution_id bigint NOT NULL,
    user_id bigint NOT NULL,
    is_responsible boolean DEFAULT false NOT NULL,
    status public.resolution_exec_status DEFAULT 'open'::public.resolution_exec_status NOT NULL,
    report text,
    reported_at timestamp with time zone,
    accepted_at timestamp with time zone,
    accepted_by bigint,
    return_note text,
    reassigned_from bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.resolution_executors FORCE ROW LEVEL SECURITY;

--
-- Name: resolution_executors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.resolution_executors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: resolution_executors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.resolution_executors_id_seq OWNED BY public.resolution_executors.id;

--
-- Name: resolutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resolutions (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    author_id bigint NOT NULL,
    author_position text,
    text text NOT NULL,
    due_date date,
    due_datetime timestamp with time zone,
    on_control boolean DEFAULT false NOT NULL,
    controller_id bigint,
    status public.resolution_status DEFAULT 'issued'::public.resolution_status NOT NULL,
    closed_at timestamp with time zone,
    closed_by bigint,
    close_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    instance_id bigint NOT NULL,
    department_id bigint NOT NULL,
    CONSTRAINT resolutions_text_check CHECK ((btrim(text) <> ''::text))
);

ALTER TABLE ONLY public.resolutions FORCE ROW LEVEL SECURITY;

--
-- Name: COLUMN resolutions.instance_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.resolutions.instance_id IS 'Экземпляр входящего документа, на который наложена резолюция. Одна действующая резолюция на экземпляр.';

--
-- Name: resolutions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.resolutions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: resolutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.resolutions_id_seq OWNED BY public.resolutions.id;

--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_version (
    version integer NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    note text
);

--
-- Name: security_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_events (
    id bigint NOT NULL,
    user_id bigint,
    event_type text NOT NULL,
    details text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.security_events FORCE ROW LEVEL SECURITY;

--
-- Name: security_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.security_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: security_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.security_events_id_seq OWNED BY public.security_events.id;

--
-- Name: special_marks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.special_marks (
    id bigint NOT NULL,
    name text NOT NULL,
    code text,
    color text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_default boolean DEFAULT false NOT NULL
);

--
-- Name: special_marks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.special_marks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: special_marks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.special_marks_id_seq OWNED BY public.special_marks.id;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key text NOT NULL,
    value jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: user_acquaint_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_acquaint_departments (
    user_id bigint NOT NULL,
    department_id bigint NOT NULL
);

--
-- Name: user_incoming_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_incoming_departments (
    user_id bigint NOT NULL,
    department_id bigint NOT NULL
);

--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_preferences (
    user_id bigint NOT NULL,
    pref_key text NOT NULL,
    value jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

--
-- Name: user_redirect_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_redirect_departments (
    user_id bigint NOT NULL,
    department_id bigint NOT NULL
);

--
-- Name: user_resolution_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_resolution_departments (
    user_id bigint NOT NULL,
    department_id bigint NOT NULL
);

--
-- Name: TABLE user_resolution_departments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_resolution_departments IS 'Дополнительные подразделения, по документам которых пользователь вправе накладывать резолюцию (п. 4 замечаний v52). Своё подразделение и вниз по иерархии действует без записи в этой таблице.';

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id bigint NOT NULL,
    department_id bigint,
    role public.role_code NOT NULL
);

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    jti text NOT NULL,
    ip inet,
    user_agent text,
    workstation text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revoke_reason text,
    ip_peer inet,
    ip_chain text
);

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;

--
-- Name: user_visible_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_visible_departments (
    user_id bigint NOT NULL,
    department_id bigint NOT NULL
);

--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    login text NOT NULL,
    password_hash text NOT NULL,
    full_name text NOT NULL,
    "position" text,
    primary_department_id bigint,
    numbering_department_id bigint,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    basis text,
    last_seen_at timestamp with time zone,
    domain_id bigint,
    email text,
    CONSTRAINT users_login_domain_chk CHECK (((domain_id IS NULL) = (POSITION(('@'::text) IN (login)) = 0)))
);

--
-- Name: COLUMN users.domain_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.domain_id IS 'Домен аутентификации; NULL — локальная учётная запись (вход по паролю из password_hash).';

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;

--
-- Name: approval_stages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_stages ALTER COLUMN id SET DEFAULT nextval('public.approval_stages_id_seq'::regclass);

--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);

--
-- Name: auth_domains id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_domains ALTER COLUMN id SET DEFAULT nextval('public.auth_domains_id_seq'::regclass);

--
-- Name: chat_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_attachments ALTER COLUMN id SET DEFAULT nextval('public.chat_attachments_id_seq'::regclass);

--
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);

--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);

--
-- Name: document_acquaintances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_acquaintances ALTER COLUMN id SET DEFAULT nextval('public.document_acquaintances_id_seq'::regclass);

--
-- Name: document_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_categories ALTER COLUMN id SET DEFAULT nextval('public.document_categories_id_seq'::regclass);

--
-- Name: document_copies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_copies ALTER COLUMN id SET DEFAULT nextval('public.document_copies_id_seq'::regclass);

--
-- Name: document_file_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_file_versions ALTER COLUMN id SET DEFAULT nextval('public.document_file_versions_id_seq'::regclass);

--
-- Name: document_files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_files ALTER COLUMN id SET DEFAULT nextval('public.document_files_id_seq'::regclass);

--
-- Name: document_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_history ALTER COLUMN id SET DEFAULT nextval('public.document_history_id_seq'::regclass);

--
-- Name: document_incoming_instances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_incoming_instances ALTER COLUMN id SET DEFAULT nextval('public.document_incoming_instances_id_seq'::regclass);

--
-- Name: document_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_links ALTER COLUMN id SET DEFAULT nextval('public.document_links_id_seq'::regclass);

--
-- Name: document_prints id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_prints ALTER COLUMN id SET DEFAULT nextval('public.document_prints_id_seq'::regclass);

--
-- Name: document_recipients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_recipients ALTER COLUMN id SET DEFAULT nextval('public.document_recipients_id_seq'::regclass);

--
-- Name: document_signatures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_signatures ALTER COLUMN id SET DEFAULT nextval('public.document_signatures_id_seq'::regclass);

--
-- Name: document_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions ALTER COLUMN id SET DEFAULT nextval('public.document_versions_id_seq'::regclass);

--
-- Name: document_views id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_views ALTER COLUMN id SET DEFAULT nextval('public.document_views_id_seq'::regclass);

--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);

--
-- Name: email_outbox id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_outbox ALTER COLUMN id SET DEFAULT nextval('public.email_outbox_id_seq'::regclass);

--
-- Name: executors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.executors ALTER COLUMN id SET DEFAULT nextval('public.executors_id_seq'::regclass);

--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);

--
-- Name: reassignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reassignments ALTER COLUMN id SET DEFAULT nextval('public.reassignments_id_seq'::regclass);

--
-- Name: recipient_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipient_groups ALTER COLUMN id SET DEFAULT nextval('public.recipient_groups_id_seq'::regclass);

--
-- Name: resolution_executors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolution_executors ALTER COLUMN id SET DEFAULT nextval('public.resolution_executors_id_seq'::regclass);

--
-- Name: resolutions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolutions ALTER COLUMN id SET DEFAULT nextval('public.resolutions_id_seq'::regclass);

--
-- Name: security_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events ALTER COLUMN id SET DEFAULT nextval('public.security_events_id_seq'::regclass);

--
-- Name: special_marks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.special_marks ALTER COLUMN id SET DEFAULT nextval('public.special_marks_id_seq'::regclass);

--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);

--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);

--
-- Name: approval_stage_dependencies approval_stage_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_stage_dependencies
    ADD CONSTRAINT approval_stage_dependencies_pkey PRIMARY KEY (stage_id, depends_on_stage_id);

--
-- Name: approval_stages approval_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_stages
    ADD CONSTRAINT approval_stages_pkey PRIMARY KEY (id);

--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);

--
-- Name: auth_domains auth_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_domains
    ADD CONSTRAINT auth_domains_pkey PRIMARY KEY (id);

--
-- Name: auth_login_failures auth_login_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_login_failures
    ADD CONSTRAINT auth_login_failures_pkey PRIMARY KEY (key);

--
-- Name: chat_attachments chat_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_attachments
    ADD CONSTRAINT chat_attachments_pkey PRIMARY KEY (id);

--
-- Name: chat_message_reads chat_message_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message_reads
    ADD CONSTRAINT chat_message_reads_pkey PRIMARY KEY (message_id, user_id);

--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);

--
-- Name: department_closure department_closure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.department_closure
    ADD CONSTRAINT department_closure_pkey PRIMARY KEY (ancestor_id, descendant_id);

--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);

--
-- Name: document_access document_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT document_access_pkey PRIMARY KEY (document_id, user_id, access_reason);

--
-- Name: document_acquaintances document_acquaintances_document_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_acquaintances
    ADD CONSTRAINT document_acquaintances_document_id_user_id_key UNIQUE (document_id, user_id);

--
-- Name: document_acquaintances document_acquaintances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_acquaintances
    ADD CONSTRAINT document_acquaintances_pkey PRIMARY KEY (id);

--
-- Name: document_categories document_categories_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_categories
    ADD CONSTRAINT document_categories_code_key UNIQUE (code);

--
-- Name: document_categories document_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_categories
    ADD CONSTRAINT document_categories_name_key UNIQUE (name);

--
-- Name: document_categories document_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_categories
    ADD CONSTRAINT document_categories_pkey PRIMARY KEY (id);

--
-- Name: document_controllers document_controllers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_controllers
    ADD CONSTRAINT document_controllers_pkey PRIMARY KEY (document_id, user_id);

--
-- Name: document_copies document_copies_document_id_copy_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_copies
    ADD CONSTRAINT document_copies_document_id_copy_number_key UNIQUE (document_id, copy_number);

--
-- Name: document_copies document_copies_document_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_copies
    ADD CONSTRAINT document_copies_document_id_user_id_key UNIQUE (document_id, user_id);

--
-- Name: document_copies document_copies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_copies
    ADD CONSTRAINT document_copies_pkey PRIMARY KEY (id);

--
-- Name: document_favorites document_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_favorites
    ADD CONSTRAINT document_favorites_pkey PRIMARY KEY (user_id, document_id);

--
-- Name: document_file_text document_file_text_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_file_text
    ADD CONSTRAINT document_file_text_pkey PRIMARY KEY (document_id);

--
-- Name: document_file_versions document_file_versions_document_id_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_file_versions
    ADD CONSTRAINT document_file_versions_document_id_version_key UNIQUE (document_id, version);

--
-- Name: document_file_versions document_file_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_file_versions
    ADD CONSTRAINT document_file_versions_pkey PRIMARY KEY (id);

--
-- Name: document_files document_files_document_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_files
    ADD CONSTRAINT document_files_document_id_key UNIQUE (document_id);

--
-- Name: document_files document_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_files
    ADD CONSTRAINT document_files_pkey PRIMARY KEY (id);

--
-- Name: document_history document_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_history
    ADD CONSTRAINT document_history_pkey PRIMARY KEY (id);

--
-- Name: document_incoming_instances document_incoming_instances_document_id_receiving_departmen_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_incoming_instances
    ADD CONSTRAINT document_incoming_instances_document_id_receiving_departmen_key UNIQUE (document_id, receiving_department_id);

--
-- Name: document_incoming_instances document_incoming_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_incoming_instances
    ADD CONSTRAINT document_incoming_instances_pkey PRIMARY KEY (id);

--
-- Name: document_links document_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_links
    ADD CONSTRAINT document_links_pkey PRIMARY KEY (id);

--
-- Name: document_links document_links_source_document_id_target_document_id_link_t_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_links
    ADD CONSTRAINT document_links_source_document_id_target_document_id_link_t_key UNIQUE (source_document_id, target_document_id, link_type);

--
-- Name: document_prints document_prints_document_id_user_id_copy_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_prints
    ADD CONSTRAINT document_prints_document_id_user_id_copy_number_key UNIQUE (document_id, user_id, copy_number);

--
-- Name: document_prints document_prints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_prints
    ADD CONSTRAINT document_prints_pkey PRIMARY KEY (id);

--
-- Name: document_recipients document_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_recipients
    ADD CONSTRAINT document_recipients_pkey PRIMARY KEY (id);

--
-- Name: document_signatures document_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_signatures
    ADD CONSTRAINT document_signatures_pkey PRIMARY KEY (id);

--
-- Name: document_versions document_versions_document_id_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_document_id_version_key UNIQUE (document_id, version);

--
-- Name: document_versions document_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_pkey PRIMARY KEY (id);

--
-- Name: document_views document_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_views
    ADD CONSTRAINT document_views_pkey PRIMARY KEY (id);

--
-- Name: documents documents_outgoing_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_outgoing_number_key UNIQUE (outgoing_number);

--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);

--
-- Name: email_outbox email_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_outbox
    ADD CONSTRAINT email_outbox_pkey PRIMARY KEY (id);

--
-- Name: executors executors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.executors
    ADD CONSTRAINT executors_pkey PRIMARY KEY (id);

--
-- Name: kerberos_seen_tokens kerberos_seen_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kerberos_seen_tokens
    ADD CONSTRAINT kerberos_seen_tokens_pkey PRIMARY KEY (token_hash);

--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);

--
-- Name: numbering_sequences numbering_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.numbering_sequences
    ADD CONSTRAINT numbering_sequences_pkey PRIMARY KEY (department_id, year, seq_type);

--
-- Name: reassignments reassignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reassignments
    ADD CONSTRAINT reassignments_pkey PRIMARY KEY (id);

--
-- Name: recipient_group_members recipient_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipient_group_members
    ADD CONSTRAINT recipient_group_members_pkey PRIMARY KEY (group_id, user_id, department_id);

--
-- Name: recipient_groups recipient_groups_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipient_groups
    ADD CONSTRAINT recipient_groups_name_key UNIQUE (name);

--
-- Name: recipient_groups recipient_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipient_groups
    ADD CONSTRAINT recipient_groups_pkey PRIMARY KEY (id);

--
-- Name: resolution_executors resolution_executors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolution_executors
    ADD CONSTRAINT resolution_executors_pkey PRIMARY KEY (id);

--
-- Name: resolution_executors resolution_executors_resolution_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolution_executors
    ADD CONSTRAINT resolution_executors_resolution_id_user_id_key UNIQUE (resolution_id, user_id);

--
-- Name: resolutions resolutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolutions
    ADD CONSTRAINT resolutions_pkey PRIMARY KEY (id);

--
-- Name: schema_version schema_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_version
    ADD CONSTRAINT schema_version_pkey PRIMARY KEY (version);

--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);

--
-- Name: special_marks special_marks_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.special_marks
    ADD CONSTRAINT special_marks_code_key UNIQUE (code);

--
-- Name: special_marks special_marks_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.special_marks
    ADD CONSTRAINT special_marks_name_key UNIQUE (name);

--
-- Name: special_marks special_marks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.special_marks
    ADD CONSTRAINT special_marks_pkey PRIMARY KEY (id);

--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);

--
-- Name: document_recipients uq_doc_recipient; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_recipients
    ADD CONSTRAINT uq_doc_recipient UNIQUE (document_id, recipient_user_id);

--
-- Name: user_acquaint_departments user_acquaint_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_acquaint_departments
    ADD CONSTRAINT user_acquaint_departments_pkey PRIMARY KEY (user_id, department_id);

--
-- Name: user_incoming_departments user_incoming_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_incoming_departments
    ADD CONSTRAINT user_incoming_departments_pkey PRIMARY KEY (user_id, department_id);

--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (user_id, pref_key);

--
-- Name: user_redirect_departments user_redirect_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_redirect_departments
    ADD CONSTRAINT user_redirect_departments_pkey PRIMARY KEY (user_id, department_id);

--
-- Name: user_resolution_departments user_resolution_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_resolution_departments
    ADD CONSTRAINT user_resolution_departments_pkey PRIMARY KEY (user_id, department_id);

--
-- Name: user_sessions user_sessions_jti_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_jti_key UNIQUE (jti);

--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);

--
-- Name: user_visible_departments user_visible_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_visible_departments
    ADD CONSTRAINT user_visible_departments_pkey PRIMARY KEY (user_id, department_id);

--
-- Name: users users_login_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_login_key UNIQUE (login);

--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);

--
-- Name: auth_domains_netbios_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX auth_domains_netbios_uq ON public.auth_domains USING btree (lower(netbios_name)) WHERE ((netbios_name IS NOT NULL) AND (netbios_name <> ''::text));

--
-- Name: auth_domains_realm_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX auth_domains_realm_uq ON public.auth_domains USING btree (realm);

--
-- Name: idx_acq_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_acq_user ON public.document_acquaintances USING btree (user_id);

--
-- Name: idx_approval_stage_approver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approval_stage_approver ON public.approval_stages USING btree (approver_id, status);

--
-- Name: idx_approval_stage_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approval_stage_doc ON public.approval_stages USING btree (document_id, display_order);

--
-- Name: idx_approval_stages_pending_since; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approval_stages_pending_since ON public.approval_stages USING btree (approver_id, activated_at) WHERE (status = 'pending'::public.stage_status);

--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_actor ON public.audit_log USING btree (actor_id, occurred_at DESC);

--
-- Name: idx_audit_denied; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_denied ON public.audit_log USING btree (occurred_at DESC) WHERE (outcome <> 'ok'::text);

--
-- Name: idx_audit_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_doc ON public.audit_log USING btree (document_id, occurred_at DESC) WHERE (document_id IS NOT NULL);

--
-- Name: idx_audit_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_event ON public.audit_log USING btree (event, occurred_at DESC);

--
-- Name: idx_audit_ip_peer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_ip_peer ON public.audit_log USING btree (ip_peer, occurred_at DESC);

--
-- Name: idx_audit_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_time ON public.audit_log USING btree (occurred_at DESC);

--
-- Name: idx_chat_attach_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_attach_message ON public.chat_attachments USING btree (message_id);

--
-- Name: idx_chat_doc_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_doc_created ON public.chat_messages USING btree (document_id, created_at);

--
-- Name: idx_chat_reads_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_reads_user ON public.chat_message_reads USING btree (user_id, message_id);

--
-- Name: idx_dept_closure_anc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dept_closure_anc ON public.department_closure USING btree (ancestor_id);

--
-- Name: idx_dept_closure_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dept_closure_desc ON public.department_closure USING btree (descendant_id);

--
-- Name: idx_dft_queue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dft_queue ON public.document_file_text USING btree (attempts, document_id) WHERE (status = ANY (ARRAY['pending'::text, 'failed'::text, 'processing'::text]));

--
-- Name: idx_dft_stale; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dft_stale ON public.document_file_text USING btree (claimed_at) WHERE (status = 'processing'::text);

--
-- Name: idx_dft_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dft_tsv ON public.document_file_text USING gin (tsv);

--
-- Name: idx_doc_access_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_access_doc ON public.document_access USING btree (document_id);

--
-- Name: idx_doc_access_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_access_user ON public.document_access USING btree (user_id, document_id);

--
-- Name: idx_doc_copies_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_copies_doc ON public.document_copies USING btree (document_id, copy_number);

--
-- Name: idx_doc_copies_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_copies_user ON public.document_copies USING btree (user_id);

--
-- Name: idx_doc_file_versions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_file_versions ON public.document_file_versions USING btree (document_id, version DESC);

--
-- Name: idx_doc_files_sha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_files_sha ON public.document_files USING btree (sha256);

--
-- Name: idx_doc_history_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_history_doc ON public.document_history USING btree (document_id, created_at);

--
-- Name: idx_doc_prints_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_prints_doc ON public.document_prints USING btree (document_id, printed_at DESC);

--
-- Name: idx_doc_prints_unreg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_prints_unreg ON public.document_prints USING btree (user_id) WHERE (reg_at IS NULL);

--
-- Name: idx_doc_prints_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_prints_user ON public.document_prints USING btree (user_id);

--
-- Name: idx_doc_recipients_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_recipients_doc ON public.document_recipients USING btree (document_id);

--
-- Name: idx_doc_recipients_incomplete; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_recipients_incomplete ON public.document_recipients USING btree (document_id) WHERE (completed_at IS NULL);

--
-- Name: idx_doc_recipients_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_recipients_user ON public.document_recipients USING btree (recipient_user_id);

--
-- Name: idx_doc_signatures_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_signatures_doc ON public.document_signatures USING btree (document_id);

--
-- Name: idx_doc_versions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_versions ON public.document_versions USING btree (document_id, version DESC);

--
-- Name: idx_doc_views_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_views_doc ON public.document_views USING btree (document_id, viewed_at DESC);

--
-- Name: idx_document_access_author_granted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_access_author_granted ON public.document_access USING btree (granted_at) WHERE (access_reason = 'author'::text);

--
-- Name: idx_document_controllers_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_controllers_user ON public.document_controllers USING btree (user_id);

--
-- Name: idx_document_links_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_links_source ON public.document_links USING btree (source_document_id);

--
-- Name: idx_document_links_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_links_target ON public.document_links USING btree (target_document_id);

--
-- Name: idx_document_recipients_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_recipients_user ON public.document_recipients USING btree (recipient_user_id);

--
-- Name: idx_documents_active_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_active_created ON public.documents USING btree (created_at DESC) WHERE (status <> 'archived'::public.doc_status);

--
-- Name: idx_documents_author_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_author_created ON public.documents USING btree (author_id, created_at DESC);

--
-- Name: idx_documents_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_category ON public.documents USING btree (category_id);

--
-- Name: idx_documents_controller; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_controller ON public.documents USING btree (controller_id) WHERE (controller_id IS NOT NULL);

--
-- Name: idx_documents_dept_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_dept_created ON public.documents USING btree (author_department_id, created_at DESC);

--
-- Name: idx_documents_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_due ON public.documents USING btree (due_date) WHERE (due_date IS NOT NULL);

--
-- Name: idx_documents_executed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_executed_at ON public.documents USING btree (executed_at) WHERE (executed_at IS NOT NULL);

--
-- Name: idx_documents_executed_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_executed_year ON public.documents USING btree (executed_at) WHERE ((status = 'executed'::public.doc_status) AND (executed_at IS NOT NULL));

--
-- Name: idx_documents_on_control; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_on_control ON public.documents USING btree (on_control) WHERE (on_control = true);

--
-- Name: idx_documents_outgoing_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_outgoing_created ON public.documents USING btree (created_at DESC) WHERE ((outgoing_number IS NOT NULL) AND (status <> 'archived'::public.doc_status));

--
-- Name: idx_documents_outnum_norm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_outnum_norm ON public.documents USING gin (public.normalize_doc_number(outgoing_number) public.gin_trgm_ops);

--
-- Name: idx_documents_special_mark; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_special_mark ON public.documents USING btree (special_mark_id);

--
-- Name: idx_documents_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_status_created ON public.documents USING btree (status, created_at DESC);

--
-- Name: idx_documents_title_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_documents_title_fold ON public.documents USING gin (public.fold_ru(title) public.gin_trgm_ops);

--
-- Name: idx_email_outbox_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_outbox_pending ON public.email_outbox USING btree (next_attempt_at) WHERE (status = 'pending'::text);

--
-- Name: idx_executors_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_executors_doc ON public.executors USING btree (document_id);

--
-- Name: idx_executors_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_executors_user ON public.executors USING btree (executor_id, completed_at);

--
-- Name: idx_incoming_dept; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incoming_dept ON public.document_incoming_instances USING btree (receiving_department_id, created_at DESC);

--
-- Name: idx_incoming_dept_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incoming_dept_open ON public.document_incoming_instances USING btree (receiving_department_id) WHERE (executed_at IS NULL);

--
-- Name: idx_incoming_executed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incoming_executed_at ON public.document_incoming_instances USING btree (executed_at) WHERE (executed_at IS NOT NULL);

--
-- Name: idx_incoming_executed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incoming_executed_by ON public.document_incoming_instances USING btree (executed_by) WHERE (executed_by IS NOT NULL);

--
-- Name: idx_incoming_not_executed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incoming_not_executed ON public.document_incoming_instances USING btree (receiving_department_id, created_at DESC) WHERE (executed_at IS NULL);

--
-- Name: idx_incoming_num_norm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incoming_num_norm ON public.document_incoming_instances USING gin (public.normalize_doc_number(incoming_number) public.gin_trgm_ops);

--
-- Name: idx_incoming_number_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_incoming_number_trgm ON public.document_incoming_instances USING gin (incoming_number public.gin_trgm_ops);

--
-- Name: idx_kerberos_seen_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kerberos_seen_at ON public.kerberos_seen_tokens USING btree (seen_at);

--
-- Name: idx_notifications_alarms; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_alarms ON public.notifications USING btree (user_id, snoozed_until) WHERE (requires_ack AND (NOT is_read));

--
-- Name: idx_notifications_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_created ON public.notifications USING btree (user_id, created_at DESC);

--
-- Name: idx_notifications_user_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_unread ON public.notifications USING btree (user_id, is_read, created_at DESC);

--
-- Name: idx_reassign_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reassign_doc ON public.reassignments USING btree (document_id, created_at);

--
-- Name: idx_recipient_group_members_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recipient_group_members_group ON public.recipient_group_members USING btree (group_id);

--
-- Name: idx_res_exec_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_exec_user ON public.resolution_executors USING btree (user_id, status) WHERE (status = ANY (ARRAY['open'::public.resolution_exec_status, 'in_progress'::public.resolution_exec_status, 'returned'::public.resolution_exec_status]));

--
-- Name: idx_resolution_executors_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resolution_executors_user ON public.resolution_executors USING btree (user_id) WHERE (status <> 'cancelled'::public.resolution_exec_status);

--
-- Name: idx_resolutions_department; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resolutions_department ON public.resolutions USING btree (department_id);

--
-- Name: idx_resolutions_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resolutions_doc ON public.resolutions USING btree (document_id, created_at);

--
-- Name: idx_resolutions_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resolutions_open ON public.resolutions USING btree (due_date) WHERE (status = ANY (ARRAY['issued'::public.resolution_status, 'in_progress'::public.resolution_status, 'on_report'::public.resolution_status]));

--
-- Name: idx_resolutions_open_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resolutions_open_due ON public.resolutions USING btree (due_date) WHERE (status = ANY (ARRAY['issued'::public.resolution_status, 'in_progress'::public.resolution_status, 'on_report'::public.resolution_status]));

--
-- Name: idx_security_events_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_created ON public.security_events USING btree (created_at DESC);

--
-- Name: idx_security_events_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_user ON public.security_events USING btree (user_id, created_at DESC);

--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_user ON public.user_sessions USING btree (user_id, created_at DESC);

--
-- Name: idx_special_marks_default; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_special_marks_default ON public.special_marks USING btree (is_default) WHERE is_default;

--
-- Name: idx_stage_deps_depends_on; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stage_deps_depends_on ON public.approval_stage_dependencies USING btree (depends_on_stage_id);

--
-- Name: idx_stage_deps_stage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stage_deps_stage ON public.approval_stage_dependencies USING btree (stage_id);

--
-- Name: idx_user_incoming_dept; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_incoming_dept ON public.user_incoming_departments USING btree (department_id);

--
-- Name: idx_user_redirect_dept; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_redirect_dept ON public.user_redirect_departments USING btree (department_id);

--
-- Name: idx_user_roles_dept_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_roles_dept_role ON public.user_roles USING btree (department_id, role);

--
-- Name: idx_user_roles_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_roles_user ON public.user_roles USING btree (user_id);

--
-- Name: idx_user_visible_dept; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_visible_dept ON public.user_visible_departments USING btree (department_id);

--
-- Name: idx_users_dept; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_dept ON public.users USING btree (primary_department_id);

--
-- Name: idx_users_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_domain ON public.users USING btree (domain_id) WHERE (domain_id IS NOT NULL);

--
-- Name: idx_users_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_last_seen ON public.users USING btree (last_seen_at DESC) WHERE (last_seen_at IS NOT NULL);

--
-- Name: uq_incoming_number_per_dept; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_incoming_number_per_dept ON public.document_incoming_instances USING btree (receiving_department_id, incoming_number) WHERE (incoming_number <> ''::text);

--
-- Name: uq_one_active_session; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_one_active_session ON public.user_sessions USING btree (user_id) WHERE (revoked_at IS NULL);

--
-- Name: uq_resolution_active_per_instance; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_resolution_active_per_instance ON public.resolutions USING btree (instance_id) WHERE (status <> 'cancelled'::public.resolution_status);

--
-- Name: uq_resolution_one_responsible; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_resolution_one_responsible ON public.resolution_executors USING btree (resolution_id) WHERE is_responsible;

--
-- Name: uq_user_roles; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_user_roles ON public.user_roles USING btree (user_id, COALESCE(department_id, (0)::bigint), role);

--
-- Name: users_login_lower_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_login_lower_uq ON public.users USING btree (lower(login));

--
-- Name: notifications notifications_dedupe; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notifications_dedupe BEFORE INSERT ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.notifications_dedupe();

--
-- Name: approval_stages trg_approval_stage_activated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_approval_stage_activated BEFORE INSERT OR UPDATE OF status ON public.approval_stages FOR EACH ROW EXECUTE FUNCTION public.approval_stage_activated();

--
-- Name: document_files trg_archive_document_file; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_archive_document_file BEFORE UPDATE ON public.document_files FOR EACH ROW EXECUTE FUNCTION public.archive_document_file_version();

--
-- Name: document_recipients trg_check_recipient_role; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_check_recipient_role BEFORE INSERT OR UPDATE ON public.document_recipients FOR EACH ROW EXECUTE FUNCTION public.check_recipient_role();

--
-- Name: users trg_check_user_domain_login; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_check_user_domain_login BEFORE INSERT OR UPDATE OF login, domain_id ON public.users FOR EACH ROW EXECUTE FUNCTION public.check_user_domain_login();

--
-- Name: document_files trg_document_files_enqueue_text; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_document_files_enqueue_text AFTER INSERT OR UPDATE OF content ON public.document_files FOR EACH ROW EXECUTE FUNCTION public.enqueue_document_text_index();

--
-- Name: documents trg_document_version; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_document_version AFTER INSERT OR UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.snapshot_document_version();

--
-- Name: documents trg_documents_archive_clears_control; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_documents_archive_clears_control BEFORE UPDATE OF status ON public.documents FOR EACH ROW EXECUTE FUNCTION public.documents_archive_clears_control();

--
-- Name: documents trg_documents_default_special_mark; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_documents_default_special_mark BEFORE INSERT OR UPDATE OF special_mark_id ON public.documents FOR EACH ROW EXECUTE FUNCTION public.set_default_special_mark();

--
-- Name: documents trg_documents_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_documents_updated_at BEFORE UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

--
-- Name: users trg_grant_executor_role; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_grant_executor_role AFTER INSERT ON public.users FOR EACH ROW EXECUTE FUNCTION public.grant_executor_role();

--
-- Name: approval_stage_dependencies approval_stage_dependencies_depends_on_stage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_stage_dependencies
    ADD CONSTRAINT approval_stage_dependencies_depends_on_stage_id_fkey FOREIGN KEY (depends_on_stage_id) REFERENCES public.approval_stages(id) ON DELETE CASCADE;

--
-- Name: approval_stage_dependencies approval_stage_dependencies_stage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_stage_dependencies
    ADD CONSTRAINT approval_stage_dependencies_stage_id_fkey FOREIGN KEY (stage_id) REFERENCES public.approval_stages(id) ON DELETE CASCADE;

--
-- Name: approval_stages approval_stages_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_stages
    ADD CONSTRAINT approval_stages_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id);

--
-- Name: approval_stages approval_stages_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_stages
    ADD CONSTRAINT approval_stages_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: audit_log audit_log_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);

--
-- Name: auth_domains auth_domains_default_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_domains
    ADD CONSTRAINT auth_domains_default_department_id_fkey FOREIGN KEY (default_department_id) REFERENCES public.departments(id) ON DELETE SET NULL;

--
-- Name: chat_attachments chat_attachments_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_attachments
    ADD CONSTRAINT chat_attachments_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id) ON DELETE CASCADE;

--
-- Name: chat_message_reads chat_message_reads_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message_reads
    ADD CONSTRAINT chat_message_reads_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id) ON DELETE CASCADE;

--
-- Name: chat_message_reads chat_message_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message_reads
    ADD CONSTRAINT chat_message_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: chat_messages chat_messages_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);

--
-- Name: chat_messages chat_messages_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: department_closure department_closure_ancestor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.department_closure
    ADD CONSTRAINT department_closure_ancestor_id_fkey FOREIGN KEY (ancestor_id) REFERENCES public.departments(id) ON DELETE CASCADE;

--
-- Name: department_closure department_closure_descendant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.department_closure
    ADD CONSTRAINT department_closure_descendant_id_fkey FOREIGN KEY (descendant_id) REFERENCES public.departments(id) ON DELETE CASCADE;

--
-- Name: departments departments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.departments(id) ON DELETE RESTRICT;

--
-- Name: document_access document_access_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT document_access_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_access document_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT document_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: document_acquaintances document_acquaintances_acquainted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_acquaintances
    ADD CONSTRAINT document_acquaintances_acquainted_by_fkey FOREIGN KEY (acquainted_by) REFERENCES public.users(id);

--
-- Name: document_acquaintances document_acquaintances_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_acquaintances
    ADD CONSTRAINT document_acquaintances_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_acquaintances document_acquaintances_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_acquaintances
    ADD CONSTRAINT document_acquaintances_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

--
-- Name: document_controllers document_controllers_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_controllers
    ADD CONSTRAINT document_controllers_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_controllers document_controllers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_controllers
    ADD CONSTRAINT document_controllers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: document_copies document_copies_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_copies
    ADD CONSTRAINT document_copies_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_copies document_copies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_copies
    ADD CONSTRAINT document_copies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: document_favorites document_favorites_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_favorites
    ADD CONSTRAINT document_favorites_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_favorites document_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_favorites
    ADD CONSTRAINT document_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: document_file_text document_file_text_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_file_text
    ADD CONSTRAINT document_file_text_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_file_versions document_file_versions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_file_versions
    ADD CONSTRAINT document_file_versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_file_versions document_file_versions_superseded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_file_versions
    ADD CONSTRAINT document_file_versions_superseded_by_fkey FOREIGN KEY (superseded_by) REFERENCES public.users(id);

--
-- Name: document_file_versions document_file_versions_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_file_versions
    ADD CONSTRAINT document_file_versions_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);

--
-- Name: document_files document_files_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_files
    ADD CONSTRAINT document_files_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_files document_files_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_files
    ADD CONSTRAINT document_files_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);

--
-- Name: document_history document_history_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_history
    ADD CONSTRAINT document_history_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);

--
-- Name: document_history document_history_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_history
    ADD CONSTRAINT document_history_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_incoming_instances document_incoming_instances_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_incoming_instances
    ADD CONSTRAINT document_incoming_instances_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_incoming_instances document_incoming_instances_executed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_incoming_instances
    ADD CONSTRAINT document_incoming_instances_executed_by_fkey FOREIGN KEY (executed_by) REFERENCES public.users(id);

--
-- Name: document_incoming_instances document_incoming_instances_received_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_incoming_instances
    ADD CONSTRAINT document_incoming_instances_received_by_fkey FOREIGN KEY (received_by) REFERENCES public.users(id);

--
-- Name: document_incoming_instances document_incoming_instances_receiving_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_incoming_instances
    ADD CONSTRAINT document_incoming_instances_receiving_department_id_fkey FOREIGN KEY (receiving_department_id) REFERENCES public.departments(id);

--
-- Name: document_links document_links_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_links
    ADD CONSTRAINT document_links_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

--
-- Name: document_links document_links_source_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_links
    ADD CONSTRAINT document_links_source_document_id_fkey FOREIGN KEY (source_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_links document_links_target_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_links
    ADD CONSTRAINT document_links_target_document_id_fkey FOREIGN KEY (target_document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_prints document_prints_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_prints
    ADD CONSTRAINT document_prints_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_prints document_prints_registered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_prints
    ADD CONSTRAINT document_prints_registered_by_fkey FOREIGN KEY (registered_by) REFERENCES public.users(id);

--
-- Name: document_prints document_prints_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_prints
    ADD CONSTRAINT document_prints_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

--
-- Name: document_recipients document_recipients_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_recipients
    ADD CONSTRAINT document_recipients_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);

--
-- Name: document_recipients document_recipients_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_recipients
    ADD CONSTRAINT document_recipients_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_recipients document_recipients_recipient_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_recipients
    ADD CONSTRAINT document_recipients_recipient_department_id_fkey FOREIGN KEY (recipient_department_id) REFERENCES public.departments(id);

--
-- Name: document_recipients document_recipients_recipient_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_recipients
    ADD CONSTRAINT document_recipients_recipient_user_id_fkey FOREIGN KEY (recipient_user_id) REFERENCES public.users(id);

--
-- Name: document_signatures document_signatures_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_signatures
    ADD CONSTRAINT document_signatures_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_signatures document_signatures_signer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_signatures
    ADD CONSTRAINT document_signatures_signer_id_fkey FOREIGN KEY (signer_id) REFERENCES public.users(id);

--
-- Name: document_versions document_versions_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);

--
-- Name: document_versions document_versions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_views document_views_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_views
    ADD CONSTRAINT document_views_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: document_views document_views_viewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_views
    ADD CONSTRAINT document_views_viewer_id_fkey FOREIGN KEY (viewer_id) REFERENCES public.users(id);

--
-- Name: documents documents_author_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_author_department_id_fkey FOREIGN KEY (author_department_id) REFERENCES public.departments(id);

--
-- Name: documents documents_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);

--
-- Name: documents documents_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.document_categories(id);

--
-- Name: documents documents_controller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_controller_id_fkey FOREIGN KEY (controller_id) REFERENCES public.users(id);

--
-- Name: documents documents_special_mark_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_special_mark_id_fkey FOREIGN KEY (special_mark_id) REFERENCES public.special_marks(id);

--
-- Name: email_outbox email_outbox_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_outbox
    ADD CONSTRAINT email_outbox_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: email_outbox email_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_outbox
    ADD CONSTRAINT email_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: executors executors_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.executors
    ADD CONSTRAINT executors_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: executors executors_executor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.executors
    ADD CONSTRAINT executors_executor_id_fkey FOREIGN KEY (executor_id) REFERENCES public.users(id);

--
-- Name: notifications notifications_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);

--
-- Name: notifications notifications_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: numbering_sequences numbering_sequences_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.numbering_sequences
    ADD CONSTRAINT numbering_sequences_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);

--
-- Name: reassignments reassignments_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reassignments
    ADD CONSTRAINT reassignments_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);

--
-- Name: reassignments reassignments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reassignments
    ADD CONSTRAINT reassignments_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: reassignments reassignments_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reassignments
    ADD CONSTRAINT reassignments_from_user_id_fkey FOREIGN KEY (from_user_id) REFERENCES public.users(id);

--
-- Name: reassignments reassignments_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reassignments
    ADD CONSTRAINT reassignments_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id);

--
-- Name: recipient_group_members recipient_group_members_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipient_group_members
    ADD CONSTRAINT recipient_group_members_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;

--
-- Name: recipient_group_members recipient_group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipient_group_members
    ADD CONSTRAINT recipient_group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.recipient_groups(id) ON DELETE CASCADE;

--
-- Name: recipient_group_members recipient_group_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipient_group_members
    ADD CONSTRAINT recipient_group_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: resolution_executors resolution_executors_accepted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolution_executors
    ADD CONSTRAINT resolution_executors_accepted_by_fkey FOREIGN KEY (accepted_by) REFERENCES public.users(id);

--
-- Name: resolution_executors resolution_executors_reassigned_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolution_executors
    ADD CONSTRAINT resolution_executors_reassigned_from_fkey FOREIGN KEY (reassigned_from) REFERENCES public.users(id);

--
-- Name: resolution_executors resolution_executors_resolution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolution_executors
    ADD CONSTRAINT resolution_executors_resolution_id_fkey FOREIGN KEY (resolution_id) REFERENCES public.resolutions(id) ON DELETE CASCADE;

--
-- Name: resolution_executors resolution_executors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolution_executors
    ADD CONSTRAINT resolution_executors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

--
-- Name: resolutions resolutions_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolutions
    ADD CONSTRAINT resolutions_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);

--
-- Name: resolutions resolutions_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolutions
    ADD CONSTRAINT resolutions_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id);

--
-- Name: resolutions resolutions_controller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolutions
    ADD CONSTRAINT resolutions_controller_id_fkey FOREIGN KEY (controller_id) REFERENCES public.users(id);

--
-- Name: resolutions resolutions_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolutions
    ADD CONSTRAINT resolutions_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);

--
-- Name: resolutions resolutions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolutions
    ADD CONSTRAINT resolutions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

--
-- Name: resolutions resolutions_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resolutions
    ADD CONSTRAINT resolutions_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.document_incoming_instances(id) ON DELETE CASCADE;

--
-- Name: security_events security_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;

--
-- Name: user_acquaint_departments user_acquaint_departments_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_acquaint_departments
    ADD CONSTRAINT user_acquaint_departments_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;

--
-- Name: user_acquaint_departments user_acquaint_departments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_acquaint_departments
    ADD CONSTRAINT user_acquaint_departments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: user_incoming_departments user_incoming_departments_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_incoming_departments
    ADD CONSTRAINT user_incoming_departments_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;

--
-- Name: user_incoming_departments user_incoming_departments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_incoming_departments
    ADD CONSTRAINT user_incoming_departments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: user_preferences user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: user_redirect_departments user_redirect_departments_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_redirect_departments
    ADD CONSTRAINT user_redirect_departments_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;

--
-- Name: user_redirect_departments user_redirect_departments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_redirect_departments
    ADD CONSTRAINT user_redirect_departments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: user_resolution_departments user_resolution_departments_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_resolution_departments
    ADD CONSTRAINT user_resolution_departments_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;

--
-- Name: user_resolution_departments user_resolution_departments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_resolution_departments
    ADD CONSTRAINT user_resolution_departments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: user_roles user_roles_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;

--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: user_visible_departments user_visible_departments_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_visible_departments
    ADD CONSTRAINT user_visible_departments_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;

--
-- Name: user_visible_departments user_visible_departments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_visible_departments
    ADD CONSTRAINT user_visible_departments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;

--
-- Name: users users_domain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES public.auth_domains(id) ON DELETE RESTRICT;

--
-- Name: users users_numbering_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_numbering_department_id_fkey FOREIGN KEY (numbering_department_id) REFERENCES public.departments(id);

--
-- Name: users users_primary_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_primary_department_id_fkey FOREIGN KEY (primary_department_id) REFERENCES public.departments(id);

--
-- Name: audit_log audit_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_insert ON public.audit_log FOR INSERT WITH CHECK (true);

--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log audit_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_select ON public.audit_log FOR SELECT USING ((((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE) OR (EXISTS ( SELECT 1
   FROM public.user_roles ur
  WHERE ((ur.user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) AND (ur.role = 'auditor'::public.role_code))))));

--
-- Name: auth_domains; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: auth_domains auth_domains_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY auth_domains_delete ON public.auth_domains FOR DELETE USING (((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE));

--
-- Name: auth_domains auth_domains_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY auth_domains_insert ON public.auth_domains FOR INSERT WITH CHECK (((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE));

--
-- Name: auth_domains auth_domains_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY auth_domains_select ON public.auth_domains FOR SELECT USING (true);

--
-- Name: auth_domains auth_domains_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY auth_domains_update ON public.auth_domains FOR UPDATE USING (((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE)) WITH CHECK (((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE));

--
-- Name: chat_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chat_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_attachments chat_attachments_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY chat_attachments_insert ON public.chat_attachments FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.chat_messages m
  WHERE ((m.id = chat_attachments.message_id) AND (m.author_id = public.app_user_id())))));

--
-- Name: chat_attachments chat_attachments_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY chat_attachments_select ON public.chat_attachments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.chat_messages m
  WHERE (m.id = chat_attachments.message_id))));

--
-- Name: chat_messages chat_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY chat_delete ON public.chat_messages FOR DELETE USING ((author_id = public.app_user_id()));

--
-- Name: chat_messages chat_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY chat_insert ON public.chat_messages FOR INSERT WITH CHECK (((author_id = public.app_user_id()) AND (EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = chat_messages.document_id)))));

--
-- Name: chat_message_reads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chat_message_reads ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_message_reads chat_reads_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY chat_reads_insert ON public.chat_message_reads FOR INSERT WITH CHECK (((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) AND (EXISTS ( SELECT 1
   FROM public.chat_messages m
  WHERE (m.id = chat_message_reads.message_id)))));

--
-- Name: chat_message_reads chat_reads_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY chat_reads_select ON public.chat_message_reads FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.chat_messages m
  WHERE (m.id = chat_message_reads.message_id))));

--
-- Name: chat_messages chat_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY chat_select ON public.chat_messages FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = chat_messages.document_id))));

--
-- Name: chat_messages chat_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY chat_update ON public.chat_messages FOR UPDATE USING ((author_id = public.app_user_id())) WITH CHECK ((author_id = public.app_user_id()));

--
-- Name: document_file_versions doc_file_versions_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY doc_file_versions_insert ON public.document_file_versions FOR INSERT WITH CHECK (true);

--
-- Name: document_file_versions doc_file_versions_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY doc_file_versions_select ON public.document_file_versions FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = document_file_versions.document_id))));

--
-- Name: document_versions doc_versions_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY doc_versions_insert ON public.document_versions FOR INSERT WITH CHECK (true);

--
-- Name: document_versions doc_versions_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY doc_versions_select ON public.document_versions FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = document_versions.document_id))));

--
-- Name: document_favorites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.document_favorites ENABLE ROW LEVEL SECURITY;

--
-- Name: document_file_text; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.document_file_text ENABLE ROW LEVEL SECURITY;

--
-- Name: document_file_text document_file_text_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY document_file_text_insert ON public.document_file_text FOR INSERT WITH CHECK (true);

--
-- Name: document_file_text document_file_text_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY document_file_text_select ON public.document_file_text FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = document_file_text.document_id))));

--
-- Name: document_file_text document_file_text_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY document_file_text_update ON public.document_file_text FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = document_file_text.document_id)))) WITH CHECK (true);

--
-- Name: document_file_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.document_file_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: document_files; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.document_files ENABLE ROW LEVEL SECURITY;

--
-- Name: document_files document_files_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY document_files_insert ON public.document_files FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE ((d.id = document_files.document_id) AND (d.author_id = public.app_user_id())))));

--
-- Name: document_files document_files_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY document_files_select ON public.document_files FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = document_files.document_id))));

--
-- Name: document_files document_files_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY document_files_update ON public.document_files FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE ((d.id = document_files.document_id) AND (d.author_id = public.app_user_id()))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE ((d.id = document_files.document_id) AND (d.author_id = public.app_user_id())))));

--
-- Name: document_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.document_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: documents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;

--
-- Name: documents documents_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY documents_delete ON public.documents FOR DELETE USING ((author_id = public.app_user_id()));

--
-- Name: documents documents_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY documents_insert ON public.documents FOR INSERT WITH CHECK ((author_id = public.app_user_id()));

--
-- Name: documents documents_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY documents_select ON public.documents FOR SELECT USING (public.app_can_see_document(id, author_id, author_department_id, outgoing_number));

--
-- Name: documents documents_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY documents_update ON public.documents FOR UPDATE USING (public.app_can_see_document(id, author_id, author_department_id, outgoing_number)) WITH CHECK (public.app_can_see_document(id, author_id, author_department_id, outgoing_number));

--
-- Name: document_favorites favorites_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY favorites_delete ON public.document_favorites FOR DELETE USING ((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint));

--
-- Name: document_favorites favorites_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY favorites_insert ON public.document_favorites FOR INSERT WITH CHECK (((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) AND (EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = document_favorites.document_id)))));

--
-- Name: document_favorites favorites_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY favorites_select ON public.document_favorites FOR SELECT USING ((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint));

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_delete ON public.notifications FOR DELETE USING (((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) OR ((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE)));

--
-- Name: notifications notifications_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_insert ON public.notifications FOR INSERT WITH CHECK (true);

--
-- Name: notifications notifications_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_select ON public.notifications FOR SELECT USING (((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) OR ((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE)));

--
-- Name: notifications notifications_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_update ON public.notifications FOR UPDATE USING (((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) OR ((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE))) WITH CHECK (((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) OR ((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE)));

--
-- Name: reassignments reassign_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY reassign_insert ON public.reassignments FOR INSERT WITH CHECK (true);

--
-- Name: reassignments reassign_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY reassign_select ON public.reassignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = reassignments.document_id))));

--
-- Name: reassignments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reassignments ENABLE ROW LEVEL SECURITY;

--
-- Name: resolution_executors res_exec_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY res_exec_insert ON public.resolution_executors FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.resolutions r
  WHERE (r.id = resolution_executors.resolution_id))));

--
-- Name: resolution_executors res_exec_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY res_exec_select ON public.resolution_executors FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.resolutions r
  WHERE (r.id = resolution_executors.resolution_id))));

--
-- Name: resolution_executors res_exec_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY res_exec_update ON public.resolution_executors FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.resolutions r
  WHERE (r.id = resolution_executors.resolution_id)))) WITH CHECK (true);

--
-- Name: resolution_executors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.resolution_executors ENABLE ROW LEVEL SECURITY;

--
-- Name: resolutions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.resolutions ENABLE ROW LEVEL SECURITY;

--
-- Name: resolutions resolutions_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY resolutions_insert ON public.resolutions FOR INSERT WITH CHECK (((author_id = public.app_user_id()) AND public.chief_scope_has(public.app_user_id(), department_id) AND (EXISTS ( SELECT 1
   FROM public.documents d
  WHERE (d.id = resolutions.document_id)))));

--
-- Name: resolutions resolutions_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY resolutions_select ON public.resolutions FOR SELECT USING (((author_id = ( SELECT public.app_user_id() AS app_user_id)) OR (controller_id = ( SELECT public.app_user_id() AS app_user_id)) OR (department_id IN ( SELECT public.app_resolution_departments() AS app_resolution_departments)) OR (id IN ( SELECT public.app_my_resolution_ids() AS app_my_resolution_ids)) OR ((document_id, department_id) IN ( SELECT dr.document_id,
    dr.recipient_department_id
   FROM public.document_recipients dr
  WHERE (dr.recipient_user_id = ( SELECT public.app_user_id() AS app_user_id)))) OR ( SELECT public.app_is_system() AS app_is_system)));

--
-- Name: resolutions resolutions_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY resolutions_update ON public.resolutions FOR UPDATE USING (((author_id = ( SELECT public.app_user_id() AS app_user_id)) OR (controller_id = ( SELECT public.app_user_id() AS app_user_id)) OR (department_id IN ( SELECT public.app_resolution_departments() AS app_resolution_departments)) OR (id IN ( SELECT public.app_my_resolution_ids() AS app_my_resolution_ids)) OR ((document_id, department_id) IN ( SELECT dr.document_id,
    dr.recipient_department_id
   FROM public.document_recipients dr
  WHERE (dr.recipient_user_id = ( SELECT public.app_user_id() AS app_user_id)))) OR ( SELECT public.app_is_system() AS app_is_system))) WITH CHECK (true);

--
-- Name: security_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;

--
-- Name: security_events security_events_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY security_events_insert ON public.security_events FOR INSERT WITH CHECK ((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint));

--
-- Name: security_events security_events_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY security_events_select ON public.security_events FOR SELECT USING (((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) OR ((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE)));

--
-- Name: user_sessions sessions_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sessions_delete ON public.user_sessions FOR DELETE USING (false);

--
-- Name: user_sessions sessions_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sessions_insert ON public.user_sessions FOR INSERT WITH CHECK (true);

--
-- Name: user_sessions sessions_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sessions_select ON public.user_sessions FOR SELECT USING (((user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) OR ((NULLIF(current_setting('app.is_admin'::text, true), ''::text))::boolean IS TRUE) OR (EXISTS ( SELECT 1
   FROM public.user_roles ur
  WHERE ((ur.user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) AND (ur.role = 'auditor'::public.role_code))))));

--
-- Name: user_sessions sessions_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sessions_update ON public.user_sessions FOR UPDATE USING (true);

--
-- Name: user_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;

--
--


SET search_path TO public;

-- ============================================================================
-- СПРАВОЧНЫЕ ДАННЫЕ (нужны для работы; не тестовые)
-- ============================================================================
INSERT INTO document_categories (id, name, code, is_active, sort_order, created_at, color) VALUES (1, 'Постоянные', 'permanent', true, 10, now(), '#2F6FEB');
INSERT INTO document_categories (id, name, code, is_active, sort_order, created_at, color) VALUES (2, 'Временные', 'temporary', true, 20, now(), '#B8860B');
INSERT INTO schema_version (version, applied_at, note) VALUES (1, now(), 'ИР «Афина»: первая версия схемы');
INSERT INTO special_marks (id, name, code, color, is_active, sort_order, created_at, is_default) VALUES (2, 'Лично', 'personal', NULL, true, 20, now(), false);
INSERT INTO special_marks (id, name, code, color, is_active, sort_order, created_at, is_default) VALUES (3, 'Срочная доставка', 'express', NULL, true, 30, now(), false);
INSERT INTO special_marks (id, name, code, color, is_active, sort_order, created_at, is_default) VALUES (1, 'Без особой отметки', 'none', NULL, true, 10, now(), true);
INSERT INTO system_settings (key, value, updated_at) VALUES ('marking.page_mode', '"first"', now());
ALTER SEQUENCE document_categories_id_seq RESTART WITH 3;
ALTER SEQUENCE special_marks_id_seq RESTART WITH 4;

-- ============================================================================
-- ПЕРВЫЙ АДМИНИСТРАТОР
-- ============================================================================
-- Локальная учётная запись admin с глобальной ролью «администратор». Пароль
-- задан параметром admin_password; смените его после первого входа.
-- Оргструктуру, пользователей, роли и домены (LDAP/Kerberos) администратор
-- заводит уже через веб-интерфейс.
INSERT INTO users (login, password_hash, full_name, position)
VALUES ('admin', crypt(current_setting('athena.admin_password'), gen_salt('bf', 12)),
        'Администратор системы', 'Администратор');
INSERT INTO user_roles (user_id, department_id, role)
SELECT id, NULL, 'admin'::role_code FROM users WHERE login = 'admin';

-- ============================================================================
-- РОЛЬ ПРИЛОЖЕНИЯ И ПРАВА
-- ============================================================================
DO $$
DECLARE
    v_role TEXT := current_setting('athena.app_role');
    v_pass TEXT := current_setting('athena.app_password');
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = v_role) THEN
        EXECUTE format('ALTER ROLE %I WITH LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE PASSWORD %L', v_role, v_pass);
    ELSE
        EXECUTE format('CREATE ROLE %I WITH LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE PASSWORD %L', v_role, v_pass);
    END IF;
    EXECUTE format('GRANT CONNECT ON DATABASE %I TO %I', current_database(), v_role);
    EXECUTE format('GRANT USAGE ON SCHEMA public TO %I', v_role);
    -- Только DML. DDL и владение объектами остаются у запускающего.
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO %I', v_role);
    EXECUTE format('GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO %I', v_role);
    EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO %I', v_role);
    EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO %I', v_role);

    -- Журнал аудита неизменяем: приложение может только добавлять и читать.
    -- Удаление за период — единственной функцией audit_purge (SECURITY DEFINER).
    EXECUTE format('REVOKE UPDATE, DELETE, TRUNCATE ON audit_log FROM %I', v_role);
    -- Подписи и история документа — юридически значимые следы: приложение
    -- их только добавляет (удаляются лишь каскадом вместе с черновиком).
    EXECUTE format('REVOKE UPDATE, DELETE, TRUNCATE ON document_signatures FROM %I', v_role);
    EXECUTE format('REVOKE UPDATE, DELETE, TRUNCATE ON document_history FROM %I', v_role);
    -- Версию схемы меняют только файлы миграций.
    EXECUTE format('REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON schema_version FROM %I', v_role);

    -- Функции с правами владельца не должны быть доступны кому попало.
    REVOKE EXECUTE ON FUNCTION audit_purge(date, date, bigint, text) FROM PUBLIC;
    REVOKE EXECUTE ON FUNCTION audit_log_bytes() FROM PUBLIC;
    REVOKE EXECUTE ON FUNCTION documents_count_by_status() FROM PUBLIC;
    EXECUTE format('GRANT EXECUTE ON FUNCTION audit_purge(date, date, bigint, text) TO %I', v_role);
    EXECUTE format('GRANT EXECUTE ON FUNCTION audit_log_bytes() TO %I', v_role);
    EXECUTE format('GRANT EXECUTE ON FUNCTION documents_count_by_status() TO %I', v_role);
END $$;

COMMIT;

\echo
\echo 'Готово: схема создана.'
\echo '  Роль приложения:' :app_role '(укажите её в database.url конфигурации)'
\echo '  Первый вход в веб-интерфейс: логин admin, пароль из параметра admin_password'
\echo '  Тестовые данные (необязательно): psql ... -f backend/sql/900_testdata.sql'
