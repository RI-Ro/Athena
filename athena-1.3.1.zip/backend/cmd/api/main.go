// Command athena — ИР «Афина»: контроль доведения и исполнения указаний.
//
// Один исполняемый файл: API, WebSocket, статика интерфейса, TLS. Схему БД
// создаёт администратор через psql (backend/sql), приложение её не меняет.
package main

import (
	"context"
	"flag"
	"log"
	"os"
	"strings"

	"athena/backend/internal/config"
	"athena/backend/internal/db"
	apphttp "athena/backend/internal/http"
	"athena/backend/internal/indexer"
	"athena/backend/internal/mailer"
	"athena/backend/internal/metrics"
	"athena/backend/internal/scheduler"
	"athena/backend/internal/service"
)

func main() {
	configPath := flag.String("config", "", "путь к файлу конфигурации (YAML)")
	flag.Parse()

	cfg, fileCfg := config.LoadWithFilePath(*configPath)
	checkConfig(cfg, fileCfg)

	// Prefork: главный процесс только запускает рабочие и следит за ними.
	if fileCfg.HTTP.Prefork && !isPreforkChild() {
		os.Exit(runPreforkMaster(fileCfg))
	}

	ctx, stop := context.WithCancel(context.Background())
	defer stop()

	pool, err := db.New(ctx, cfg.DatabaseURL, fileCfg.Database.MaxConns, fileCfg.Database.MinConns)
	if err != nil {
		log.Fatalf("подключение к БД: %v", err)
	}
	defer pool.Close()
	if err := db.CheckSchemaVersion(ctx, pool); err != nil {
		log.Fatalf("схема БД: %v", err)
	}
	// Разграничение доступа построено на RLS, а для суперпользователя и роли
	// с BYPASSRLS PostgreSQL его отключает — с такой ролью не запускаемся.
	if !db.WarnIfRLSBypassed(ctx, pool) && os.Getenv("ALLOW_RLS_BYPASS") != "1" {
		log.Fatalf("приложение подключено привилегированной ролью: разграничение доступа не действует. " +
			"Укажите в database.url роль athena_app (создаётся файлом backend/sql/000_init.sql)")
	}
	sysPool, err := db.NewSystem(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("подключение к БД (фоновые задачи): %v", err)
	}
	defer sysPool.Close()

	metrics.SetDBPool(pool)
	service.ConfigureAlarms(fileCfg.Notifications.AlarmKinds, fileCfg.Notifications.SnoozeMinutes,
		fileCfg.Notifications.RepeatSeconds)
	db.WarnIfLocaleCannotFoldCyrillic(ctx, pool)

	// Фоновые задачи. Все они берут работу из БД с блокировкой строк, поэтому
	// безопасно выполняются в каждом рабочем процессе prefork.
	indexer.New(sysPool, indexer.FromConfig(indexer.ConfigInput{
		Enabled:               fileCfg.Search.Enabled,
		BatchSize:             fileCfg.Search.BatchSize,
		IntervalSeconds:       fileCfg.Search.IntervalSeconds,
		MaxAttempts:           fileCfg.Search.MaxAttempts,
		ExtractCommand:        fileCfg.Search.ExtractCommand,
		ExtractTimeoutSeconds: fileCfg.Search.ExtractTimeoutSeconds,
		StaleAfterSeconds:     fileCfg.Search.StaleAfterSeconds,
		MaxTextBytes:          fileCfg.Search.MaxTextBytes,
		StoreText:             fileCfg.Search.StoreText,
	})).Start(ctx)

	sched := scheduler.New(sysPool, service.NewExecutionService())
	if fileCfg.Lifecycle.AutoArchiveExecutedNextYear {
		sched.StartAutoArchive(ctx)
	}
	sched.StartStageReminders(ctx, fileCfg.Approval.StageReminderDays)
	sched.StartHousekeeping(ctx)

	mailer.Configure(fileCfg.Email, fileCfg.Branding.AppName)
	mailer.Start(ctx, sysPool)

	app := apphttp.NewRouter(cfg, fileCfg, pool)

	if err := serve(ctx, app, cfg, fileCfg); err != nil {
		log.Fatalf("сервер: %v", err)
	}
	stop()
	log.Printf("остановлено")
}

// checkConfig останавливает запуск при небезопасной или противоречивой
// конфигурации — до открытия портов.
func checkConfig(cfg config.Config, fc config.FileConfig) {
	var problems []string
	if strings.EqualFold(cfg.JWTSecret, "change-me-in-production") || len(cfg.JWTSecret) < 16 {
		problems = append(problems, "auth.jwt_secret: задайте собственный секрет не короче 16 знаков "+
			"(значение по умолчанию известно всем; после смены секрета пользователи войдут заново)")
	}
	if len(fc.Signing.Secret) < 16 {
		problems = append(problems, "signing.secret: задайте секрет простой электронной подписи не короче 16 знаков "+
			"(им подписываются документы; храните его копию отдельно от БД)")
	}
	if fc.Signing.Secret != "" && fc.Signing.Secret == cfg.JWTSecret {
		problems = append(problems, "signing.secret и auth.jwt_secret должны быть разными")
	}
	if fc.HTTP.Prefork && fc.Realtime.RedisAddr == "" {
		problems = append(problems, "http.prefork: true требует realtime.redis_addr — рабочие процессы "+
			"обмениваются событиями (уведомления, обсуждение) только через Redis")
	}
	if fc.Email.Enabled {
		if fc.Email.SMTP.Host == "" || fc.Email.SMTP.From == "" {
			problems = append(problems, "email.enabled: true требует email.smtp.host и email.smtp.from")
		}
		if fc.Email.PublicURL == "" {
			problems = append(problems, "email.enabled: true требует email.public_url (адрес системы для ссылок в письмах)")
		}
	}
	if len(problems) > 0 {
		log.Fatalf("конфигурация не позволяет запустить приложение:\n  - %s", strings.Join(problems, "\n  - "))
	}
}
