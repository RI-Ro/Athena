package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"runtime"
	"strings"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"

	"athena/backend/internal/config"
)

// serve открывает порты приложения. Отдельный веб-сервер перед приложением
// не нужен: TLS, перенаправление на HTTPS и статику обслуживает оно само.
//
// Без сертификатов:
//
//	http.addr          — приложение, вход по паролю (HTTP)
//	http.kerberos_addr — приложение, вход по Kerberos (HTTP), если задан
//
// С сертификатами (http.tls.cert_file + key_file):
//
//	http.addr          — ТОЛЬКО перенаправление 308 на HTTPS
//	http.https_addr    — приложение, вход по паролю (HTTPS)
//	http.kerberos_addr — приложение, вход по Kerberos (HTTPS), если задан
//
// Оба порта приложения обслуживает один и тот же экземпляр; режим входа
// определяется по порту, на который пришёл запрос (middleware.AuthMode).
//
// По сигналу SIGINT/SIGTERM сервер перестаёт принимать новые соединения и
// даёт начатым запросам до 15 секунд на завершение.
func serve(ctx context.Context, app *fiber.App, cfg config.Config, fc config.FileConfig) error {
	var tlsCfg *tls.Config
	if fc.TLSEnabled() {
		cert, err := tls.LoadX509KeyPair(fc.HTTP.TLS.CertFile, fc.HTTP.TLS.KeyFile)
		if err != nil {
			return fmt.Errorf("сертификат TLS (%s, %s): %w", fc.HTTP.TLS.CertFile, fc.HTTP.TLS.KeyFile, err)
		}
		tlsCfg = &tls.Config{
			MinVersion:   tls.VersionTLS12,
			Certificates: []tls.Certificate{cert},
			NextProtos:   []string{"http/1.1"}, // fasthttp не поддерживает HTTP/2
		}
	} else if fc.HTTP.TLS.CertFile != "" || fc.HTTP.TLS.KeyFile != "" {
		return fmt.Errorf("для HTTPS нужны ОБА файла: http.tls.cert_file и http.tls.key_file")
	}

	child := isPreforkChild()
	listenPlain := func(addr string) (net.Listener, error) {
		lc := net.ListenConfig{}
		if child {
			// Рабочие процессы prefork слушают один и тот же порт; ядро
			// распределяет между ними входящие соединения.
			lc.Control = reusePortControl
		}
		ln, err := lc.Listen(context.Background(), "tcp", addr)
		if err != nil {
			return nil, fmt.Errorf("порт %s: %w", addr, err)
		}
		return ln, nil
	}
	listen := func(addr string) (net.Listener, error) {
		ln, err := listenPlain(addr)
		if err != nil {
			return nil, err
		}
		if tlsCfg != nil {
			return tls.NewListener(ln, tlsCfg), nil
		}
		return ln, nil
	}

	passwordAddr := cfg.HTTPAddr
	if tlsCfg != nil {
		passwordAddr = fc.HTTP.HTTPSAddr
	}
	if fc.HTTP.KerberosAddr != "" && portOf(fc.HTTP.KerberosAddr) == portOf(passwordAddr) {
		return fmt.Errorf("вход по Kerberos и вход по паролю должны быть на РАЗНЫХ портах (сейчас оба %s)", passwordAddr)
	}

	errc := make(chan error, 3)
	scheme := "http"
	var redirectSrv *http.Server
	if tlsCfg != nil {
		scheme = "https"
		rln, err := listenPlain(cfg.HTTPAddr)
		if err != nil {
			return err
		}
		redirectSrv = redirectServer(fc.HTTP.HTTPSAddr, fc.HTTP.PublicHost)
		go func() {
			if err := redirectSrv.Serve(rln); err != nil && err != http.ErrServerClosed {
				errc <- err
			}
		}()
		logOnce(child, "перенаправление http %s → https %s", cfg.HTTPAddr, fc.HTTP.HTTPSAddr)
	}

	pln, err := listen(passwordAddr)
	if err != nil {
		return err
	}
	logOnce(child, "вход по паролю (локальные учётные записи и LDAP): %s://%s", scheme, passwordAddr)
	go func() { errc <- app.Listener(pln) }()

	if fc.HTTP.KerberosAddr != "" {
		kln, err := listen(fc.HTTP.KerberosAddr)
		if err != nil {
			return err
		}
		logOnce(child, "вход по Kerberos (SPNEGO): %s://%s", scheme, fc.HTTP.KerberosAddr)
		go func() { errc <- app.Listener(kln) }()
	} else {
		logOnce(child, "вход по Kerberos выключен (http.kerberos_addr пуст)")
	}

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	select {
	case err := <-errc:
		return err
	case s := <-sig:
		log.Printf("получен сигнал %s — завершаем начатые запросы", s)
	case <-ctx.Done():
	}
	if redirectSrv != nil {
		sctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = redirectSrv.Shutdown(sctx)
		cancel()
	}
	return app.ShutdownWithTimeout(15 * time.Second)
}

func logOnce(child bool, format string, args ...any) {
	// В режиме prefork одинаковые строки от каждого рабочего процесса только
	// засоряют журнал — о портах сообщает главный процесс.
	if !child {
		log.Printf(format, args...)
	}
}

func portOf(addr string) string {
	if _, p, err := net.SplitHostPort(addr); err == nil {
		return p
	}
	return strings.TrimPrefix(addr, ":")
}

// redirectServer — HTTP-сервер, который на любой запрос отвечает
// перенаправлением на тот же путь по HTTPS. 308 сохраняет метод и тело.
func redirectServer(httpsAddr, publicHost string) *http.Server {
	httpsPort := portOf(httpsAddr)
	return &http.Server{
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      10 * time.Second,
		Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			host := publicHost
			if host == "" {
				host = r.Host
				if h, _, err := net.SplitHostPort(host); err == nil {
					host = h
				}
			}
			// Имя узла попадает в Location: не даём подставить туда мусор.
			if host == "" || strings.ContainsAny(host, "/\\@ \t\r\n") {
				http.Error(w, "bad host", http.StatusBadRequest)
				return
			}
			target := "https://" + host
			if strings.Contains(host, ":") && !strings.HasPrefix(host, "[") {
				target = "https://[" + host + "]" // IPv6 без скобок
			}
			if httpsPort != "443" {
				target += ":" + httpsPort
			}
			w.Header().Set("Connection", "close")
			http.Redirect(w, r, target+r.URL.RequestURI(), http.StatusPermanentRedirect)
		}),
	}
}

// ---------------------------------------------------------------------------
// Prefork
// ---------------------------------------------------------------------------
//
// http.prefork: true — главный процесс запускает несколько рабочих процессов
// (http.prefork_processes, по умолчанию по числу ядер). Каждый рабочий —
// полноценное приложение со своим пулом соединений к БД; все слушают одни и
// те же порты (SO_REUSEPORT). Состояние, общее для процессов, хранится в БД
// (сессии, счётчики неудачных входов, предъявленные билеты Kerberos, очередь
// писем, очередь индексации); события реального времени между процессами
// передаёт Redis — поэтому для prefork обязателен realtime.redis_addr.
//
// Собственная реализация вместо fiber.Config.Prefork нужна потому, что
// встроенная работает только с одним портом, а у приложения их до трёх.

const preforkChildEnv = "ATHENA_PREFORK_CHILD"

func isPreforkChild() bool { return os.Getenv(preforkChildEnv) != "" }

func runPreforkMaster(fc config.FileConfig) int {
	n := fc.HTTP.PreforkProcesses
	if n <= 0 {
		n = runtime.NumCPU()
	}
	if runtime.GOOS == "windows" {
		log.Printf("prefork не поддерживается в Windows")
		return 1
	}
	log.Printf("prefork: запускаем рабочих процессов: %d (у каждого свой пул БД до %d соединений — "+
		"всего до %d; сверьте с max_connections PostgreSQL)", n, fc.Database.MaxConns+3, n*int(fc.Database.MaxConns+3))
	children := make([]*exec.Cmd, 0, n)
	exited := make(chan int, n)
	for i := 0; i < n; i++ {
		cmd := exec.Command(os.Args[0], os.Args[1:]...)
		cmd.Env = append(os.Environ(), fmt.Sprintf("%s=%d", preforkChildEnv, i+1))
		cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
		if err := cmd.Start(); err != nil {
			log.Printf("prefork: не удалось запустить рабочий процесс: %v", err)
			for _, c := range children {
				_ = c.Process.Signal(syscall.SIGTERM)
			}
			return 1
		}
		children = append(children, cmd)
		go func(i int, c *exec.Cmd) { _ = c.Wait(); exited <- i }(i, cmd)
	}
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	code := 0
	select {
	case s := <-sig:
		log.Printf("prefork: сигнал %s — останавливаем рабочие процессы", s)
	case i := <-exited:
		// Один рабочий завершился сам — это отказ; останавливаем остальных,
		// чтобы служба перезапустила приложение целиком (systemd Restart=).
		log.Printf("prefork: рабочий процесс №%d завершился — останавливаем приложение", i+1)
		code = 1
	}
	for _, c := range children {
		_ = c.Process.Signal(syscall.SIGTERM)
	}
	deadline := time.After(20 * time.Second)
	for range children[:len(children)-code] {
		select {
		case <-exited:
		case <-deadline:
			for _, c := range children {
				_ = c.Process.Kill()
			}
			return 1
		}
	}
	return code
}
