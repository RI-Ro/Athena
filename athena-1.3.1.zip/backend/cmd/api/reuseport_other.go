//go:build !unix

package main

import "syscall"

// reusePortControl: prefork доступен только в Unix-системах.
func reusePortControl(_, _ string, _ syscall.RawConn) error { return nil }
