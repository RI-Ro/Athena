import { cva } from "class-variance-authority";

/**
 * Минимальный buttonVariants для компонентов Kokonut UI (они импортируют его
 * из shadcn). Цвета берутся из токенов тем система, а не из shadcn-палитры, чтобы
 * кнопка выглядела так же, как .btn-primary / .btn-secondary из index.css.
 */
export const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium whitespace-nowrap select-none disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-accent text-accent-contrast hover:opacity-90",
        outline: "border border-border text-text-primary hover:bg-surface-alt",
        ghost: "text-text-secondary hover:bg-surface-alt hover:text-text-primary",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 px-3",
        lg: "h-10 px-6",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  }
);
