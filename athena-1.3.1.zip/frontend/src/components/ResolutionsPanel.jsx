import React, { useCallback, useEffect, useState } from 'react'
import Icon from './Icon'
import PersonPicker from './PersonPicker'
import { api } from '../api/client'
import { fmtDateTime } from '../utils/format'

// Резолюции руководителя (, п. 3) — заменили поручения.
//
// Жизненный цикл, который должен быть виден в интерфейсе:
//
//   руководитель НАЛОЖИЛ резолюцию
//      -> исполнитель взял в работу
//      -> исполнитель ОТЧИТАЛСЯ
//      -> автор резолюции ПРИНЯЛ отчёт либо ВЕРНУЛ на доработку
//      -> когда приняты отчёты всех исполнителей, резолюция исполнена
//
// Главное отличие от прежнего поручения: закрывает резолюцию АВТОР, а не
// исполнитель. Поэтому кнопки «Принять отчёт» и «Вернуть» видит автор, а
// «Отчитаться» — исполнитель, и перепутать их нельзя.
//
// Дерево: резолюция нижестоящего руководителя показывается с отступом под
// родительской. Без этого непонятно, во исполнение чего она дана.

const STATUS_COLOR = {
  issued: 'text-text-secondary',
  in_progress: 'text-accent-2',
  on_report: 'text-warning',
  done: 'text-success',
  cancelled: 'text-text-secondary line-through',
}

function fmt(v) {
  if (!v) return ''
  try {
    return fmtDateTime(v)
  } catch {
    return String(v)
  }
}

function fmtDate(v) {
  if (!v) return '—'
  const d = new Date(v)
  return Number.isNaN(d.getTime()) ? v : d.toLocaleDateString('ru-RU')
}

// myReport — мой собственный текст отчёта по резолюции, если он уже есть.
// Нужен, чтобы при повторном открытии окна отчёта поле не было пустым:
// исправляют обычно пару слов, а не пишут заново.
function myReportOf(r, currentUserId) {
  const mine = (r.executors || []).find((e) => String(e.user_id) === String(currentUserId))
  return mine?.report || ''
}

// Резолюция накладывается на ЭКЗЕМПЛЯР входящего документа — отдельно в
// каждом подразделении-адресате. Сервер отдаёт только те резолюции, которые
// человеку положено видеть (своего подразделения), и готовые флаги действий.
export default function ResolutionsPanel({ documentId, currentUserId, onChanged }) {
  const [items, setItems] = useState(null)
  const [canIssue, setCanIssue] = useState(false)
  const [cancelFor, setCancelFor] = useState(null)
  const [reassignFor, setReassignFor] = useState(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  // Форма: либо новая резолюция по документу (parent=null), либо дочерняя.
  const [form, setForm] = useState(null)
  const [reportFor, setReportFor] = useState(null)
  // п. 5 — окна «закрыть без отчёта» и «вернуть на доработку». Прежде возврат
  // спрашивал причину через prompt(): браузерное окно нельзя оформить, в нём
  // не видно текста резолюции, а в части браузеров оно и вовсе отключено.
  const [closeFor, setCloseFor] = useState(null)
  const [returnFor, setReturnFor] = useState(null)

  const load = useCallback(() => {
    api
      .listResolutions(documentId)
      .then((r) => {
        setItems(r.items || [])
        setCanIssue(!!r.can_issue)
      })
      .catch((e) => setError(e.message || 'Не удалось загрузить резолюции'))
  }, [documentId])

  useEffect(() => {
    load()
  }, [load])

  const act = async (fn) => {
    setBusy(true)
    setError('')
    try {
      await fn()
      load()
      onChanged?.()
    } catch (e) {
      setError(e.message || 'Не удалось выполнить действие')
    } finally {
      setBusy(false)
    }
  }

  if (items === null) {
    return <div className="text-sm text-text-secondary">Загрузка…</div>
  }

  const myReport = (r) => myReportOf(r, currentUserId)

  const renderNode = (r) => {
    const closed = r.status === 'done' || r.status === 'cancelled'

    return (
      <div key={r.id} className="mb-2">
        <div
          className={`border rounded-md p-3 ${
            r.overdue ? 'border-danger/50 bg-danger/5' : 'border-border'
          }`}
        >
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              {r.department_name && (
                <div className="text-[11px] text-text-secondary mb-0.5">Экземпляр: {r.department_name}</div>
              )}
              <div className="text-sm whitespace-pre-wrap">{r.text}</div>
              <div className="kicker mt-1">
                {r.author_name}
                {r.author_position ? `, ${r.author_position}` : ''} · {fmt(r.created_at)}
                {r.due_date && (
                  <>
                    {' · срок '}
                    <span className={r.overdue ? 'text-danger font-medium' : ''}>
                      {fmtDate(r.due_date)}
                    </span>
                  </>
                )}
                {r.on_control && ' · на контроле'}
                {r.controller_name && ` (контролёр: ${r.controller_name})`}
              </div>
            </div>
            <span className={`text-xs whitespace-nowrap ${STATUS_COLOR[r.status] || ''}`}>
              {r.status_label}
            </span>
          </div>

          {/* Исполнители со своими состояниями: по резолюции с несколькими
              исполнителями без этого не видно, кто уже отчитался. */}
          <ul className="mt-2 space-y-1">
            {(r.executors || []).map((e) => (
              <li key={e.id} className="text-xs flex items-start gap-2">
                <Icon
                  name={e.is_responsible ? 'tab-resolution' : 'tab-recipients'}
                  size={12}
                  className="mt-0.5 shrink-0"
                  style={{
                    color:
                      e.status === 'accepted'
                        ? 'var(--color-success)'
                        : e.status === 'returned'
                          ? 'var(--color-danger)'
                          : 'var(--color-text-secondary)',
                  }}
                />
                <span className="flex-1 min-w-0">
                  <span className={e.status === 'cancelled' ? 'line-through opacity-60' : ''}>
                    {e.full_name}
                  </span>
                  {e.is_responsible && <span className="text-text-secondary"> — ответственный</span>}
                  <span className="text-text-secondary"> · {e.status_label}</span>
                  {e.reassigned_from_name && (
                    <span className="text-text-secondary"> (передано от {e.reassigned_from_name})</span>
                  )}
                  {e.report && (
                    <div className="text-text-secondary mt-0.5">
                      Отчёт: {e.report}
                      {e.reported_at && ` (${fmt(e.reported_at)})`}
                    </div>
                  )}
                  {e.return_note && (
                    <div className="text-danger mt-0.5">На доработку: {e.return_note}</div>
                  )}
                </span>
              </li>
            ))}
          </ul>

          {/* Кнопки — строго по флагам сервера (п. 5). Никаких условий,
              вычисленных здесь: именно самодельные условия и приводили к
              тому, что действие было разрешено, а кнопки не было. */}
          <div className="mt-2 flex flex-wrap gap-1.5">
            {r.can_progress && (
              <button
                disabled={busy}
                onClick={() => act(() => api.resolutionProgress(r.id))}
                className="btn btn-secondary text-xs py-1"
              >
                Взять в работу
              </button>
            )}
            {r.can_report && (
              <button
                disabled={busy}
                onClick={() => setReportFor({ id: r.id, text: myReport(r) })}
                className="btn btn-primary text-xs py-1"
              >
                {myReport(r) ? 'Изменить отчёт' : 'Отчитаться'}
              </button>
            )}
            {r.can_accept && (
              <button
                disabled={busy}
                onClick={() => act(() => api.resolutionAccept(r.id, {}))}
                className="btn text-xs py-1 bg-success text-white"
              >
                Принять отчёт
              </button>
            )}
            {/* п. 5 — закрытие резолюции БЕЗ отчёта исполнителя. Отдельная
                кнопка с отдельным текстом: это не «принять отчёт», а решение
                руководителя, и заключение по нему обязательно. */}
            {r.can_close && (
              <button
                disabled={busy}
                onClick={() => setCloseFor({ id: r.id, text: '' })}
                className="btn btn-secondary text-xs py-1"
              >
                Исполнено, закрыть
              </button>
            )}
            {r.can_return && (
              <button
                disabled={busy}
                onClick={() => setReturnFor({ id: r.id, text: '' })}
                className="btn btn-secondary text-xs py-1"
              >
                Вернуть на доработку
              </button>
            )}
            {r.can_reassign && (
              <button
                disabled={busy}
                onClick={() => setReassignFor({ id: r.id, executors: r.executors || [], from: '', to: [], reason: '' })}
                className="btn btn-secondary text-xs py-1"
              >
                Заменить исполнителя
              </button>
            )}
            {r.can_cancel && (
              <button
                disabled={busy}
                onClick={() => setCancelFor({ id: r.id, text: '' })}
                className="btn btn-secondary text-xs py-1 text-danger"
              >
                Отозвать
              </button>
            )}
          </div>
          {/* Если по незакрытой резолюции у человека нет ни одной кнопки — он
              здесь просто наблюдатель, и сказать об этом лучше, чем оставить
              пустое место, в котором он будет искать пропавшую кнопку. */}
          {!closed && !r.can_progress && !r.can_report && !r.can_accept && !r.can_close
            && !r.can_return && !r.can_cancel && !r.can_reassign && (
            <div className="mt-2 text-[11px] text-text-secondary">
              По этой резолюции действия от вас не требуются.
            </div>
          )}

          {r.close_note && (
            <div className="mt-2 text-xs text-text-secondary">Заключение: {r.close_note}</div>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {error && <div className="text-danger text-xs">{error}</div>}

      {items.length === 0 && (
        <div className="text-sm text-text-secondary">Резолюций по документу нет.</div>
      )}
      {items.map((r) => renderNode(r))}

      {canIssue && (
        <button
          onClick={() => setForm({ text: '', due_date: '', co: [], resp: [] })}
          className="btn btn-primary text-sm"
        >
          Наложить резолюцию
        </button>
      )}

      {form && (
        <ResolutionForm
          documentId={documentId}
          form={form}
          setForm={setForm}
          currentUserId={currentUserId}
          onSaved={() => {
            setForm(null)
            load()
            onChanged?.()
          }}
        />
      )}

      {cancelFor && (
        <Modal title="Отзыв резолюции" onClose={() => setCancelFor(null)}>
          <p className="text-xs text-text-secondary mb-2">
            Резолюция останется в карточке со статусом «Отменена» и причиной. После отзыва на этот
            экземпляр документа можно наложить новую резолюцию.
          </p>
          <textarea
            value={cancelFor.text}
            onChange={(e) => setCancelFor({ ...cancelFor, text: e.target.value })}
            rows={3}
            className="field w-full"
            placeholder="Причина отзыва (обязательно)"
          />
          <div className="flex justify-end gap-2 mt-3">
            <button className="btn btn-secondary" onClick={() => setCancelFor(null)}>Не отзывать</button>
            <button
              className="btn btn-primary"
              disabled={busy || !cancelFor.text.trim()}
              onClick={() =>
                act(() => api.resolutionCancel(cancelFor.id, cancelFor.text.trim())).then(() => setCancelFor(null))
              }
            >
              Отозвать резолюцию
            </button>
          </div>
        </Modal>
      )}

      {reassignFor && (
        <Modal title="Замена исполнителя" onClose={() => setReassignFor(null)}>
          <label className="block text-xs text-text-secondary mb-1">Кого заменить</label>
          <select
            className="field w-full mb-3"
            value={reassignFor.from}
            onChange={(e) => setReassignFor({ ...reassignFor, from: e.target.value })}
          >
            <option value="">— выберите исполнителя —</option>
            {reassignFor.executors
              .filter((e) => e.status !== 'accepted' && e.status !== 'cancelled')
              .map((e) => (
                <option key={e.user_id} value={e.user_id}>
                  {e.full_name}{e.is_responsible ? ' — ответственный' : ''}
                </option>
              ))}
          </select>
          <label className="block text-xs text-text-secondary mb-1">На кого</label>
          <PersonPicker
            group="resolution"
            multiple={false}
            value={reassignFor.to}
            onChange={(v) => setReassignFor({ ...reassignFor, to: v })}
            excludeIds={[
              ...(currentUserId ? [currentUserId] : []),
              ...reassignFor.executors.filter((e) => e.status !== 'cancelled').map((e) => e.user_id),
            ]}
          />
          <label className="block text-xs text-text-secondary mb-1 mt-3">Причина замены</label>
          <textarea
            value={reassignFor.reason}
            onChange={(e) => setReassignFor({ ...reassignFor, reason: e.target.value })}
            rows={2}
            className="field w-full"
            placeholder="Например: исполнитель в отпуске"
          />
          <div className="flex justify-end gap-2 mt-3">
            <button className="btn btn-secondary" onClick={() => setReassignFor(null)}>Отмена</button>
            <button
              className="btn btn-primary"
              disabled={busy || !reassignFor.from || !reassignFor.to[0] || !reassignFor.reason.trim()}
              onClick={() =>
                act(() =>
                  api.resolutionReassign(reassignFor.id, {
                    from_user_id: Number(reassignFor.from),
                    to_user_id: reassignFor.to[0].id,
                    reason: reassignFor.reason.trim(),
                  }),
                ).then(() => setReassignFor(null))
              }
            >
              Заменить
            </button>
          </div>
        </Modal>
      )}

      {reportFor && (
        <Modal title="Отчёт об исполнении" onClose={() => setReportFor(null)}>
          <p className="text-xs text-text-secondary mb-2">
            Напишите, что сделано. Отчёт увидит автор резолюции: он примет его
            или вернёт на доработку. Пустой отчёт не принимается.
          </p>
          <textarea
            value={reportFor.text}
            onChange={(e) => setReportFor({ ...reportFor, text: e.target.value })}
            rows={5}
            className="field w-full"
            placeholder="Например: подготовлена справка исх. № 12/44 от 10.10.2026, направлена в адрес…"
          />
          <div className="flex justify-end gap-2 mt-3">
            <button className="btn btn-secondary" onClick={() => setReportFor(null)}>
              Отмена
            </button>
            <button
              className="btn btn-primary"
              disabled={busy || !reportFor.text.trim()}
              onClick={() =>
                act(() => api.resolutionReport(reportFor.id, reportFor.text.trim())).then(() =>
                  setReportFor(null)
                )
              }
            >
              Отправить отчёт
            </button>
          </div>
        </Modal>
      )}

      {/* п. 5 — закрытие резолюции по решению руководителя, без отчёта
          исполнителя. Заключение обязательно: в резолюции не останется ни
          отчёта, ни причины, и через месяц будет непонятно, на каком
          основании она исполнена. Это же требование проверяет сервер. */}
      {closeFor && (
        <Modal title="Закрыть резолюцию без отчёта" onClose={() => setCloseFor(null)}>
          <p className="text-xs text-text-secondary mb-2">
            Исполнитель отчёт не представил. Если результат вам известен иначе — доложили
            лично, исполнитель в отпуске, работа отменена, — напишите заключение: оно
            встанет на место отчёта и попадёт в отчёт по документу.
          </p>
          <textarea
            value={closeFor.text}
            onChange={(e) => setCloseFor({ ...closeFor, text: e.target.value })}
            rows={4}
            className="field w-full"
            placeholder="Например: «исполнено, доложено на совещании 14.10.2026»"
          />
          <div className="flex justify-end gap-2 mt-3">
            <button className="btn btn-secondary" onClick={() => setCloseFor(null)}>
              Отмена
            </button>
            <button
              className="btn btn-primary"
              disabled={busy || !closeFor.text.trim()}
              onClick={() =>
                act(() => api.resolutionAccept(closeFor.id, { force: true, note: closeFor.text.trim() }))
                  .then(() => setCloseFor(null))
              }
            >
              Закрыть резолюцию
            </button>
          </div>
        </Modal>
      )}

      {returnFor && (
        <Modal title="Вернуть на доработку" onClose={() => setReturnFor(null)}>
          <p className="text-xs text-text-secondary mb-2">
            Напишите, что требуется доработать. Без этого исполнитель не знает, что
            переделывать, и вернёт то же самое — поэтому поле обязательное.
          </p>
          <textarea
            value={returnFor.text}
            onChange={(e) => setReturnFor({ ...returnFor, text: e.target.value })}
            rows={4}
            className="field w-full"
            placeholder="Например: «в отчёте нет исходящего номера направленного ответа»"
          />
          <div className="flex justify-end gap-2 mt-3">
            <button className="btn btn-secondary" onClick={() => setReturnFor(null)}>
              Отмена
            </button>
            <button
              className="btn btn-primary"
              disabled={busy || !returnFor.text.trim()}
              onClick={() =>
                act(() => api.resolutionReturn(returnFor.id, { note: returnFor.text.trim() }))
                  .then(() => setReturnFor(null))
              }
            >
              Вернуть
            </button>
          </div>
        </Modal>
      )}

    </div>
  )
}

// ResolutionForm — наложение резолюции.
function ResolutionForm({ documentId, form, setForm, currentUserId, onSaved }) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const submit = async () => {
    if (!form.text.trim()) {
      setError('Укажите текст резолюции')
      return
    }
    if (!form.resp[0]?.id) {
      setError('Укажите ответственного исполнителя')
      return
    }
    setBusy(true)
    setError('')
    try {
      await api.createResolution(documentId, {
        text: form.text.trim(),
        due_date: form.due_date || '',
        on_control: !!form.on_control,
        responsible_id: form.resp[0].id,
        co_executor_ids: (form.co || []).map((x) => x.id),
      })
      onSaved()
    } catch (e) {
      setError(e.message || 'Не удалось наложить резолюцию')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal
      title="Резолюция руководителя"
      onClose={() => setForm(null)}
    >
      {error && <div className="text-danger text-xs mb-2">{error}</div>}
      <label className="block text-xs text-text-secondary mb-1">Текст резолюции</label>
      <textarea
        value={form.text}
        onChange={(e) => setForm({ ...form, text: e.target.value })}
        rows={3}
        className="field w-full"
        placeholder="Например: Исполнить. О результатах доложить."
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
        <div>
          <label className="block text-xs text-text-secondary mb-1">
            Ответственный исполнитель
          </label>
          <PersonPicker
            group="resolution"
            multiple={false}
            value={form.resp}
            onChange={(v) => setForm({ ...form, resp: v })}
            excludeIds={currentUserId ? [currentUserId] : []}
          />
        </div>
        <div>
          <label className="block text-xs text-text-secondary mb-1">
            Соисполнители (необязательно)
          </label>
          <PersonPicker
            group="resolution"
            value={form.co}
            onChange={(v) => setForm({ ...form, co: v })}
            excludeIds={[
              ...(currentUserId ? [currentUserId] : []),
              ...(form.resp[0] ? [form.resp[0].id] : []),
            ]}
          />
        </div>
        <div>
          <label className="block text-xs text-text-secondary mb-1">Срок исполнения</label>
          <input
            type="date"
            value={form.due_date}
            onChange={(e) => setForm({ ...form, due_date: e.target.value })}
            className="field w-full"
          />
        </div>
        <div className="flex items-end">
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={!!form.on_control}
              onChange={(e) => setForm({ ...form, on_control: e.target.checked })}
            />
            Поставить на контроль
          </label>
        </div>
      </div>
      <div className="flex justify-end gap-2 mt-4">
        <button className="btn btn-secondary" onClick={() => setForm(null)}>
          Отмена
        </button>
        <button className="btn btn-primary" disabled={busy} onClick={submit}>
          {busy ? 'Сохранение…' : 'Наложить'}
        </button>
      </div>
    </Modal>
  )
}

// Modal — общая обёртка окна. Заведена здесь, а не импортируется: в проекте
// нет единого компонента окна, а плодить ещё один общий модуль ради трёх
// использований в одном файле незачем.
function Modal({ title, children, onClose }) {
  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="surface-1 w-full max-w-xl max-h-[85vh] overflow-auto shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-3 border-b border-border sticky top-0 bg-surface">
          <h3 className="font-display text-base font-semibold">{title}</h3>
          <button onClick={onClose} className="text-text-secondary hover:text-text-primary">
            <Icon name="close" size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  )
}
