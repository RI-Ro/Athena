import React, { useEffect, useRef, useState } from 'react'
import Icon from './Icon'
import DocumentViewer from './DocumentViewer'

// #32 — ПРЕДПРОСМОТР ФАЙЛА ДО СОХРАНЕНИЯ.
//
// Раньше выбранный PDF никак не показывался: пользователь узнавал, что
// приложил не тот файл или не ту его версию, только после создания документа —
// а документ уже ушёл на согласование, и исправлять приходилось заменой файла
// со сбросом маршрута.
//
// Здесь файл открывается прямо из браузера, не загружаясь на сервер: из File
// файл показывается ТЕМ ЖЕ защищённым просмотрщиком, что и карточка документа
// (DocumentViewer с prop file).
//
// Сначала здесь стоял <object data=blob-url>, то есть встроенный просмотрщик
// браузера. У него своя панель — «скачать», «печать», «открыть в новой
// вкладке», — и для документа система это недопустимо: обойти учёт экземпляров и
// маркировку можно было прямо из окна предпросмотра. Просить «не нажимать»
// бессмысленно, поэтому панели просто нет: pdf.js рисует страницы на canvas,
// никаких кнопок браузера не появляется.
//
// Заодно исчезла нужда в blob-URL: просмотрщик принимает сам объект File,
// поэтому нечего и освобождать (прежняя версия обязана была вызывать
// revokeObjectURL, иначе каждый выбор файла оставлял копию PDF в памяти
// вкладки до её закрытия).
function FilePreview({ file, className = '' }) {
  const [open, setOpen] = useState(false)

  // Новый файл — сворачиваем предпросмотр: пользователь сам решит смотреть.
  // blob-URL здесь больше не создаётся: просмотрщик получает сам объект File,
  // поэтому и освобождать нечего — прежняя версия обязана была вызывать
  // revokeObjectURL, иначе каждый выбор файла оставлял бы копию PDF в памяти
  // вкладки до её закрытия.
  useEffect(() => {
    setOpen(false)
  }, [file])

  if (!file) return null

  const sizeMB = file.size / (1024 * 1024)
  const isPDF = file.type === 'application/pdf' || /\.pdf$/i.test(file.name)

  return (
    <div className={`mt-2 border border-border rounded-md ${className}`}>
      <div className="flex items-center gap-2 px-2 py-1.5 text-xs">
        <Icon name="paperclip" size={14} />
        <span className="truncate flex-1" title={file.name}>
          {file.name}
        </span>
        <span className="text-text-secondary whitespace-nowrap">
          {sizeMB < 0.1 ? `${Math.max(1, Math.round(file.size / 1024))} КБ` : `${sizeMB.toFixed(1)} МБ`}
        </span>
        {isPDF && (
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="text-accent whitespace-nowrap"
          >
            {open ? 'Скрыть' : 'Посмотреть'}
          </button>
        )}
      </div>

      {/* Не-PDF до сервера не доходит (бэкенд принимает только PDF), поэтому
          предупреждаем здесь, пока ошибку легко исправить. */}
      {!isPDF && (
        <div className="px-2 pb-1.5 text-[11px] text-danger">
          Это не PDF — документ принимается только в формате PDF.
        </div>
      )}

      {open && isPDF && (
        <div className="border-t border-border h-96">
          {/* Тот же защищённый просмотрщик, что и в карточке документа: без
              панели браузера, без кнопок «скачать» и «печать». Файл ещё не на
              сервере, поэтому передаётся объектом, а не идентификатором. */}
          <DocumentViewer file={file} />
        </div>
      )}
    </div>
  )
}

// Обёрнут в React.memo намеренно.
//
// Этот компонент стоит в формах рядом с текстовыми полями. Без memo он
// перерисовывался при вводе КАЖДОЙ буквы в соседнем поле — форма создания
// документа из-за этого заметно подтормаживала. Свойства здесь стабильные:
// value — состояние родителя, onChange — setState, excludeIds — запомненный
// массив, поэтому memo действительно отсекает лишние перерисовки.
export default React.memo(FilePreview)
