import React, { useEffect, useState } from 'react'
import Icon from './Icon'
import { api } from '../api/client'
import { fmtDateTime } from '../utils/format'

// Версии карточки и вложений.
//
// ЧТО ИЗМЕНИЛОСЬ В v52:
//
//   п. 6 — «версию карточки показывать только исполнителю. Все подписи в
//          версии на русском, а не как в БД. Все значения выдавать не как Id,
//          а значения (не id автора, а ФИО)».
//
//          Право и расшифровка значений — на СЕРВЕРЕ (handlers/versions.go).
//          Здесь не осталось ни одного места, где бы интерфейс сам решал, что
//          показать, или сам переводил код в слово: иначе один и тот же
//          реквизит выглядел бы по-разному в истории изменений и в отчёте по
//          документу. Прежде панель печатала ключи снимка как есть —
//          «author_id», «special_mark_id» — и рядом с ними числа.
//
//   п. 7 — «версии файла документа нельзя скачивать!». Кнопка скачивания
//          убрана, и вместе с ней удалён обработчик на сервере — скрыть
//          кнопку, оставив работающий путь, означало бы мнимый запрет.
//          Перечень версий остался: он отвечает на вопрос «подменяли ли файл
//          и когда», и для этого достаточно хэша, автора и времени.

function fmt(v) {
  if (!v) return '—'
  try {
    return fmtDateTime(v)
  } catch {
    return String(v)
  }
}

function fmtSize(b) {
  if (!b) return '—'
  if (b < 1024) return `${b} Б`
  if (b < 1024 * 1024) return `${Math.round(b / 1024)} КБ`
  return `${(b / 1024 / 1024).toFixed(1)} МБ`
}

export default function VersionsPanel({ documentId }) {
  const [data, setData] = useState(null)
  const [error, setError] = useState('')
  const [open, setOpen] = useState(null)

  useEffect(() => {
    api
      .listVersions(documentId)
      .then(setData)
      .catch((e) => setError(e.message || 'Не удалось загрузить версии'))
  }, [documentId])

  if (error) return <div className="text-danger text-sm">{error}</div>
  if (!data) return <div className="text-sm text-text-secondary">Загрузка…</div>

  const cards = data.card_versions || []
  const files = data.file_versions || []
  const cardsAllowed = !!data.card_versions_allowed

  return (
    <div className="space-y-5">
      <div>
        <h3 className="text-sm font-medium mb-2">
          История изменений карточки{cardsAllowed ? ` (${cards.length})` : ''}
        </h3>
        {/* Прямое объяснение вместо пустого раздела: пустой список читается
            как «правок не было», то есть как неверные сведения. */}
        {!cardsAllowed && (
          <div className="text-xs text-text-secondary border border-border rounded-md px-3 py-2">
            История изменений реквизитов доступна исполнителю документа — тому, кто его
            готовил. Это рабочая переписка по подготовке документа, и остальным участникам
            она не показывается.
          </div>
        )}
        {cardsAllowed && cards.length === 0 && (
          <div className="text-xs text-text-secondary">Версий нет.</div>
        )}
        {cardsAllowed && (
          <ul className="space-y-1.5">
            {[...cards].reverse().map((v) => (
              <li key={v.version} className="border border-border rounded-md">
                <button
                  onClick={() => setOpen(open === v.version ? null : v.version)}
                  className="w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-surface-alt"
                >
                  <Icon
                    name={open === v.version ? 'chevron-down' : 'chevron-right'}
                    size={13}
                    className="shrink-0 text-text-secondary"
                  />
                  <span className="text-sm">Версия {v.version}</span>
                  <span className="kicker flex-1 truncate">
                    {v.changed_by_name || 'система'} · {fmt(v.created_at)}
                  </span>
                  <span className="text-xs text-text-secondary shrink-0">
                    {v.version === 1
                      ? 'создание'
                      : `изменено реквизитов: ${(v.changes || []).length}`}
                  </span>
                </button>
                {open === v.version && (
                  <div className="px-3 pb-3 pt-1 border-t border-border">
                    {v.version === 1 || (v.changes || []).length === 0 ? (
                      // Первая версия — это состав карточки на момент
                      // создания. Показываем весь состав: разницы ещё нет, а
                      // «изменений нет» без самих значений бесполезно.
                      <table className="w-full text-xs">
                        <tbody>
                          {(v.card || []).map((f) => (
                            <tr key={f.field} className="border-b border-border last:border-0">
                              <td className="py-1 pr-3 text-text-secondary w-56">{f.label}</td>
                              <td className="py-1">{f.value}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="text-left text-text-secondary">
                            <th className="py-1 pr-3 font-medium w-56">Реквизит</th>
                            <th className="py-1 pr-3 font-medium">Было</th>
                            <th className="py-1 font-medium">Стало</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(v.changes || []).map((c) => (
                            <tr key={c.field} className="border-b border-border last:border-0">
                              <td className="py-1 pr-3 text-text-secondary">{c.label}</td>
                              <td className="py-1 pr-3 text-danger">{c.from}</td>
                              <td className="py-1 text-success">{c.to}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div>
        <h3 className="text-sm font-medium mb-2">Версии файла документа ({files.length})</h3>
        <p className="text-[11px] text-text-secondary mb-2">
          Прежние копии сохраняются при каждой замене файла и служат доказательством
          подмены: по контрольной сумме видно, тот ли файл действовал на момент подписи.
          Скачивание прежних версий не предусмотрено — доступна только действующая.
        </p>
        {files.length === 0 && <div className="text-xs text-text-secondary">Файла нет.</div>}
        {files.length > 0 && (
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-text-secondary border-b border-border">
                <th className="py-1.5 pr-3 font-medium">Версия</th>
                <th className="py-1.5 pr-3 font-medium">Загрузил</th>
                <th className="py-1.5 pr-3 font-medium">Когда</th>
                <th className="py-1.5 pr-3 font-medium">Размер</th>
                <th className="py-1.5 pr-3 font-medium">Заменена</th>
                <th className="py-1.5 font-medium">SHA-256</th>
              </tr>
            </thead>
            <tbody>
              {[...files].reverse().map((f) => (
                <tr key={f.version} className="border-b border-border last:border-0">
                  <td className="py-1.5 pr-3 whitespace-nowrap">
                    {f.current ? (
                      <span className="text-success font-medium">текущая</span>
                    ) : (
                      <span className="text-text-secondary">v{f.version}</span>
                    )}
                  </td>
                  <td className="py-1.5 pr-3">{f.uploaded_by_name || '—'}</td>
                  <td className="py-1.5 pr-3 whitespace-nowrap nums">{fmt(f.uploaded_at)}</td>
                  <td className="py-1.5 pr-3 whitespace-nowrap nums">{fmtSize(f.size_bytes)}</td>
                  <td className="py-1.5 pr-3 whitespace-nowrap nums">
                    {f.current
                      ? '—'
                      : `${fmt(f.superseded_at)}${f.superseded_by_name ? `, ${f.superseded_by_name}` : ''}`}
                  </td>
                  <td className="py-1.5 font-mono text-[10px] break-all">{f.sha256}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
