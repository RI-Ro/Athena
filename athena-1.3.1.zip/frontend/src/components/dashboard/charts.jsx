import React, { useCallback, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useTheme, THEMES } from '../../context/ThemeContext'
import { mix } from '../../lib/colorMix'

// Графики сводной панели — лёгкий SVG без сторонних библиотек.
//
// Цвета рядов — проверенная палитра (синий, оранжевый, бирюзовый): различимы
// при нарушениях цветового зрения, у каждой темы — свои шаги для светлого и
// тёмного фона. Цвет несёт только отметка (линия, полоса), текст всегда в
// цветах текста темы. Состояния (в срок / скоро / просрочено) — отдельная
// палитра и всегда со значком и подписью, не одним цветом.

const SERIES = {
  light: ['#2a78d6', '#eb6834', '#1baf7a'],
  dark: ['#3987e5', '#d95926', '#199e70'],
}
export const STATUS = {
  good: '#0ca30c',
  warning: '#fab219',
  serious: '#ec835a',
  critical: '#d03b3b',
}

export function useChartPalette() {
  const { theme } = useTheme()
  const dark = (THEMES.find((t) => t.id === theme) || THEMES[0]).dark
  return { series: dark ? SERIES.dark : SERIES.light, dark }
}

const nf = new Intl.NumberFormat('ru-RU')
export const fmtInt = (n) => (n == null || Number.isNaN(n) ? '—' : nf.format(Math.round(n)))

// Ширина контейнера: графики перестраиваются по месту, без перерисовки страницы.
function useWidth(initial = 640) {
  const ref = useRef(null)
  const [w, setW] = useState(initial)
  useLayoutEffect(() => {
    const el = ref.current
    if (!el) return undefined
    const ro = new ResizeObserver((entries) => {
      const cw = Math.floor(entries[0].contentRect.width)
      if (cw > 0) setW(cw)
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [])
  return [ref, w]
}

// Круглые деления оси: 0, 5, 10… — по наибольшему значению.
function niceScale(max, count = 4) {
  if (!max || max <= 0) return { top: 4, ticks: [0, 1, 2, 3, 4] }
  const raw = max / count
  const mag = 10 ** Math.floor(Math.log10(raw))
  const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => s >= raw) || 10 * mag
  const top = Math.ceil(max / step) * step
  const ticks = []
  for (let v = 0; v <= top + step / 2; v += step) ticks.push(Math.round(v * 100) / 100)
  return { top, ticks }
}

// Подсказка рядом с указателем; не выходит за край контейнера.
export function Tooltip({ x, y, width, children }) {
  if (x == null) return null
  const left = Math.min(Math.max(8, x + 14), Math.max(8, width - 220))
  return (
    <div
      role="status"
      className="pointer-events-none absolute z-20 min-w-[160px] max-w-[260px] rounded-md border border-border bg-surface px-3 py-2 text-xs shadow-lg"
      style={{ left, top: Math.max(0, y - 10) }}
    >
      {children}
    </div>
  )
}

// LineChart — динамика нескольких показателей по времени. Подписи значений
// только у концов линий (если не налезают друг на друга), остальное — в
// подсказке, которая показывает все ряды в выбранной точке.
export function LineChart({ points, series, height = 260, formatX, formatXLong, hidden = [], ariaLabel }) {
  const [ref, width] = useWidth()
  const [active, setActive] = useState(null)
  const visible = series.filter((s) => !hidden.includes(s.key))
  const pad = { l: 44, r: 56, t: 14, b: 30 }
  const innerW = Math.max(40, width - pad.l - pad.r)
  const innerH = height - pad.t - pad.b
  const n = points.length
  const max = Math.max(0, ...points.flatMap((p) => visible.map((s) => p[s.key] || 0)))
  const { top, ticks } = niceScale(max)
  const x = (i) => pad.l + (n <= 1 ? innerW / 2 : (i * innerW) / (n - 1))
  const y = (v) => pad.t + innerH - (v / top) * innerH

  const paths = visible.map((s) => ({
    ...s,
    d: points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p[s.key] || 0).toFixed(1)}`).join(''),
  }))

  // Подписи у концов: показываем только те, что не сталкиваются (≥16px).
  const endLabels = useMemo(() => {
    if (!n) return []
    const ends = visible.map((s) => ({ key: s.key, v: points[n - 1][s.key] || 0, y: y(points[n - 1][s.key] || 0) }))
      .sort((a, b) => a.y - b.y)
    return ends.filter((e, i) => (i === 0 || e.y - ends[i - 1].y >= 16) && (i === ends.length - 1 || ends[i + 1].y - e.y >= 16))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [points, visible.map((s) => s.key).join(','), top, height])

  const labelEvery = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(innerW / 70))))

  const onMove = useCallback((e) => {
    if (!n) return
    const r = e.currentTarget.getBoundingClientRect()
    const px = e.clientX - r.left
    const i = n <= 1 ? 0 : Math.round(((px - pad.l) / innerW) * (n - 1))
    setActive(Math.min(n - 1, Math.max(0, i)))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [n, innerW])

  const onKey = (e) => {
    if (!n) return
    if (e.key === 'ArrowLeft') { e.preventDefault(); setActive((a) => Math.max(0, (a ?? n - 1) - 1)) }
    if (e.key === 'ArrowRight') { e.preventDefault(); setActive((a) => Math.min(n - 1, (a ?? n - 1) + 1)) }
    if (e.key === 'Escape') setActive(null)
  }

  return (
    <div ref={ref} className="relative w-full select-none">
      <svg
        width={width}
        height={height}
        role="img"
        aria-label={ariaLabel}
        tabIndex={0}
        onPointerMove={onMove}
        onPointerLeave={() => setActive(null)}
        onFocus={() => setActive((a) => a ?? n - 1)}
        onBlur={() => setActive(null)}
        onKeyDown={onKey}
        className="block outline-none focus-visible:ring-2 focus-visible:ring-accent rounded"
      >
        {ticks.map((t) => (
          <g key={t}>
            <line x1={pad.l} x2={pad.l + innerW} y1={y(t)} y2={y(t)} stroke="var(--color-border)" strokeWidth="1" />
            <text x={pad.l - 8} y={y(t)} dy="0.32em" textAnchor="end" fontSize="11" fill="var(--color-text-secondary)" style={{ fontVariantNumeric: 'tabular-nums' }}>
              {fmtInt(t)}
            </text>
          </g>
        ))}
        {points.map((p, i) => (i % labelEvery === 0 || i === n - 1) && (
          <text key={i} x={x(i)} y={height - 8} textAnchor="middle" fontSize="11" fill="var(--color-text-secondary)">
            {formatX(p.bucket)}
          </text>
        ))}
        {active != null && (
          <line x1={x(active)} x2={x(active)} y1={pad.t} y2={pad.t + innerH} stroke="var(--color-text-secondary)" strokeWidth="1" opacity="0.6" />
        )}
        {paths.map((s) => (
          <path key={s.key} d={s.d} fill="none" stroke={s.color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        ))}
        {n > 0 && paths.map((s) => {
          const i = active ?? n - 1
          return (
            <circle key={s.key} cx={x(i)} cy={y(points[i][s.key] || 0)} r="4" fill={s.color} stroke="var(--color-surface)" strokeWidth="2" />
          )
        })}
        {active == null && endLabels.map((e) => (
          <text key={e.key} x={x(n - 1) + 9} y={e.y} dy="0.32em" fontSize="12" fontWeight="600" fill="var(--color-text-primary)">
            {fmtInt(e.v)}
          </text>
        ))}
      </svg>
      {active != null && n > 0 && (
        <Tooltip x={x(active)} y={pad.t} width={width}>
          <div className="text-text-secondary mb-1">{formatXLong(points[active].bucket)}</div>
          {visible.map((s) => (
            <div key={s.key} className="flex items-center gap-2 py-0.5">
              <span className="inline-block w-3 h-0.5 rounded" style={{ background: s.color }} />
              <b className="text-text-primary tabular-nums">{fmtInt(points[active][s.key] || 0)}</b>
              <span className="text-text-secondary">{s.label}</span>
            </div>
          ))}
          {points[active].executed_late > 0 && (
            <div className="text-text-secondary mt-1">из исполненных экземпляров с опозданием: {points[active].executed_late}</div>
          )}
        </Tooltip>
      )}
    </div>
  )
}

// Legend — ключи рядов; щелчок скрывает/показывает ряд.
export function Legend({ series, hidden = [], onToggle }) {
  return (
    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs" role="group" aria-label="Ряды графика">
      {series.map((s) => {
        const off = hidden.includes(s.key)
        return (
          <button
            key={s.key}
            type="button"
            onClick={() => onToggle?.(s.key)}
            aria-pressed={!off}
            className={`flex items-center gap-1.5 rounded px-1 py-0.5 hover:bg-surface-alt ${off ? 'opacity-45 line-through' : ''}`}
            title={off ? 'Показать на графике' : 'Скрыть с графика'}
          >
            <span className="inline-block w-4 h-0.5 rounded" style={{ background: s.color }} />
            <span className="text-text-secondary">{s.label}</span>
          </button>
        )
      })}
    </div>
  )
}

// BarList — горизонтальные полосы от одной базовой линии, значение у конца
// полосы. Строка целиком — область наведения и (если задан onSelect) кнопка.
export function BarList({ rows, value, label, format = fmtInt, color, sub, tip, onSelect, max: maxProp, emptyText = 'Нет данных' }) {
  const [hover, setHover] = useState(null)
  const wrap = useRef(null)
  if (!rows.length) return <p className="text-sm text-text-secondary py-4">{emptyText}</p>
  const max = maxProp || Math.max(1, ...rows.map(value))
  return (
    <div ref={wrap} className="relative" onPointerLeave={() => setHover(null)}>
      <ul className="space-y-1">
        {rows.map((r, i) => {
          const v = value(r)
          const pct = Math.max(0, Math.min(100, (v / max) * 100))
          const Tag = onSelect ? 'button' : 'div'
          return (
            <li key={i}>
              <Tag
                type={onSelect ? 'button' : undefined}
                onClick={onSelect ? () => onSelect(r) : undefined}
                onPointerMove={(e) => {
                  const b = wrap.current.getBoundingClientRect()
                  setHover({ i, x: e.clientX - b.left, y: e.clientY - b.top + 12 })
                }}
                onFocus={(e) => {
                  const b = wrap.current.getBoundingClientRect(); const t = e.currentTarget.getBoundingClientRect()
                  setHover({ i, x: t.left - b.left + 40, y: t.bottom - b.top })
                }}
                onBlur={() => setHover(null)}
                className={`w-full grid grid-cols-[minmax(0,42%)_1fr] items-center gap-3 rounded-md px-2 py-1.5 text-left ${hover?.i === i ? 'bg-surface-alt' : ''} ${onSelect ? 'cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent' : ''}`}
              >
                <span className="min-w-0">
                  <span className="block truncate text-sm text-text-primary">{label(r)}</span>
                  {sub && <span className="block truncate text-xs text-text-secondary">{sub(r)}</span>}
                </span>
                <span className="flex items-center gap-2 min-w-0">
                  <span className="flex-1 h-3 relative">
                    <span
                      className="absolute left-0 top-0 h-3"
                      style={{ width: `${pct}%`, minWidth: v > 0 ? 3 : 0, background: color, borderRadius: '0 4px 4px 0' }}
                    />
                  </span>
                  <span className="w-16 shrink-0 text-right text-sm font-semibold text-text-primary tabular-nums">{format(v, r)}</span>
                </span>
              </Tag>
            </li>
          )
        })}
      </ul>
      {hover && tip && (
        <Tooltip x={hover.x} y={hover.y} width={wrap.current?.clientWidth || 400}>{tip(rows[hover.i])}</Tooltip>
      )}
    </div>
  )
}

// SplitBars — полоса из двух частей (например, «просрочено» и «в срок»),
// части разделены зазором 2px; легенда — над списком.
export function SplitBars({ rows, label, sub, parts, onSelect, tip }) {
  const [hover, setHover] = useState(null)
  const wrap = useRef(null)
  if (!rows.length) return <p className="text-sm text-text-secondary py-4">Нет данных</p>
  const max = Math.max(1, ...rows.map((r) => parts.reduce((a, p) => a + (p.value(r) || 0), 0)))
  return (
    <div ref={wrap} className="relative" onPointerLeave={() => setHover(null)}>
      <div className="flex flex-wrap gap-4 text-xs mb-2">
        {parts.map((p) => (
          <span key={p.key} className="flex items-center gap-1.5 text-text-secondary">
            <span className="inline-block w-3 h-3 rounded-sm" style={{ background: p.color }} />{p.label}
          </span>
        ))}
      </div>
      <ul className="space-y-1">
        {rows.map((r, i) => {
          const total = parts.reduce((a, p) => a + (p.value(r) || 0), 0)
          const Tag = onSelect ? 'button' : 'div'
          return (
            <li key={i}>
              <Tag
                type={onSelect ? 'button' : undefined}
                onClick={onSelect ? () => onSelect(r) : undefined}
                onPointerMove={(e) => { const b = wrap.current.getBoundingClientRect(); setHover({ i, x: e.clientX - b.left, y: e.clientY - b.top + 12 }) }}
                onFocus={(e) => { const b = wrap.current.getBoundingClientRect(); const t = e.currentTarget.getBoundingClientRect(); setHover({ i, x: t.left - b.left + 40, y: t.bottom - b.top }) }}
                onBlur={() => setHover(null)}
                className={`w-full grid grid-cols-[minmax(0,42%)_1fr] items-center gap-3 rounded-md px-2 py-1.5 text-left ${hover?.i === i ? 'bg-surface-alt' : ''}`}
              >
                <span className="min-w-0">
                  <span className="block truncate text-sm text-text-primary">{label(r)}</span>
                  {sub && <span className="block truncate text-xs text-text-secondary">{sub(r)}</span>}
                </span>
                <span className="flex items-center gap-2 min-w-0">
                  <span className="flex-1 flex h-3 gap-[2px]">
                    {parts.map((p, k) => {
                      const v = p.value(r) || 0
                      if (!v) return null
                      const last = parts.slice(k + 1).every((q) => !(q.value(r) || 0))
                      return (
                        <span key={p.key} className="h-3" style={{ width: `${(v / max) * 100}%`, background: p.color, borderRadius: last ? '0 4px 4px 0' : 0 }} />
                      )
                    })}
                  </span>
                  <span className="w-12 shrink-0 text-right text-sm font-semibold text-text-primary tabular-nums">{fmtInt(total)}</span>
                </span>
              </Tag>
            </li>
          )
        })}
      </ul>
      {hover && (
        <Tooltip x={hover.x} y={hover.y} width={wrap.current?.clientWidth || 400}>
          {tip ? tip(rows[hover.i]) : parts.map((p) => (
            <div key={p.key} className="flex items-center gap-2 py-0.5">
              <span className="inline-block w-3 h-0.5 rounded" style={{ background: p.color }} />
              <b className="text-text-primary tabular-nums">{fmtInt(p.value(rows[hover.i]) || 0)}</b>
              <span className="text-text-secondary">{p.label}</span>
            </div>
          ))}
        </Tooltip>
      )}
    </div>
  )
}

// Sparkline — 12 точек тренда в приглушённом цвете, последняя — акцентом.
export function Sparkline({ values, color, width = 96, height = 28 }) {
  if (!values || values.length < 2) return null
  const max = Math.max(1, ...values)
  const step = width / (values.length - 1)
  const pts = values.map((v, i) => [i * step, height - 3 - (v / max) * (height - 6)])
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join('')
  const last = pts[pts.length - 1]
  return (
    <svg width={width} height={height} aria-hidden="true" className="block overflow-visible">
      <path d={d} fill="none" stroke="var(--color-text-secondary)" strokeWidth="1.5" strokeLinejoin="round" opacity="0.7" />
      <circle cx={last[0]} cy={last[1]} r="3" fill={color} stroke="var(--color-surface)" strokeWidth="1.5" />
    </svg>
  )
}

// Meter — доля «в срок»: заполнение окрашено по состоянию, дорожка —
// светлый шаг того же цвета; рядом всегда число.
export function Meter({ pct, width = 96 }) {
  if (pct == null) return <span className="text-text-secondary text-sm">—</span>
  const st = pct >= 80 ? STATUS.good : pct >= 60 ? STATUS.warning : STATUS.critical
  return (
    <span className="inline-flex items-center gap-2">
      <span className="inline-block h-2 rounded-full overflow-hidden" style={{ width, background: mix(st, 22) }}>
        <span className="block h-2 rounded-full" style={{ width: `${Math.max(0, Math.min(100, pct))}%`, background: st }} />
      </span>
      <span className="tabular-nums text-sm font-semibold text-text-primary w-11 text-right">{Math.round(pct)} %</span>
    </span>
  )
}
