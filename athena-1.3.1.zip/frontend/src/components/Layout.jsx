import React, { useCallback, useEffect, useRef, useState } from 'react'
import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom'
import Icon from './Icon'
import ThemeSwitcher from './ThemeSwitcher'
import NotificationsBell from './NotificationsBell'
import AlarmNotifications from './AlarmNotifications'
import ChangePasswordModal from './ChangePasswordModal'
import { useAuth } from '../context/AuthContext'
import { api } from '../api/client'
import { usePreference } from '../lib/usePreference'
import SettingsModal from './SettingsModal'
import { applyPerfMode } from '../lib/perf'
import { useTheme } from '../context/ThemeContext'
import { prefetchRoute, idlePrefetch } from '../lazy-routes'

// Живой фон грузится отдельным чанком и только когда включён.
const BackgroundPaths = React.lazy(() => import('./kokonutui/background-paths'))
import { motion, AnimatePresence } from 'motion/react'
import { animate as animeAnimate, stagger as animeStagger } from 'animejs'
import { PageTransition, AnimatedNumber, spring, prefersReducedMotion } from '../motion'

// Бегунок активного раздела меню. Один и тот же layoutId у всех пунктов, поэтому
// при смене раздела полоска не появляется заново, а переезжает пружиной от
// старого пункта к новому (в том числе между группами меню).
function NavBar({ isActive }) {
  if (!isActive) return null
  return (
    <motion.span
      layoutId="nav-bar"
      transition={spring}
      aria-hidden="true"
      className="absolute left-0 top-1 bottom-1 w-0.5 rounded-full bg-accent"
    />
  )
}

// Разделы бокового меню.
//
// Каждый раздел описан тремя вещами помимо подписи:
//   icon/color — цветная иконка перед текстом. Цвет
//     берётся из переменной темы, а не задаётся числом: один набор иконок
//     одинаково читается во всех десяти темах, включая светлые.
//   count      — показывать ли счётчик. Он оставлен только там, где число
//     требует действия: «на контроле», «на согласование», «на подписи»,
//     «ожидают регистрации», «на регистрацию» (, п. 5).
//     Список обязан совпадать с countedCategories в
//     backend/internal/http/handlers/category_counts.go.
//
// Порядок здесь — порядок ПО УМОЛЧАНИЮ; пользователь может переставить
// разделы под себя, и его порядок хранится на сервере.
const CATEGORIES = [
  // Сводная панель: аналитика по всем доступным документам, настраивается.
  { id: 'dashboard', label: 'Сводная панель', icon: 'cat-dashboard', color: 'var(--color-accent)', to: '/dashboard' },
  { id: 'all', label: 'Все документы', icon: 'cat-all', color: 'var(--color-text-secondary)' },
  { id: 'favorites', label: 'Избранное', icon: 'star-filled', color: 'var(--color-warning)' },
  { id: 'awaiting', label: 'Ожидают регистрации', icon: 'cat-awaiting', color: 'var(--color-warning)', count: true },
  { id: 'outgoing', label: 'Исходящие', icon: 'cat-outgoing', color: 'var(--color-accent)' },
  { id: 'incoming', label: 'Входящие', icon: 'cat-incoming', color: 'var(--color-accent-2)' },
  { id: 'on_approval', label: 'На согласовании', icon: 'tab-route', color: 'var(--color-accent)', count: true },
  { id: 'on_signing', label: 'На подписи', icon: 'tab-sign', color: 'var(--color-accent-2)', count: true },
  // «Резолюции Вам» — поручения лично этому человеку, по которым он ещё не
  // отчитался. Стоит рядом с «На контроле»: обе строки про то, что с тебя
  // спросят. Со счётчиком: это как раз то число, на которое надо реагировать.
  // «Ваши резолюции» — все резолюции пользователя строками (отдельная страница).
  { id: 'resolutions', label: 'Ваши резолюции', icon: 'tab-resolution', color: 'var(--color-accent)', to: '/resolutions', count: true, countKey: 'my_resolutions' },
  { id: 'control', label: 'На контроле', icon: 'tab-control', color: 'var(--color-danger)', count: true },
  { id: 'print_unregistered', label: 'На регистрацию', icon: 'tab-prints', color: 'var(--color-warning)', count: true },
  { id: 'executed', label: 'Исполнено', icon: 'cat-executed', color: 'var(--color-success)' },
  { id: 'archive', label: 'Архив', icon: 'cat-archive', color: 'var(--color-text-secondary)' },
  // Всё, что происходит с документами (сообщения, регистрация, резолюции...).
  { id: 'history', label: 'История', icon: 'tab-history', color: 'var(--color-text-secondary)', to: '/history' },
]

// Инструкция по работе с ИР для пользователей: PDF рядом со статикой интерфейса.
const GUIDE_URL = '/docs/user-guide.pdf'

export default function Layout() {
  const { login, doLogout, canCreate, fullName, position, isAdmin, userId } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [brand, setBrand] = useState({ app_name: 'ИР «Афина»', tagline: 'контроль доведения и исполнения указаний', copyright: '', about: '' })
  const [showAbout, setShowAbout] = useState(false)
  // #19 — выпадающее меню профиля
  const [userMenu, setUserMenu] = useState(false)
  // Самостоятельная смена пароля — из меню профиля.
  const [showPassword, setShowPassword] = useState(false)
  // Пункта «Сеансы работы» в меню больше нет — убран по просьбе заказчика.
  // Сведения о том, кто в системе сейчас, остались у администратора в
  // разделе «Состояние системы», где им и место.
  const userMenuRef = useRef(null)
  // Каскадное появление пунктов бокового меню при первом показе (anime.js).
  // Только при заходе в систему, не при каждом переходе: Layout живёт всё
  // время сеанса, поэтому эффект с пустыми зависимостями срабатывает один раз.
  const navRef = useRef(null)
  useEffect(() => {
    const root = navRef.current
    if (!root || prefersReducedMotion()) return undefined
    const items = Array.from(root.querySelectorAll('a, button'))
    const anim = animeAnimate(items, {
      opacity: [0, 1],
      x: [-14, 0],
      delay: animeStagger(28, { start: 120 }),
      duration: 520,
      ease: 'outQuart',
      onComplete: () => items.forEach((el) => { el.style.removeProperty('transform'); el.style.removeProperty('opacity') }),
    })
    return () => anim.cancel()
  }, [])
  // #41 — количество документов по категориям
  const [counts, setCounts] = useState({})
  // Сколько входящих документов ждут регистрации (входящий номер ещё не
  // присвоен подразделению). Приходит тем же запросом, что и счётчики
  // разделов, — отдельный опрос ради одного числа не нужен.
  const [pendingReg, setPendingReg] = useState(0)

  // Порядок разделов меню, выбранный пользователем.
  // Хранится на сервере, поэтому следует за человеком, а не за браузером.
  // Сохраняем именно ИДЕНТИФИКАТОРЫ, а не номера позиций: при добавлении
  // нового раздела в будущих версиях сохранённые номера «сдвинули» бы меню,
  // а список идентификаторов просто не знает о новом разделе — и тот встанет
  // в конец, ничего не сломав.
  const [navOrder, setNavOrder] = usePreference('ui.nav_order', { order: [] })
  const [reorder, setReorder] = useState(false)
  // Разделы, скрытые пользователем (Настройки → Разделы бокового меню).
  const [navVisible, setNavVisible] = usePreference('ui.nav_visible', { hidden: [] })
  const hiddenNav = Array.isArray(navVisible?.hidden) ? navVisible.hidden : []
  const [showSettings, setShowSettings] = useState(false)
  // Живой фон (волны) за рабочей областью. По умолчанию ВЫКЛЮЧЕН у всех
  // (1.3): он постоянно нагружает процессор, а на слабых ПК и в старых
  // Firefox заметно тормозит. Включается в «Настройках» — только явно.
  const [animBg, setAnimBg] = usePreference('ui.anim_bg', { enabled: false })
  const animEnabled = animBg?.enabled === true && !prefersReducedMotion()

  const orderedCategories = React.useMemo(() => {
    const saved = Array.isArray(navOrder?.order) ? navOrder.order : []
    const byId = new Map(CATEGORIES.map((c) => [c.id, c]))
    const out = []
    for (const id of saved) {
      const c = byId.get(id)
      if (c) {
        out.push(c)
        byId.delete(id)
      }
    }
    // Разделы, которых нет в сохранённом порядке (новые или впервые), идут
    // после него в порядке по умолчанию.
    for (const c of CATEGORIES) if (byId.has(c.id)) out.push(c)
    return out
  }, [navOrder])

  const moveCategory = useCallback(
    (idx, delta) => {
      const to = idx + delta
      if (to < 0 || to >= orderedCategories.length) return
      const ids = orderedCategories.map((c) => c.id)
      const [moved] = ids.splice(idx, 1)
      ids.splice(to, 0, moved)
      setNavOrder({ order: ids })
    },
    [orderedCategories, setNavOrder]
  )
  // Свёрнутое боковое меню — настройка учётной записи (сервер).
  // Тема и облегчённый режим — настройки учётной записи: после входа берём
  // их с сервера (могли быть выбраны на другом компьютере).
  const { loadServerTheme } = useTheme()
  useEffect(() => { loadServerTheme() }, [loadServerTheme])
  const [perfPref, setPerfPref, { loaded: perfLoaded }] = usePreference('ui.perf', { mode: 'auto' })
  useEffect(() => { if (perfLoaded) applyPerfMode(perfPref.mode) }, [perfLoaded, perfPref.mode])
  const [navPref, setNavPref] = usePreference('ui.nav_collapsed', { collapsed: false })
  const navCollapsed = !!navPref.collapsed
  const toggleNav = () => setNavPref((cur) => ({ ...cur, collapsed: !cur.collapsed }))

  useEffect(() => {
    api.getAppConfig().then(setBrand).catch(() => {})
    idlePrefetch()
  }, [])

  // Счётчики документов по категориям.
  //
  // Требование: числа должны обновляться САМИ, а не только при клике на
  // раздел, чтобы было видно появление новых входящих и реагировать на них.
  //
  // «значения возле вкладок обновляются с большой
  // задержкой». Так и было: обновление шло по приходу уведомления и
  // периодическим опросом раз в 60 секунд. Но собственные действия человека
  // уведомления ему НЕ создают (NotifyDocumentEvent не пишет актору), и после
  // подписи, отметки об исполнении или отправки документа счётчик стоял до
  // следующего опроса — до минуты. Выглядело это так, будто действие не
  // сработало.
  //
  // Теперь источников обновления пять:
  //   1) при входе;
  //   2) по приходу уведомления (событие 'athena:notification' рассылает
  //      колокол, который держит WebSocket) — мгновенная реакция на изменение,
  //      сделанное КЕМ-ТО ДРУГИМ;
  //   3) по событию 'athena:changed' — его посылает интерфейс после СВОЕГО
  //      действия, меняющего состояние документа. Это и есть решение п. 16:
  //      свои действия обновляют счётчики сразу, без ожидания опроса;
  //   4) при переходе между разделами — человек всё равно смотрит на меню
  //      именно в этот момент;
  //   5) периодический опрос раз в 20 с — страховка на случай обрыва WS и на
  //      изменения, по которым уведомление не приходит (например, коллега
  //      зарегистрировал входящий). 20 с вместо 60 с: запрос дешёвый (один
  //      агрегат по индексам), а минута ожидания числа заметна.
  // Плюс обновление при возврате на вкладку браузера: пока вкладка скрыта,
  // опрашивать сервер незачем — это тысячи бесполезных запросов при 1000
  // пользователей с открытой, но неактивной вкладкой.
  const loadCounts = useCallback(() => {
    if (typeof document !== 'undefined' && document.hidden) return
    api
      .getCategoryCounts()
      .then((r) => {
        setCounts(r.counts || {})
        setPendingReg(Number(r.pending_registration) || 0)
      })
      .catch(() => {})
  }, [])


  useEffect(() => {
    loadCounts()
    const timer = setInterval(loadCounts, 20000)
    window.addEventListener('athena:notification', loadCounts)
    window.addEventListener('athena:changed', loadCounts)
    window.addEventListener('focus', loadCounts)
    document.addEventListener('visibilitychange', loadCounts)
    return () => {
      clearInterval(timer)
      window.removeEventListener('athena:notification', loadCounts)
      window.removeEventListener('athena:changed', loadCounts)
      window.removeEventListener('focus', loadCounts)
      document.removeEventListener('visibilitychange', loadCounts)
    }
  }, [loadCounts])

  // Обновление при переходе между разделами (п. 16). Отдельным эффектом, а не
  // внутри предыдущего: иначе при каждом переходе пересоздавались бы таймер и
  // все подписки на события.
  useEffect(() => {
    loadCounts()
  }, [location.pathname, loadCounts])

  // Закрытие меню профиля по клику вне него.
  useEffect(() => {
    function onDown(e) {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) setUserMenu(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [])

  return (
    <div className="min-h-screen flex bg-bg text-text-primary font-body relative isolate">
      {animEnabled && (
        <React.Suspense fallback={null}>
        <BackgroundPaths
          className="!fixed inset-0 !min-h-0 -z-10 pointer-events-none !bg-transparent dark:!bg-transparent text-accent opacity-50"
          count={28}
          speed={0.45}
          interactive={false}
        >
          {null}
        </BackgroundPaths>
        </React.Suspense>
      )}
      {/* #42 — Сворачиваемое боковое меню. В свёрнутом виде оно убирается
          полностью (а не превращается в полоску с иконками): пункты здесь
          текстовые, и узкая полоска с обрезанными подписями была бы хуже, чем
          её отсутствие. Рабочая зона при этом занимает всю ширину. */}
      <aside
        className={`${
          navCollapsed ? 'w-0 overflow-hidden border-r-0' : 'w-60 border-r'
        } shrink-0 border-border bg-surface flex flex-col h-screen sticky top-0 transition-[width] duration-150`}
      >
        <div className="px-4 py-4 border-b border-border shrink-0 flex items-center gap-3">
          <img src="/logo.png" alt="" width="40" height="40" className="shrink-0 rounded-lg" decoding="async" />
          <div className="min-w-0">
            <div className="font-display font-semibold text-lg tracking-tight leading-tight">{brand.app_name}</div>
            <div className="text-[11px] leading-snug text-text-secondary mt-0.5">{brand.tagline}</div>
          </div>
        </div>
        <nav
          ref={navRef}
          className="flex-1 py-2 overflow-y-auto overflow-x-hidden"
          onPointerOver={(e) => { const a = e.target.closest && e.target.closest('a[href]'); if (a) prefetchRoute(a.getAttribute('href')) }}
          onFocus={(e) => { const a = e.target.closest && e.target.closest('a[href]'); if (a) prefetchRoute(a.getAttribute('href')) }}
          onTouchStart={(e) => { const a = e.target.closest && e.target.closest('a[href]'); if (a) prefetchRoute(a.getAttribute('href')) }}
        >
          {canCreate && (
            <NavLink
              to="/document/new"
              className="glow-accent block mx-2 mb-3 px-4 py-2 text-sm rounded-md bg-accent text-accent-contrast text-center font-semibold"
            >
              + Новый документ
            </NavLink>
          )}
          {/* ОЖИДАЮТ РЕГИСТРАЦИИ.
              Входящий номер присваивается подразделению, когда документ
              впервые открывает кто-то из получателей. Пока не открыл никто,
              документ лежит незарегистрированным, и заметить это было
              неоткуда: уведомление о направлении теряется среди прочих.
              Поэтому отдельная строка, и она появляется только когда есть о
              чём сказать — постоянный пункт с нулём быстро перестают
              замечать. */}
          {pendingReg > 0 && !hiddenNav.includes('awaiting') && (
            <NavLink
              to="/registry/incoming"
              className="flex items-center justify-between gap-2 mx-2 mb-3 px-4 py-2 text-sm rounded-md border border-warning/50 bg-warning/10 text-warning hover:bg-warning/20"
              title="Входящие документы, которым ещё не присвоен входящий номер. Номер присваивается при первом открытии документа."
            >
              <span>Ожидают регистрации</span>
              <span className="nums font-semibold"><AnimatedNumber value={pendingReg} /></span>
            </NavLink>
          )}
          {/* Кнопка режима перестановки разделов. Вынесена в отдельный режим
              намеренно: если бы разделы можно было таскать всегда, случайное
              движение мышью при обычном переходе по меню меняло бы порядок. */}
          <div className="px-2 mb-1 flex items-center justify-end">
            <button
              onClick={() => setReorder((v) => !v)}
              className={`flex items-center gap-1 px-2 py-1 text-[11px] rounded-md ${
                reorder ? 'bg-accent text-accent-contrast' : 'text-text-secondary hover:bg-surface-alt'
              }`}
              title="Изменить порядок разделов"
            >
              <Icon name="grip" size={12} />
              {reorder ? 'Готово' : 'Порядок'}
            </button>
          </div>
          {reorder && (
            <div className="mx-2 mb-2 px-2 py-1.5 text-[11px] leading-snug text-text-secondary bg-surface-alt rounded-md">
              Клик по разделу — ниже, правая кнопка — выше. Порядок сохраняется
              на сервере и действует после перезагрузки.
            </div>
          )}
          {orderedCategories.map((cat, idx) => {
            if (!reorder && hiddenNav.includes(cat.id)) return null
            // Счётчик — только у разделов с cat.count (п. 5). Ноль не
            // показываем: «На контроле 0» ни к чему не призывает.
            const n = cat.count ? counts[cat.countKey || cat.id] : undefined
            const body = (
              <>
                <Icon name={cat.icon} size={14} className="shrink-0" style={{ color: cat.color }} />
                <span className="flex-1 truncate">{cat.label}</span>
                {n > 0 && (
                  <span className="shrink-0 min-w-5 px-1.5 text-[11px] leading-5 text-center rounded-full bg-surface-alt text-text-secondary">
                    {n > 999 ? '999+' : <AnimatedNumber value={n} />}
                  </span>
                )}
              </>
            )
            // В режиме перестановки это не ссылка, а кнопка: иначе клик увёл
            // бы со страницы вместо перемещения раздела.
            if (reorder) {
              return (
                <button
                  key={cat.id}
                  onClick={() => moveCategory(idx, 1)}
                  onContextMenu={(e) => {
                    e.preventDefault()
                    moveCategory(idx, -1)
                  }}
                  className="w-full flex items-center gap-2 px-4 py-2 text-sm rounded-md mx-2 mb-1 text-left border border-dashed border-border hover:bg-surface-alt"
                  style={{ width: 'calc(100% - 1rem)' }}
                  title="Клик — ниже, правая кнопка — выше"
                >
                  {body}
                </button>
              )
            }
            return (
              <NavLink
                key={cat.id}
                to={cat.to || `/documents/${cat.id}`}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-4 py-2 text-sm rounded-md mx-2 mb-1 ${
                    isActive ? 'nav-active nav-motion' : 'hover:bg-surface-alt text-text-primary'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <NavBar isActive={isActive} />
                    {body}
                  </>
                )}
              </NavLink>
            )
          })}
          {/* Журналы — в самом низу навигации, после архива. */}
          <NavLink
            to="/registry/outgoing"
            className={({ isActive }) =>
              `block px-4 py-2 text-sm rounded-md mx-2 mb-1 mt-2 border-t border-border pt-3 ${
                isActive ? 'nav-active nav-motion' : 'hover:bg-surface-alt text-text-primary'
              }`
            }
          >
            {({ isActive }) => (
                <>
                  <NavBar isActive={isActive} />
                  Журналы
                </>
              )}
          </NavLink>

          {/* Раздел сводной отчётности убран: он ничего не показывал, а
              нужный отчёт — по конкретному документу — открывается кнопкой
              «Отчёт» в карточке документа (там же считается право на него).
              Право на этот отчёт считается по участию в документе (автор,
              подписант, контролёр), а не ролью: роль «формирование
              отчётности» убрана вместе со сводной отчётностью. */}

          {isAdmin && (
            <>
              {/* «журнал аудита и состояние системы —
                  при выборе подсвечивается и вкладка „Администрирование"».

                  Причина: NavLink по умолчанию считает ссылку активной, если
                  текущий путь НАЧИНАЕТСЯ с её адреса. Пути /admin/audit и
                  /admin/metrics начинаются с /admin, поэтому подсвечивались
                  сразу два пункта, и было непонятно, где ты находишься.
                  Атрибут end требует ПОЛНОГО совпадения пути. */}
              <NavLink
                to="/admin"
                end
                className={({ isActive }) =>
                  `block px-4 py-2 text-sm rounded-md mx-2 mb-1 mt-1 ${
                    isActive ? 'nav-active nav-motion' : 'hover:bg-surface-alt text-text-primary'
                  }`
                }
              >
                {({ isActive }) => (
                <>
                  <NavBar isActive={isActive} />
                  Администрирование
                </>
              )}
              </NavLink>
              {/* #10 — техническое состояние системы: метрики, очередь
                  индексации, пул БД. Отдельно от админки, т.к. это не
                  управление справочниками, а наблюдение за системой. */}
              {/*, п. 9 — журнал аудита. */}
              <NavLink
                to="/admin/audit"
                className={({ isActive }) =>
                  `block px-4 py-2 text-sm rounded-md mx-2 mb-1 ${
                    isActive ? 'nav-active nav-motion' : 'hover:bg-surface-alt text-text-primary'
                  }`
                }
              >
                {({ isActive }) => (
                <>
                  <NavBar isActive={isActive} />
                  Журнал аудита
                </>
              )}
              </NavLink>
              <NavLink
                to="/admin/metrics"
                className={({ isActive }) =>
                  `block px-4 py-2 text-sm rounded-md mx-2 mb-1 ${
                    isActive ? 'nav-active nav-motion' : 'hover:bg-surface-alt text-text-primary'
                  }`
                }
              >
                {({ isActive }) => (
                <>
                  <NavBar isActive={isActive} />
                  Состояние системы
                </>
              )}
              </NavLink>
            </>
          )}
        </nav>
        {/* #19 — Блок пользователя (ФИО, должность, логин, «Выйти») переехал в
            выпадающее меню в правом верхнем углу. Здесь в подвале бокового
            меню остаётся только «©» со справкой о системе: место внизу
            сайдбара нужно под навигацию, а профиль по привычке ищут справху
            справа, рядом с колоколом и темой. */}
        <div className="px-4 py-3 border-t border-border shrink-0 relative group">
          <button
            className="text-[11px] text-text-secondary opacity-70 leading-snug text-left hover:opacity-100 hover:text-accent w-full"
            onClick={() => setShowAbout(true)}
          >
            © {brand.copyright || brand.app_name}
          </button>
          {/* При наведении на сведения о системе — ссылки на документы:
              инструкция первого запуска открывается как PDF в новой вкладке. */}
          <div className="hidden group-hover:block absolute left-3 right-3 bottom-full pb-1 z-30">
            <div className="surface-2 border border-border p-3 text-xs">
              <div className="font-semibold text-text-primary mb-1">{brand.app_name}</div>
              <div className="text-text-secondary mb-2">{brand.tagline}</div>
              <a href={GUIDE_URL} target="_blank" rel="noopener" className="block text-accent hover:underline py-0.5">
                Инструкция по работе с информационным ресурсом (PDF)
              </a>
              <button className="block text-accent hover:underline py-0.5" onClick={() => setShowAbout(true)}>
                О системе и поддержка
              </button>
            </div>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 border-b border-border bg-surface flex items-center px-4 gap-3 sticky top-0 z-10">
          {/* #42 — «гамбургер»: скрыть/показать боковое меню */}
          <button
            onClick={toggleNav}
            className="px-2 py-1.5 rounded-md hover:bg-surface-alt"
            title={navCollapsed ? 'Показать меню' : 'Скрыть меню'}
            aria-label={navCollapsed ? 'Показать меню' : 'Скрыть меню'}
            aria-expanded={!navCollapsed}
          >
            <Icon name="menu" size={18} />
          </button>
          {/* В свёрнутом состоянии название системы уезжает вместе с меню,
              поэтому показываем его здесь — иначе непонятно, где находишься. */}
          {navCollapsed && (
            <span className="font-display font-semibold tracking-tight flex items-center gap-2">
              <img src="/logo.png" alt="" width="26" height="26" className="rounded-md" decoding="async" />
              {brand.app_name}
            </span>
          )}
          <div className="flex-1" />
          <NotificationsBell />
          <ThemeSwitcher />
          {/* #19 — профиль пользователя: выпадающее меню справа сверху */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setUserMenu((v) => !v)}
              className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-surface-alt max-w-56"
              title={fullName || login}
            >
              <Icon name="user" size={18} />
              <span className="text-sm truncate">{fullName || login}</span>
              <Icon name="chevron-down" size={14} />
            </button>
            <AnimatePresence>
            {userMenu && (
              <motion.div
                initial={{ opacity: 0, y: -6, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.98, transition: { duration: 0.1 } }}
                transition={spring}
                style={{ transformOrigin: 'top right' }}
                className="absolute right-0 mt-1 w-64 surface-1 shadow-lg z-30"
              >
                <div className="px-3 py-2 border-b border-border">
                  <div className="text-sm font-medium truncate" title={fullName || login}>
                    {fullName || login}
                  </div>
                  {position && (
                    <div className="text-xs text-text-secondary truncate" title={position}>
                      {position}
                    </div>
                  )}
                  <div className="text-[11px] text-text-secondary opacity-70 mt-0.5">{login}</div>
                </div>
                <button
                  className="w-full text-left px-3 py-2 text-sm hover:bg-surface-alt"
                  onClick={() => {
                    setUserMenu(false)
                    setShowPassword(true)
                  }}
                >
                  Сменить пароль
                </button>
                <button
                  className="w-full text-left px-3 py-2 text-sm hover:bg-surface-alt"
                  onClick={() => {
                    setUserMenu(false)
                    setShowSettings(true)
                  }}
                >
                  Настройки
                </button>
                <button
                  className="w-full text-left px-3 py-2 text-sm text-danger hover:bg-surface-alt border-t border-border"
                  onClick={async () => {
                    //, п. 8 — сеанс закрывается НА СЕРВЕРЕ.
                    // Без этого при политике «запрещать вход» человек,
                    // закрывший вкладку, не смог бы войти с другого места до
                    // истечения срока токена. Ошибка выхода не должна мешать
                    // уйти со страницы, поэтому она гасится.
                    try {
                      await api.logout()
                    } catch (_) {
                      /* сеанс всё равно будет закрыт по сроку */
                    }
                    doLogout()
                    navigate('/login')
                  }}
                >
                  Выйти
                </button>
              </motion.div>
            )}
            </AnimatePresence>
          </div>
        </header>
        <main className="flex-1 min-w-0">
          <PageTransition>
            <Outlet />
          </PageTransition>
        </main>
      </div>

      {showSettings && (
        <SettingsModal
          categories={orderedCategories}
          hidden={hiddenNav}
          animEnabled={animEnabled}
          onToggleAnim={(v) => setAnimBg({ enabled: v })}
          perfMode={perfPref.mode || 'auto'}
          onChangePerf={(m) => { setPerfPref({ mode: m }); applyPerfMode(m) }}
          onChangeHidden={(hidden) => setNavVisible({ hidden })}
          onClose={() => setShowSettings(false)}
        />
      )}

      {showAbout && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowAbout(false)}>
          <div className="surface-1 w-full max-w-2xl max-h-[85vh] overflow-auto shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-3 border-b border-border sticky top-0 bg-surface">
              <h2 className="font-display text-lg font-semibold">О системе {brand.app_name}</h2>
              <button onClick={() => setShowAbout(false)} className="text-text-secondary text-2xl leading-none hover:text-text-primary">×</button>
            </div>
            <div className="p-5 text-sm text-text-primary whitespace-pre-wrap leading-relaxed">
              {brand.about || 'Справочная информация не задана (branding.about в конфиге).'}
            </div>
            <div className="px-5 pb-4 text-xs text-text-secondary flex items-center justify-between gap-3">
              <span>© {brand.copyright || brand.app_name}</span>
              <a href={GUIDE_URL} target="_blank" rel="noopener" className="text-accent hover:underline whitespace-nowrap">
                Инструкция по работе с информационным ресурсом (PDF)
              </a>
            </div>
          </div>
        </div>
      )}

      {/* #2 — Блокирующее окно уведомлений, которые нельзя пропустить.
          Монтируется в Layout, а не на отдельной странице: будильник должен
          срабатывать в любом разделе системы. Само окно рисуется только когда
          есть что показать. */}
      {showPassword && <ChangePasswordModal onClose={() => setShowPassword(false)} />}

      <AlarmNotifications />
    </div>
  )
}
