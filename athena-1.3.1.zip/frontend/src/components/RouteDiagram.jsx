import React, { useEffect, useMemo, useRef, useState } from 'react'
import { animate, stagger, svg } from 'animejs'
import Icon from './Icon'
import { prefersReducedMotion } from '../motion'

// Визуализация схемы текущего процесса (, п. 1).
//
// ЗАЧЕМ. Маршрут согласования показывался списком. По списку видно, КТО в
// маршруте, но не видно, ГДЕ СЕЙЧАС СТОИТ ДОКУМЕНТ и почему он стоит:
// параллельные ветки в списке выглядят так же, как последовательные, и
// понять, ждёт ли этап своей очереди или уже можно действовать, нельзя.
// Именно это в разборе ТЕЗИС отмечено как «визуализация схемы процесса».
//
// КАК УСТРОЕНО. Маршрут — направленный ациклический граф: у этапа есть
// зависимости (depends_on). Схема строится «по слоям»: слой этапа = 1 + самый
// глубокий слой его зависимостей. Этапы одного слоя идут параллельно и
// рисуются в столбик друг под другом, слои — слева направо. Такая раскладка
// (longest-path layering) даёт ровно то, что нужно читателю: столбец — это
// «ждут одновременно», стрелка — «только после».
//
// Своя отрисовка на SVG, а не библиотека графов: нужен один конкретный вид
// схемы, а любая библиотека потянула бы сотни килобайт и собственную
// систему тем. Здесь всё рисуется цветами темы и печатается как есть.

// Геометрия. Вынесена в константы, потому что от неё зависят и размеры
// холста, и координаты стрелок — подбирать их по месту значит получить
// расхождение при первом же изменении.
const NODE_W = 168
const NODE_H = 58
const GAP_X = 54
const GAP_Y = 16
const PAD = 14

const STATUS_VIEW = {
  waiting_deps: { label: 'Ожидает очереди', color: 'var(--color-text-secondary)', icon: 'cat-awaiting' },
  pending: { label: 'Ждёт решения', color: 'var(--color-warning)', icon: 'tab-decision' },
  approved: { label: 'Согласовано', color: 'var(--color-success)', icon: 'tab-execution' },
  rejected: { label: 'Отклонено', color: 'var(--color-danger)', icon: 'close' },
  skipped: { label: 'Пропущено', color: 'var(--color-text-secondary)', icon: 'minus' },
}

const TYPE_LABEL = {
  hierarchy: 'Согласование',
  cross_dept: 'Межведомственное',
  signing: 'Подпись',
}

// layout раскладывает этапы по слоям.
//
// Зависимости могут ссылаться на этап, которого в выборке нет (его удалили
// при перестроении маршрута). Такие ссылки игнорируются: иначе весь граф
// «уехал» бы вправо из-за одной висячей связи.
function layout(stages) {
  const byId = new Map(stages.map((s) => [s.id, s]))
  const depth = new Map()

  const calc = (id, guard) => {
    if (depth.has(id)) return depth.get(id)
    // guard защищает от цикла в данных: цикла быть не должно (маршрут —
    // DAG), но если он появится из-за ошибки в данных, рекурсия без защиты
    // повесила бы вкладку намертво.
    if (guard.has(id)) return 0
    guard.add(id)
    const s = byId.get(id)
    let d = 0
    for (const dep of s?.depends_on || []) {
      if (!byId.has(dep)) continue
      d = Math.max(d, calc(dep, guard) + 1)
    }
    guard.delete(id)
    depth.set(id, d)
    return d
  }
  stages.forEach((s) => calc(s.id, new Set()))

  const columns = []
  stages.forEach((s) => {
    const d = depth.get(s.id) || 0
    if (!columns[d]) columns[d] = []
    columns[d].push(s)
  })
  // Внутри слоя сохраняем порядок отображения из маршрута: так схема
  // совпадает со списком, и человек не теряется, переключаясь между ними.
  columns.forEach((col) => col.sort((a, b) => a.display_order - b.display_order))

  const pos = new Map()
  const maxRows = Math.max(1, ...columns.map((c) => c.length))
  columns.forEach((col, ci) => {
    // Короткие столбцы центрируются по высоте: иначе схема выглядит
    // «проваленной» вниз и связи читаются хуже.
    const offset = ((maxRows - col.length) * (NODE_H + GAP_Y)) / 2
    col.forEach((s, ri) => {
      pos.set(s.id, {
        x: PAD + ci * (NODE_W + GAP_X),
        y: PAD + offset + ri * (NODE_H + GAP_Y),
      })
    })
  })

  return {
    pos,
    width: PAD * 2 + columns.length * NODE_W + Math.max(0, columns.length - 1) * GAP_X,
    height: PAD * 2 + maxRows * NODE_H + Math.max(0, maxRows - 1) * GAP_Y,
    columns,
  }
}

export default function RouteDiagram({ stages, currentUserId, onStageClick }) {
  const [zoom, setZoom] = useState(1)
  // Схема «рисуется» при первом показе (anime.js): сначала карточки этапов
  // проявляются слева направо, затем линии связей прочерчиваются от этапа к
  // этапу. Только один раз за показ — повторная отрисовка при каждом
  // обновлении данных мешала бы читать схему.
  const svgRef = useRef(null)
  useEffect(() => {
    const root = svgRef.current
    if (!root || prefersReducedMotion()) return undefined
    const nodes = root.querySelectorAll('[data-node]')
    const edges = root.querySelectorAll('[data-edge]')
    const anims = []
    anims.push(animate(nodes, { opacity: [0, 1], delay: stagger(60), duration: 380, ease: 'outQuad' }))
    if (edges.length) {
      anims.push(
        animate(svg.createDrawable(edges), {
          draw: ['0 0', '0 1'],
          delay: stagger(70, { start: 220 }),
          duration: 700,
          ease: 'inOutQuad',
        }),
      )
    }
    return () => anims.forEach((a) => a.cancel())
  }, [])
  const list = useMemo(
    () => (stages || []).filter((s) => s && s.id),
    [stages]
  )
  const g = useMemo(() => layout(list), [list])

  if (list.length === 0) {
    return (
      <div className="text-sm text-text-secondary">
        Маршрут согласования не задан.
      </div>
    )
  }

  const byId = new Map(list.map((s) => [s.id, s]))

  return (
    // min-w-0 + w-full: схема никогда не раздвигает страницу — всё, что не
    // помещается, прокручивается внутри своей рамки.
    <div className="space-y-2 min-w-0 w-full max-w-full">
      <div className="flex items-center gap-2">
        <span className="label">Схема маршрута</span>
        <div className="flex-1" />
        {/* Масштаб нужен для длинных маршрутов: при десятке этапов схема
            шире экрана, а горизонтальная прокрутка на ноутбуке неудобна. */}
        <button onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))}
          className="px-2 py-0.5 rounded hover:bg-surface-alt" title="Уменьшить">
          <Icon name="minus" size={14} />
        </button>
        <span className="text-xs text-text-secondary w-10 text-center">{Math.round(zoom * 100)}%</span>
        <button onClick={() => setZoom((z) => Math.min(1.6, +(z + 0.1).toFixed(2)))}
          className="px-2 py-0.5 rounded hover:bg-surface-alt" title="Увеличить">
          <Icon name="plus" size={14} />
        </button>
        <button onClick={() => setZoom(1)}
          className="px-2 py-0.5 rounded hover:bg-surface-alt text-xs" title="Сбросить масштаб">
          100%
        </button>
      </div>

      <div className="overflow-auto max-w-full max-h-[60vh] border border-border rounded-md bg-surface-alt/40 p-1" tabIndex={0} aria-label="Схема маршрута: прокрутите, если не помещается">
        <svg
          ref={svgRef}
          width={g.width * zoom}
          height={g.height * zoom}
          viewBox={`0 0 ${g.width} ${g.height}`}
          role="img"
          aria-label="Схема маршрута согласования документа"
        >
          <defs>
            {/* Два наконечника: обычный и для «пройденной» связи. Цвет
                наконечника задаётся в marker и не наследуется от линии,
                поэтому вариантов ровно столько, сколько цветов связей. */}
            <marker id="rd-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5"
              orient="auto" markerUnits="strokeWidth">
              <path d="M0,0 L7,3.5 L0,7 z" fill="var(--color-border)" />
            </marker>
            <marker id="rd-arrow-done" markerWidth="7" markerHeight="7" refX="6" refY="3.5"
              orient="auto" markerUnits="strokeWidth">
              <path d="M0,0 L7,3.5 L0,7 z" fill="var(--color-success)" />
            </marker>
          </defs>

          {/* Связи рисуются ПЕРВЫМИ, чтобы карточки этапов были поверх них. */}
          {list.map((s) =>
            (s.depends_on || []).map((depId) => {
              const from = g.pos.get(depId)
              const to = g.pos.get(s.id)
              if (!from || !to) return null
              const dep = byId.get(depId)
              const done = dep && (dep.status === 'approved' || dep.status === 'skipped')
              const x1 = from.x + NODE_W
              const y1 = from.y + NODE_H / 2
              const x2 = to.x
              const y2 = to.y + NODE_H / 2
              // Кубическая кривая: прямая линия между разными строками
              // пересекала бы карточки соседних этапов.
              const dx = Math.max(18, (x2 - x1) / 2)
              return (
                <path
                  data-edge=""
                  key={`${depId}-${s.id}`}
                  d={`M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`}
                  fill="none"
                  stroke={done ? 'var(--color-success)' : 'var(--color-border)'}
                  strokeWidth={done ? 1.8 : 1.4}
                  markerEnd={done ? 'url(#rd-arrow-done)' : 'url(#rd-arrow)'}
                />
              )
            })
          )}

          {list.map((s) => {
            const p = g.pos.get(s.id)
            if (!p) return null
            const view = STATUS_VIEW[s.status] || STATUS_VIEW.waiting_deps
            // «Мой» этап — тот, по которому я вправе принять решение
            // (флаг can_decide с сервера), либо назначенный лично мне.
            // Второе условие нужно для уже ПРОЙДЕННЫХ этапов: can_decide у
            // них false, но свой пройденный этап человек должен узнавать на
            // схеме.
            const mine = !!s.can_decide || (currentUserId && s.approver_id === currentUserId)
            const active = s.status === 'pending'
            return (
              <g
                data-node=""
                key={s.id}
                transform={`translate(${p.x}, ${p.y})`}
                onClick={() => onStageClick && onStageClick(s)}
                style={{ cursor: onStageClick ? 'pointer' : 'default' }}
              >
                <title>
                  {`${TYPE_LABEL[s.stage_type] || s.stage_type}: ${s.approver_name}` +
                    (s.approver_position ? `, ${s.approver_position}` : '') +
                    `\n${view.label}` +
                    (s.decided_at ? `\n${new Date(s.decided_at).toLocaleString('ru-RU')}` : '') +
                    (s.comment ? `\n«${s.comment}»` : '')}
                </title>
                <rect
                  width={NODE_W} height={NODE_H} rx="7"
                  fill="var(--color-surface)"
                  stroke={view.color}
                  // Текущий этап обводится толще: «где документ сейчас» —
                  // главный вопрос к этой схеме, и он должен считываться
                  // мгновенно, без чтения подписей.
                  strokeWidth={active ? 2.2 : 1}
                />
                {/* Полоса слева цветом статуса — дублирует цвет рамки в
                    более заметном виде и различима при печати. */}
                <rect width="4" height={NODE_H} rx="2" fill={view.color} />
                {mine && (
                  <rect x={NODE_W - 7} y="0" width="4" height={NODE_H} rx="2"
                    fill="var(--color-accent)" />
                )}
                <text x="13" y="17" fontSize="8" fill="var(--color-text-secondary)">
                  {TYPE_LABEL[s.stage_type] || s.stage_type}
                </text>
                <text x="13" y="32" fontSize="10.5" fill="var(--color-text-primary)">
                  {clip(s.approver_name || '—', 23)}
                </text>
                <text x="13" y="45" fontSize="8" fill={view.color}>
                  {view.label}
                  {mine ? ' · вы' : ''}
                </text>
                <text x={NODE_W - 12} y="45" fontSize="7.5" textAnchor="end"
                  fill="var(--color-text-secondary)">
                  {s.decided_at ? new Date(s.decided_at).toLocaleDateString('ru-RU') : ''}
                </text>
              </g>
            )
          })}
        </svg>
      </div>

      {/* Легенда: цвет не должен быть единственным носителем смысла, а схему
          распечатывают. */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-text-secondary">
        {Object.entries(STATUS_VIEW).map(([k, v]) => (
          <span key={k} className="inline-flex items-center gap-1">
            <span className="inline-block w-2.5 h-2.5 rounded-sm" style={{ background: v.color }} />
            {v.label}
          </span>
        ))}
        <span className="inline-flex items-center gap-1">
          <span className="inline-block w-2.5 h-2.5 rounded-sm" style={{ background: 'var(--color-accent)' }} />
          ваш этап
        </span>
      </div>
    </div>
  )
}

// clip — обрезка подписи в узле. В SVG нет переноса текста, а длинное ФИО
// вылезает за карточку; обрезка с многоточием честнее, чем наползающий текст
// (полное значение есть в подсказке по наведению).
function clip(s, max) {
  if (s.length <= max) return s
  return s.slice(0, max - 1) + '…'
}
