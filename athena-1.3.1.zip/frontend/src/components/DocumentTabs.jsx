import React, { useState, useEffect, useCallback, useRef } from 'react'
import Icon from './Icon'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import PersonPicker from './PersonPicker'
import RouteDiagram from './RouteDiagram'
import ResolutionsPanel from './ResolutionsPanel'
import VersionsPanel from './VersionsPanel'
import SendPanel from './SendPanel'
import RecipientGroupPicker from './RecipientGroupPicker'
import { fmtDateTime } from '../utils/format'
import { EVENT_LABELS as STATUS_LABELS } from '../lib/historyLabels'
import { usePreference } from '../lib/usePreference'

const COPY_REASON_LABELS = {
  author: 'Автор (оригинал)',
  approver_hierarchy: 'Согласование',
  approver_cross_dept: 'Согласование',
  approval_stage: 'Согласование/подпись',
  signer: 'Подпись',
  recipient: 'Получатель',
  executor: 'Исполнитель',
  acquaintance: 'Ознакомление',
  // Основание доступа называется так же, как роль, которая его даёт.
  chief_of_dept: 'Может ставить резолюции',
  controller: 'Контролёр',
  clerk: 'Канцелярия',
  view: 'Просмотр',
}
const LINK_TYPE_LABELS = {
  related: 'Связанный',
  reply_to: 'В ответ на',
  annuls: 'Отменяет',
  appendix: 'Приложение',
  in_addition: 'В дополнение',
  in_pursuance_of: 'Во исполнение', // легаси-значение (для отображения старых связей)
}

// Типы связи, доступные при СОЗДАНИИ (порядок как в требовании).
const LINK_TYPE_OPTIONS = [
  ['related', 'Связанный'],
  ['reply_to', 'В ответ на'],
  ['annuls', 'Отменяет'],
  ['appendix', 'Приложение'],
  ['in_addition', 'В дополнение'],
]


// Технологические события маршрута/служебные — пользователю не показываем
// (они шумят и не несут смысла для человека). Показываем только значимые.
// Скрываем только ТЕХНИЧЕСКИЕ события (перестроение маршрута, выдача/отзыв
// доступа). #33 — отметка об исполнении и факт исполнения документа являются
// значимыми событиями и теперь показываются в истории.

const HIDDEN_HISTORY_EVENTS = new Set(['route_rebuilt', 'access_granted', 'access_revoked', 'route_restart'])

function fmt(dt) {
  if (!dt) return ''
  try { return fmtDateTime(dt) } catch { return dt }
}

// Вкладки карточки документа: Маршрут | История | Просмотры | Рассылка.
// Рассылка включает кнопку "Отметить исполнение" для текущего получателя.
export default function DocumentTabs({
  documentId,
  currentUserId,
  routeSlot,
  decisionSlot, // #15 — блок решения (согласовать/подписать) отдельной вкладкой
  chatSlot, // #38 — обсуждение отдельной вкладкой
  onChanged,
  docStatus,
  doc,
  patchDoc,
  tab: tabProp, // #40 — активная вкладка снаружи (хранится в адресе страницы)
  onTabChange,
}) {
  // #40 — Вкладка управляется СНАРУЖИ, если переданы tab/onTabChange: тогда
  // она лежит в адресе страницы и не теряется ни при обновлении данных, ни при
  // настоящей перезагрузке. Внутреннее состояние остаётся запасным вариантом,
  // чтобы компонент можно было использовать и без внешнего управления.
  const [tabState, setTabState] = useState('route')
  const controlled = typeof onTabChange === 'function'
  const tab = (controlled ? tabProp : tabState) || 'route'
  const setTab = controlled ? onTabChange : setTabState
  const [counts, setCounts] = useState(null) // #17 — числа в подписях вкладок
  // Порядок вкладок, выбранный пользователем, и режим его изменения.
  // Хранится на сервере — переживает перезагрузку и смену компьютера.
  const [tabOrderPref, setTabOrderPref] = usePreference('ui.doc_tab_order', { order: [] })
  const [reorderMode, setReorderMode] = useState(false)
  const [stages, setStages] = useState(null) // нужны, чтобы знать, ждут ли решения
  const [roles, setRoles] = useState(null)
  const [history, setHistory] = useState(null)
  const [sigs, setSigs] = useState(null) // #8 — данные о подписи (63-ФЗ)
  const [recipients, setRecipients] = useState(null)
  const [copies, setCopies] = useState(null)
  const [prints, setPrints] = useState(null)
  const [regForm, setRegForm] = useState({})
  const [links, setLinks] = useState(null)
  const [linkMode, setLinkMode] = useState('system') // 'system' | 'external'
  const [linkDocs, setLinkDocs] = useState([]) // мультивыбор системных документов
  const [linkSearch, setLinkSearch] = useState('')
  const [linkSearchResults, setLinkSearchResults] = useState([])
  const [linkNote, setLinkNote] = useState('') // текст для несистемного документа
  const [linkType, setLinkType] = useState('related')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [printDiag, setPrintDiag] = useState(null) // #11 — результат проверки готовности к печати
  const [execModal, setExecModal] = useState(false) // #10 — модалка отметки исполнения
  // состояние отметки об исполнении и доступные
  // действия с ней. Приходит с сервера целиком: право ставить отметку зависит
  // от данных, которых у интерфейса нет (кто адресат по какому
  // подразделению, кто ознакомлен, кто исполнитель резолюции), и попытка
  // вычислить его здесь и была причиной жалобы п. 21.
  const [execStatus, setExecStatus] = useState(null)
  // Режим окна отметки: 'mark' — поставить, 'change' — изменить отчёт,
  // 'cancel' — отменить (тогда в поле вводится причина, а не отчёт).
  const [execMode, setExecMode] = useState('mark')
  const [error, setError] = useState('')

  const loadTab = useCallback(async (t) => {
    setError('')
    try {
      if (t === 'history' && !history) setHistory((await api.getHistory(documentId)).items || [])
      if (t === 'history' && sigs === null) setSigs((await api.getDocumentSignatures(documentId)).items || [])
      if (t === 'copies' && !copies) setCopies((await api.getCopies(documentId)).items || [])
      if (t === 'prints') setPrints((await api.getPrints(documentId)).items || [])
      if (t === 'recipients') setRecipients((await api.getRecipients(documentId)).items || [])
      if (t === 'links') setLinks((await api.getLinks(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    }
  }, [documentId, history, sigs])

  // Ссылка на последнюю версию loadTab. Нужна, чтобы эффект обновления по
  // событиям не пересоздавался при каждом изменении истории или подписей:
  // иначе подписки на события снимались и ставились заново десятки раз.
  const loadTabRef = useRef(null)
  loadTabRef.current = loadTab


  // ОБНОВЛЕНИЕ СОСТОЯНИЯ КАРТОЧКИ.
  //
  // Жалобы были две и у них одна причина:
  //   п. 2  — «изменение документа не приводит к актуальному отображению
  //           состояния (например схема маршрута)»;
  //   п. 11 — «схема маршрута не обновляется онлайн, требуется перезагрузка».
  //
  // Причина: всё это загружалось ОДИН раз, при монтировании, и зависело только
  // от documentId. Сохранение формы изменения документа id не меняет, поэтому
  // ни этапы, ни роли, ни счётчики не перечитывались — на экране оставался
  // прежний маршрут. Решение коллеги по соседнему этапу тоже ничего не
  // обновляло: WebSocket-сообщение приходило, но его здесь никто не слушал.
  //
  // Теперь загрузка вынесена в reload и вызывается по четырём поводам:
  //   1) при открытии документа;
  //   2) после НАШЕГО действия — по событию 'athena:changed' (его рассылает
  //      карточка документа после каждой своей перезагрузки);
  //   3) после действия КОГО-ТО ДРУГОГО — по событию
  //      'athena:document_changed', которое приходит из WebSocket;
  //   4) при возврате на вкладку браузера: пока вкладка скрыта, человек на
  //      схему не смотрит, а по возврату она обязана быть актуальной.
  //
  // Опроса по таймеру здесь намеренно НЕТ: карточка документа открыта у
  // человека долго, и опрос четырёх запросов в минуту на каждого при тысяче
  // пользователей — это нагрузка без причины. Событий WebSocket для
  // «онлайн» достаточно, а возврат на вкладку закрывает случай обрыва связи.
  const reload = useCallback(() => {
    api.getMyRoles(documentId).then(setRoles).catch(() => setRoles(null))
    // Получателей грузим сразу: от них зависит доступность вкладок «Рассылка»
    // и «Ознакомление».
    api.getRecipients(documentId).then((r) => setRecipients(r.items || [])).catch(() => {})
    // #17 — счётчики: один дешёвый запрос вместо загрузки всех вкладок.
    api.getDocumentCounts(documentId).then(setCounts).catch(() => setCounts(null))
    // #15 — этапы нужны ЗДЕСЬ, чтобы решить, показывать ли вкладку решения и
    // открывать ли её сразу. ApprovalPanel грузит их для себя сам, но он
    // смонтирован только когда его вкладка активна.
    api.getStages(documentId).then((r) => setStages(r.items || [])).catch(() => setStages([]))
    // Состояние отметки об исполнении и доступные действия с ней (пп. 21, 22).
    api.executionStatus(documentId).then(setExecStatus).catch(() => setExecStatus(null))
  }, [documentId])

  useEffect(() => {
    reload()
    const onExternal = (e) => {
      // Событие приходит и по чужим документам (один WebSocket на всё
      // приложение) — реагируем только на свой.
      //
      // Два написания ключа читаются намеренно: 'athena:changed' рассылает сам
      // интерфейс (documentId), а 'athena:document_changed' приходит из
      // WebSocket, где сервер отдаёт поле document_id. Приводить их к одному
      // виду в двух местах пришлось бы на каждой стороне, и однажды одна из
      // сторон осталась бы со старым именем — а молча не сработавшее
      // обновление ровно и было предметом замечаний пп. 2 и 11.
      const id = e?.detail?.documentId ?? e?.detail?.document_id
      if (id != null && String(id) !== String(documentId)) return
      reload()
    }
    const onVisible = () => {
      if (!document.hidden) reload()
    }
    window.addEventListener('athena:changed', onExternal)
    window.addEventListener('athena:document_changed', onExternal)
    document.addEventListener('visibilitychange', onVisible)
    return () => {
      window.removeEventListener('athena:changed', onExternal)
      window.removeEventListener('athena:document_changed', onExternal)
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [documentId, reload])

  // Открытые вкладки тоже перечитываются по тем же событиям: иначе история,
  // рассылка или связи оставались бы в том виде, в каком их загрузили при
  // первом открытии вкладки. Отдельным эффектом, потому что зависит от того,
  // какая вкладка открыта сейчас.
  useEffect(() => {
    const onExternal = (e) => {
      const id = e?.detail?.documentId ?? e?.detail?.document_id
      if (id != null && String(id) !== String(documentId)) return
      // Сброс кэша вкладки: loadTab грузит только то, чего ещё нет.
      if (tab === 'history') { setHistory(null); setSigs(null) }
      if (tab === 'links') setLinks(null)
      if (tab === 'copies') setCopies(null)
      loadTabRef.current?.(tab)
    }
    window.addEventListener('athena:changed', onExternal)
    window.addEventListener('athena:document_changed', onExternal)
    return () => {
      window.removeEventListener('athena:changed', onExternal)
      window.removeEventListener('athena:document_changed', onExternal)
    }
  }, [documentId, tab])

  // #15 — от пользователя ждут решения: его этап согласования/подписи активен.
  // «Мой» этап определяется флагом can_decide с сервера.
  const myPendingStage = (stages || []).find((s) => s.can_decide)
  const needsMyDecision = !!myPendingStage
  const myDecisionLabel = myPendingStage?.stage_type === 'signing' ? '● Подписать' : '● Согласовать'

  // Если решения ждут — открываем вкладку решения, иначе маршрут. Делаем это
  // один раз, после загрузки этапов, и только пока пользователь сам не
  // переключил вкладку (иначе мы бы перебивали его выбор).
  const autoTabDoneRef = useRef(false)
  // Если вкладка задана в адресе явно (?tab=...), автовыбор не применяем:
  // пользователь уже сказал, что хочет открыть, в том числе перезагрузкой
  // страницы или ссылкой от коллеги (#40).
  const hasExplicitTab = controlled && !!tabProp
  useEffect(() => {
    if (stages === null || autoTabDoneRef.current) return
    autoTabDoneRef.current = true
    if (hasExplicitTab) return
    if (stages.some((s) => s.can_decide)) {
      setTab('decision')
    }
    // setTab в управляемом режиме меняет идентичность на каждый рендер, но
    // повторный запуск исключён флагом autoTabDoneRef.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stages, currentUserId, hasExplicitTab])

  // Одно действие на три режима (пп. 21, 22). Отдельные функции здесь были бы
  // тремя копиями одного и того же: проверить, отправить, перечитать,
  // сообщить об изменении. Разница только в вызываемом методе и в том, что
  // поле означает — отчёт или причину отмены.
  async function submitExecution() {
    setBusy(true); setError('')
    try {
      if (execMode === 'cancel') {
        await api.cancelExecutionMark(documentId, note)
      } else if (execMode === 'change') {
        await api.changeExecutionMark(documentId, note)
      } else {
        await api.markExecuted(documentId, note)
      }
      setNote('')
      setExecModal(false)
      // Перечитываем и состояние отметки, и рассылку: после простановки
      // меняются оба, а после отмены документ ещё и возвращается в работу.
      api.executionStatus(documentId).then(setExecStatus).catch(() => {})
      setRecipients((await api.getRecipients(documentId)).items || [])
      onChanged?.()
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  // Открыть окно отметки в нужном режиме. Для изменения поле заполняется
  // текущим отчётом: исправляют обычно пару слов, а не пишут заново.
  function openExec(mode) {
    setExecMode(mode)
    setNote(mode === 'change' ? (execStatus?.note || '') : '')
    setError('')
    setExecModal(true)
  }

  const myRecipient = recipients?.find((r) => r.user_id === currentUserId)

  // Участие пользователя определяет, какие вкладки показывать. Базовые
  // (маршрут/история/просмотры/связанные) видят все с доступом к документу.
  // Рассылка и поручения — только участникам (автор, подписант, получатель,
  // контролёр), чтобы не показывать посторонним лишние управляющие вкладки.
  // Роли берём из /my-roles (надёжный источник). Пока не загрузились —
  // показываем базовые вкладки. Рассылка/поручения — только участникам.
  const isParticipant = roles
    ? roles.is_author || roles.is_controller || roles.is_signer || roles.is_approver || roles.is_recipient || roles.is_admin
    : false
  const isApprovalParticipant = roles
    ? roles.is_author || roles.is_approver || roles.is_signer || roles.is_admin
    : true

  // Права управления: связи и направление — только автор/подписант.
  const canManage = !!(roles && (roles.is_author || roles.is_signer || roles.is_admin))
  const canRedirect = !!(roles && roles.can_redirect) // #7 — дежурный донаправляет
  // НАПРАВЛЕНИЕ документа адресатам — только после подписи: до подписи
  // направлять нечего.
  const canSend = (canManage || canRedirect) && ['signed', 'sent', 'in_progress', 'executed'].includes(docStatus)

  // ПЛАНОВАЯ РАССЫЛКА ДО ПОДПИСИ (, п. 3: «автор не может
  // добавить/изменить/удалить рассылку до подписи, после подписи может.
  // Сделать активным до подписи автору и подписанту»).
  //
  // Это РАЗНЫЕ вещи, и именно их смешение было причиной жалобы. До подписи
  // адресаты — ПЛАНОВЫЕ (is_planned): документа у них ещё нет, список правится
  // целиком через updatePlannedRecipients. После подписи документ адресатам
  // УЖЕ НАПРАВЛЕН, и список меняется направлением новых и удалением
  // непросмотревших.
  //
  // Прежде вкладка «Рассылка» показывала средства управления только при
  // статусах signed/sent/in_progress/executed (условие canSend). До подписи
  // человек видел список без единой кнопки — ни добавить, ни удалить, — хотя
  // сервер правку плановой рассылки разрешал. Снаружи это и выглядело как
  // «до подписи нельзя, после подписи можно».
  //
  // Право даётся автору И подписанту (так в замечании): подписант своей
  // подписью направляет документ плановым адресатам и должен иметь
  // возможность поправить список до того, как подпишет.
  const canEditPlanned = !!(roles && (roles.is_author || roles.is_signer || roles.is_admin))
    && ['draft', 'on_approval_hierarchy', 'on_approval_cross_dept', 'on_signing', 'rejected'].includes(docStatus)
  // #6/#7 — Ознакомление и поручения доступны ПО ПРАВАМ (не по факту рассылки):
  // canAcquaint/canAssign приходят из /my-roles. Показываем вкладки любому, у
  // кого есть доступ к документу и соответствующее право (даже если он просто
  // ознакомлен). Конкретный список кандидатов ограничивает бэкенд.
  const canAcquaint = !!(roles && roles.can_acquaint)
  const canAssign = !!(roles && roles.can_assign)
  const isAssignee = !!(roles && roles.is_assignee) // #1 — исполнитель видит поручения
  // #10 +, п. 7 — отметку об исполнении ставит не только
  // получатель.
  //
  // Право считает СЕРВЕР (флаг can_mark_execution в /my-roles): отметка
  // принадлежит входящему экземпляру, и поставить её может получатель по этому
  // подразделению ЛИБО тот, кому выдана роль «может ставить отметки о
  // выполнении» в этом подразделении (дежурному и канцелярии роль не нужна —
  // у них основание из факта получения). Дублировать это условие на клиенте
  // нельзя: оно опирается на данные, которых у фронта нет.
  //
  // Теперь источник один — ответ
  // /api/documents/:id/execution: он говорит и о состоянии отметки, и о том,
  // что с ней можно сделать. Прежний флаг can_mark_execution из /my-roles
  // остаётся запасным вариантом на время, пока этот запрос не ответил, иначе
  // вкладка на миг исчезала бы.
  //
  // Вкладка показывается, если можно поставить отметку, ИЛИ изменить её, ИЛИ
  // отменить (п. 22): после простановки она не должна исчезать — именно там
  // находятся «изменить» и «отменить».
  const canExecute = execStatus
    ? !!(execStatus.can_mark || execStatus.can_change || execStatus.can_cancel)
    : roles
      ? !!roles.can_mark_execution
      : !!(myRecipient && !myRecipient.completed_at)

  // Порядок вкладок (#15, #38, #39):
  //   * #15 — «Согласование/Подпись» вынесено в ПЕРВУЮ отдельную вкладку:
  //     решение по документу — главное действие, за которым сюда приходят, а
  //     кнопки были спрятаны внутри вкладки «Маршрут» ниже схемы маршрута.
  //     Вкладка показывается только тому, от кого сейчас ждут решения.
  //   * #38 — «Обсуждение» стало отдельной вкладкой (раньше переписка висела
  //     сбоку от карточки и на узких экранах уезжала вниз).
  //   * #39 — «История» ушла последней: это архивная справка, а не рабочая
  //     вкладка, и она занимала второе место.
  //   * #13 — вкладки «Просмотры» больше нет, её данные в «Экземплярах».
  //
  // #17 — в подписях вкладок стоят счётчики: сколько экземпляров, сообщений,
  // файлов, поручений. Раньше узнать это можно было только открыв вкладку.
  // Цветные иконки вкладок. Цвет — смысловой, не декоративный: решение и
  // контроль предупреждающие, исполнение и согласование — «состоялось»,
  // служебные вкладки (экземпляры, печать, связи, история) нейтральные. Так
  // по цвету видно, где требуется действие, ещё до чтения подписи.
  const TAB_META = {
    decision:    { icon: 'tab-sign',    color: 'var(--color-warning)' },
    route:       { icon: 'tab-route',       color: 'var(--color-accent)' },
    recipients:  { icon: 'tab-recipients',  color: 'var(--color-accent-2)' },
    execution:   { icon: 'tab-execution',   color: 'var(--color-success)' },
    assignments: { icon: 'tab-resolution', color: 'var(--color-accent-2)' },
    acquaint:    { icon: 'tab-acquaint',    color: 'var(--color-accent)' },
    chat:        { icon: 'tab-chat',        color: 'var(--color-accent-2)' },
    copies:      { icon: 'tab-copies',      color: 'var(--color-text-secondary)' },
    prints:      { icon: 'tab-prints',      color: 'var(--color-text-secondary)' },
    links:       { icon: 'tab-links',       color: 'var(--color-text-secondary)' },
    control:     { icon: 'tab-control',     color: 'var(--color-danger)' },
    history:     { icon: 'tab-history',     color: 'var(--color-text-secondary)' },
    versions:    { icon: 'tab-copies',      color: 'var(--color-text-secondary)' },
  }

  // Набор вкладок, доступных пользователю. Порядок здесь — порядок ПО
  // УМОЛЧАНИЮ; дальше он переупорядочивается по настройке пользователя.
  const AVAILABLE_TABS = [
    ...(needsMyDecision ? [{ id: 'decision', label: myDecisionLabel }] : []),
    ...(isApprovalParticipant ? [{ id: 'route', label: 'Маршрут' }] : []),
    ...(isParticipant ? [{ id: 'recipients', label: 'Рассылка', count: recipients?.length }] : []),
    ...(canExecute ? [{ id: 'execution', label: 'Исполнение' }] : []),
    ...(canAssign || isParticipant || isAssignee
      ? [{ id: 'assignments', label: 'Резолюции', count: counts?.resolutions }]
      : []),
    ...(canAcquaint ? [{ id: 'acquaint', label: 'Ознакомление' }] : []),
    { id: 'chat', label: 'Обсуждение', count: counts?.messages },
    { id: 'copies', label: 'Экземпляры', count: counts?.copies },
    { id: 'prints', label: 'Печать', count: counts?.prints },
    { id: 'links', label: 'Связанные', count: counts?.links },
    { id: 'control', label: doc?.on_control ? 'На контроле ●' : 'Контроль' },
    { id: 'history', label: 'История' },
    //, п. 2 — версии карточки и файла. Вкладка доступна всем,
    // кто видит документ: история изменений реквизитов — такая же часть
    // документа, как и история событий, скрывать её не от кого.
    { id: 'versions', label: 'Версии' },
  ]

  // ПОРЯДОК ВКЛАДОК, выбранный пользователем.
  //
  // Храним СПИСОК ИДЕНТИФИКАТОРОВ, а не индексы: набор вкладок у разных
  // документов разный (у одного есть «Решение», у другого нет), и индексы
  // поехали бы. Вкладки, которых нет в сохранённом порядке (появились позже
  // или стали доступны), встают в конец — ничего не пропадает.
  const ordered = (() => {
    const saved = Array.isArray(tabOrderPref.order) ? tabOrderPref.order : []
    const byId = new Map(AVAILABLE_TABS.map((t) => [t.id, t]))
    const out = []
    saved.forEach((id) => {
      if (byId.has(id)) {
        out.push(byId.get(id))
        byId.delete(id)
      }
    })
    byId.forEach((t) => out.push(t))
    return out
  })()
  const TABS = ordered

  // Перестановка вкладки на одну позицию. Сохраняем ПОЛНЫЙ порядок
  // доступных вкладок, а не только переставленную: иначе при следующем
  // открытии документа с другим набором вкладок порядок был бы неполным.
  const moveTab = (idx, delta) => {
    const to = idx + delta
    if (to < 0 || to >= ordered.length) return
    const ids = ordered.map((t) => t.id)
    const [moved] = ids.splice(idx, 1)
    ids.splice(to, 0, moved)
    setTabOrderPref({ order: ids })
  }

  // #40 — Вкладка из адреса может быть недоступна этому пользователю (ссылка
  // от коллеги с другими правами, или решения от вас уже не ждут). Тогда
  // показываем первую доступную, а не пустоту. Набор вкладок зависит от
  // ролей, которые приходят асинхронно, поэтому пока TABS пуст — не трогаем.
  const activeTab = TABS.some((t) => t.id === tab) ? tab : TABS[0]?.id || tab

  // Данные вкладки грузим по ФАКТИЧЕСКИ открытой вкладке (#40).
  useEffect(() => { loadTab(activeTab) }, [activeTab, loadTab])

  // Поиск системных документов для связывания (ILIKE, частичное совпадение).
  useEffect(() => {
    if (linkMode !== 'system' || !linkSearch.trim()) { setLinkSearchResults([]); return }
    let cancelled = false
    const t = setTimeout(async () => {
      try {
        const res = await api.searchSystemDocuments(linkSearch.trim())
        if (!cancelled) setLinkSearchResults((res.items || []).filter((d) => String(d.id) !== String(documentId)))
      } catch (_) { if (!cancelled) setLinkSearchResults([]) }
    }, 300)
    return () => { cancelled = true; clearTimeout(t) }
  }, [linkSearch, linkMode, documentId])

  const pickLinkDoc = (d) => {
    if (linkDocs.some((x) => x.id === d.id)) return
    setLinkDocs([...linkDocs, { id: d.id, title: d.title, number: d.outgoing_number || `#${d.id}` }])
    setLinkSearch('')
    setLinkSearchResults([])
  }

  async function addLink() {
    setBusy(true); setError('')
    try {
      if (linkMode === 'system') {
        if (linkDocs.length === 0) return
        // Мультивыбор: одна связь на каждый выбранный системный документ.
        for (const d of linkDocs) {
          await api.createLink(documentId, d.id, linkType)
        }
        setLinkDocs([])
      } else {
        if (!linkNote.trim()) return
        await api.createLinkNote(documentId, linkNote.trim(), linkType)
        setLinkNote('')
      }
      setLinks((await api.getLinks(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="surface-1 overflow-hidden flex flex-col h-full min-w-0 w-full">
      <div className="flex flex-wrap border-b border-border shrink-0 gap-x-1">
        {TABS.map((t, idx) => (
          <button
            key={t.id}
            onClick={() => (reorderMode ? moveTab(idx, +1) : setTab(t.id))}
            onContextMenu={(e) => {
              // В режиме изменения порядка правый клик двигает влево: так
              // переставить можно одной рукой, без перетаскивания, которое на
              // узкой панели вкладок промахивается.
              if (!reorderMode) return
              e.preventDefault()
              moveTab(idx, -1)
            }}
            title={reorderMode ? 'Клик — правее, правый клик — левее' : undefined}
            className={`inline-flex items-center gap-1.5 px-2.5 py-2 text-xs whitespace-nowrap ${
              activeTab === t.id ? 'border-b-2 border-accent text-text-primary' : 'text-text-secondary'
            } ${t.id === 'decision' ? 'text-warning font-medium' : ''} ${
              reorderMode ? 'cursor-grab bg-surface-alt/60' : ''
            }`}
          >
            {/* Цветная иконка перед подписью. Цвет задаётся явно, а не
                наследуется: вкладка «Решение» и так окрашена, а остальным
                нужен свой смысловой цвет. */}
            {TAB_META[t.id] && (
              <Icon
                name={TAB_META[t.id].icon}
                size={13}
                className="shrink-0"
                style={{ color: TAB_META[t.id].color }}
              />
            )}
            {t.label}
            {/* #17 — количество рядом с подписью вкладки. Ноль не показываем:
                «Поручения 0» — это шум, пустая вкладка и так об этом скажет. */}
            {t.count > 0 && (
              <span className="ml-1 px-1 rounded bg-surface-alt text-[10px] text-text-secondary">
                {t.count}
              </span>
            )}
          </button>
        ))}
        {/* Порядок вкладок настраивает сам пользователь. Кнопка в конце
            панели, а не в настройках: переставлять удобнее там же, где
            вкладки видно. */}
        <button
          onClick={() => setReorderMode((v) => !v)}
          title={reorderMode
            ? 'Готово. Клик по вкладке — правее, правый клик — левее'
            : 'Изменить порядок вкладок'}
          className={`ml-auto px-2 py-2 text-xs ${reorderMode ? 'text-accent' : 'text-text-secondary'}`}
        >
          <Icon name="grip" size={14} />
        </button>
      </div>
      {reorderMode && (
        <div className="px-3 py-1.5 text-[11px] text-text-secondary border-b border-border bg-surface-alt/60">
          Клик по вкладке перемещает её правее, правый клик — левее. Порядок
          сохраняется и применяется ко всем документам.
        </div>
      )}

      <div className="p-3 flex-1 min-h-0 overflow-auto">
        {error && <div className="text-danger text-xs mb-2">{error}</div>}

        {/* #15 — решение по документу: первая вкладка, открывается сразу */}
        {activeTab === 'decision' && decisionSlot}
        {activeTab === 'route' && (
          <div className="space-y-4">
            {/*, п. 1 — схема текущего процесса ПЕРЕД списком.
                Сначала «где документ стоит», потом подробности по каждому
                этапу: список отвечает на второй вопрос, но не на первый. */}
            <RouteDiagram stages={stages} currentUserId={currentUserId} />
            {routeSlot}
          </div>
        )}
        {/* #38 — обсуждение отдельной вкладкой, во всю высоту панели */}
        {activeTab === 'chat' && <div className="h-full min-h-0">{chatSlot}</div>}
        {activeTab === 'control' && (
          <ControlTab
            documentId={documentId}
            doc={doc}
            canManage={canManage}
            patchDoc={patchDoc}
          />
        )}

        {activeTab === 'history' && (
          <ol className="space-y-1.5 text-sm">
            {(history || []).filter((e) => !HIDDEN_HISTORY_EVENTS.has(e.event_type)).map((e, i) => (
              <li key={i} className="flex justify-between border-b border-border last:border-0 pb-1.5">
                <span>
                  {STATUS_LABELS[e.event_type] || e.event_type}
                  {e.actor_name && <span className="text-text-secondary"> — {e.actor_name}</span>}
                  {e.comment && <span className="text-text-secondary"> «{e.comment}»</span>}
                </span>
                <span className="kicker whitespace-nowrap ml-2">{fmt(e.created_at)}</span>
              </li>
            ))}
            {history && history.filter((e) => !HIDDEN_HISTORY_EVENTS.has(e.event_type)).length === 0 && (
              <div className="text-text-secondary text-xs">Событий нет</div>
            )}
            {/* #8 — Данные о факте подписания (63-ФЗ) */}
            {sigs && sigs.length > 0 && (
              <li className="block pt-2">
                <div className="text-xs font-medium mb-1">Данные о подписи (Федеральный закон «Об электронной подписи» от 06.04.2011 № 63-ФЗ)</div>
                {sigs.map((s, i) => (
                  <div key={i} className="text-[11px] text-text-secondary border border-border rounded-md p-2 mb-1 space-y-0.5">
                    <div>{s.signer_fio}{s.signer_position ? `, ${s.signer_position}` : ''}</div>
                    <div>Тип: {s.signature_type} · {fmt(s.signed_at)}</div>
                    {/* Результат проверки ПЭП сервером: подпись сверяется с
                        серверным секретом, файл — с хэшем на момент подписи. */}
                    {s.verdict && (
                      <div className={s.valid ? 'text-success font-medium' : 'text-danger font-medium'}>
                        {s.valid ? '✓ ' : '✗ '}{s.verdict}
                      </div>
                    )}
                    {s.signature_hash && <div className="break-all">Отпечаток подписи: {s.signature_hash}</div>}
                    {s.document_hash && <div className="break-all">Хэш документа (SHA-256): {s.document_hash}</div>}
                  </div>
                ))}
              </li>
            )}
          </ol>
        )}

        {/* #13 — вкладка «Просмотры» удалена, её данные здесь: номер
            экземпляра присваивается ровно при первом просмотре, поэтому два
            списка одних и тех же людей приходилось сопоставлять глазами. */}
        {activeTab === 'copies' && (
          <div>
            <div className="text-text-secondary text-xs mb-2">
              Экземпляры документа: №1 — у автора (оригинал), далее по порядку получения
              (согласование, подпись, получатели, ознакомленные). Для каждого экземпляра
              показан первый и последний просмотр и их количество.
            </div>
            <ol className="space-y-1.5 text-sm">
              {(copies || []).map((c) => (
                <li key={c.copy_number} className="border-b border-border last:border-0 pb-1.5">
                  <div className="flex items-center justify-between">
                    <span>
                      <span className="kicker mr-2">Экз. № {c.copy_number}</span>
                      {c.full_name}
                      <span className="text-text-secondary"> · {COPY_REASON_LABELS[c.reason] || c.reason}</span>
                    </span>
                    <span className="kicker whitespace-nowrap ml-2">{fmt(c.assigned_at)}</span>
                  </div>
                  <div className="text-[11px] text-text-secondary mt-0.5">
                    {c.view_count > 0 ? (
                      <>
                        Просмотров: {c.view_count} · первый {fmt(c.first_view_at)}
                        {c.view_count > 1 && <> · последний {fmt(c.last_view_at)}</>}
                      </>
                    ) : (
                      'Ещё не открывал документ'
                    )}
                  </div>
                </li>
              ))}
              {copies && copies.length === 0 && <div className="text-text-secondary text-xs">Экземпляры ещё не выданы</div>}
            </ol>
          </div>
        )}

        {activeTab === 'prints' && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="text-text-secondary text-xs max-w-[70%]">
                Скачивание «на печать» доступно только с ролью «Печать» и выдаёт ТОЛЬКО маркированный PDF.
                После печати обязательно зарегистрируйте экземпляр в бумажном журнале (за других ставить нельзя).
              </div>
              {roles?.is_printer && (
                <div className="flex items-center gap-2">
                  <button
                    className="btn btn-primary font-medium whitespace-nowrap"
                    onClick={async () => {
                      setPrintDiag(null)
                      try { await api.downloadPrint(documentId); setPrints((await api.getPrints(documentId)).items || []) }
                      catch (e) {
                        setError(e.message || 'Не удалось скачать на печать')
                        // #11 — сразу показываем ТОЧНУЮ причину отказа.
                        try { setPrintDiag(await api.printDiagnostics(documentId)) } catch (_) { /* noop */ }
                      }
                    }}
                  >
                    Скачать на печать
                  </button>
                  <button
                    className="px-2 py-1.5 rounded-md border border-border text-xs whitespace-nowrap"
                    title="Проверить, почему документ не выдаётся на печать"
                    onClick={async () => {
                      setError('')
                      try { setPrintDiag(await api.printDiagnostics(documentId)) }
                      catch (e) { setError(e.message) }
                    }}
                  >
                    Проверить готовность
                  </button>
                </div>
              )}
            </div>
            {printDiag && (
              <div className="mb-3 border border-border rounded-md p-3 text-xs">
                <div className="font-medium mb-1">
                  {printDiag.ready_for_print
                    ? 'Документ готов к выдаче на печать'
                    : 'Документ НЕ готов к выдаче на печать — причины ниже'}
                </div>
                <ul className="space-y-0.5">
                  {(printDiag.checks || []).map((ch, i) => (
                    <li key={i} className={ch.ok ? 'text-success' : 'text-danger'}>
                      {ch.ok ? '✓' : '✗'} {ch.name}{ch.info ? `: ${ch.info}` : ''}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <ul className="space-y-2 text-sm">
              {(prints || []).map((p) => {
                const mine = p.user_id === currentUserId
                const f = regForm[p.id] || { reg_journal: '', reg_number: '' }
                return (
                  <li key={p.id} className="border border-border rounded-md p-2">
                    <div className="flex items-center justify-between">
                      <span>
                        <span className="kicker mr-2">Экз. № {p.instance_number || '—'} · Копия № {p.copy_number}</span>
                        {p.full_name}
                      </span>
                      <span className="kicker">скачано {fmt(p.printed_at)}</span>
                    </div>
                    {p.reg_at ? (
                      <div className="mt-1 flex items-center gap-2 flex-wrap">
                        <span className="text-success text-xs">
                          Зарегистрировано: журнал «{p.reg_journal}», № {p.reg_number}, {fmt(p.reg_at)} · {p.registrant_fio}
                        </span>
                        {mine && (
                          <button className="px-2 py-0.5 rounded border border-border text-xs"
                            onClick={() => setRegForm((s) => ({ ...s, [p.id]: { reg_journal: p.reg_journal || '', reg_number: p.reg_number || '', edit: true } }))}>
                            Изменить
                          </button>
                        )}
                      </div>
                    ) : null}
                    {mine && (!p.reg_at || (regForm[p.id] && regForm[p.id].edit)) ? (
                      <div className="mt-2 flex flex-wrap gap-2 items-end">
                        <input className="px-2 py-1 rounded border border-border bg-surface-alt text-xs" placeholder="Журнал"
                          value={f.reg_journal} onChange={(e) => setRegForm((s) => ({ ...s, [p.id]: { ...f, reg_journal: e.target.value } }))} />
                        <input className="px-2 py-1 rounded border border-border bg-surface-alt text-xs" placeholder="Рег. №"
                          value={f.reg_number} onChange={(e) => setRegForm((s) => ({ ...s, [p.id]: { ...f, reg_number: e.target.value } }))} />
                        <button className="px-2 py-1 rounded-md border border-accent text-accent text-xs"
                          disabled={!f.reg_journal || !f.reg_number}
                          onClick={async () => {
                            try { await api.registerPrint(documentId, p.id, { reg_journal: f.reg_journal, reg_number: f.reg_number }); setRegForm((s) => ({ ...s, [p.id]: undefined })); setPrints((await api.getPrints(documentId)).items || []) }
                            catch (e) { setError(e.message || 'Не удалось сохранить отметку') }
                          }}>
                          {p.reg_at ? 'Сохранить изменения' : 'Отметить регистрацию'}
                        </button>
                      </div>
                    ) : (!p.reg_at && !mine) ? (
                      <div className="text-warning text-xs mt-1">Не зарегистрировано (регистрирует только тот, кто скачал)</div>
                    ) : null}
                  </li>
                )
              })}
              {prints && prints.length === 0 && <div className="text-text-secondary text-xs">Документ ещё не скачивали на печать</div>}
            </ul>
          </div>
        )}

        {activeTab === 'recipients' && (
          <div>
            {/*, п. 3 — до подписи рассылка ПЛАНОВАЯ, и ею
                управляют автор и подписант. Пояснение рядом со списком
                обязательно: «плановый адресат» означает, что документа он пока
                не видит, и без этой строки человек не понимает, почему
                адресаты есть, а «просмотрено» ни у кого нет. */}
            {canEditPlanned && (
              <div className="mb-3 text-xs text-text-secondary border border-border rounded-md px-3 py-2">
                Документ ещё не подписан, поэтому рассылка <b>плановая</b>: перечисленные
                ниже адресаты документа пока не видят. Он уйдёт им автоматически в момент
                подписания. Список можно менять до подписи — изменять его вправе автор и
                подписант.
              </div>
            )}
            <ul className="space-y-1.5 text-sm mb-3">
              {(recipients || []).map((r) => (
                <li key={r.user_id} className="flex items-center justify-between border-b border-border last:border-0 pb-1.5">
                  <span>
                    {r.full_name}
                    {r.department_name && <span className="text-text-secondary"> · {r.department_name}</span>}
                    {r.incoming_number && <span className="kicker ml-1">{r.incoming_number}</span>}
                    {r.is_planned && <span className="kicker ml-1">плановый</span>}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className={r.completed_at ? 'text-success text-xs' : 'text-text-secondary text-xs'}>
                      {r.completed_at ? `исполнено ${fmt(r.completed_at)}` : (r.viewed ? 'просмотрено' : 'ожидает')}
                    </span>
                    {/* До подписи удаление идёт через замену ПЛАНОВОГО списка,
                        после подписи — через удаление получателя: это два
                        разных действия над разными сущностями, и один
                        обработчик для обоих был бы неверен. */}
                    {canEditPlanned && r.is_planned && (
                      <button
                        title="Убрать из плановой рассылки"
                        className="text-danger hover:text-danger/80 text-sm px-1"
                        onClick={async () => {
                          if (!confirm(`Убрать «${r.full_name}» из плановой рассылки?`)) return
                          try {
                            const left = (recipients || [])
                              .filter((x) => x.is_planned && x.user_id !== r.user_id)
                              .map((x) => ({ user_id: x.user_id, department_id: x.department_id }))
                            await api.updatePlannedRecipients(documentId, left)
                            setRecipients((await api.getRecipients(documentId)).items || [])
                            onChanged?.()
                          } catch (e) { alert(e.message || 'Не удалось изменить рассылку') }
                        }}
                      >
                        <Icon name="close" />
                      </button>
                    )}
                    {canSend && !r.is_planned && !r.viewed && !r.completed_at && (
                      <button
                        title="Удалить получателя (пока не просмотрел)"
                        className="text-danger hover:text-danger/80 text-sm px-1"
                        onClick={async () => {
                          if (!confirm(`Удалить получателя «${r.full_name}»?`)) return
                          try { await api.deleteRecipient(documentId, r.id); setRecipients((await api.getRecipients(documentId)).items || []) }
                          catch (e) { alert(e.message || 'Не удалось удалить получателя') }
                        }}
                      >
                        <Icon name="close" />
                      </button>
                    )}
                  </div>
                </li>
              ))}
              {recipients && recipients.length === 0 && (
                <div className="text-text-secondary text-xs">
                  {canEditPlanned ? 'Плановых адресатов нет.' : 'Документ ещё не направлен'}
                </div>
              )}
            </ul>

            {/* Добавление плановых адресатов до подписи (п. 3). */}
            {canEditPlanned && (
              <PlannedRecipientsEditor
                documentId={documentId}
                currentUserId={currentUserId}
                excludeIds={(recipients || []).map((r) => r.user_id)}
                onSaved={async () => {
                  setRecipients((await api.getRecipients(documentId)).items || [])
                  onChanged?.()
                }}
              />
            )}

            {/* Направление рассылке — автор/подписант, во вкладке «Рассылка»,
                с учётом уже показанных выше адресатов. */}
            {canSend && (
              <div className="border-t border-border pt-3 mb-3">
                <SendPanel
                  documentId={documentId}
                  plannedHint={docStatus === 'signed'}
                  excludeIds={(recipients || []).map((r) => r.user_id)}
                  onSent={async () => {
                    setRecipients((await api.getRecipients(documentId)).items || [])
                    onChanged?.()
                  }}
                />
              </div>
            )}
          </div>
        )}

        {activeTab === 'execution' && (
          <div>
            {/* Вкладка показывает СОСТОЯНИЕ отметки
                и ровно те действия, которые сервер разрешил. Прежде она
                показывала одну кнопку «Отметить исполненным» и исчезала после
                нажатия, а право на неё интерфейс определял сам — по признаку
                «я адресат рассылки». Отсюда обе жалобы: у исполнителя, не
                являющегося адресатом, кнопки не было (п. 21), а изменить или
                отменить поставленную отметку было нельзя вовсе (п. 22). */}
            {!execStatus && <div className="text-sm text-text-secondary">Загрузка…</div>}

            {execStatus && execStatus.department_name && (
              <div className="text-xs text-text-secondary mb-3">
                Входящий № <b className="nums">{execStatus.incoming_number || '—'}</b>
                {' · '}{execStatus.department_name}
              </div>
            )}

            {execStatus && execStatus.executed && (
              <div className="mb-3 border border-success/40 bg-success/5 rounded-md px-3 py-2 text-xs">
                <div className="text-success font-medium">Отметка об исполнении проставлена</div>
                <div className="mt-1">
                  {execStatus.executed_by_name || '—'}
                  {execStatus.executed_at ? ` · ${fmt(execStatus.executed_at)}` : ''}
                </div>
                {execStatus.note && (
                  <div className="mt-1 whitespace-pre-wrap">Отчёт: {execStatus.note}</div>
                )}
              </div>
            )}

            {execStatus && !execStatus.executed && execStatus.can_mark && (
              <p className="text-sm mb-3">
                Отметьте исполнение документа по входящему номеру вашего подразделения.
                Отметка одна на входящий номер. Она фиксируется в истории, попадает в
                отчёт по документу и учитывается в статусе исполнения.
              </p>
            )}

            <div className="flex flex-wrap gap-2">
              {execStatus?.can_mark && (
                <button
                  onClick={() => openExec('mark')}
                  className="px-4 py-2 rounded-md bg-success text-white text-sm font-medium"
                >
                  Отметить исполненным
                </button>
              )}
              {execStatus?.can_change && (
                <button onClick={() => openExec('change')} className="btn btn-secondary">
                  Изменить отчёт
                </button>
              )}
              {execStatus?.can_cancel && (
                <button onClick={() => openExec('cancel')} className="btn btn-danger">
                  Отменить отметку
                </button>
              )}
            </div>

            {/* Объяснение вместо пустого места: человек, у которого нет ни
                одной кнопки, должен понимать, чего ему не хватает — роли,
                резолюции или присвоенного входящего номера. */}
            {execStatus && !execStatus.can_mark && !execStatus.can_change
              && !execStatus.can_cancel && (
              <div className="text-sm text-text-secondary">{execStatus.reason || 'Действие недоступно.'}</div>
            )}

            {execStatus?.can_cancel && (
              <p className="text-[11px] text-text-secondary mt-3">
                Отмена отметки возвращает документ в работу и требует причины. И отмена,
                и изменение отчёта остаются в истории документа и в журнале аудита —
                прежний текст отчёта сохраняется в записи истории.
              </p>
            )}
          </div>
        )}

        {/* Окно отметки об исполнении: один компонент на три действия
            (поставить / изменить отчёт / отменить). Три отдельных окна были бы
            тремя копиями одной формы с разными заголовками. */}
        {execModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setExecModal(false)}>
            <div className="surface-1 p-5 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
              <h3 className="font-display text-base font-semibold mb-2">
                {execMode === 'cancel'
                  ? 'Отмена отметки об исполнении'
                  : execMode === 'change'
                    ? 'Изменение отчёта об исполнении'
                    : 'Отметка об исполнении'}
              </h3>
              <p className="text-xs text-text-secondary mb-3">
                {execMode === 'cancel'
                  ? 'Отметка будет снята, документ вернётся в работу. Причина обязательна: без неё потом невозможно понять, почему исполненный документ снова открыт.'
                  : execMode === 'change'
                    ? 'Исправьте текст отчёта. Время отметки и её автор не меняются — отметка остаётся свидетельством того, когда и кем работа закрыта; исправление попадёт в историю вместе с прежним текстом.'
                    : 'Подтвердите исполнение своей части документа. Отчёт о выполнении попадёт в отчёт по документу, поэтому напишите, что именно сделано.'}
              </p>
              <label className="block text-xs text-text-secondary mb-1">
                {execMode === 'cancel' ? 'Причина отмены (обязательно)' : 'Отчёт о выполнении (обязательно)'}
              </label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
                placeholder={execMode === 'cancel'
                  ? 'Например: «отметка поставлена по ошибке, документ не исполнен»'
                  : 'Например: «Исполнено, ответ направлен исх. №…»'}
                className="w-full mb-3 field"
              />
              {error && <div className="text-danger text-xs mb-2">{error}</div>}
              <div className="flex justify-end gap-2">
                <button onClick={() => setExecModal(false)} className="btn btn-secondary">
                  Закрыть
                </button>
                <button
                  onClick={submitExecution}
                  disabled={busy || !note.trim()}
                  className={'px-3 py-1.5 rounded-md text-white text-sm font-medium disabled:opacity-60 '
                    + (execMode === 'cancel' ? 'bg-danger' : 'bg-success')}
                >
                  {busy
                    ? 'Сохранение…'
                    : execMode === 'cancel'
                      ? 'Отменить отметку'
                      : execMode === 'change'
                        ? 'Сохранить отчёт'
                        : 'Отметить исполненным'}
                </button>
              </div>
            </div>
          </div>
        )}


        {activeTab === 'acquaint' && canAcquaint && (
          <div>
            <p className="text-xs text-text-secondary mb-2">
              Ознакомление сотрудников с документом. Кандидаты — из административно назначенных вам
              подразделений.
            </p>
            <AcquaintBlock
              documentId={documentId}
              onDone={async () => {
                setRecipients((await api.getRecipients(documentId)).items || [])
                onChanged?.()
              }}
            />
          </div>
        )}

        {activeTab === 'links' && (
          <div className="p-1">
            <ul className="space-y-1.5 text-sm mb-3">
              {(links || []).map((l, i) => (
                <li key={i} className="flex items-center justify-between border-b border-border last:border-0 pb-1.5">
                  {l.document_id ? (
                    // Системный документ — кликабельная ссылка.
                    <Link to={`/document/${l.document_id}`} className="text-accent hover:underline">
                      <span className="kicker mr-1">{l.number}</span>
                      {l.title}
                    </Link>
                  ) : (
                    // Несистемный (внешний/бумажный) документ — простой текст.
                    <span className="text-text-primary">
                      <span className="kicker mr-1">внешний</span>
                      {l.text_note}
                    </span>
                  )}
                  <div className="flex items-center gap-2 ml-2">
                    <span className="text-xs text-text-secondary whitespace-nowrap">
                      {LINK_TYPE_LABELS[l.link_type] || l.link_type}
                      {l.document_id ? (l.direction === 'incoming' ? ' ↩' : ' ↪') : ''}
                    </span>
                    {l.direction !== 'incoming' && (
                      <button
                        title="Удалить связь"
                        className="text-danger hover:text-danger/80 text-sm px-1"
                        onClick={async () => {
                          if (!confirm('Удалить связь?')) return
                          try { await api.deleteLink(documentId, l.link_id); setLinks((await api.getLinks(documentId)).items || []) }
                          catch (e) { alert(e.message || 'Не удалось удалить связь') }
                        }}
                      >
                        <Icon name="close" />
                      </button>
                    )}
                  </div>
                </li>
              ))}
              {links && links.length === 0 && (
                <div className="text-text-secondary text-xs">Связанных документов нет</div>
              )}
            </ul>

            <div className="border-t border-border pt-2 space-y-2">
              {!canManage && (
                <div className="text-xs text-text-secondary">Добавлять связи может только автор или подписант.</div>
              )}
              {canManage && (
              <>
              {/* Переключатель вида связи */}
              <div className="flex gap-1 text-xs">
                <button type="button" onClick={() => setLinkMode('system')}
                  className={`px-2 py-1 rounded-md border ${linkMode === 'system' ? 'border-accent text-accent' : 'border-border text-text-secondary'}`}>
                  Документ из системы
                </button>
                <button type="button" onClick={() => setLinkMode('external')}
                  className={`px-2 py-1 rounded-md border ${linkMode === 'external' ? 'border-accent text-accent' : 'border-border text-text-secondary'}`}>
                  Внешний документ
                </button>
              </div>

              {linkMode === 'system' && (
                <div className="relative">
                  {linkDocs.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-1">
                      {linkDocs.map((d) => (
                        <span key={d.id} className="inline-flex items-center gap-1 bg-accent/15 border border-accent/40 rounded-full px-2 py-0.5 text-xs">
                          <span className="kicker">{d.number}</span>{d.title}
                          <button type="button" className="text-danger ml-0.5" onClick={() => setLinkDocs(linkDocs.filter((x) => x.id !== d.id))}>×</button>
                        </span>
                      ))}
                    </div>
                  )}
                  <input
                    value={linkSearch}
                    onChange={(e) => setLinkSearch(e.target.value)}
                    placeholder="Поиск документа по названию/номеру…"
                    className="field w-full"
                  />
                  {linkSearchResults.length > 0 && (
                    <div className="absolute z-20 mt-1 w-full max-h-48 overflow-auto bg-surface border border-border rounded-md shadow-lg">
                      {linkSearchResults.map((d) => (
                        <button key={d.id} type="button" onClick={() => pickLinkDoc(d)}
                          className="w-full text-left px-3 py-1.5 text-sm hover:bg-surface-alt">
                          <span className="kicker mr-1">{d.outgoing_number || `#${d.id}`}</span>{d.title}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {linkMode === 'external' && (
                <input
                  value={linkNote}
                  onChange={(e) => setLinkNote(e.target.value)}
                  placeholder="Реквизиты внешнего документа (напр. «Приказ № 12 от 01.03.2025»)"
                  className="field w-full"
                />
              )}

              <div className="flex gap-2 items-end">
                <div className="flex-1">
                  <label className="block text-xs text-text-secondary mb-1">Тип связи</label>
                  <select value={linkType} onChange={(e) => setLinkType(e.target.value)}
                    className="field w-full">
                    {LINK_TYPE_OPTIONS.map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                </div>
                <button onClick={addLink}
                  disabled={busy || (linkMode === 'system' ? linkDocs.length === 0 : !linkNote.trim())}
                  className="btn btn-primary disabled:opacity-60">
                  Связать
                </button>
              </div>
              </>
              )}
            </div>
          </div>
        )}

        {activeTab === 'versions' && <VersionsPanel documentId={documentId} />}

        {activeTab === 'assignments' && (
          <ResolutionsPanel
            documentId={documentId}
            currentUserId={currentUserId}
            onChanged={onChanged}
          />
        )}
      </div>
    </div>
  )
}

// AcquaintBlock — ознакомление сотрудников с документом. Кандидаты — только из
// административно назначенных текущему пользователю подразделений (бэкенд
// /acquaint-candidates фильтрует). Мультивыбор.
function AcquaintBlock({ documentId, onDone }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])
  const [picked, setPicked] = useState([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [list, setList] = useState([])

  useEffect(() => {
    api.getAcquaintances(documentId).then((r) => setList(r.items || [])).catch(() => {})
  }, [documentId])

  useEffect(() => {
    if (!open) return
    let cancelled = false
    const t = setTimeout(async () => {
      try {
        const r = await api.acquaintCandidates(q.trim(), documentId)
        if (!cancelled) setResults(r.items || [])
      } catch (_) {
        if (!cancelled) setResults([])
      }
    }, q.trim() ? 250 : 0)
    return () => { cancelled = true; clearTimeout(t) }
  }, [q, open])

  async function submit() {
    if (picked.length === 0) return
    setBusy(true); setError('')
    try {
      await api.acquaint(documentId, picked.map((p) => p.id))
      setPicked([])
      setOpen(false)
      setList((await api.getAcquaintances(documentId)).items || [])
      onDone?.()
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const pickedIds = new Set(picked.map((p) => p.id))

  return (
    <div className="border-t border-border pt-3">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs text-text-secondary">Ознакомление</p>
        <button onClick={() => setOpen((v) => !v)} className="text-xs text-accent">
          {open ? 'Скрыть' : 'Ознакомить сотрудников'}
        </button>
      </div>

      {list.length > 0 && (
        <ul className="text-xs text-text-secondary mb-2 space-y-0.5">
          {list.map((a) => (
            <li key={a.user_id}>
              {a.full_name} <span className="opacity-70">— ознакомил {a.acquainted_by_name}</span>
            </li>
          ))}
        </ul>
      )}

      {open && (
        <div>
          {picked.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-1">
              {picked.map((p) => (
                <span key={p.id} className="inline-flex items-center gap-1 bg-accent/15 border border-accent/40 rounded-full px-2 py-0.5 text-xs">
                  {p.full_name}
                  <button type="button" className="text-danger ml-0.5" onClick={() => setPicked(picked.filter((x) => x.id !== p.id))}>×</button>
                </span>
              ))}
            </div>
          )}
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск сотрудника для ознакомления…"
            className="field mb-1"
          />
          <div className="max-h-40 overflow-auto border border-border rounded-md mb-2">
            {results.filter((r) => !pickedIds.has(r.id)).length === 0 && (
              <div className="px-3 py-2 text-xs text-text-secondary">
                {q.trim() ? 'Ничего не найдено' : 'Нет доступных для ознакомления сотрудников'}
              </div>
            )}
            {results.filter((r) => !pickedIds.has(r.id)).map((r) => (
              <button key={r.id} type="button"
                onClick={() => { setPicked([...picked, r]); setQ('') }}
                className="w-full text-left px-3 py-1.5 text-sm hover:bg-surface-alt">
                {r.full_name}
                {r.department_name && <span className="text-text-secondary text-xs ml-2">{r.department_name}</span>}
              </button>
            ))}
          </div>
          {error && <div className="text-danger text-xs mb-1">{error}</div>}
          <button onClick={submit} disabled={busy || picked.length === 0}
            className="btn btn-primary w-full justify-center disabled:opacity-60">
            {busy ? 'Ознакомление…' : `Ознакомить (${picked.length})`}
          </button>
        </div>
      )}
    </div>
  )
}

// ControlTab — постановка/снятие с контроля и выбор/смена контролёров (#4).
// Автор (canManage) может менять; остальные видят статус и список контролёров.
function ControlTab({ documentId, doc, canManage, patchDoc }) {
  const [onControl, setOnControl] = useState(!!doc?.on_control)
  const [controller, setController] = useState([]) // #4 — несколько контролёров
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState(false)

  // Грузим текущих контролёров документа.
  useEffect(() => {
    let cancelled = false
    api.getDocumentControllers(documentId).then((r) => {
      if (cancelled) return
      setController((r.items || []).map((cn) => ({
        id: cn.user_id, full_name: cn.full_name, position: cn.position,
        department_name: cn.department_name, city: cn.city,
      })))
    }).catch(() => {})
    return () => { cancelled = true }
  }, [documentId])

  async function save() {
    setBusy(true); setError(''); setSaved(false)
    try {
      await api.setControl(documentId, onControl, controller.map((c) => c.id))
      setSaved(true)
      patchDoc?.({
        on_control: onControl,
        controller_id: controller[0]?.id || null,
        controller_name: controller[0]?.full_name || null,
      })
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  if (!canManage) {
    return (
      <div className="p-1 text-sm">
        {doc?.on_control ? (
          <div className="text-danger">
            ● Документ на контроле
            {controller.length > 0 && (
              <span className="text-text-secondary"> — контролёры: {controller.map((c) => c.full_name).join(', ')}</span>
            )}
          </div>
        ) : (
          <div className="text-text-secondary">Документ не на контроле</div>
        )}
      </div>
    )
  }

  return (
    <div className="p-1 space-y-3">
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={onControl} onChange={(e) => setOnControl(e.target.checked)} />
        Документ на контроле
      </label>
      {onControl && (
        <div>
          <label className="block text-xs text-text-secondary mb-1">Контролёры (можно несколько)</label>
          <PersonPicker group="controller" multiple value={controller} onChange={setController} />
        </div>
      )}
      {error && <div className="text-danger text-xs">{error}</div>}
      {saved && <div className="text-success text-xs">Сохранено</div>}
      <button onClick={save} disabled={busy}
        className="btn btn-primary disabled:opacity-60">
        {busy ? 'Сохранение…' : 'Сохранить'}
      </button>
    </div>
  )
}

// PlannedRecipientsEditor — добавление ПЛАНОВЫХ адресатов до подписи
// (, п. 3).
//
// Почему отдельный компонент, а не SendPanel. SendPanel НАПРАВЛЯЕТ документ:
// он вызывает /send, выдаёт адресатам доступ и рассылает уведомления — это
// действие после подписи. До подписи направлять нечего, и список правится
// целиком через updatePlannedRecipients. Попытка использовать одну панель для
// обоих случаев привела бы к тому, что до подписи документ уходил бы адресатам
// преждевременно.
//
// Отправляется ПОЛНЫЙ список (уже имеющиеся плюс добавленные): сервер
// заменяет плановых адресатов целиком. Поэтому existing передаётся снаружи —
// без него сохранение стёрло бы тех, кто был выбран при создании документа.
function PlannedRecipientsEditor({ documentId, currentUserId, excludeIds, onSaved }) {
  const [picked, setPicked] = useState([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [existing, setExisting] = useState([])
  const exclude = [...(excludeIds || []), ...(currentUserId ? [currentUserId] : [])]

  // Текущий плановый список читается здесь, а не берётся из props: он нужен
  // ровно в момент сохранения, и держать его копию в двух местах значило бы
  // однажды сохранить устаревшую.
  const loadExisting = useCallback(async () => {
    try {
      const r = await api.getRecipients(documentId)
      setExisting((r.items || []).filter((x) => x.is_planned))
    } catch (_) { /* список уже показан выше, повторная ошибка не нужна */ }
  }, [documentId])

  useEffect(() => { loadExisting() }, [loadExisting])

  const save = async () => {
    if (picked.length === 0) return
    setBusy(true); setError('')
    try {
      const all = [
        ...existing.map((x) => ({ user_id: x.user_id, department_id: x.department_id })),
        ...picked.map((x) => ({ user_id: x.id, department_id: x.department_id })),
      ]
      await api.updatePlannedRecipients(documentId, all)
      setPicked([])
      await loadExisting()
      onSaved?.()
    } catch (e) {
      setError(e.message || 'Не удалось изменить рассылку')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="border-t border-border pt-3">
      <h4 className="text-sm font-medium mb-1">Добавить плановых адресатов</h4>
      <p className="text-[11px] text-text-secondary mb-2">
        Адресатом может быть только сотрудник канцелярии или дежурный в своём
        подразделении — это проверяет система. Документ уйдёт выбранным
        автоматически в момент подписания.
      </p>
      {/* Себя в собственную рассылку не включаем: документ и так виден
          автору и подписанту, а лишний адресат портит счётчик «исполнили N
          из M». Так же сделано в форме создания и изменения документа. */}
      <RecipientGroupPicker value={picked} onChange={setPicked} excludeIds={exclude} />
      <PersonPicker group="recipients" multiple value={picked} onChange={setPicked} excludeIds={exclude} />
      {error && <div className="text-danger text-xs mt-1">{error}</div>}
      <button
        onClick={save}
        disabled={busy || picked.length === 0}
        className="btn btn-primary mt-2 disabled:opacity-60"
      >
        {busy ? 'Сохранение…' : 'Добавить в рассылку'}
      </button>
    </div>
  )
}
