// Загрузчики страниц и предзагрузка маршрутов.
//
// Один словарь на всё приложение: App.jsx оборачивает загрузчики в lazy(),
// а меню вызывает prefetchRoute() при наведении/фокусе — к моменту клика
// чанк уже в кэше браузера, переход мгновенный.
export const loaders = {
  layout: () => import('./components/Layout'),
  login: () => import('./pages/LoginPage'),
  sso: () => import('./pages/SsoPage'),
  documents: () => import('./pages/DocumentsListPage'),
  document: () => import('./pages/DocumentDetailPage'),
  create: () => import('./pages/CreateDocumentPage'),
  registry: () => import('./pages/RegistryPage'),
  resolutions: () => import('./pages/ResolutionsPage'),
  history: () => import('./pages/HistoryPage'),
  dashboard: () => import('./pages/DashboardPage'),
  admin: () => import('./pages/AdminPage'),
  metrics: () => import('./pages/AdminDashboardPage'),
  audit: () => import('./pages/AuditPage'),
}

function routeKey(path) {
  if (path.startsWith('/registry')) return 'registry'
  if (path.startsWith('/resolutions')) return 'resolutions'
  if (path.startsWith('/history')) return 'history'
  if (path.startsWith('/dashboard')) return 'dashboard'
  if (path.startsWith('/documents')) return 'documents'
  if (path.startsWith('/document/new')) return 'create'
  if (path.startsWith('/document/')) return 'document'
  if (path.startsWith('/admin/metrics')) return 'metrics'
  if (path.startsWith('/admin/audit')) return 'audit'
  if (path.startsWith('/admin')) return 'admin'
  if (path.startsWith('/sso')) return 'sso'
  if (path.startsWith('/login')) return 'login'
  return null
}

const done = new Set()

function saveData() {
  try {
    const c = navigator.connection
    return !!(c && (c.saveData || /(^|-)2g$/.test(c.effectiveType || '')))
  } catch (_) {
    return false
  }
}

// Предзагрузка чанка маршрута. Повторные вызовы и ошибки сети безвредны.
export function prefetchRoute(path) {
  if (saveData()) return
  const key = routeKey(path || '')
  if (!key || done.has(key)) return
  done.add(key)
  loaders[key]().catch(() => done.delete(key))
}

// В простое браузера подгружаем самые частые страницы после входа.
export function idlePrefetch(paths = ['/documents/all', '/document/0', '/resolutions']) {
  if (saveData()) return
  const run = () => paths.forEach(prefetchRoute)
  if ('requestIdleCallback' in window) window.requestIdleCallback(run, { timeout: 4000 })
  else setTimeout(run, 2000)
}
