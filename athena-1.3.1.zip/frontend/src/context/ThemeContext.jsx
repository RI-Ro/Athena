import React, { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { api, isAuthenticated } from '../api/client'

// 10 тем: 5 тёмных + 5 светлых; по умолчанию — light («Светлое оформление 1»).
// Названия тем убраны: выбор оформления идёт по
// образцам цвета, а поле label нигде не читалось бы и рассинхронизировалось
// бы с настоящими цветами.
export const THEMES = [
  { id: 'balun', dark: true },
  { id: 'midnight', dark: true },
  { id: 'carbon', dark: true },
  { id: 'graphite-neon', dark: true },
  { id: 'ember', dark: true },
  { id: 'light', dark: false },
  { id: 'paper', dark: false },
  { id: 'mint', dark: false },
  { id: 'frost', dark: false },
  { id: 'rose', dark: false },
]

const ThemeContext = createContext(null)

export function ThemeProvider({ children }) {
  // Тема — настройка учётной записи (сервер, ui.theme). localStorage — копия
  // для первого кадра: страница входа и первая отрисовка до ответа сервера.
  const [theme, setThemeState] = useState(() => {
    // По умолчанию — «Светлое оформление 1» (тема light), пока пользователь
    // не выбрал другую.
    try { return localStorage.getItem('athena_theme') || 'light' } catch (_) { return 'light' }
  })

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
    try { localStorage.setItem('athena_theme', theme) } catch (_) { /* noop */ }
  }, [theme])

  // Выбор пользователя: применяется и сохраняется на сервере.
  const setTheme = useCallback((id) => {
    setThemeState(id)
    if (isAuthenticated()) api.savePreference('ui.theme', { id }).catch(() => {})
  }, [])

  // После входа — тема с сервера (выбранная на другом компьютере).
  const loadServerTheme = useCallback(() => {
    api.getPreference('ui.theme').then((p) => {
      if (p && typeof p.id === 'string' && THEMES.some((t) => t.id === p.id)) setThemeState(p.id)
    }).catch(() => {})
  }, [])

  return <ThemeContext.Provider value={{ theme, setTheme, loadServerTheme }}>{children}</ThemeContext.Provider>
}

export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider')
  return ctx
}
