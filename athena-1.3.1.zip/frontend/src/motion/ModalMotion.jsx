import { useEffect } from 'react'
import { animate } from 'motion'
import { prefersReducedMotion } from './presets'

// ModalMotion — анимация появления ВСЕХ модальных окон разом.
//
// В проекте больше десятка окон, у каждого своя разметка вида
//   <div class="fixed inset-0 … z-50"> <div class="панель"> … </div> </div>
// Переписывать каждое значило бы трогать двенадцать файлов ради одного и того
// же эффекта и забывать про следующее окно. Поэтому один наблюдатель ловит
// появление такого оверлея в DOM: затемнение плавно проявляется, панель
// всплывает с лёгким масштабом. Выхода (exit) нет: окна размонтируются
// условным рендером, и закрытие остаётся мгновенным — как и раньше.
export default function ModalMotion() {
  useEffect(() => {
    if (prefersReducedMotion()) return undefined

    const isOverlay = (el) =>
      el.nodeType === 1 &&
      el.classList.contains('fixed') &&
      el.classList.contains('inset-0') &&
      el.classList.contains('z-50')

    const play = (overlay) => {
      // Полноэкранный просмотрщик документа тоже fixed inset-0 z-50, но
      // это не диалог — ему достаточно лёгкого проявления.
      animate(overlay, { opacity: [0, 1] }, { duration: 0.18, ease: 'easeOut' })
      const panel = overlay.firstElementChild
      if (panel && /bg-black/.test(overlay.className)) {
        animate(
          panel,
          { opacity: [0, 1], scale: [0.965, 1], y: [14, 0] },
          { type: 'spring', stiffness: 460, damping: 34 },
        )
      }
    }

    const observer = new MutationObserver((records) => {
      for (const r of records) {
        r.addedNodes.forEach((n) => {
          if (isOverlay(n)) play(n)
        })
      }
    })
    observer.observe(document.body, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [])

  return null
}
