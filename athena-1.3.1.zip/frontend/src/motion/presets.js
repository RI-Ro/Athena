// Общие пресеты движения. Один набор на весь интерфейс, чтобы анимации
// ощущались как одна система: короткие, с мягкой пружиной, без «качелей».
//
// Манера — по образцу интерфейсов Manus: элементы не «выскакивают», а
// мягко всплывают на 6–10 px с прозрачностью, пружина критически
// демпфирована (без перелёта), задержки в списках не больше ~0,3 с в сумме.

export const EASE_OUT = [0.23, 1, 0.32, 1]

export const spring = { type: 'spring', stiffness: 420, damping: 36, mass: 0.9 }
export const springSoft = { type: 'spring', stiffness: 260, damping: 30 }

// Появление блока.
export const fadeUp = {
  hidden: { opacity: 0, y: 8 },
  show: { opacity: 1, y: 0, transition: { duration: 0.26, ease: EASE_OUT } },
}

// Контейнер для каскада детей. staggerChildren мал намеренно: в система список
// открывают по двадцать раз в день, и длинный каскад быстро начинает мешать.
export const stagger = (step = 0.035, delay = 0) => ({
  hidden: {},
  show: { transition: { staggerChildren: step, delayChildren: delay } },
})

// Задержка строки таблицы по индексу; после 14-й строки не растёт.
export const rowDelay = (i) => Math.min(i, 14) * 0.022

export const prefersReducedMotion = () =>
  typeof window !== 'undefined' &&
  typeof window.matchMedia === 'function' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches
