import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { usePreference } from '../lib/usePreference'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import { fmtDateTime } from '../utils/format'
import { eventLabel, HIDDEN_HISTORY_EVENTS, HISTORY_GROUPS, historyGroup } from '../lib/historyLabels'

// «История» — всё, что происходит с документами, доступными пользователю:
// сообщения, регистрация, резолюции и отчёты, отметки об исполнении, подписи,
// согласование. Новые записи подтягиваются онлайн.
const PAGE = 100

export default function HistoryPage() {
  const [items, setItems] = useState([])
  const [historyPref, setHistoryPref] = usePreference('filters.history', { group: 'all' })
  const group = historyPref.group || 'all'
  const setGroup = (g) => setHistoryPref({ group: g })
  const [q, setQ] = useState('')
  const [loading, setLoading] = useState(true)
  const [cursor, setCursor] = useState('') // курсор следующей страницы ('' — страниц больше нет)
  const [loadingMore, setLoadingMore] = useState(false)
  const [error, setError] = useState('')

  const keyOf = (e) => `${e.src}-${e.id}`
  const cmp = (x, y) =>
    y.created_at.localeCompare(x.created_at) || y.src - x.src || y.id - x.id

  // load — первая страница. При онлайн-обновлении уже подгруженные ниже
  // страницы НЕ сбрасываются: новая первая страница объединяется со списком.
  const load = useCallback(async () => {
    try {
      const r = await api.getGlobalHistory({ limit: PAGE })
      const fresh = r.items || []
      setItems((cur) => {
        const m = new Map(cur.map((e) => [keyOf(e), e]))
        fresh.forEach((e) => m.set(keyOf(e), e))
        return [...m.values()].sort(cmp)
      })
      if (!cur0.current) { setCursor(r.next_cursor || ''); cur0.current = true }
      setError('')
    } catch (e) {
      setError(e.message || 'Не удалось загрузить историю')
    } finally {
      setLoading(false)
    }
  }, [])
  const cur0 = React.useRef(false)

  useEffect(() => { load() }, [load])

  useEffect(() => {
    let timer = null
    const onChanged = () => { clearTimeout(timer); timer = setTimeout(load, 700) }
    window.addEventListener('athena:document_changed', onChanged)
    window.addEventListener('athena:changed', onChanged)
    return () => {
      clearTimeout(timer)
      window.removeEventListener('athena:document_changed', onChanged)
      window.removeEventListener('athena:changed', onChanged)
    }
  }, [load])

  async function loadMore() {
    if (!cursor || loadingMore) return
    setLoadingMore(true)
    try {
      const r = await api.getGlobalHistory({ limit: PAGE, cursor })
      const older = r.items || []
      setItems((cur) => {
        const m = new Map(cur.map((e) => [keyOf(e), e]))
        older.forEach((e) => m.set(keyOf(e), e))
        return [...m.values()].sort(cmp)
      })
      setCursor(r.next_cursor || '')
    } catch (e) { setError(e.message) } finally { setLoadingMore(false) }
  }

  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase()
    return items.filter((e) => {
      if (HIDDEN_HISTORY_EVENTS.has(e.event_type)) return false
      if (group !== 'all' && historyGroup(e.event_type) !== group) return false
      if (!needle) return true
      return [e.document_title, e.actor_name, e.comment, eventLabel(e.event_type), e.outgoing_number]
        .some((v) => (v || '').toLowerCase().includes(needle))
    })
  }, [items, group, q])

  return (
    <div className="p-6 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-xl font-semibold">История</h1>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Поиск по документу, автору, тексту"
          className="field w-72 max-w-full"
        />
      </div>

      <div className="flex flex-wrap gap-1.5">
        {HISTORY_GROUPS.map(([id, label]) => (
          <button
            key={id}
            onClick={() => setGroup(id)}
            className={`px-2.5 py-1 text-xs rounded-full border ${
              group === id ? 'bg-accent text-accent-contrast border-accent' : 'border-border text-text-secondary hover:bg-surface-alt'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {error && <div className="text-danger text-sm">{error}</div>}

      <ol className="surface-1 divide-y divide-border">
        {shown.map((e, i) => (
          <li key={`${keyOf(e)}-${i}`} className="px-4 py-2.5 text-sm flex flex-wrap justify-between gap-x-4">
            <div className="min-w-0">
              <div>
                <span className="font-medium">{eventLabel(e.event_type)}</span>
                {e.actor_name && <span className="text-text-secondary"> — {e.actor_name}</span>}
              </div>
              {e.comment && <div className="text-text-secondary break-words">«{e.comment}»</div>}
              <Link to={`/document/${e.document_id}`} className="text-accent text-xs hover:underline">
                {e.document_title || `Документ № ${e.document_id}`}{e.outgoing_number ? ` · № ${e.outgoing_number}` : ''}
              </Link>
            </div>
            <div className="kicker whitespace-nowrap">{fmtDateTime(e.created_at)}</div>
          </li>
        ))}
        {!loading && shown.length === 0 && <li className="px-4 py-8 text-center text-text-secondary">Событий нет</li>}
        {loading && <li className="px-4 py-8 text-center text-text-secondary">Загрузка…</li>}
      </ol>

      {cursor && (
        <button onClick={loadMore} disabled={loadingMore} className="btn btn-secondary disabled:opacity-60">
          {loadingMore ? 'Загрузка…' : 'Показать ещё'}
        </button>
      )}
    </div>
  )
}
