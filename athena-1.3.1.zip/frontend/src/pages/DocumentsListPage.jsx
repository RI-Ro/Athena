import React, { useEffect, useRef, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import Icon from '../components/Icon'
import FilterPersonPicker from '../components/FilterPersonPicker'
import Pagination from '../components/Pagination'
import PersonPicker from '../components/PersonPicker'
import { fmtDateTime, fmtDate, docYears } from '../utils/format'
import { motion } from 'motion/react'
import { rowDelay, EASE_OUT } from '../motion'
import { mix } from '../lib/colorMix'

const STATUS_LABELS = {
  draft: 'Черновик',
  on_approval_hierarchy: 'Согласование (иерархия)',
  on_approval_cross_dept: 'Согласование (межвед.)',
  on_signing: 'На подписи',
  signed: 'Подписан',
  sent: 'Отправлен',
  in_progress: 'В работе',
  executed: 'Исполнен',
  archived: 'В архиве',
  rejected: 'Отклонён',
}

const STATUS_COLORS = {
  draft: 'text-text-secondary',
  on_approval_hierarchy: 'text-warning',
  on_approval_cross_dept: 'text-warning',
  on_signing: 'text-warning',
  signed: 'text-accent',
  sent: 'text-accent',
  in_progress: 'text-accent-2',
  executed: 'text-success',
  archived: 'text-text-secondary',
  rejected: 'text-danger',
}

const CATEGORY_TITLES = {
  all: 'Все документы',
  favorites: 'Избранное',
  awaiting: 'Ожидают регистрации',
  print_unregistered: 'На регистрацию',
  outgoing: 'Исходящие',
  incoming: 'Входящие',
  on_approval: 'На согласовании',
  on_signing: 'На подписи',
  my_resolutions: 'Резолюции Вам',
  control: 'На контроле',
  executed: 'Исполнено',
  archive: 'Архив',
}

// #29 — Field объявлен НА ВЕРХНЕМ УРОВНЕ модуля. Если объявить его внутри
// компонента, React на каждый рендер получает новый тип компонента, размонтирует
// поддерево и поле ввода теряет фокус после первого же символа.
function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs text-text-secondary mb-1">{label}</label>
      {children}
    </div>
  )
}

const PAGE_SIZE = 20
const SEARCH_DEBOUNCE_MS = 300

const EMPTY_FILTERS = {
  status: '', onControl: '', number: '', incomingNumber: '', categoryId: '',
  signedFrom: '', signedTo: '', createdFrom: '', createdTo: '', dueFrom: '', dueTo: '',
  author: [], signer: [], controller: [],
  // --- Группа D ---
  content: '',        // #4 — поиск по СОДЕРЖИМОМУ файла документа
  specialMarkId: '',  // #26 — особая отметка
  participant: null,  // #28 — любое участие человека в документе
  authorP: null,      // #28 — автор (без ограничения иерархией, включая уволенных)
  signerP: null,      // #28 — подписант (то же)
}

// #3 — Ключ, под которым состояние фильтров хранится НА СЕРВЕРЕ (а не в
// localStorage): требование — «для каждого пользователя», то есть настройки
// должны следовать за человеком, а не за браузером.
const FILTERS_PREF_KEY = 'filters.documents'

export default function DocumentsListPage() {
  const { category = 'all' } = useParams()
  const navigate = useNavigate()

  const [page, setPage] = useState(1)
  const [data, setData] = useState({ items: [], total_count: 0, page: 1, page_size: PAGE_SIZE })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [searchInput, setSearchInput] = useState('')
  const [activeQuery, setActiveQuery] = useState('')
  const [f, setF] = useState(EMPTY_FILTERS)          // применённые фильтры (по ним грузим)
  const [draft, setDraft] = useState(EMPTY_FILTERS)   // #29 — черновик, правится полями
  const [showFilters, setShowFilters] = useState(false)
  const [counts, setCounts] = useState({})
  const [modalDoc, setModalDoc] = useState(null)
  const [approversDoc, setApproversDoc] = useState(null)
  const [incomingDoc, setIncomingDoc] = useState(null)
  const [archiveYear, setArchiveYear] = useState('') // фильтр года для архива ('' = все)
  const [categories, setCategories] = useState([])
  const [specialMarks, setSpecialMarks] = useState([])      // #26
  const [indexStatus, setIndexStatus] = useState(null)      // #4 — прогресс индексации
  // #3 — пока сохранённые фильтры не прочитаны, их НЕ перезаписываем: иначе
  // первый же рендер со пустым состоянием затёр бы то, что пользователь
  // сохранил в прошлый раз.
  const prefsLoadedRef = useRef(false)

  useEffect(() => { api.listCategories().then((r) => setCategories(r.items || [])).catch(() => {}) }, [])
  useEffect(() => { api.getSpecialMarks().then((r) => setSpecialMarks(r.items || [])).catch(() => {}) }, [])

  // #4 — Прогресс фоновой индексации содержимого PDF.
  //
  // Запрашивается только когда открыты фильтры: пока пользователь не искал по
  // содержимому, этот счётчик ему не нужен, а запрос лишний. Пока индексация
  // не завершена, поиск по содержимому даёт НЕПОЛНЫЙ результат, и пользователь
  // должен это видеть — иначе он решит, что документа в системе нет.
  useEffect(() => {
    if (!showFilters) return undefined
    let alive = true
    const tick = () => api.getSearchIndexStatus()
      .then((st) => { if (alive) setIndexStatus(st) })
      .catch(() => {})
    tick()
    const t = setInterval(tick, 15000)
    return () => { alive = false; clearInterval(t) }
  }, [showFilters])

  // #3 — Чтение сохранённого состояния фильтров при входе в категорию.
  useEffect(() => {
    let alive = true
    prefsLoadedRef.current = false
    api.getPreference(FILTERS_PREF_KEY)
      .then((saved) => {
        if (!alive) return
        const forCat = saved && saved[category]
        if (forCat) {
          // Сливаем с EMPTY_FILTERS: в сохранённом состоянии может не быть
          // полей, добавленных в форму позже, и без слияния они стали бы
          // undefined, а поля ввода — «неуправляемыми».
          const restored = { ...EMPTY_FILTERS, ...forCat }
          setDraft(restored)
          setF(restored)
          if (typeof forCat.q === 'string') {
            setSearchInput(forCat.q)
            setActiveQuery(forCat.q)
          }
          setShowFilters(true)
        }
      })
      .catch(() => {})
      .finally(() => { if (alive) prefsLoadedRef.current = true })
    return () => { alive = false }
  }, [category])

  // Поля правят ЧЕРНОВИК; применение — по кнопке «Найти» (#29).
  const setFilter = (patch) => setDraft((prev) => ({ ...prev, ...patch }))
  const applyFilters = () => {
    setF(draft)
    setActiveQuery(searchInput.trim())
    setPage(1)
    // #3 — Сохраняем состояние ПО КАТЕГОРИЯМ: у «Входящих» и «Архива» фильтры
    // осмысленно разные, и один общий набор был бы неудобен.
    if (!prefsLoadedRef.current) return
    api.getPreference(FILTERS_PREF_KEY)
      .then((saved) => api.savePreference(FILTERS_PREF_KEY, {
        ...(saved || {}),
        [category]: { ...draft, q: searchInput.trim() },
      }))
      .catch(() => { /* не критично: фильтры применились, просто не запомнились */ })
  }

  useEffect(() => {
    setPage(1)
    setSearchInput('')
    setActiveQuery('')
    setF(EMPTY_FILTERS)
    setDraft(EMPTY_FILTERS)
  }, [category])

  useEffect(() => {
    const t = setTimeout(() => {
      setActiveQuery(searchInput.trim())
      setPage(1)
    }, SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  const hasAnyFilter = Boolean(
    activeQuery || f.status || f.onControl || f.number || f.incomingNumber || f.categoryId ||
    f.signedFrom || f.signedTo || f.createdFrom || f.createdTo || f.dueFrom || f.dueTo ||
    f.author.length || f.signer.length || f.controller.length ||
    f.content || f.specialMarkId || f.participant || f.authorP || f.signerP
  )

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    // Ограничения, вытекающие из текущей категории (вкладки) — чтобы поиск/
    // фильтр работал В ПРЕДЕЛАХ категории, а не по всей базе.
    const catParams = {}
    if (category === 'control') catParams.onControl = 'true'
    else if (category === 'executed') catParams.status = 'executed'
    else if (category === 'archive') catParams.status = 'archived'
    else if (category === 'on_signing') catParams.status = 'on_signing'
    else if (category === 'on_approval') catParams.status = 'on_approval_hierarchy,on_approval_cross_dept'
    try {
      const res = hasAnyFilter
        ? await api.searchDocuments({
            category, // ограничиваем поиск пределами категории
            q: activeQuery || undefined,
            status: f.status || catParams.status || undefined,
            onControl: f.onControl || catParams.onControl || undefined,
            number: f.number || undefined,
            incomingNumber: f.incomingNumber || undefined,
            categoryId: f.categoryId || undefined,
            signedFrom: f.signedFrom || undefined,
            signedTo: f.signedTo || undefined,
            createdFrom: f.createdFrom || undefined,
            createdTo: f.createdTo || undefined,
            dueFrom: f.dueFrom || undefined,
            dueTo: f.dueTo || undefined,
            // Автор/подписант могут приходить из двух мест: старые
            // мультипикеры (по иерархии) и новые фильтровые (#28, без
            // ограничений). Приоритет у фильтрового — он шире.
            authorId: f.authorP?.id || f.author[0]?.id || undefined,
            signerId: f.signerP?.id || f.signer[0]?.id || undefined,
            controllerId: f.controller[0]?.id || undefined,
            content: f.content || undefined,
            specialMarkId: f.specialMarkId || undefined,
            participantId: f.participant?.id || undefined,
            page,
            pageSize: PAGE_SIZE,
          })
        : await api.listDocuments({
            category,
            page,
            pageSize: PAGE_SIZE,
            year: category === 'archive' && archiveYear ? archiveYear : undefined,
          })
      setData(res)
      // Доп. реквизиты строк (автор, подписант, дата подписи, вх. номера,
      // счётчик адресатов) подтягиваются пакетно эффектом ниже по всем id.
    } catch (err) {
      setError(err.message || 'Не удалось загрузить список документов')
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category, page, activeQuery, f, archiveYear])

  useEffect(() => { load() }, [load])

  // #16 — Живое обновление списка.
  //
  // Событие приходит из колокола (единственное WS-соединение приложения),
  // который получает его от сервера только для тех пользователей, кому
  // документ доступен — список адресатов строится из document_access, то есть
  // ровно из тех, кого пропустит RLS. Сам список после события перечитывается
  // обычным REST-запросом, где RLS отрабатывает как всегда, поэтому увидеть
  // чужое нельзя даже при ошибочно присланном событии.
  //
  // Перечитывание отложено (debounce): при массовой рассылке документа
  // событий приходит сразу много, и без задержки список дёргался бы на каждое.
  useEffect(() => {
    let timer = null
    function onChanged() {
      clearTimeout(timer)
      timer = setTimeout(load, 700)
    }
    window.addEventListener('athena:document_changed', onChanged)
    // СВОИ действия сервер уведомлениями не рассылает
    // (актору уведомление не создаётся), поэтому после подписи, отметки об
    // исполнении или резолюции список не обновлялся до следующего открытия.
    // Событие 'athena:changed' посылает сам интерфейс после своего действия.
    window.addEventListener('athena:changed', onChanged)
    return () => {
      clearTimeout(timer)
      window.removeEventListener('athena:document_changed', onChanged)
      window.removeEventListener('athena:changed', onChanged)
    }
  }, [load])

  // Пакетно подтягиваем счётчики адресатов для текущей страницы (без N+1).
  useEffect(() => {
    const ids = (data.items || []).map((d) => d.id)
    if (!ids.length) { setCounts({}); return }
    let cancelled = false
    api.recipientsCounts(ids).then((r) => { if (!cancelled) setCounts(r.counts || {}) }).catch(() => {})
    return () => { cancelled = true }
  }, [data])

  // Избранное (, п. 4).
  //
  // favOverride хранит только РАЗНИЦУ с тем, что пришло с сервера (id → bool).
  // Так звёздочка переключается мгновенно, без перезагрузки списка, и при этом
  // не приходится копировать весь массив документов. Если запрос не прошёл,
  // разница откатывается — иначе звёздочка врала бы о сохранённом состоянии.
  const [favOverride, setFavOverride] = useState({})
  const isFavorite = (doc) =>
    Object.prototype.hasOwnProperty.call(favOverride, doc.id) ? favOverride[doc.id] : !!doc.is_favorite
  const toggleFavorite = (doc) => {
    const next = !isFavorite(doc)
    setFavOverride((m) => ({ ...m, [doc.id]: next }))
    const call = next ? api.addFavorite(doc.id) : api.removeFavorite(doc.id)
    call.catch(() => {
      setFavOverride((m) => ({ ...m, [doc.id]: !next }))
      alert('Не удалось изменить избранное')
    })
  }
  // В разделе «Избранное» снятая звёздочка означает, что документ больше не
  // относится к разделу: перечитываем список, иначе он остался бы в таблице
  // и выглядел бы как не сработавшая кнопка.
  useEffect(() => {
    if (category !== 'favorites') return
    const ids = Object.keys(favOverride).filter((id) => favOverride[id] === false)
    if (!ids.length) return
    const timer = setTimeout(() => {
      setFavOverride({})
      load()
    }, 900)
    return () => clearTimeout(timer)
  }, [favOverride, category, load])

  const resetFilters = () => {
    setF(EMPTY_FILTERS); setDraft(EMPTY_FILTERS); setSearchInput(''); setActiveQuery(''); setPage(1)
    // #3 — Сброс обязан убрать и СОХРАНЁННОЕ состояние, иначе фильтры
    // вернутся при следующем открытии раздела, и кнопка будет выглядеть
    // сломанной. Удаляем только свою категорию, остальные не трогаем.
    api.getPreference(FILTERS_PREF_KEY)
      .then((saved) => {
        const rest = { ...(saved || {}) }
        delete rest[category]
        return api.savePreference(FILTERS_PREF_KEY, rest)
      })
      .catch(() => {})
  }

  const dateInput = (key) => (
    <input
      type="date"
      value={draft[key]}
      onChange={(e) => setFilter({ [key]: e.target.value })}
      className="field"
    />
  )
  const textInput = (key, ph) => (
    <input
      value={draft[key]}
      onChange={(e) => setFilter({ [key]: e.target.value })}
      placeholder={ph}
      className="field w-40"
    />
  )

  return (
    <div className="p-6 max-w-[120rem] mx-auto">
      <div className="flex items-center justify-between mb-4 gap-4">
        <h1 className="font-display text-xl font-semibold">{CATEGORY_TITLES[category] || 'Документы'}</h1>
        <div className="flex items-center gap-2">
          {category === 'archive' && (
            <select
              value={archiveYear}
              onChange={(e) => { setArchiveYear(e.target.value); setPage(1) }}
              className="field"
              title="Год архива"
            >
              <option value="">Все годы</option>
              {docYears().map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          )}
          <input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Поиск по названию и содержанию…"
            className="w-72 px-3 py-1.5 rounded-md border border-border bg-surface-alt text-sm focus:outline-none focus:ring-2 focus:ring-accent"
          />
          <button
            onClick={() => setShowFilters((v) => !v)}
            className={`px-3 py-1.5 rounded-md border text-sm ${hasAnyFilter ? 'border-accent text-accent' : 'border-border text-text-secondary'}`}
          >
            Фильтры{hasAnyFilter ? ' •' : ''}
          </button>
        </div>
      </div>

      {showFilters && (
        <div className="mb-4 surface-1 p-4 grid grid-cols-2 md:grid-cols-4 gap-3 items-start">
          <Field label="Статус">
            <select value={draft.status} onChange={(e) => setFilter({ status: e.target.value })}
              className="field w-full">
              <option value="">Любой</option>
              {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </Field>
          <Field label="Категория">
            <select value={draft.categoryId} onChange={(e) => setFilter({ categoryId: e.target.value })}
              className="field w-full">
              <option value="">Любая</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="Контроль">
            <select value={draft.onControl} onChange={(e) => setFilter({ onControl: e.target.value })}
              className="field w-full">
              <option value="">Любой</option>
              <option value="true">Только на контроле</option>
              <option value="false">Не на контроле</option>
            </select>
          </Field>
          <Field label="Исходящий №">{textInput('number', 'часть номера')}</Field>
          <Field label="Входящий №">{textInput('incomingNumber', 'часть номера')}</Field>
          <Field label="Создан с">{dateInput('createdFrom')}</Field>
          <Field label="Создан по">{dateInput('createdTo')}</Field>
          <Field label="Срок с">{dateInput('dueFrom')}</Field>
          <Field label="Срок по">{dateInput('dueTo')}</Field>
          <Field label="Подписан с">{dateInput('signedFrom')}</Field>
          <Field label="Подписан по">{dateInput('signedTo')}</Field>
          {/* #26 — особая отметка участвует во всех фильтрах наравне с категорией */}
          <Field label="Особая отметка">
            <select
              value={draft.specialMarkId}
              onChange={(e) => setFilter({ specialMarkId: e.target.value })}
              className="field"
            >
              <option value="">Любая</option>
              {specialMarks.map((m) => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </select>
          </Field>

          {/* #28 — люди для фильтра: без ограничения иерархией, включая
              уволенных. Старые пикеры по иерархии здесь неуместны: документ
              мог подписать руководитель другого подразделения. */}
          <div className="col-span-2 md:col-span-4 grid grid-cols-1 md:grid-cols-4 gap-3">
            <Field label="Автор">
              <FilterPersonPicker role="author" value={draft.authorP} onChange={(v) => setFilter({ authorP: v })} />
            </Field>
            <Field label="Подписант">
              <FilterPersonPicker role="signer" value={draft.signerP} onChange={(v) => setFilter({ signerP: v })} />
            </Field>
            <Field label="Контролёр"><PersonPicker group="all" multiple={false} value={draft.controller} onChange={(v) => setFilter({ controller: v })} /></Field>
            <Field label="Любое участие">
              <FilterPersonPicker value={draft.participant} onChange={(v) => setFilter({ participant: v })} placeholder="автор, подписант, согласующий…" />
            </Field>
          </div>

          {/* #4 — поиск по СОДЕРЖИМОМУ файла документа */}
          <div className="col-span-2 md:col-span-4">
            <Field label="Поиск по содержимому документа">
              <input
                value={draft.content}
                onChange={(e) => setFilter({ content: e.target.value })}
                placeholder='слова из текста документа; "точная фраза"; минус исключает: отчёт -черновик'
                className="field"
              />
            </Field>
            {/* Ограничение поиска надо назвать прямо: скан без текстового слоя
                — это картинка, слов в нём для поиска нет, и человек иначе
                решит, что документа в системе нет. */}
            <p className="mt-1 text-[11px] text-text-secondary">
              Ищется только по тексту PDF. Скан без текстового слоя (PDF-изображение) по содержимому не найти — ищите по номеру, заголовку или реквизитам.
            </p>
            {/* Прелоадер: пока индексация не завершена, результат неполный, и
                об этом надо сказать прямо — иначе пользователь решит, что
                документа в системе нет. */}
            {/* «в фильтре убрать отметку
                „проиндексировано документов"». Убрана именно отметка о
                ЗАВЕРШЁННОЙ индексации: она сообщала число, которое человеку
                при поиске ни о чём не говорит, и занимала место под полем
                ввода.

                Предупреждение о НЕЗАВЕРШЁННОЙ индексации оставлено
                намеренно, и это не отступление от замечания: пока индексация
                идёт, поиск по содержимому возвращает НЕПОЛНЫЙ результат, и без
                предупреждения человек решит, что документа в системе нет.
                Исчезает оно само, как только индексация закончена. */}
            {indexStatus && !indexStatus.complete && (
              <div className="mt-1 text-[11px]">
                <span className="text-warning">
                  Идёт индексация содержимого: {indexStatus.percent}% ({indexStatus.indexed} из {indexStatus.total}).
                  Поиск по содержимому пока показывает НЕ ВСЕ документы — осталось {indexStatus.pending}.
                </span>
                <div className="mt-0.5 h-1 bg-surface-alt rounded overflow-hidden">
                  <div
                    className="h-full bg-warning"
                    style={{ width: `${Math.max(2, indexStatus.percent)}%` }}
                  />
                </div>
              </div>
            )}
          </div>
          {/* #29 — фильтры применяются ТОЛЬКО по кнопке, а не на каждый символ. */}
          <div className="col-span-2 md:col-span-4 flex items-center gap-2">
            <button onClick={applyFilters}
              className="btn btn-primary">
              Найти
            </button>
            {hasAnyFilter && (
              <button onClick={resetFilters} className="px-3 py-1.5 text-sm text-danger">Сбросить все фильтры</button>
            )}
          </div>
        </div>
      )}

      {error && (
        <div className="mb-4 text-danger text-sm border border-danger/40 bg-danger/5 rounded-md px-3 py-2">{error}</div>
      )}

      {/* #9 — «показано N из M» видно ВСЕГДА, на любой вкладке. Раньше это
          число показывала только пагинация, да и то лишь когда страниц больше
          одной: на вкладке с 15 записями из 15 было непонятно, это весь
          список или начало. При активных фильтрах поясняем, что M — число
          записей, попавших под фильтр. */}
      <div className="flex items-center justify-between mb-2 gap-4">
        <div className="label">
          Показано {(data.items || []).length} из {data.total_count || 0}
          {hasAnyFilter && ' (по фильтру)'}
        </div>
        <Pagination page={data.page || page} pageSize={data.page_size || PAGE_SIZE} totalCount={data.total_count || 0} onPageChange={setPage} />
      </div>

      <div className="surface-1 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border thead-sticky">
              {/* Избранное (, п. 4): узкая колонка со звёздочкой.
                  Стоит перед особой отметкой, т.к. это не данные документа, а
                  личная пометка пользователя — ей место на самом краю строки. */}
              <th className="px-2 py-2 font-medium w-8" title="Избранное"> </th>
              {/* Особая отметка — ПЕРВОЙ колонкой среди данных: по требованию
                  она должна читаться раньше всего остального в строке. */}
              <th className="px-3 py-2 font-medium">Особая отметка</th>
              <th className="px-3 py-2 font-medium">Готовность</th>
              <th className="px-3 py-2 font-medium">№ исх. / дата подписи</th>
              <th className="px-3 py-2 font-medium">№ вх. (подр., рег.)</th>
              <th className="px-3 py-2 font-medium">Подписант</th>
              <th className="px-3 py-2 font-medium">Описание</th>
              <th className="px-3 py-2 font-medium">Статус</th>
              <th className="px-3 py-2 font-medium">Автор</th>
              <th className="px-3 py-2 font-medium">Согласующие</th>
              <th className="px-3 py-2 font-medium">Рассылка</th>
              {/* #17 — переписка и вложения: видно из списка, без открытия карточки */}
              <th className="px-3 py-2 font-medium" title="Комментарии и вложенные файлы">Обсуждение</th>
              <th className="px-3 py-2 font-medium">Создан</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={14} className="px-4 py-6 text-center text-text-secondary">Загрузка…</td></tr>
            )}
            {!loading && data.items?.length === 0 && (
              <tr><td colSpan={14} className="px-4 py-6 text-center text-text-secondary">
                {hasAnyFilter ? 'Ничего не найдено' : 'В этой категории пока нет документов'}
              </td></tr>
            )}
            {!loading && data.items?.map((doc, rowIdx) => {
              const c = counts[doc.id] || {}
              // #25 — строка подсвечивается цветом КАТЕГОРИИ документа.
              // Фон делаем мягким (color-mix), слева — насыщенная полоса: так
              // категория читается и в светлой, и в тёмной теме, и не зависит
              // только от цвета (есть ещё текстовая колонка «Категория»).
              const catColor = doc.category_color || ''
              const rowStyle = catColor
                ? { background: mix(catColor, 10), boxShadow: `inset 3px 0 0 0 ${catColor}` }
                : undefined
              const dueVal = doc.due_datetime || doc.due_date
              const overdue = dueVal && new Date(dueVal) < new Date() && !['executed', 'archived'].includes(doc.status)
              const apr = c.approvers || []
              const aprDone = apr.filter((x) => x.status === 'approved').length
              return (
              <motion.tr key={doc.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.22, ease: EASE_OUT, delay: rowDelay(rowIdx) }}
                className="border-b border-border last:border-0 cursor-pointer align-top row-hover"
                style={rowStyle}
                title={doc.category_name ? `Категория: ${doc.category_name}` : undefined}
                onClick={() => navigate(`/document/${doc.id}`)}>
                {/* Звёздочка «в избранное». stopPropagation обязателен: без
                    него клик по звёздочке открывал бы документ, т.к. обработчик
                    висит на всей строке. */}
                <td className="px-2 py-2 align-middle">
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleFavorite(doc) }}
                    className={`p-1 rounded hover:bg-surface-alt ${
                      isFavorite(doc) ? 'text-warning' : 'text-text-secondary opacity-40 hover:opacity-100'
                    }`}
                    title={isFavorite(doc) ? 'Убрать из избранного' : 'В избранное'}
                    aria-pressed={isFavorite(doc)}
                  >
                    <Icon name={isFavorite(doc) ? 'star-filled' : 'star'} size={15} />
                  </button>
                </td>
                {/* Особая отметка — первая в строке. Цвет отметки берётся из
                    справочника; если цвет не задан, остаётся только текст. */}
                <td className="px-3 py-2 whitespace-nowrap">
                  {doc.special_mark_name ? (
                    <span
                      className="chip"
                      style={doc.special_mark_color
                        ? { background: mix(doc.special_mark_color, 18),
                            color: doc.special_mark_color }
                        : undefined}
                      title={`Особая отметка: ${doc.special_mark_name}`}
                    >
                      {doc.special_mark_name}
                    </span>
                  ) : <span className="text-text-secondary">—</span>}
                </td>
                {/* Готовность (с временем) */}
                <td className="px-3 py-2 whitespace-nowrap nums">
                  {dueVal ? (
                    <span className={`font-medium ${overdue ? 'text-danger' : 'text-text-primary'}`}>
                      {doc.due_datetime
                        ? fmtDateTime(doc.due_datetime)
                        : fmtDate(doc.due_date)}
                    </span>
                  ) : <span className="text-text-secondary">—</span>}
                </td>
                {/* № исх. / дата подписи */}
                <td className="px-3 py-2 font-mono text-xs text-text-secondary whitespace-nowrap nums">
                  <div>{doc.outgoing_number || `#${doc.id}`}</div>
                  {c.signed_at && (
                    <div className="text-[10px]">{fmtDateTime(c.signed_at)}</div>
                  )}
                </td>
                {/* № вх. — компактно: количество, по клику детали (#2) */}
                <td className="px-3 py-2 font-mono text-xs"
                  onClick={(e) => { e.stopPropagation(); if ((c.incoming_numbers || []).length) setIncomingDoc({ doc, inc: c.incoming_numbers }) }}>
                  {(c.incoming_numbers || []).length
                    ? <span className="text-accent hover:underline cursor-pointer">{(c.incoming_numbers || []).length} вх.</span>
                    : <span className="text-text-secondary">—</span>}
                </td>
                {/* Подписант (с должностью) */}
                <td className="px-3 py-2 text-text-secondary text-xs">{c.signer_name || '—'}</td>
                {/* Описание */}
                <td className="px-3 py-2">
                  <div className="font-medium text-text-primary">{doc.title}</div>
                </td>
                {/* Статус (цветом) */}
                <td className={`px-3 py-2 font-medium ${STATUS_COLORS[doc.status] || 'text-text-secondary'}`}>{STATUS_LABELS[doc.status] || doc.status}</td>
                {/* Автор — #6: без подразделения, одной строкой (как подписант) */}
                <td className="px-3 py-2 text-text-secondary text-xs">{c.author_name || '—'}</td>
                {/* Согласующие (2/1) — по клику детали со статусом и временем */}
                <td className="px-3 py-2"
                  onClick={(e) => { e.stopPropagation(); if (apr.length) setApproversDoc({ doc, apr }) }}>
                  {apr.length ? (
                    <span className="text-accent hover:underline cursor-pointer">
                      {apr.length} / <span className="text-success font-medium">{aprDone}</span>
                    </span>
                  ) : <span className="text-text-secondary">—</span>}
                </td>
                {/* Рассылка (2/1) */}
                <td className="px-3 py-2"
                  onClick={(e) => { e.stopPropagation(); if (c.total) setModalDoc(doc) }}>
                  {c.total !== undefined ? (
                    <span className={`inline-flex items-center gap-1 ${c.total ? 'text-accent hover:underline cursor-pointer' : 'text-text-secondary'}`}>
                      {c.total}{' / '}<span className="text-success font-medium">{c.done}</span>
                    </span>
                  ) : <span className="text-text-secondary">—</span>}
                </td>
                {/* #17 — комментарии / вложения. Числа приходят вместе со
                    строкой списка (один LATERAL в запросе), отдельных запросов
                    на документ нет. Нули не рисуем — только то, что есть. */}
                <td className="px-3 py-2 text-xs whitespace-nowrap nums">
                  {(doc.message_count > 0 || doc.file_count > 0) ? (
                    <span className="inline-flex items-center gap-2 text-text-secondary">
                      {doc.message_count > 0 && (
                        <span className="inline-flex items-center gap-0.5" title={`Комментариев: ${doc.message_count}`}>
                          <Icon name="dot" size={8} /> {doc.message_count}
                        </span>
                      )}
                      {doc.file_count > 0 && (
                        <span className="inline-flex items-center gap-0.5" title={`Вложенных файлов: ${doc.file_count}`}>
                          <Icon name="paperclip" size={12} /> {doc.file_count}
                        </span>
                      )}
                    </span>
                  ) : <span className="text-text-secondary">—</span>}
                </td>
                {/* Дата создания */}
                <td className="px-3 py-2 text-text-secondary text-xs whitespace-nowrap nums">{fmtDateTime(doc.created_at)}</td>
              </motion.tr>
            )})}
          </tbody>
        </table>
      </div>

      {modalDoc && <RecipientsModal doc={modalDoc} onClose={() => setModalDoc(null)} />}
      {approversDoc && <ApproversModal data={approversDoc} onClose={() => setApproversDoc(null)} />}
      {incomingDoc && <IncomingModal data={incomingDoc} onClose={() => setIncomingDoc(null)} />}
    </div>
  )
}

// Модалка с детальной информацией об адресатах документа и отметке исполнения.
function RecipientsModal({ doc, onClose }) {
  const [items, setItems] = useState(null)
  const [error, setError] = useState('')
  useEffect(() => {
    let cancelled = false
    api.getRecipients(doc.id)
      .then((r) => { if (!cancelled) setItems((r.items || []).filter((x) => !x.is_planned)) })
      .catch((e) => { if (!cancelled) setError(e.message) })
    return () => { cancelled = true }
  }, [doc.id])
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="surface-1 p-5 w-full max-w-2xl max-h-[85vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-lg font-semibold">Адресаты — {doc.title}</h2>
          <button onClick={onClose} className="text-text-secondary text-xl leading-none">×</button>
        </div>
        {error && <div className="text-danger text-sm mb-2">{error}</div>}
        {!items && !error && <div className="text-text-secondary text-sm">Загрузка…</div>}
        {items && items.length === 0 && <div className="text-text-secondary text-sm">Документ ещё не направлен адресатам</div>}
        {items && items.length > 0 && (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-text-secondary border-b border-border thead-sticky">
                <th className="py-2 pr-3 font-medium">Получатель</th>
                <th className="py-2 pr-3 font-medium">Подразделение</th>
                <th className="py-2 pr-3 font-medium">Исполнение</th>
                <th className="py-2 font-medium">Отметка</th>
              </tr>
            </thead>
            <tbody>
              {items.map((r) => (
                <tr key={r.user_id} className="border-b border-border last:border-0">
                  <td className="py-2 pr-3">{r.full_name}</td>
                  <td className="py-2 pr-3 text-text-secondary">{r.department_name}</td>
                  <td className="py-2 pr-3">
                    {r.completed_at ? (
                      <span className="text-success">исполнено · {fmtDate(r.completed_at)}</span>
                    ) : (
                      <span className="text-warning">в работе</span>
                    )}
                  </td>
                  <td className="py-2 text-text-secondary">{r.completion_note || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {items && items.length > 0 && (
          <div className="mt-3 text-xs text-text-secondary">
            Всего: {items.length} · исполнили:{' '}
            <span className="text-success">{items.filter((x) => x.completed_at).length}</span>
          </div>
        )}
      </div>
    </div>
  )
}

// Модалка согласующих: ФИО с должностью, статус (цветом) и время согласования.
const APPROVAL_STATUS_LABELS = {
  approved: 'согласовано',
  rejected: 'отклонено',
  pending: 'на согласовании',
  waiting_deps: 'ожидает',
}
const APPROVAL_STATUS_COLORS = {
  approved: 'text-success',
  rejected: 'text-danger',
  pending: 'text-warning',
  waiting_deps: 'text-text-secondary',
}
function IncomingModal({ data, onClose }) {
  const { doc, inc } = data
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="surface-1 p-5 w-full max-w-2xl max-h-[85vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-lg font-semibold">Входящие номера — {doc.title}</h2>
          <button onClick={onClose} className="text-text-secondary text-xl leading-none">×</button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border thead-sticky">
              <th className="py-2 pr-3 font-medium">Подразделение</th>
              <th className="py-2 pr-3 font-medium">Входящий №</th>
              <th className="py-2 font-medium">Зарегистрирован</th>
            </tr>
          </thead>
          <tbody>
            {(inc || []).map((i, idx) => (
              <tr key={idx} className="border-b border-border last:border-0">
                <td className="py-2 pr-3 text-text-secondary">{i.department || '—'}</td>
                <td className="py-2 pr-3 font-mono">{i.number}</td>
                <td className="py-2 text-text-secondary">{i.registered_at ? fmtDateTime(i.registered_at) : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="mt-3 text-xs text-text-secondary">Всего входящих номеров: {(inc || []).length}</div>
      </div>
    </div>
  )
}

function ApproversModal({ data, onClose }) {
  const { doc, apr } = data
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="surface-1 p-5 w-full max-w-2xl max-h-[85vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-lg font-semibold">Согласующие — {doc.title}</h2>
          <button onClick={onClose} className="text-text-secondary text-xl leading-none">×</button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border thead-sticky">
              <th className="py-2 pr-3 font-medium">Согласующий</th>
              <th className="py-2 pr-3 font-medium">Этап</th>
              <th className="py-2 pr-3 font-medium">Статус</th>
              <th className="py-2 font-medium">Время согласования</th>
            </tr>
          </thead>
          <tbody>
            {apr.map((a, i) => (
              <tr key={i} className="border-b border-border last:border-0">
                <td className="py-2 pr-3">{a.name}</td>
                <td className="py-2 pr-3 text-text-secondary">{a.stage_type === 'cross_dept' ? 'межвед.' : 'иерархия'}</td>
                <td className={`py-2 pr-3 font-medium ${APPROVAL_STATUS_COLORS[a.status] || 'text-text-secondary'}`}>
                  {APPROVAL_STATUS_LABELS[a.status] || a.status}
                </td>
                <td className="py-2 text-text-secondary">
                  {a.decided_at ? fmtDateTime(a.decided_at) : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="mt-3 text-xs text-text-secondary">
          Всего: {apr.length} · согласовали:{' '}
          <span className="text-success">{apr.filter((x) => x.status === 'approved').length}</span>
        </div>
      </div>
    </div>
  )
}
