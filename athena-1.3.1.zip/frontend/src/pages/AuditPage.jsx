import React, { useCallback, useEffect, useState } from 'react'
import { usePreference } from '../lib/usePreference'
import Icon from './../components/Icon'
import { api } from '../api/client'
import { fmtDateTime } from '../utils/format'

// Журнал аудита.
//
// Журнал НЕОТКЛЮЧАЕМЫЙ и ЗАПИСИ В НЁМ НЕИЗМЕНЯЕМЫ — это обеспечено на уровне
// БД (у таблицы audit_log нет политик UPDATE и DELETE, включён FORCE ROW LEVEL
// SECURITY, у прикладной роли отозваны права). Кнопки «отключить» нет и быть
// не должно.
//
// УДАЛЕНИЕ ЗА ПЕРИОД — единственное исключение, и оно
// прямо противоречит тому, что написано выше. Совместить требования полностью
// нельзя, поэтому исключение сделано как можно более узким:
//
//   * удаляется только ДИАПАЗОН ДАТ, целиком; отдельную запись удалить
//     нельзя, изменить — тоже;
//   * удаление выполняет одна функция БД (audit_purge), а не прямой DELETE:
//     отзыв прав у прикладной роли остаётся в силе;
//   * функция ПЕРЕД удалением пишет в журнал запись о том, кто и за какой
//     период чистит и сколько строк затронуто, и эта запись переживает
//     очистку;
//   * удалить «сегодняшнее» нельзя — иначе очистка стёрла бы запись о себе.
//
// Доступ к журналу: администратор или роль «аудитор». Роль аудитора отделена
// от администратора намеренно: смысл журнала в том, чтобы действия
// администратора тоже были кому-то видны. Удаление при этом доступно ТОЛЬКО
// администратору.

const OUTCOME = {
  ok: { label: 'выполнено', cls: 'text-success' },
  denied: { label: 'отказано', cls: 'text-danger' },
  error: { label: 'ошибка', cls: 'text-warning' },
}

// Подписи событий. Неизвестное событие показывается как есть: новая версия
// системы может писать события, о которых этот экран ещё не знает, и прятать
// их было бы прямым нарушением смысла журнала.
const EVENT_LABELS = {
  'auth.login': 'Вход в систему',
  'auth.logout': 'Выход',
  'auth.login_failed': 'Неудачная попытка входа',
  'auth.login_denied_session': 'Вход отклонён: уже есть сеанс',
  'auth.session_revoked_access': 'Обращение по завершённому сеансу',
  'session.revoke': 'Завершение сеанса',
  'document.create': 'Создание документа',
  'document.read': 'Просмотр документа',
  'document.update': 'Изменение документа',
  'document.delete': 'Удаление документа',
  'resolution.create': 'Наложение резолюции',
  'resolution.update': 'Изменение резолюции',
  'resolution.delete': 'Отмена резолюции',
  'audit.export': 'Выгрузка журнала аудита',
  // п. 13 — событие о проведённой очистке. Их ДВА, и это не дубль:
  //   audit.purge  — пишет сама функция БД, ПЕРЕД удалением; эта запись и
  //                  остаётся в журнале после очистки;
  //   audit.delete — пишет общий механизм журналирования запросов
  //                  (middleware.Audit) по методу DELETE на /api/audit.
  // Подписаны обе: иначе одно из двух показывалось бы техническим именем.
  'audit.purge': 'Удаление записей журнала за период',
  'audit.delete': 'Запрос на удаление записей журнала',
  // пп. 21, 22 — отметка об исполнении. Имена событий строятся из ПУТИ
  // запроса (/api/documents/:id/complete), поэтому область здесь «complete»,
  // а не «execution»: подписи обязаны совпадать с тем, что реально
  // записывается, иначе в журнале будут технические имена.
  'complete.create': 'Отметка об исполнении',
  'complete.update': 'Изменение отчёта об исполнении',
  'complete.delete': 'Отмена отметки об исполнении',
  'execution.read': 'Просмотр состояния отметки об исполнении',
  'version.read': 'Просмотр версий документа',
  'report.read': 'Отчёт по документу',
  'file.read': 'Скачивание файла документа',
  'signature.create': 'Подписание документа',
}

function fmt(v) {
  if (!v) return ''
  try {
    return fmtDateTime(v)
  } catch {
    return String(v)
  }
}

const today = () => new Date().toISOString().slice(0, 10)
const daysAgo = (n) => new Date(Date.now() - n * 86400000).toISOString().slice(0, 10)

export default function AuditPage() {
  // Отбор по событию и результату запоминается (настройка учётной записи);
  // период — всегда «последние 7 дней» на сегодня, иначе сохранённые даты
  // устаревали бы.
  const [auditPref, setAuditPref, { loaded: auditPrefLoaded }] = usePreference('filters.audit', { event: '', outcome: 'all' })
  const [filter, setFilter] = useState(() => ({
    from: daysAgo(7),
    to: today(),
    event: auditPref.event || '',
    outcome: auditPref.outcome || 'all',
    q: '',
  }))
  useEffect(() => {
    if (!auditPrefLoaded) return
    setFilter((f) => ({ ...f, event: auditPref.event || '', outcome: auditPref.outcome || 'all' }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auditPrefLoaded])
  useEffect(() => {
    if (!auditPrefLoaded) return
    if (filter.event !== auditPref.event || filter.outcome !== auditPref.outcome) {
      setAuditPref({ event: filter.event, outcome: filter.outcome })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter.event, filter.outcome, auditPrefLoaded])
  const [page, setPage] = useState(1)
  const [data, setData] = useState({ items: [], total_count: 0 })
  const [events, setEvents] = useState([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [expanded, setExpanded] = useState(null)
  // п. 13 — размер журнала и окно удаления за период.
  const [size, setSize] = useState(null)
  const [purge, setPurge] = useState(null)
  const [purgeBusy, setPurgeBusy] = useState(false)
  const [purgeMsg, setPurgeMsg] = useState('')

  const params = useCallback(
    () => ({ ...filter, page, page_size: 100 }),
    [filter, page]
  )

  const load = useCallback(() => {
    setLoading(true)
    setError('')
    api
      .auditList(params())
      .then(setData)
      .catch((e) => setError(e.message || 'Не удалось загрузить журнал'))
      .finally(() => setLoading(false))
  }, [params])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    api.auditEvents().then((r) => setEvents(r.items || [])).catch(() => {})
  }, [])

  // Размер журнала (п. 13). Запрос отдельный и только для администратора: он
  // считает размер таблицы целиком, и тянуть его вместе с каждой страницей
  // журнала было бы лишней работой. У роли «аудитор» он ответит отказом —
  // ошибка гасится, блок размера просто не показывается.
  const loadSize = useCallback(() => {
    api.auditSize().then(setSize).catch(() => setSize(null))
  }, [])
  useEffect(() => { loadSize() }, [loadSize])

  const doPurge = async () => {
    setPurgeBusy(true)
    setError('')
    setPurgeMsg('')
    try {
      const res = await api.auditPurge(purge.from, purge.to)
      setPurgeMsg(res.message || `Удалено записей: ${res.deleted}`)
      setPurge(null)
      loadSize()
      load()
    } catch (e) {
      setError(e.message || 'Не удалось удалить записи журнала')
    } finally {
      setPurgeBusy(false)
    }
  }

  const exportCsv = async () => {
    try {
      await api.download(api.auditExportUrl(filter), `audit_${filter.from}_${filter.to}.csv`)
    } catch (e) {
      setError(e.message || 'Не удалось выгрузить журнал')
    }
  }

  const totalPages = Math.max(1, Math.ceil((data.total_count || 0) / 100))

  return (
    <div className="p-6 max-w-[110rem] mx-auto space-y-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-xl font-semibold">Журнал аудита</h1>
          <p className="kicker mt-0.5">
            Отдельную запись журнала нельзя изменить или удалить — это обеспечено
            средствами базы данных, а не настройкой приложения. Доступна только
            очистка за завершившийся период, и сам факт очистки остаётся в журнале.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button onClick={exportCsv} className="btn btn-secondary">
            <Icon name="arrow-down" size={14} /> Выгрузить CSV
          </button>
        </div>
      </div>

      {/* п. 13 — размер журнала и его очистка. Размер показан рядом с
          кнопкой очистки намеренно: чистят журнал именно из-за места на
          диске, и решение принимают, глядя на число. */}
      {size && (
        <div className="surface-1 p-4 flex flex-wrap items-end justify-between gap-4">
          <div className="text-sm">
            <div className="font-medium">Объём журнала</div>
            <div className="text-text-secondary text-xs mt-1">
              <b className="nums">{size.megabytes != null ? size.megabytes.toFixed(1) : '—'} МБ</b>
              {' · записей: '}<span className="nums">{(size.rows ?? 0).toLocaleString('ru-RU')}</span>
              {size.oldest && size.newest && (
                <> · с <span className="nums">{size.oldest}</span> по <span className="nums">{size.newest}</span></>
              )}
            </div>
            <div className="text-[11px] text-text-secondary mt-1">
              Размер указан вместе с индексами — именно столько журнал занимает на диске.
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={() => {
              setPurgeMsg('')
              // По умолчанию предлагается период от начала журнала до
              // «сегодня минус год»: это самый частый случай — убрать
              // прошлогоднее, оставив текущий год. Границы человек правит.
              setPurge({ from: size.oldest || daysAgo(3650), to: daysAgo(365) })
            }}
          >
            Удалить за период…
          </button>
        </div>
      )}

      {purgeMsg && (
        <div className="surface-1 p-3 text-sm text-success">{purgeMsg}</div>
      )}

      {purge && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setPurge(null)}>
          <div className="surface-1 p-5 w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display text-base font-semibold mb-2">
              Удаление записей журнала за период
            </h3>
            <p className="text-xs text-text-secondary mb-3">
              Будут удалены записи, попадающие в указанный период по дате включительно.
              Действие необратимо. В журнале останется запись о самой очистке — кто её
              выполнил, за какой период и сколько записей удалено.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-text-secondary mb-1">С</label>
                <input type="date" className="field w-full" value={purge.from}
                  onChange={(e) => setPurge({ ...purge, from: e.target.value })} />
              </div>
              <div>
                <label className="block text-xs text-text-secondary mb-1">По (включительно)</label>
                <input type="date" className="field w-full" value={purge.to} max={daysAgo(1)}
                  onChange={(e) => setPurge({ ...purge, to: e.target.value })} />
              </div>
            </div>
            <p className="text-[11px] text-warning mt-2">
              Удалять можно только завершившиеся дни: конец периода должен быть раньше
              сегодняшнего. Иначе очистка удалила бы и запись о самой себе.
            </p>
            {error && <div className="text-danger text-xs mt-2">{error}</div>}
            <div className="flex justify-end gap-2 mt-4">
              <button className="btn btn-secondary" onClick={() => setPurge(null)}>Отмена</button>
              <button
                className="btn btn-danger"
                disabled={purgeBusy || !purge.from || !purge.to || purge.to >= today()}
                onClick={() => {
                  if (confirm(`Удалить записи журнала с ${purge.from} по ${purge.to}? Действие необратимо.`)) {
                    doPurge()
                  }
                }}
              >
                {purgeBusy ? 'Удаление…' : 'Удалить'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="surface-1 p-4 grid grid-cols-1 md:grid-cols-6 gap-3">
        <div>
          <label className="block text-xs text-text-secondary mb-1">С</label>
          <input type="date" className="field w-full" value={filter.from}
            onChange={(e) => { setFilter({ ...filter, from: e.target.value }); setPage(1) }} />
        </div>
        <div>
          <label className="block text-xs text-text-secondary mb-1">По</label>
          <input type="date" className="field w-full" value={filter.to}
            onChange={(e) => { setFilter({ ...filter, to: e.target.value }); setPage(1) }} />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs text-text-secondary mb-1">Событие</label>
          <select className="field w-full" value={filter.event}
            onChange={(e) => { setFilter({ ...filter, event: e.target.value }); setPage(1) }}>
            <option value="">Все события</option>
            {/* Группа по области: «auth» ловит все события входа. */}
            <option value="auth">— все события входа —</option>
            <option value="document">— все действия с документами —</option>
            <option value="resolution">— все действия с резолюциями —</option>
            {events.map((e) => (
              <option key={e.event} value={e.event}>
                {EVENT_LABELS[e.event] || e.event} ({e.count})
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-text-secondary mb-1">Результат</label>
          <select className="field w-full" value={filter.outcome}
            onChange={(e) => { setFilter({ ...filter, outcome: e.target.value }); setPage(1) }}>
            <option value="all">Любой</option>
            <option value="ok">Выполнено</option>
            <option value="denied">Отказано</option>
            <option value="error">Ошибка</option>
          </select>
        </div>
        <div>
          <label className="block text-xs text-text-secondary mb-1">Поиск</label>
          <input className="field w-full" placeholder="логин, путь, IP" value={filter.q}
            onChange={(e) => { setFilter({ ...filter, q: e.target.value }); setPage(1) }} />
        </div>
      </div>

      {error && <div className="text-danger text-sm">{error}</div>}

      <div className="surface-1 overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border thead-sticky">
              <th className="px-3 py-2 font-medium">Время</th>
              <th className="px-3 py-2 font-medium">Пользователь</th>
              <th className="px-3 py-2 font-medium">Событие</th>
              <th className="px-3 py-2 font-medium">Результат</th>
              <th className="px-3 py-2 font-medium">Документ</th>
              <th className="px-3 py-2 font-medium">Запрос</th>
              <th className="px-3 py-2 font-medium">IP</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={7} className="px-4 py-6 text-center text-text-secondary">Загрузка…</td></tr>
            )}
            {!loading && data.items.length === 0 && (
              <tr><td colSpan={7} className="px-4 py-6 text-center text-text-secondary">
                За выбранный период записей нет
              </td></tr>
            )}
            {!loading && data.items.map((r) => {
              const oc = OUTCOME[r.outcome] || OUTCOME.ok
              return (
                <React.Fragment key={r.id}>
                  <tr
                    className="border-b border-border last:border-0 cursor-pointer row-hover"
                    onClick={() => setExpanded(expanded === r.id ? null : r.id)}
                  >
                    <td className="px-3 py-1.5 whitespace-nowrap nums">{fmt(r.occurred_at)}</td>
                    <td className="px-3 py-1.5">
                      {r.actor_name || r.actor_login || <span className="text-text-secondary">—</span>}
                      {r.actor_login && r.actor_name && (
                        <span className="text-text-secondary"> ({r.actor_login})</span>
                      )}
                    </td>
                    <td className="px-3 py-1.5">{EVENT_LABELS[r.event] || r.event}</td>
                    <td className={`px-3 py-1.5 ${oc.cls}`}>{oc.label}</td>
                    <td className="px-3 py-1.5 nums">
                      {r.document_id ? (
                        <a href={`/document/${r.document_id}`} className="text-accent hover:underline"
                          onClick={(e) => e.stopPropagation()}>
                          №{r.document_id}
                        </a>
                      ) : '—'}
                    </td>
                    <td className="px-3 py-1.5 font-mono text-[10px] text-text-secondary">
                      {r.http_method} {r.http_path} {r.http_status ? `→ ${r.http_status}` : ''}
                    </td>
                    <td className="px-3 py-1.5 nums text-text-secondary">{r.ip || '—'}</td>
                  </tr>
                  {expanded === r.id && (
                    <tr className="bg-surface-alt/50">
                      <td colSpan={7} className="px-3 py-2">
                        <div className="text-[11px] space-y-0.5">
                          <div>Идентификатор записи: {r.id}</div>
                          {r.session_id && <div>Сеанс: {r.session_id}</div>}
                          {r.user_agent && <div className="break-all">Клиент: {r.user_agent}</div>}
                          {r.details && Object.keys(r.details).length > 0 && (
                            <pre className="mt-1 whitespace-pre-wrap break-all text-[10px] text-text-secondary">
                              {JSON.stringify(r.details, null, 2)}
                            </pre>
                          )}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              )
            })}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-xs text-text-secondary">
        <span>Всего записей: {data.total_count}</span>
        <div className="flex items-center gap-2">
          <button disabled={page <= 1} onClick={() => setPage(page - 1)}
            className="btn btn-secondary py-1 disabled:opacity-40">Назад</button>
          <span>Стр. {page} из {totalPages}</span>
          <button disabled={page >= totalPages} onClick={() => setPage(page + 1)}
            className="btn btn-secondary py-1 disabled:opacity-40">Вперёд</button>
        </div>
      </div>
    </div>
  )
}
