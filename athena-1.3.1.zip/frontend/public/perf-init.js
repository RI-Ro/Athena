// До первой отрисовки: тема (без мерцания) и облегчённый режим для слабых ПК.
// Тема по умолчанию — «Светлое оформление 1» (light); выбранная пользователем
// хранится в его учётной записи, здесь — её копия для первого кадра.
// Ручное переопределение режима: localStorage athena_perf = 'lite' | 'full'.
(function () {
  try {
    var d = document.documentElement, n = navigator, force = null, theme = null
    try { theme = localStorage.getItem('athena_theme'); force = localStorage.getItem('athena_perf') } catch (e) {}
    d.setAttribute('data-theme', theme || 'light')
    var lite = force ? force === 'lite'
      : (n.hardwareConcurrency && n.hardwareConcurrency <= 4) ||
        (n.deviceMemory && n.deviceMemory <= 4) ||
        (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) ||
        (n.connection && n.connection.saveData)
    if (lite) d.setAttribute('data-perf', 'lite')
  } catch (e) {}
})()
