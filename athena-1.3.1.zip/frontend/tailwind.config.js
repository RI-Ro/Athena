/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  darkMode: ['class'],
  theme: {
    extend: {
      colors: {
        bg: 'var(--color-bg)',
        surface: 'var(--color-surface)',
        'surface-alt': 'var(--color-surface-alt)',
        border: 'var(--color-border)',
        'text-primary': 'var(--color-text-primary)',
        'text-secondary': 'var(--color-text-secondary)',
        accent: 'var(--color-accent)',
        'accent-2': 'var(--color-accent-2)',
        'accent-contrast': 'var(--color-accent-contrast)',
        accent2: 'var(--color-accent2)',
        info: 'var(--color-info)',
        success: 'var(--color-success)',
        warning: 'var(--color-warning)',
        danger: 'var(--color-danger)',
        // Токены для компонентов Bklit UI (графики): см. themes/chart-tokens.css
        foreground: 'var(--color-text-primary)',
        'chart-label': 'var(--chart-label)',
        'chart-tooltip-foreground': 'var(--chart-tooltip-foreground)',
        'chart-tooltip-muted': 'var(--chart-tooltip-muted)',
        'chart-tooltip-background': 'var(--chart-tooltip-background)',
        'urgency-normal': 'var(--color-urgency-normal)',
        'urgency-urgent': 'var(--color-urgency-urgent)',
        'urgency-outofturn': 'var(--color-urgency-outofturn)',
      },
      fontFamily: {
        display: 'var(--font-display)',
        body: 'var(--font-body)',
        mono: 'var(--font-mono)',
      },
    },
  },
  plugins: [],
}
